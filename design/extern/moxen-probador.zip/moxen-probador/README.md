# Probador · Moxen

Una rejilla de plantillas dibujadas como miniaturas vivas: pasar por una la inclina con suavidad y pulsarla la expande con FLIP hasta un marco de escritorio. Los botones de dispositivo estrechan el marco con resorte mientras el contenido se recompone de verdad, un deslizador recolorea la plantilla al instante y las flechas pasan a la siguiente con un cruce.

## Qué trae

- `index.html` — la demostración
- `probador.css`
- `probador.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `probador.css` y `probador.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

A grid of templates drawn as live thumbnails: hovering one tilts it gently and clicking it expands it with FLIP into a desktop frame. The device buttons squeeze the frame with a spring while the content genuinely reflows, an accent slider recolours the template instantly and the arrows move on to the next one with a cross-fade.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
