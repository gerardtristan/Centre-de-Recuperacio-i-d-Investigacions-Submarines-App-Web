/* =====================================================================
   Antefirma · Moxen
   Un armador de firmas de correo: escribes tus datos y la firma sale
   armada, con formato, lista para pegar en el programa de correo.

   · La vista previa y lo que se copia son lo mismo. La firma se arma UNA
     vez como una cadena de HTML con todos los estilos EN LÍNEA (los
     programas de correo no leen hojas de estilo ni clases), se pone en la
     vista previa con innerHTML y se copia leyendo ese mismo innerHTML.
     Por eso lo que pegas en tu correo es exactamente lo que ves.
   · Tres copias: «Copiar con formato» deja en el portapapeles el HTML y el
     texto plano a la vez (el programa de correo elige el que entiende), «Texto
     plano» solo el texto y «Código HTML» el código como texto. Si el navegador
     no tiene la API del portapapeles, se selecciona la firma y se copia con
     el comando clásico; si tampoco, la demo lo dice y deja la firma
     seleccionada para Ctrl+C.
   · Un campo vacío no deja nada suelto: ni la línea, ni el separador (·, |),
     ni la raya de arriba. Las líneas se arman juntando solo las piezas que
     existen. Lo mismo vale para el texto plano.
   · Validación de verdad: el correo necesita su @, su dominio y su
     terminación; el teléfono lleva entre 7 y 15 dígitos y solo los
     caracteres de un teléfono (+, espacios, paréntesis, puntos y guiones);
     el sitio web, un dominio. Un dato mal escrito no entra a la firma, se
     explica junto al campo y no se deja copiar hasta corregirlo.
   · La firma usa Arial: es la tipografía que cualquier programa de correo
     tiene, y una fuente web no viaja en el portapapeles.
   · Teclado: es un formulario normal; las plantillas y los colores son
     grupos de opciones nativos (← →). Movimiento reducido: la firma cambia de
     golpe, sin resaltados que se desvanecen. Sin Date, sin azar y sin red.

   Montaje (se inicia solo sobre [data-antefirma]; index.html es la plantilla):
     const a = Antefirma(document.querySelector('[data-antefirma]'), {
       datos: { nombre, area, empresa, correo, tel, web, dir },   // lo que trae el formulario al abrir
       plantilla: 'clasica',    // 'clasica' | 'barra' | 'compacta'
       color: 'azul',           // 'azul' | 'mandarina' | 'ciruela' | 'tinta'
       alCopiar: ({ modo, html, texto, via }) => {},   // 'formato' | 'plano' | 'codigo'; via: 'api' o 'seleccion'
     });
     a.pon('tel', '+1 202 555 0147');  a.copia('formato');  a.plantilla('barra');  a.color('mandarina');  a.reinicia();
     Antefirma.plano(valores, plantilla);  Antefirma.html(valores, plantilla, color);   // funciones puras, sin pantalla

   Qué se personaliza: los colores de la interfaz, en las variables --af-* de
   antefirma.css; los colores de la firma (acento de la barra y de los textos) y las
   plantillas, en las constantes COLORES y PLANTILLAS de aquí abajo. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';

  /* ── Los colores de la firma ────────────────────────────────────────────
     «barra» es el color de la raya y de la barra lateral; «texto» es el del nombre y los enlaces, un poco más
     oscuro cuando el acento claro no alcanzaría contraste sobre blanco (la mandarina). */
  const COLORES = {
    azul:      { barra: '#3048c8', texto: '#3048c8' },
    mandarina: { barra: '#ff8a3d', texto: '#c4510c' },
    ciruela:   { barra: '#7a3b8f', texto: '#7a3b8f' },
    tinta:     { barra: '#1a1b24', texto: '#1a1b24' },
  };
  const TINTA = '#1a1b24', GRIS = '#555a6b', GRIS_2 = '#6b6f80', GRIS_3 = '#9a9eb0';
  const FUENTE = 'font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.5;color:' + TINTA + ';';

  /* ── Las plantillas ─────────────────────────────────────────────────────
     Cada plantilla dice qué piezas van en cada línea y con qué separador. Una línea sin ninguna pieza
     no existe, y una pieza ausente no deja su separador. */
  const PLANTILLAS = {
    clasica:  { lineas: [['nombre'], ['area', 'empresa'], ['tel', 'correo', 'web'], ['dir']], sep: ' · ' },
    barra:    { lineas: [['nombre'], ['area'], ['empresa'], ['tel'], ['correo'], ['web'], ['dir']], sep: ' · ' },
    compacta: { lineas: [['nombre', 'area', 'empresa'], ['tel', 'correo', 'web'], ['dir']], sep: [' | ', ' · ', ' · '] },
  };
  const EJEMPLO = { nombre: 'Dirección de proyectos', area: 'Diseño y animación', empresa: 'Estudio de ejemplo', correo: 'hola@estudio.dev', tel: '', web: 'estudio.dev', dir: '' };
  const CAMPOS = ['nombre', 'area', 'empresa', 'correo', 'tel', 'web', 'dir'];
  const NOMBRES = { correo: 'el correo', tel: 'el teléfono', web: 'el sitio web' };

  /* ── Limpiar y validar ────────────────────────────────────────────────── */
  const limpia = v => String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
  // el sitio se muestra sin «https://» ni la barra final; el enlace vuelve a ponerlos
  const webTexto = v => limpia(v).replace(/^https?:\/\//i, '').replace(/\/+$/, '');
  const esc = s => String(s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

  const RE_CORREO = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;
  function motivoCorreo(v) {
    const arrobas = v.split('@').length - 1;
    if (arrobas === 0) return 'Falta la @, como en nombre@estudio.dev.';
    if (arrobas > 1) return 'Hay más de una @.';
    const dom = v.split('@')[1];
    if (!v.split('@')[0]) return 'Falta lo que va antes de la @.';
    if (!dom) return 'Falta el dominio después de la @.';
    if (!/\.[A-Za-z]{2,}$/.test(dom)) return 'Falta la terminación del dominio, como .com o .dev.';
    return 'Revisa el correo: hay un carácter que no se puede usar.';
  }
  function validaCorreo(v) {
    if (!v) return null;
    if (RE_CORREO.test(v) && !/\.\./.test(v.split('@')[0]) && !/^\.|\.$/.test(v.split('@')[0])) return null;
    return motivoCorreo(v);
  }
  function validaTel(v) {
    if (!v) return null;
    if (!/^\+?[0-9()\s.-]+$/.test(v)) return 'Usa solo números, espacios, paréntesis, puntos y guiones.';
    const n = v.replace(/\D/g, '').length;
    if (n < 7) return 'Faltan dígitos: un teléfono tiene entre 7 y 15 (llevas ' + n + ').';
    if (n > 15) return 'Sobran dígitos: el máximo es 15 (llevas ' + n + ').';
    return null;
  }
  function validaWeb(v) {
    if (!v) return null;
    return /^([A-Za-z0-9-]+\.)+[A-Za-z]{2,}(\/\S*)?$/.test(v) ? null : 'Escribe un sitio como estudio.dev.';
  }
  const VALIDA = { correo: validaCorreo, tel: validaTel, web: validaWeb };

  // los valores crudos del formulario → { v: valores limpios y válidos, errores: { campo: motivo } }
  function analiza(crudos) {
    const v = {}, errores = {};
    CAMPOS.forEach(c => {
      let t = c === 'web' ? webTexto(crudos[c]) : limpia(crudos[c]);
      const mal = VALIDA[c] && VALIDA[c](t);
      if (mal) { errores[c] = mal; t = ''; }          // lo mal escrito no entra a la firma
      v[c] = t;
    });
    return { v, errores };
  }

  /* ── Armar las líneas ───────────────────────────────────────────────────
     Una línea es { sep, partes: [{ k, t, href? }] }. El texto plano y el HTML salen de estas mismas líneas. */
  // el enlace del sitio ya con la forma que le da el navegador al copiar (anfitrión en minúsculas y «/» al final),
  // para que lo que se ve en la vista previa y lo que llega al portapapeles sean idénticos, letra por letra
  function hrefWeb(w) {
    const i = w.indexOf('/');
    return 'https://' + (i < 0 ? w.toLowerCase() + '/' : w.slice(0, i).toLowerCase() + w.slice(i));
  }
  function pieza(k, v) {
    if (!v[k]) return null;
    if (k === 'tel') return { k, t: v.tel, href: 'tel:' + v.tel.replace(/[^\d+]/g, '') };
    if (k === 'correo') return { k, t: v.correo, href: 'mailto:' + v.correo };
    if (k === 'web') return { k, t: v.web, href: hrefWeb(v.web) };
    return { k, t: v[k] };
  }
  function lineas(v, plantilla) {
    const P = PLANTILLAS[plantilla] || PLANTILLAS.clasica;
    const salida = [];
    P.lineas.forEach((claves, i) => {
      const partes = claves.map(k => pieza(k, v)).filter(Boolean);
      if (partes.length) salida.push({ sep: Array.isArray(P.sep) ? P.sep[i] : P.sep, partes });
    });
    return salida;
  }
  const planoDe = L => L.map(l => l.partes.map(p => p.t).join(l.sep)).join('\n');

  /* ── El HTML de la firma, todo en línea ───────────────────────────────── */
  function estiloPieza(plantilla, k, c) {
    switch (k) {
      case 'nombre':  return 'font-weight:bold;color:' + c.texto + ';' + (plantilla === 'compacta' ? '' : 'font-size:' + (plantilla === 'barra' ? 16 : 17) + 'px;');
      case 'area':    return plantilla === 'compacta' ? 'color:' + TINTA + ';' : 'color:' + GRIS + ';';
      case 'empresa': return plantilla === 'barra' ? 'font-weight:bold;color:' + TINTA + ';' : plantilla === 'compacta' ? 'font-weight:bold;color:' + TINTA + ';' : 'font-weight:bold;color:' + GRIS + ';';
      case 'dir':     return 'font-size:12px;color:' + GRIS_2 + ';';
      default:        return 'color:' + c.texto + ';text-decoration:none;';   // tel, correo, web: enlaces
    }
  }
  function htmlPieza(plantilla, p, c) {
    const e = estiloPieza(plantilla, p.k, c), t = esc(p.t);
    return p.href ? '<a href="' + esc(p.href) + '" style="' + e + '">' + t + '</a>' : '<span style="' + e + '">' + t + '</span>';
  }
  // el estilo del <div> de cada línea: separación, raya de arriba (solo si hay algo encima) y tamaño
  function estiloLinea(plantilla, l, i, c) {
    const tipo = l.partes.some(p => p.k === 'tel' || p.k === 'correo' || p.k === 'web') ? 'contacto' : l.partes[0].k === 'dir' ? 'dir' : 'texto';
    if (plantilla === 'clasica') {
      if (tipo === 'contacto') return i ? 'margin:9px 0 0;padding:9px 0 0;border-top:2px solid ' + c.barra + ';' : 'margin:0;';
      if (tipo === 'dir') return 'margin:' + (i ? 3 : 0) + 'px 0 0;';
      return 'margin:0;';
    }
    if (plantilla === 'barra') return tipo === 'dir' && i ? 'margin:6px 0 0;' : 'margin:0;';
    if (tipo === 'contacto') return 'margin:' + (i ? 3 : 0) + 'px 0 0;font-size:12px;';
    return 'margin:' + (i && tipo === 'dir' ? 2 : 0) + 'px 0 0;';
  }
  function armaHtml(L, plantilla, color) {
    if (!L.length) return '';
    const c = COLORES[color] || COLORES.azul;
    const cuerpo = L.map((l, i) => '<div style="' + estiloLinea(plantilla, l, i, c) + '">' +
      l.partes.map(p => htmlPieza(plantilla, p, c)).join('<span style="color:' + GRIS_3 + ';">' + esc(l.sep) + '</span>') + '</div>').join('');
    if (plantilla === 'barra') {
      return '<table cellpadding="0" cellspacing="0" border="0" role="presentation" style="border-collapse:collapse;"><tbody><tr>' +
        '<td style="' + FUENTE + 'border-left:3px solid ' + c.barra + ';padding:2px 0 2px 12px;">' + cuerpo + '</td></tr></tbody></table>';
    }
    return '<div style="' + FUENTE + '">' + cuerpo + '</div>';
  }

  // las funciones puras: sin pantalla, para usarlas desde otro código o para probarlas
  const plano = (valores, plantilla) => planoDe(lineas(analiza(valores).v, plantilla));
  const html = (valores, plantilla, color) => armaHtml(lineas(analiza(valores).v, plantilla), plantilla, color);

  /* ── El portapapeles ────────────────────────────────────────────────────
     Primero la API moderna (deja HTML y texto a la vez). Si no está o no la dejan usar, el comando clásico:
     con la firma seleccionada (formato) o con un cuadro de texto oculto (solo texto). */
  async function alPortapapeles({ html: h, texto, seleccion }) {
    if (navigator.clipboard && navigator.clipboard.write && window.ClipboardItem) {
      try {
        const partes = { 'text/plain': new Blob([texto], { type: 'text/plain' }) };
        if (h != null) partes['text/html'] = new Blob([h], { type: 'text/html' });
        await navigator.clipboard.write([new ClipboardItem(partes)]);
        return 'api';
      } catch (e) { /* sin permiso o sin foco: se prueba el comando clásico */ }
    }
    try {
      let ok = false;
      if (h != null && seleccion) {
        seleccion.inert = false;
        const r = document.createRange(); r.selectNodeContents(seleccion);
        const s = getSelection(); s.removeAllRanges(); s.addRange(r);
        ok = document.execCommand('copy');
        s.removeAllRanges();
        seleccion.inert = true;
      } else {
        const ta = document.createElement('textarea');
        ta.value = texto; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
        document.body.appendChild(ta); ta.select();
        ok = document.execCommand('copy');
        ta.remove();
      }
      return ok ? 'seleccion' : null;
    } catch (e) { return null; }
  }

  function Antefirma(raiz, opciones) {
    const o = Object.assign({ datos: EJEMPLO, plantilla: 'clasica', color: 'azul', alCopiar: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const entradas = {}; CAMPOS.forEach(c => { entradas[c] = $('[data-in="' + c + '"]'); });
    const campos = {}; CAMPOS.forEach(c => { campos[c] = $('[data-campo="' + c + '"]'); });
    const el = { firma: $('[data-firma]'), caja: $('[data-caja]'), vacio: $('[data-vacio]'), estado: $('[data-estado]'), vivo: $('[data-vivo]'), reinicia: $('[data-reinicia]') };
    const botones = {}; raiz.querySelectorAll('[data-copiar]').forEach(b => { botones[b.dataset.copiar] = b; });
    const textos = { formato: $('[data-t-formato]'), plano: $('[data-t-plano]'), codigo: $('[data-t-codigo]') };
    const ROTULOS = { formato: 'Copiar con formato', plano: 'Texto plano', codigo: 'Código HTML' };
    const MSG0 = 'Pégala en tu correo con Ctrl+V: conserva el formato y los enlaces.';
    const voz = t => { el.vivo.textContent = ''; setTimeout(() => { el.vivo.textContent = t; }, 30); };

    let plantilla = o.plantilla, color = o.color, tocados = {}, previo = null, temporizador = 0;
    const nuevas = {}, RESALTE = 1100;   // líneas recién aparecidas → instante en que aparecieron
    // la vista previa es solo para mirar: inerte, sus enlaces ni se pulsan ni entran en el orden del teclado.
    // Para los lectores de pantalla, la caja lleva el texto de la firma en su etiqueta.
    el.firma.inert = true;

    const crudos = () => { const d = {}; CAMPOS.forEach(c => { d[c] = entradas[c].value; }); return d; };
    const pon = (c, valor) => { entradas[c].value = valor; pinta(); };

    function marcaErrores(errores, todos) {
      CAMPOS.forEach(c => {
        const mal = errores[c] && (todos || tocados[c]);
        campos[c].toggleAttribute('data-invalido', !!mal);
        entradas[c].setAttribute('aria-invalid', mal ? 'true' : 'false');
        campos[c].querySelector('[data-err]').textContent = mal ? errores[c] : '';
      });
    }
    const mensaje = (t, tipo) => { el.estado.textContent = t; if (tipo) el.estado.dataset.tipo = tipo; else delete el.estado.dataset.tipo; };

    /* pinta: arma la firma con lo que hay en el formulario y la pone en la vista previa.
       Lo que cambió se anuncia con un resaltado que se desvanece: una línea nueva, una plantilla distinta. */
    function pinta() {
      const { v, errores } = analiza(crudos());
      const L = lineas(v, plantilla);
      const marcado = armaHtml(L, plantilla, color);
      const claves = L.map(l => l.partes.map(p => p.k).join('+'));
      el.firma.inert = true;
      el.firma.innerHTML = marcado;
      el.vacio.hidden = !!L.length;
      el.caja.setAttribute('role', 'group');
      el.caja.setAttribute('aria-label', L.length ? 'Vista previa de la firma: ' + planoDe(L).replace(/\n/g, '. ') : 'Vista previa de la firma, vacía');
      marcaErrores(errores, false);

      const nErr = Object.keys(errores).length;
      const lista = Object.keys(errores).map(c => NOMBRES[c]);
      const bloqueada = nErr > 0 || !L.length;
      Object.keys(botones).forEach(m => botones[m].setAttribute('aria-disabled', bloqueada ? 'true' : 'false'));
      if (nErr) mensaje('Corrige ' + lista.join(' y ') + ' para copiar la firma.', 'aviso');
      else if (!L.length) mensaje('Escribe al menos un dato para armar la firma.', 'aviso');
      else if (el.estado.dataset.tipo !== 'ok') mensaje(MSG0);

      // los resaltados, solo si ya había una firma pintada (no al abrir) y no hay movimiento reducido
      if (previo && !quieto()) {
        if (previo.plantilla !== plantilla) {
          el.firma.animate([{ opacity: 0, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: 560, easing: CURVA });
        } else if (previo.color !== color) {
          el.firma.animate([{ opacity: .45 }, { opacity: 1 }], { duration: 420, easing: CURVA });
        } else {
          // una línea nueva se resalta 1,1 s. Como cada tecla vuelve a armar la firma, el resaltado se retoma
          // por donde iba (retraso negativo) en vez de empezar de cero en cada letra.
          const ahora = performance.now();
          const hojas = [...el.firma.querySelectorAll('div')].filter(d => !d.querySelector('div'));
          claves.forEach(k => { if (previo.claves.indexOf(k) === -1) nuevas[k] = ahora; });
          claves.forEach((k, i) => {
            const t0 = nuevas[k];
            if (t0 === undefined) return;
            if (ahora - t0 >= RESALTE) { delete nuevas[k]; return; }
            if (hojas[i]) hojas[i].animate(
              [{ backgroundColor: 'rgba(255,138,61,.5)', opacity: 0, transform: 'translateY(6px)' }, { backgroundColor: 'rgba(255,138,61,0)', opacity: 1, transform: 'none' }],
              { duration: RESALTE, delay: -(ahora - t0), easing: CURVA, fill: 'backwards' });
          });
        }
      }
      previo = { plantilla, color, claves };
      return { v, errores, L };
    }

    /* copia: toma lo que se VE (el innerHTML de la vista previa) y lo deja en el portapapeles. */
    async function copia(modo) {
      const { errores, L } = pinta();
      if (Object.keys(errores).length) {
        marcaErrores(errores, true);
        const primero = CAMPOS.find(c => errores[c]);
        if (primero) entradas[primero].focus();
        voz('Corrige los datos marcados para copiar la firma.');
        return false;
      }
      if (!L.length) { entradas.nombre.focus(); return false; }
      const h = el.firma.innerHTML, t = planoDe(L);
      const via = await alPortapapeles(modo === 'formato' ? { html: h, texto: t, seleccion: el.firma } : modo === 'plano' ? { texto: t } : { texto: h });
      if (!via) {
        // ni la API ni el comando clásico: se deja la firma seleccionada (y ya no inerte) para que la persona copie con el teclado
        el.firma.inert = false;
        const r = document.createRange(); r.selectNodeContents(el.firma); getSelection().removeAllRanges(); getSelection().addRange(r);
        mensaje('Tu navegador no dejó copiar solo. La firma quedó seleccionada: cópiala con Ctrl+C.', 'aviso');
        voz('No se pudo copiar automáticamente. La firma quedó seleccionada.');
        return false;
      }
      const MSG = { formato: 'Copiada con formato. Pégala en tu correo con Ctrl+V.', plano: 'Copiada como texto plano, sin formato.', codigo: 'Código HTML copiado.' };
      mensaje(MSG[modo], 'ok'); voz(MSG[modo]);
      Object.keys(botones).forEach(m => { botones[m].classList.remove('es-copiado'); textos[m].textContent = ROTULOS[m]; });
      botones[modo].classList.add('es-copiado'); textos[modo].textContent = modo === 'formato' ? 'Copiada' : 'Copiado';
      el.caja.classList.remove('es-copiada'); void el.caja.offsetWidth; el.caja.classList.add('es-copiada');
      clearTimeout(temporizador);
      temporizador = setTimeout(() => {
        botones[modo].classList.remove('es-copiado'); textos[modo].textContent = ROTULOS[modo];
        el.caja.classList.remove('es-copiada'); mensaje(MSG0);
      }, 2400);
      if (o.alCopiar) o.alCopiar({ modo, html: h, texto: t, via });
      return true;
    }

    function reinicia() {
      CAMPOS.forEach(c => { entradas[c].value = o.datos[c] || ''; });
      tocados = {};
      plantilla = o.plantilla; color = o.color;
      raiz.querySelector('input[name="plantilla"][value="' + plantilla + '"]').checked = true;
      raiz.querySelector('input[name="color"][value="' + color + '"]').checked = true;
      clearTimeout(temporizador);
      Object.keys(botones).forEach(m => { botones[m].classList.remove('es-copiado'); textos[m].textContent = ROTULOS[m]; });
      el.caja.classList.remove('es-copiada');
      mensaje(MSG0);
      pinta();
    }

    CAMPOS.forEach(c => {
      entradas[c].addEventListener('input', pinta);
      entradas[c].addEventListener('blur', () => { tocados[c] = true; pinta(); });
    });
    raiz.querySelectorAll('input[name="plantilla"]').forEach(i => i.addEventListener('change', () => { plantilla = i.value; pinta(); }));
    raiz.querySelectorAll('input[name="color"]').forEach(i => i.addEventListener('change', () => { color = i.value; pinta(); }));
    Object.keys(botones).forEach(m => botones[m].addEventListener('click', () => {
      if (botones[m].getAttribute('aria-disabled') === 'true') {
        const { errores } = pinta(); marcaErrores(errores, true);
        const primero = CAMPOS.find(c => errores[c]); if (primero) entradas[primero].focus();
        return;
      }
      copia(m);
    }));
    el.reinicia.addEventListener('click', reinicia);

    reinicia();
    return {
      pon,
      copia,
      reinicia,
      plantilla: p => { if (p) { plantilla = p; raiz.querySelector('input[name="plantilla"][value="' + p + '"]').checked = true; pinta(); } return plantilla; },
      color: c => { if (c) { color = c; raiz.querySelector('input[name="color"][value="' + c + '"]').checked = true; pinta(); } return color; },
      datos: () => crudos(),
      html: () => el.firma.innerHTML,
      plano: () => planoDe(lineas(analiza(crudos()).v, plantilla)),
    };
  }

  Antefirma.plano = plano;
  Antefirma.html = html;
  Antefirma.valida = analiza;
  Antefirma.COLORES = COLORES;
  window.Antefirma = Antefirma;

  const raiz = document.querySelector('[data-antefirma]');
  if (raiz) Antefirma.actual = Antefirma(raiz);
})();
