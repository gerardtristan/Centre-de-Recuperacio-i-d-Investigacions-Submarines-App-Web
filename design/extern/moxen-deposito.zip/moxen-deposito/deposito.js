/* =====================================================================
   Depósito · Moxen
   Recibir un pago por transferencia sin perseguir a nadie. Quien paga ve los datos del negocio para copiar de un toque, sube el
   comprobante, y el negocio lo confirma o lo rechaza desde su propio panel; el avance se ve en los dos lados. Aquí no hay importes:
   son datos, un archivo y un estado. Los datos bancarios son inventados y genéricos («Banco de ejemplo»). Lo que hace de verdad:

   · Copiar: cada fila copia solo su valor, «Copiar todo» copia todas con su etiqueta («Banco: Banco de ejemplo»), y lo copiado se lee
     del propio texto que se ve en pantalla, así que siempre es idéntico (el número de cuenta se agrupa con espacios de CSS, no de
     texto, para que se pueda pegar tal cual). Usa el portapapeles y, si el navegador no deja, un respaldo con execCommand.
   · El comprobante se valida de verdad: se mira la firma de los primeros bytes (PNG, JPG, WebP o PDF), no el nombre ni lo que diga el
     navegador, y se rechaza lo que pese más de 3 MB o esté vacío, con su motivo («Pesa 4,2 MB: el máximo es 3 MB.»). Se puede elegir,
     soltar sobre la zona o pegar; las imágenes tienen vista previa. «Usar un ejemplo» dibuja un comprobante en un canvas y lo pasa
     por la misma validación.
   · El pago es una máquina de estados (TRANSICIONES): datos → listo → revisión → confirmado o rechazado, y desde «rechazado» solo se
     puede subir otro comprobante. El panel del negocio solo deja actuar sobre lo que está por revisar: «Confirmar», o «Rechazar» con
     un motivo, que quien paga lee en su pantalla. Nada se manda a ningún lado: es una demostración en la página.

   Montaje (se inicia solo sobre [data-deposito]; el HTML de la demo es la plantilla):
     const d = Deposito(document.querySelector('[data-deposito]'), { referencia: 'PD-0482', datos: DATOS, maximo: 3 * 1024 * 1024 });
     d.estado();    // → { paso, archivo, error, filas: [{ id, estado, motivo, propia }], cuentas }
     d.recibe(file);  d.ejemplo();  d.envia();  d.decide('PD-0482', 'confirmado');  d.reinicia();
   Teclado: Tab recorre todo; C copia todos los datos y R reinicia (fuera de los campos); los botones se activan con Intro o Espacio.
   Qué cambia qué: DATOS (arriba de este archivo) son los datos que se copian; MOTIVOS, los que ofrece el negocio al rechazar; los
   colores, las variables --dp-* de deposito.css (--dp-azul y --dp-ambar). El tiempo sale de transiciones y animaciones CSS y de
   setTimeout (sin Date: la hora de la bandeja es un texto de ejemplo). Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  // Datos de ejemplo, inventados y genéricos: cámbialos por los de tu negocio. «grupos» parte un número en bloques solo a la vista.
  const DATOS = [
    { id: 'banco',   etiqueta: 'Banco',                  valor: 'Banco de ejemplo' },
    { id: 'titular', etiqueta: 'Titular',                valor: 'Estudio de ejemplo' },
    { id: 'tipo',    etiqueta: 'Tipo de cuenta',         valor: 'Cuenta corriente' },
    { id: 'cuenta',  etiqueta: 'N.º de cuenta',          valor: '000012345678', grupos: 4 },
    { id: 'correo',  etiqueta: 'Correo de aviso', valor: 'pagos@estudio.dev' },
    { id: 'ref',     etiqueta: 'Referencia',             valor: 'PD-0482', clase: 'dp-dato--ref' }
  ];
  const MOTIVOS = ['No se lee', 'No coincide la referencia', 'Falta una parte'];
  const MAX_BYTES = 3 * 1024 * 1024;
  // lo que ya había en la bandeja del negocio (de ejemplo)
  const FILAS_BASE = [
    { id: 'PD-0480', estado: 'revision',   hora: 'hoy 09:40',  nombre: 'recibo-0480.pdf', tipo: 'PDF' },
    { id: 'PD-0479', estado: 'confirmado', hora: 'hoy 09:12',  nombre: 'recibo-0479.png', tipo: 'PNG' },
    { id: 'PD-0477', estado: 'rechazado',  hora: 'ayer 18:05', nombre: 'recibo-0477.jpg', tipo: 'JPG', motivo: 'No coincide la referencia' }
  ];
  const HORA_NUEVA = 'hoy 10:42';
  // desde cada estado del pago, a cuáles se puede pasar: nada más
  const TRANSICIONES = { datos: ['listo'], listo: ['datos', 'revision'], revision: ['confirmado', 'rechazado'], rechazado: ['listo', 'datos'], confirmado: [] };
  const ETIQUETA = { revision: 'Por revisar', confirmado: 'Confirmado', rechazado: 'Rechazado' };

  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const bytesA = n => (n < 1024 ? n + ' B' : n < 1048576 ? Math.round(n / 1024) + ' KB' : (n / 1048576).toFixed(1).replace('.', ',').replace(',0', '') + ' MB');

  /* ── qué es de verdad un archivo: la firma de sus primeros bytes ──── */
  async function tipoReal(file) {
    const b = new Uint8Array(await file.slice(0, 12).arrayBuffer());
    const es = (...x) => x.every((v, i) => b[i] === v);
    if (es(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)) return { id: 'png', nombre: 'PNG', imagen: true };
    if (es(0xFF, 0xD8, 0xFF)) return { id: 'jpg', nombre: 'JPG', imagen: true };
    if (es(0x52, 0x49, 0x46, 0x46) && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return { id: 'webp', nombre: 'WebP', imagen: true };
    if (es(0x25, 0x50, 0x44, 0x46, 0x2D)) return { id: 'pdf', nombre: 'PDF', imagen: false };
    return null;
  }
  async function revisa(file, maximo) {
    if (file.size === 0) return { ok: false, motivo: 'El archivo está vacío.' };
    const tipo = await tipoReal(file);
    if (!tipo) return { ok: false, motivo: 'No es un JPG, PNG, WebP ni PDF: sube una imagen del comprobante o su PDF.' };
    if (file.size > maximo) return { ok: false, motivo: (bytesA(file.size) === bytesA(maximo) ? 'Pesa un poco más de ' + bytesA(maximo) : 'Pesa ' + bytesA(file.size)) + ': el máximo es ' + bytesA(maximo) + '.' };
    return { ok: true, tipo };
  }

  function Deposito(raiz, opciones) {
    const o = Object.assign({ datos: DATOS, maximo: MAX_BYTES }, opciones);
    const $ = s => raiz.querySelector(s);
    const $$ = s => Array.from(raiz.querySelectorAll(s));
    const quieto = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    const listaDatos = $('[data-datos]'), btnTodo = $('[data-copia-todo]'), btnTodoT = $('[data-copia-todo-t]'), icoTodo = $('[data-copia-todo-i] use');
    const pasos = $$('[data-paso]');
    const zona = $('[data-zona]'), input = $('[data-input]'), suelta = $('[data-suelta]'), cajaArchivo = $('[data-archivo]');
    const vista = $('[data-vista]'), archN = $('[data-archivo-n]'), archD = $('[data-archivo-d]'), archV = $('[data-archivo-v]');
    const btnQuita = $('[data-quita]'), btnElige = $('[data-elige]'), btnEjemplo = $('[data-ejemplo]');
    const errorP = $('[data-error]'), errorT = $('[data-error-t]');
    const btnEnvia = $('[data-envia]'), estadoP = $('[data-estado]'), estadoT = $('[data-estado-t]'), btnNuevo = $('[data-nuevo]'), pista = $('[data-pista]');
    const cuentas = $$('[data-cuenta]'), filasUl = $('[data-filas]'), anuncio = $('[data-anuncio]');
    const REF = (o.datos.find(d => d.id === 'ref') || {}).valor || 'PD-0000';

    const E = { paso: 'datos', archivo: null, error: '', motivo: '', filas: [], sig: 1, tCopia: {}, tTodo: 0, listo: false };
    const filasDom = new Map();

    /* ── los datos para copiar: las filas salen de DATOS ───────────────── */
    listaDatos.innerHTML = o.datos.map(d => {
      const valor = d.grupos ? d.valor.match(new RegExp('.{1,' + d.grupos + '}', 'g')).map(g => '<span class="dp-g">' + esc(g) + '</span>').join('') : esc(d.valor);
      return '<li class="dp-dato ' + (d.clase || '') + '" data-dato="' + esc(d.id) + '"><span class="dp-dato-e">' + esc(d.etiqueta) + '</span><span class="dp-dato-v">' + valor + '</span>' +
        '<button type="button" class="dp-copia" aria-label="Copiar ' + esc(d.etiqueta.toLowerCase()) + '"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#dp-i-copia"/></svg></button></li>';
    }).join('');
    const textoFila = li => li.querySelector('.dp-dato-v').textContent;                 // lo que se copia es lo que se ve
    const lineaFila = li => li.querySelector('.dp-dato-e').textContent + ': ' + textoFila(li);

    async function copiaTexto(t) {
      try { await navigator.clipboard.writeText(t); return true; } catch (e) { /* sin permiso: el respaldo */ }
      try {
        const ta = document.createElement('textarea');
        ta.value = t; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:0;top:0;opacity:0;pointer-events:none';
        document.body.appendChild(ta); ta.select();
        const ok = document.execCommand('copy');
        ta.remove();
        return ok;
      } catch (e) { return false; }
    }
    function anuncia(t) { anuncio.textContent = ''; setTimeout(() => { anuncio.textContent = t; }, 30); }
    function barrido(li) {                                   // una barra azul que cruza la fila y se va
      li.classList.remove('dp-copiado'); void li.offsetWidth;
      li.classList.add('dp-copiado');
      setTimeout(() => li.classList.remove('dp-copiado'), 1100);
    }
    async function copiaUna(id) {
      const li = listaDatos.querySelector('[data-dato="' + id + '"]'); if (!li) return false;
      const ok = await copiaTexto(textoFila(li));
      if (!ok) { anuncia('Tu navegador no dejó copiar: selecciona el dato y cópialo a mano.'); return false; }
      const b = li.querySelector('.dp-copia');
      b.classList.add('dp-hecho'); b.querySelector('use').setAttribute('href', '#dp-i-tilde');
      barrido(li);
      clearTimeout(E.tCopia[id]);
      E.tCopia[id] = setTimeout(() => { b.classList.remove('dp-hecho'); b.querySelector('use').setAttribute('href', '#dp-i-copia'); }, 1700);
      anuncia('Copiado: ' + li.querySelector('.dp-dato-e').textContent);
      return true;
    }
    async function copiaTodo() {
      const lis = Array.from(listaDatos.children), texto = lis.map(lineaFila).join('\n');
      const ok = await copiaTexto(texto);
      if (!ok) { anuncia('Tu navegador no dejó copiar: selecciona los datos y cópialos a mano.'); return false; }
      btnTodo.classList.add('dp-hecho'); btnTodoT.textContent = 'Copiado'; icoTodo.setAttribute('href', '#dp-i-tilde');
      lis.forEach((li, i) => { if (!quieto()) setTimeout(() => barrido(li), i * 70); });
      clearTimeout(E.tTodo);
      E.tTodo = setTimeout(() => { btnTodo.classList.remove('dp-hecho'); btnTodoT.textContent = 'Copiar todo'; icoTodo.setAttribute('href', '#dp-i-copia'); }, 1900);
      anuncia('Copiados los ' + lis.length + ' datos');
      return true;
    }
    listaDatos.addEventListener('click', ev => { const b = ev.target.closest('.dp-copia'); if (b) copiaUna(b.closest('[data-dato]').dataset.dato); });
    btnTodo.addEventListener('click', copiaTodo);

    /* ── pintar el lado de quien paga ─────────────────────────────────── */
    function pintaPasos() {
      const mapa = { datos: ['activo', '', '', ''], listo: ['hecho', 'activo', '', ''], revision: ['hecho', 'hecho', 'activo', ''], confirmado: ['hecho', 'hecho', 'hecho', 'hecho'], rechazado: ['hecho', 'hecho', 'mal', ''] }[E.paso];
      pasos.forEach((li, i) => {
        li.dataset.e = mapa[i];
        if (mapa[i] === 'activo') li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current');
      });
    }
    function pintaZona() {
      const a = E.archivo, bloqueada = E.paso === 'revision' || E.paso === 'confirmado';
      suelta.hidden = !!a; cajaArchivo.hidden = !a;
      if (a) {
        archN.textContent = a.nombre;
        archD.textContent = a.tipo.nombre + ' · ' + bytesA(a.bytes);
        archV.textContent = 'Tipo y tamaño válidos';
        vista.innerHTML = a.url ? '<img src="' + a.url + '" alt="Vista previa del comprobante">' : '<span><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#dp-i-doc"/></svg><small>PDF</small></span>';
        btnQuita.hidden = bloqueada;
      }
      errorP.hidden = !E.error; errorT.textContent = E.error;
    }
    function pintaPie() {
      const p = E.paso;
      btnEnvia.hidden = !(p === 'datos' || p === 'listo' || p === 'rechazado');
      btnEnvia.setAttribute('aria-disabled', p === 'listo' ? 'false' : 'true');
      estadoP.hidden = !(p === 'revision' || p === 'confirmado' || (p === 'rechazado'));
      btnNuevo.hidden = p !== 'confirmado';
      if (!estadoP.hidden) {
        estadoP.dataset.e = p;
        estadoT.textContent = p === 'revision' ? 'En revisión: el negocio mira tu comprobante' : p === 'confirmado' ? 'Pago confirmado' : 'Rechazado: ' + E.motivo;
      }
      pista.textContent = {
        datos: 'Pon ' + REF + ' en el mensaje de la transferencia.',
        listo: 'Revisa el comprobante y envíalo al negocio.',
        revision: 'Cuando el negocio responda, lo verás aquí.',
        confirmado: 'Listo: el pedido ' + REF + ' quedó pagado.',
        rechazado: 'Sube otro comprobante y vuelve a enviarlo.'
      }[p];
    }
    function pintaCliente() { pintaPasos(); pintaZona(); pintaPie(); }

    /* ── la bandeja del negocio ───────────────────────────────────────── */
    function miniatura(f) {
      if (f.url) return '<img src="' + f.url + '" alt="">';
      if (f.tipo === 'PDF') return '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#dp-i-doc"/></svg>';
      return '<span class="dp-mini-glifo" aria-hidden="true"><i></i><i></i><i></i><i></i></span>';
    }
    function pintaFilas() {
      const vivos = new Set();
      E.filas.forEach((f, idx) => {
        vivos.add(f.k);
        let li = filasDom.get(f.k);
        if (!li) {
          li = document.createElement('li'); li.className = 'dp-fila'; filasDom.set(f.k, li);
          if (E.listo && f.nueva && !quieto()) li.classList.add('dp-nueva');
          setTimeout(() => li.classList.remove('dp-nueva'), 760);
        }
        const huella = f.estado + '|' + (f.rechazando ? 1 : 0) + '|' + f.motivo;
        if (li.dataset.huella !== huella) {
          li.dataset.huella = huella; li.dataset.e = f.estado;
          li.innerHTML = '<span class="dp-mini">' + miniatura(f) + '</span>' +
            '<div class="dp-fila-t"><p class="dp-fila-n"><b>' + esc(f.id) + '</b><span class="dp-chip" data-e="' + f.estado + '">' + ETIQUETA[f.estado] + '</span></p>' +
            '<span class="dp-fila-d">' + esc(f.hora) + ' · ' + esc(f.nombre) + (f.estado === 'rechazado' && f.motivo ? ' · ' + esc(f.motivo) : '') + '</span></div>' +
            (f.estado === 'revision' && !f.rechazando ? '<div class="dp-acciones"><button type="button" class="dp-acc dp-acc-si" data-confirma aria-label="Confirmar el comprobante ' + esc(f.id) + '">Confirmar</button><button type="button" class="dp-acc" data-rechaza aria-label="Rechazar el comprobante ' + esc(f.id) + '">Rechazar</button></div>' : '') +
            (f.estado === 'revision' && f.rechazando ? '<div class="dp-motivos" role="group" aria-label="Motivo del rechazo"><span>Motivo:</span>' + MOTIVOS.map((m, i) => '<button type="button" class="dp-acc" data-motivo="' + i + '">' + esc(m) + '</button>').join('') + '<button type="button" class="dp-acc dp-acc-no" data-cancela>Cancelar</button></div>' : '');
          li.dataset.k = f.k;
        }
        if (filasUl.children[idx] !== li) filasUl.insertBefore(li, filasUl.children[idx] || null);
      });
      filasDom.forEach((li, k) => { if (!vivos.has(k)) { li.remove(); filasDom.delete(k); } });
      const n = { revision: 0, confirmado: 0, rechazado: 0 };
      E.filas.forEach(f => { n[f.estado]++; });
      cuentas.forEach(c => {
        const v = n[c.dataset.cuenta], b = c.querySelector('b');
        if (b.textContent !== String(v)) { b.textContent = v; if (E.listo && !quieto() && b.animate) b.animate([{ transform: 'scale(1.5)' }, { transform: 'none' }], { duration: 420, easing: 'cubic-bezier(.3, 1.45, .5, 1)' }); }
        c.classList.toggle('dp-hay', v > 0);
      });
    }
    const pinta = () => { pintaCliente(); pintaFilas(); };

    /* ── el pago: una máquina de estados ───────────────────────────────── */
    function ir(a) {
      if (!TRANSICIONES[E.paso].includes(a)) return false;
      E.paso = a;
      pinta();
      return true;
    }
    const base = () => FILAS_BASE.map(f => Object.assign({ k: E.sig++, motivo: '', rechazando: false }, f));

    async function recibe(file) {
      if (!file) return false;
      if (E.paso === 'revision' || E.paso === 'confirmado') { E.error = 'Ya enviaste un comprobante: el negocio lo está revisando.'; pintaZona(); return false; }
      const r = await revisa(file, o.maximo);
      if (!r.ok) { E.error = r.motivo; pintaZona(); anuncia(r.motivo); return false; }
      if (E.archivo && E.archivo.url) URL.revokeObjectURL(E.archivo.url);
      E.archivo = { nombre: file.name, bytes: file.size, tipo: r.tipo, url: r.tipo.imagen ? URL.createObjectURL(file) : '' };
      E.error = '';
      if (E.paso === 'listo') pinta(); else ir('listo');
      anuncia('Comprobante listo: ' + file.name);
      return true;
    }
    function quita() {
      if (E.paso !== 'listo') return false;
      if (E.archivo && E.archivo.url) URL.revokeObjectURL(E.archivo.url);
      E.archivo = null; E.error = '';
      return ir('datos');
    }
    function envia() {
      if (E.paso !== 'listo') return false;
      const intento = E.filas.filter(f => f.propia).length + 1;
      E.filas.unshift({ k: E.sig++, id: REF, estado: 'revision', hora: HORA_NUEVA, nombre: E.archivo.nombre, tipo: E.archivo.tipo.nombre, url: E.archivo.url, propia: true, nueva: true, motivo: '', rechazando: false, intento });
      E.motivo = '';
      ir('revision');
      anuncia('Comprobante enviado: queda por revisar');
      return true;
    }
    // el negocio actúa solo sobre lo que está por revisar
    function decide(id, estado, motivo) {
      const f = E.filas.find(x => x.id === id && x.estado === 'revision'); if (!f || (estado !== 'confirmado' && estado !== 'rechazado')) return false;
      f.estado = estado; f.motivo = estado === 'rechazado' ? (motivo || MOTIVOS[0]) : ''; f.rechazando = false;
      if (f.propia) {
        E.motivo = f.motivo;
        if (estado === 'rechazado') E.archivo = null;           // su vista previa ya no es del cliente: se queda en la bandeja
        ir(estado);
      } else pinta();
      anuncia(id + (estado === 'confirmado' ? ' confirmado' : ' rechazado: ' + f.motivo));
      return true;
    }
    filasUl.addEventListener('click', ev => {
      const li = ev.target.closest('.dp-fila'); if (!li) return;
      const f = E.filas.find(x => x.k === +li.dataset.k); if (!f) return;
      if (ev.target.closest('[data-confirma]')) decide(f.id, 'confirmado');
      else if (ev.target.closest('[data-rechaza]')) { f.rechazando = true; pintaFilas(); const b = li.querySelector('[data-motivo]'); if (b) b.focus(); }
      else if (ev.target.closest('[data-cancela]')) { f.rechazando = false; pintaFilas(); const b = li.querySelector('[data-rechaza]'); if (b) b.focus(); }
      else { const m = ev.target.closest('[data-motivo]'); if (m) decide(f.id, 'rechazado', MOTIVOS[+m.dataset.motivo]); }
    });

    /* ── subir el comprobante: elegir, soltar, pegar o usar un ejemplo ── */
    btnElige.addEventListener('click', () => input.click());
    input.addEventListener('change', () => { const f = input.files && input.files[0]; input.value = ''; recibe(f); });
    btnQuita.addEventListener('click', quita);
    ['dragenter', 'dragover'].forEach(n => zona.addEventListener(n, ev => { ev.preventDefault(); zona.classList.add('dp-sobre'); }));
    ['dragleave', 'drop'].forEach(n => zona.addEventListener(n, ev => { ev.preventDefault(); if (n === 'drop' || !zona.contains(ev.relatedTarget)) zona.classList.remove('dp-sobre'); }));
    zona.addEventListener('drop', ev => { const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0]; recibe(f); });
    ['dragover', 'drop'].forEach(n => window.addEventListener(n, ev => { if (!zona.contains(ev.target)) ev.preventDefault(); }));   // soltar fuera no abre el archivo
    document.addEventListener('paste', ev => { const f = ev.clipboardData && ev.clipboardData.files && ev.clipboardData.files[0]; if (f) { ev.preventDefault(); recibe(f); } });

    // un comprobante de ejemplo, dibujado en un canvas con datos inventados (sin importes) y pasado por la misma validación
    function ejemplo() {
      return new Promise(res => {
        const W = 340, H = 440, k = 2, c = document.createElement('canvas');
        c.width = W * k; c.height = H * k;
        const g = c.getContext('2d'); g.scale(k, k);
        const tinta = '#14182a', azul = '#1f3fa8', gris = '#6b6f86';
        g.fillStyle = '#fbf8f1'; g.fillRect(0, 0, W, H);
        g.fillStyle = azul; g.fillRect(0, 0, W, 78);
        g.fillStyle = '#fff'; g.font = '600 12px "Schibsted Grotesk", system-ui, sans-serif'; g.fillText('COMPROBANTE DE TRANSFERENCIA', 24, 32);
        g.font = '700 22px "Schibsted Grotesk", system-ui, sans-serif'; g.fillText('Banco de ejemplo', 24, 60);
        g.fillStyle = '#e8a33d'; g.beginPath(); g.arc(W - 36, 39, 14, 0, Math.PI * 2); g.fill();
        g.strokeStyle = '#14182a'; g.lineWidth = 2.600; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); g.moveTo(W - 42, 40); g.lineTo(W - 37, 45); g.lineTo(W - 29, 33); g.stroke();
        const filas = [['Estado', 'Realizada'], ['Referencia', REF], ['Fecha', '23 oct 2026 · 10:41'], ['N.º de operación', '00012345'], ['Titular', 'Estudio de ejemplo'], ['Cuenta destino', 'termina en 5678']];
        filas.forEach((f, i) => {
          const y = 116 + i * 40;
          g.fillStyle = gris; g.font = '500 12px "Schibsted Grotesk", system-ui, sans-serif'; g.fillText(f[0], 24, y);
          g.fillStyle = tinta; g.font = '600 15px "Spline Sans Mono", ui-monospace, monospace'; g.fillText(f[1], 24, y + 18);
          g.strokeStyle = 'rgba(20,24,42,.12)'; g.lineWidth = 1; g.beginPath(); g.moveTo(24, y + 28); g.lineTo(W - 24, y + 28); g.stroke();
        });
        g.fillStyle = tinta;                                          // un código de barras de adorno, con semilla fija
        let s = 7, x = 24;
        while (x < W - 24) { s = (s * 1103515245 + 12345) & 0x7fffffff; const w = 1 + (s % 3); if ((s >> 8) % 2) g.fillRect(x, 372, w, 44); x += w + 1; }
        c.toBlob(blob => res(blob ? recibe(new File([blob], 'comprobante-ejemplo.png', { type: 'image/png' })) : false), 'image/png');
      });
    }
    btnEjemplo.addEventListener('click', ejemplo);

    btnEnvia.addEventListener('click', () => {
      if (btnEnvia.getAttribute('aria-disabled') === 'true') {
        btnEnvia.classList.remove('dp-sacude'); void btnEnvia.offsetWidth; btnEnvia.classList.add('dp-sacude');
        setTimeout(() => btnEnvia.classList.remove('dp-sacude'), 460);
        E.error = 'Primero sube tu comprobante: una imagen o un PDF.'; pintaZona();
        return;
      }
      envia();
    });
    btnNuevo.addEventListener('click', () => reinicia());

    function reinicia() {
      E.filas.forEach(f => { if (f.url) URL.revokeObjectURL(f.url); });
      if (E.archivo && E.archivo.url) URL.revokeObjectURL(E.archivo.url);
      E.archivo = null; E.error = ''; E.motivo = ''; E.paso = 'datos'; E.filas = base();
      filasDom.forEach(li => li.remove()); filasDom.clear();
      if (raiz.contains(document.activeElement) && document.activeElement.blur) document.activeElement.blur();
      pinta();
    }
    document.addEventListener('keydown', ev => {
      if (ev.metaKey || ev.ctrlKey || ev.altKey) return;
      const t = ev.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
      const k = ev.key.toLowerCase();
      if (k === 'c') copiaTodo(); else if (k === 'r') reinicia();
    });

    reinicia();
    E.listo = true;

    return {
      estado: () => {
        const n = { revision: 0, confirmado: 0, rechazado: 0 };
        E.filas.forEach(f => { n[f.estado]++; });
        return { paso: E.paso, archivo: E.archivo && { nombre: E.archivo.nombre, bytes: E.archivo.bytes, tipo: E.archivo.tipo.nombre }, error: E.error, motivo: E.motivo,
          filas: E.filas.map(f => ({ id: f.id, estado: f.estado, motivo: f.motivo, propia: !!f.propia })), cuentas: n };
      },
      recibe, ejemplo, envia, decide, quita, copiaTodo, copiaUna, reinicia,
      puede: a => TRANSICIONES[E.paso].includes(a)
    };
  }

  window.Deposito = Deposito;
  const raiz = document.querySelector('[data-deposito]');
  if (raiz) raiz.__deposito = Deposito(raiz);
})();
