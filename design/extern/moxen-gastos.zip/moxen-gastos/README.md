# Gastos · Moxen

Un anillo de segmentos redondeados reparte el gasto del mes y el total rueda como un odómetro en su centro. Al pulsar una categoría su porción se separa y la lista de movimientos se filtra con FLIP; las flechas deslizan de mes y «Añadir gasto» hace crecer la porción con resorte.

## Qué trae

- `index.html` — la demostración
- `gastos.css`
- `gastos.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `gastos.css` y `gastos.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

A ring of rounded segments splits the month's spending and the total rolls like an odometer at its centre. Tapping a category pulls its slice out and the list of transactions filters with FLIP; the arrows slide between months and “Add expense” grows the slice on a spring.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
