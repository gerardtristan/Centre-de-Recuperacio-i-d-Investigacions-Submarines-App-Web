# Reasigna · Moxen

Marcas «Falta hoy» en una columna y sus citas se levantan y vuelan, una tras otra, hacia quien da el mismo servicio y tiene la hora libre; las que no caben quedan marcadas «sin lugar» y se pueden pasar a otro día. El margen de hora (misma hora, ± 30 min o ± 1 h) rehace el reparto al instante, cada propuesta se cambia a mano y todo se confirma de una vez.

## Qué trae

- `index.html` — la demostración
- `reasigna.css`
- `reasigna.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `reasigna.css` y `reasigna.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Mark “Absent today” on a column and its appointments lift off and fly, one after another, to whoever offers the same service and has the time free; the ones that don’t fit are flagged “no slot” and can be moved to another day. The time margin (same time, ± 30 min or ± 1 h) redoes the split instantly, each proposal can be changed by hand and everything is confirmed at once.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
