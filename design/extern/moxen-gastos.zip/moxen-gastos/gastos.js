/* =====================================================================
   Gastos · Moxen
   Un panel de gastos del mes, claro y luminoso. A la izquierda, un anillo
   de segmentos redondeados con espacio entre ellos y el total en el centro,
   que rueda como un odómetro; debajo, una línea que compara con el mes
   anterior («▼ 8 % menos que en septiembre»). A la derecha, las seis
   categorías (ícono, monto, píldora de porcentaje y una barra fina) y los
   movimientos del mes.

   · Pulsa una categoría (o su porción del anillo, o las teclas 1–6): su
     porción se separa del anillo con un resorte, las demás se apagan, el
     centro pasa a mostrar su total y la lista de movimientos se filtra con
     FLIP: las filas que sobran se van y las que quedan vuelan a su sitio.
     Pulsa otra vez (o Esc, o la píldora del filtro) para volver.
   · Las flechas ‹ › (o las teclas ← →) cambian de mes: el gráfico y las
     listas se deslizan hacia un lado, entran por el otro, los segmentos
     se dibujan uno tras otro y las cifras ruedan.
   · «+ Añadir gasto» (o la tecla A) despliega un formulario dentro del
     panel: importe y categoría. Al confirmar, la porción crece con resorte,
     el total rueda, el movimiento entra arriba y aparece «Deshacer».

   Montaje (se inicia solo sobre [data-gastos]; el HTML de esta demo es la plantilla):
     const g = Gastos(document.querySelector('[data-gastos]'), {
       actual: 3,       // el mes que se abre (índice de MESES)
       hoy: 18,         // el día de «hoy» en el último mes
       semilla: 3,      // los movimientos de ejemplo salen siempre igual
       alCambiar: ({ mes, total, categorias }) => {},   // cada vez que algo cambia
     });
     g.agrega(2, 45);   // añade 45 a la categoría 2 (Transporte), como el formulario
   Los datos de ejemplo salen de CATS (nombre, color y conceptos), MESES y
   TOTALES (el gasto de cada categoría en cada mes); los movimientos se
   reparten con azar con semilla. Para usar los tuyos, reemplaza genera()
   por tu lista de { cat, concepto, monto, dia } de cada mes. Qué cambia qué:
   los colores, en --ga-* de gastos.css (el anillo y las píldoras leen
   --ga-c1…c6); el grosor y el hueco del anillo, en ANILLO (más abajo).
   ?tema=oscuro es la misma tarjeta con tinta azul. Sin dependencias; el
   tiempo sale de rAF, timers y animaciones web.
   ===================================================================== */
(function () {
  'use strict';

  /* ── utilidades ───────────────────────────────────────────────────── */
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const NS = 'http://www.w3.org/2000/svg';
  const resorte = (x, k, c) => ({ x, v: 0, meta: x, k, c });
  function avanza(r, h) { r.v += (r.k * (r.meta - r.x) - r.c * r.v) * h; r.x += r.v * h; }
  const reposo = r => Math.abs(r.v) < .0008 && Math.abs(r.meta - r.x) < .0008;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  // un resorte convertido en curva CSS linear(); `ms` es lo que tarda en asentarse
  function muelle(k, c) {
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const out = [];
    for (let i = 0; i <= 40; i++) out.push(pts[Math.round(i / 40 * (pts.length - 1))].toFixed(4));
    out[40] = '1';
    return { ease: 'linear(' + out.join(', ') + ')', ms: Math.round(t * 1000) };
  }
  // azar con semilla: los movimientos salen siempre iguales (la página y el vídeo coinciden)
  function mulberry32(s) {
    return () => {
      s = s + 0x6D2B79F5 | 0;
      let t = Math.imul(s ^ s >>> 15, 1 | s);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const el = (tag, clase, html) => { const e = document.createElement(tag); if (clase) e.className = clase; if (html != null) e.innerHTML = html; return e; };
  const icono = id => `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${document.getElementById('ga-i-' + id).innerHTML}</svg>`;
  const fmt = n => '$' + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');

  /* ── los datos de ejemplo ─────────────────────────────────────────── */
  const CATS = [
    { id: 'hogar', nombre: 'Hogar', nuevo: 'Gasto del hogar', conceptos: ['Alquiler'] },
    { id: 'comida', nombre: 'Comida', nuevo: 'Supermercado', conceptos: ['Supermercado', 'Panadería', 'Verdulería', 'Almuerzo fuera'] },
    { id: 'transporte', nombre: 'Transporte', nuevo: 'Transporte público', conceptos: ['Transporte público', 'Combustible', 'Estacionamiento'] },
    { id: 'ocio', nombre: 'Ocio', nuevo: 'Salida', conceptos: ['Cena en restaurante', 'Entradas de cine', 'Libros', 'Museo'] },
    { id: 'salud', nombre: 'Salud', nuevo: 'Farmacia', conceptos: ['Farmacia', 'Consulta médica'] },
    { id: 'suscripciones', nombre: 'Suscripciones', nuevo: 'Suscripción', conceptos: ['Música en línea', 'Vídeo en línea', 'Almacenamiento'] },
  ];
  const MESES = ['Julio', 'Agosto', 'Septiembre', 'Octubre'];
  const ABREV = ['jul', 'ago', 'sep', 'oct'];
  // lo gastado en cada categoría, mes por mes (en el orden de CATS)
  const TOTALES = [
    [780, 436, 96, 190, 40, 52],     // julio
    [780, 402, 104, 148, 120, 52],   // agosto
    [780, 468, 118, 267, 62, 52],    // septiembre
    [780, 420, 110, 160, 85, 52],    // octubre: 1.607, un 8 % menos que septiembre
  ];
  const PARTES = [1, 4, 3, 3, 2, 3];   // en cuántos movimientos se reparte cada categoría
  let ids = 0;
  // reparte los totales en movimientos con fechas, con azar con semilla
  function genera(mes, semilla, ultimoDia) {
    const azar = mulberry32(semilla * 97 + mes * 13 + 5), movs = [];
    TOTALES[mes].forEach((total, cat) => {
      const n = PARTES[cat], pesos = Array.from({ length: n }, () => .55 + azar());
      const suma = pesos.reduce((a, b) => a + b, 0);
      let resto = total;
      for (let k = 0; k < n; k++) {
        const monto = k === n - 1 ? resto : Math.max(6, Math.round(total * pesos[k] / suma));
        resto -= monto;
        movs.push({ id: ++ids, cat, concepto: CATS[cat].conceptos[k % CATS[cat].conceptos.length], monto, dia: cat === 0 ? 1 : 1 + Math.floor(azar() * (ultimoDia - 1)) });
      }
    });
    return movs.sort((a, b) => b.dia - a.dia || a.cat - b.cat);
  }

  /* =====================================================================
     Las cifras que ruedan
     Cada dígito es una columna recortada con una tira del 0 al 9; para
     cambiarlo solo se mueve la tira (--d). Los del final salen antes (--i).
     ===================================================================== */
  function Cifras(caja) {
    let cols = [], pre = null;
    caja.textContent = '';
    function columna(ch) {
      const c = document.createElement('span'), dig = /\d/.test(ch);
      c.dataset.tipo = dig ? 'd' : 's';
      if (dig) {
        c.className = 'ga-col';
        const t = document.createElement('span');
        t.className = 'ga-tira';
        t.innerHTML = '0<br>1<br>2<br>3<br>4<br>5<br>6<br>7<br>8<br>9';
        c.appendChild(t);
      } else { c.className = 'ga-sep'; c.textContent = ch; }
      c.setAttribute('aria-hidden', 'true');
      return c;
    }
    function pon(texto, anima) {
      caja.setAttribute('role', 'text'); caja.setAttribute('aria-label', texto);
      const m = /^(\D*)([\s\S]*)$/.exec(texto), resto = Array.from(m[2]);
      if (!pre) { pre = document.createElement('span'); pre.className = 'ga-sig'; pre.setAttribute('aria-hidden', 'true'); caja.appendChild(pre); }
      pre.textContent = m[1];
      while (cols.length > resto.length) caja.removeChild(cols.shift());
      while (cols.length < resto.length) {
        const c = columna(resto[resto.length - cols.length - 1]);
        caja.insertBefore(c, pre.nextSibling); cols.unshift(c);
        if (anima && c.dataset.tipo === 'd') c.style.setProperty('--d', 0);
      }
      resto.forEach((ch, i) => {
        if (cols[i].dataset.tipo === (/\d/.test(ch) ? 'd' : 's')) return;
        const c = columna(ch); caja.replaceChild(c, cols[i]); cols[i] = c;
        if (anima && c.dataset.tipo === 'd') c.style.setProperty('--d', 0);
      });
      if (anima) void caja.offsetWidth;
      resto.forEach((ch, i) => {
        const c = cols[i];
        if (c.dataset.tipo === 'd') { c.style.setProperty('--i', resto.length - 1 - i); c.style.setProperty('--d', ch); }
        else if (c.textContent !== ch) c.textContent = ch;
      });
    }
    return { pon };
  }

  /* =====================================================================
     El anillo
     Un camino por categoría, con puntas redondas y un hueco entre ellos.
     Cada uno tiene resortes para dónde empieza, cuánto mide, cuánto se
     separa del centro, su grosor y su opacidad; el bucle se duerme cuando
     todo está quieto.
     ===================================================================== */
  const ANILLO = { radio: 128, grosor: 30, hueco: 13, separa: 15, resalta: 7 };   // px del dibujo de 340
  function Anillo(g, n, alPulsar) {
    const R = ANILLO.radio, SW = ANILLO.grosor, TAU = Math.PI * 2;
    const arcos = Array.from({ length: n }, (_, i) => {
      const p = document.createElementNS(NS, 'path');
      p.setAttribute('class', 'ga-seg ga-c' + (i + 1)); p.dataset.i = i;
      p.addEventListener('click', () => alPulsar(i));
      p.addEventListener('pointerenter', () => { if (hover !== i) { hover = i; aplica(); } });
      p.addEventListener('pointerleave', () => { if (hover === i) { hover = -1; aplica(); } });
      g.appendChild(p);
      return { el: p, ini: resorte(0, 90, 14), lar: resorte(0, 90, 14), sep: resorte(0, 320, 17), gro: resorte(0, 280, 19), op: resorte(1, 170, 24), _d: '' };
    });
    let sel = -1, hover = -1, raf = 0, previo = 0, resto = 0;
    const PASO = 1 / 120;
    const todos = () => arcos.reduce((a, c) => a.concat(c.ini, c.lar, c.sep, c.gro, c.op), []);
    function aplica() {
      arcos.forEach((a, i) => {
        a.sep.meta = i === sel ? ANILLO.separa : i === hover ? 5 : 0;
        a.gro.meta = i === sel ? ANILLO.resalta : i === hover ? 2.5 : 0;
        a.op.meta = sel >= 0 && i !== sel ? .26 : 1;
      });
      despierta();
    }
    function dibuja() {
      arcos.forEach(a => {
        const largo = a.lar.x;
        if (largo < .0015) { if (a._d !== '') { a.el.setAttribute('d', ''); a._d = ''; } return; }
        const t0 = a.ini.x * TAU - Math.PI / 2, t1 = (a.ini.x + largo) * TAU - Math.PI / 2;
        const sw = SW + a.gro.x, gap = ANILLO.hueco / R, cap = (sw / 2) / R;
        const s = t0 + gap / 2 + cap;
        const e = Math.max(s, t1 - gap / 2 - cap);
        const mid = (t0 + t1) / 2, dx = Math.cos(mid) * a.sep.x, dy = Math.sin(mid) * a.sep.x;
        const d = 'M' + (Math.cos(s) * R + dx).toFixed(2) + ' ' + (Math.sin(s) * R + dy).toFixed(2) + 'A' + R + ' ' + R + ' 0 ' + (e - s > Math.PI ? 1 : 0) + ' 1 ' + (Math.cos(e) * R + dx).toFixed(2) + ' ' + (Math.sin(e) * R + dy).toFixed(2);
        if (d !== a._d) { a.el.setAttribute('d', d); a._d = d; }
        a.el.style.strokeWidth = sw.toFixed(2); a.el.style.opacity = lim(a.op.x, 0, 1).toFixed(3);
      });
    }
    function cuadro(ms) {
      raf = 0;
      if (document.hidden) return;
      const dt = previo ? Math.min(.1, (ms - previo) / 1000) : 0;
      previo = ms; resto += dt;
      let k = 0;
      const rs = todos();
      while (resto >= PASO && k < 24) { rs.forEach(r => avanza(r, PASO)); resto -= PASO; k++; }
      if (k === 24) resto = 0;
      dibuja();
      if (!rs.every(reposo)) raf = requestAnimationFrame(cuadro);
    }
    function despierta() { if (reduce) { salta(); return; } if (!raf) { previo = 0; raf = requestAnimationFrame(cuadro); } }
    function salta() { todos().forEach(r => { r.x = r.meta; r.v = 0; }); dibuja(); }
    document.addEventListener('visibilitychange', () => { previo = 0; if (!document.hidden) despierta(); });
    return {
      // los tamaños (fracciones del anillo) de cada categoría; `desde` los hace crecer uno tras otro
      pon(partes, desde) {
        let acu = 0;
        partes.forEach((p, i) => {
          const a = arcos[i];
          a.ini.meta = acu; a.lar.meta = p; acu += p;
          if (desde) { a.ini.x = a.ini.meta; a.ini.v = 0; a.lar.x = 0; a.lar.v = 0; }
        });
        if (!desde) despierta(); else if (reduce) salta();
      },
      selecciona(i) { sel = i; aplica(); },
      hoverea(i) { hover = i; aplica(); },
      pulso(i) { const a = arcos[i]; a.gro.v += 110; a.sep.v += 130; despierta(); },
      salta, despierta, arcos,
    };
  }

  /* =====================================================================
     Los gastos
     ===================================================================== */
  function Gastos(raiz, opciones) {
    const o = Object.assign({ actual: MESES.length - 1, hoy: 18, semilla: 3, alCambiar: null }, opciones);
    const $ = s => raiz.querySelector(s), $$ = s => Array.from(raiz.querySelectorAll(s));

    // los resortes de CSS: la tarjeta, el formulario y las entradas
    const SALTO = muelle(300, 15), ENTRA = muelle(170, 19);
    raiz.style.setProperty('--ga-muelle', SALTO.ease);

    const relojes = new Set();
    const luego = (fn, ms) => { const id = setTimeout(() => { relojes.delete(id); fn(); }, ms); relojes.add(id); return id; };
    const anima = (e, frames, dur, easing, extra) => (reduce ? null : e.animate(frames, Object.assign({ duration: dur, easing: easing || 'ease' }, extra)));
    const vivo = $('[data-vivo]');
    const avisa = s => { vivo.textContent = ''; vivo.textContent = s; };

    /* ── los datos ─────────────────────────────────────────────────── */
    const movs = MESES.map((_, m) => genera(m, o.semilla, m === MESES.length - 1 ? o.hoy - 1 : 28));
    let mes = lim(o.actual, 0, MESES.length - 1), sel = -1, ocupado = false, ultimoAdd = null;
    const del = m => movs[m];
    const porCat = m => CATS.map((_, c) => del(m).filter(x => x.cat === c).reduce((s, x) => s + x.monto, 0));
    const suma = a => a.reduce((s, x) => s + x, 0);
    const diaDe = m => (m === MESES.length - 1 ? o.hoy : 28);
    const nombreMes = m => MESES[m] + ' 2026';

    /* ── el texto que cambia con un deslizamiento ─────────────────── */
    function cambiaTexto(caja, texto, dir, eje) {
      const viejo = caja.querySelector('span:last-child');
      if (viejo && viejo.textContent === texto) return;
      const nuevo = el('span', '', texto);
      caja.appendChild(nuevo);
      if (!viejo) return;
      if (reduce) { viejo.remove(); return; }
      const d = dir || 1, T = eje === 'X' ? 'translateX(' : 'translateY(', k = eje === 'X' ? 40 : 70;
      viejo.animate([{ transform: 'none', opacity: 1 }, { transform: T + -d * k + '%)', opacity: 0 }], { duration: 320, easing: 'cubic-bezier(.22, 1, .36, 1)', fill: 'forwards' });
      nuevo.animate([{ transform: T + d * k + '%)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 520, easing: 'cubic-bezier(.22, 1, .36, 1)' });
      luego(() => viejo.remove(), 380);
    }
    function rueda(caja, texto, dir) {
      const viejo = caja.firstElementChild;
      if (viejo && viejo.textContent === texto) return;
      const nuevo = el('span', '', texto);
      caja.appendChild(nuevo);
      if (!viejo) return;
      if (reduce) { viejo.remove(); return; }
      const d = dir || 1;
      viejo.animate([{ transform: 'none', opacity: 1 }, { transform: 'translateY(' + -d * 100 + '%)', opacity: 0 }], { duration: 340, easing: 'cubic-bezier(.22, 1, .36, 1)', fill: 'forwards' });
      nuevo.animate([{ transform: 'translateY(' + d * 100 + '%)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: SALTO.ms, easing: SALTO.ease });
      luego(() => viejo.remove(), 380);
    }

    /* ── el anillo y el total ──────────────────────────────────────── */
    const mesCaja = $('.ga-mes-et');
    const anillo = Anillo($('[data-segmentos]'), CATS.length, i => selecciona(i));
    const total = Cifras($('[data-total]'));
    const cuerpo = $('[data-cuerpo]');

    /* ── las categorías ────────────────────────────────────────────── */
    const cats = CATS.map((c, i) => {
      const b = el('button', 'ga-cat ga-c' + (i + 1));
      b.type = 'button'; b.dataset.i = i; b.setAttribute('aria-pressed', 'false');
      b.innerHTML = '<span class="ga-tile">' + icono(c.id) + '</span><span class="ga-cat-info"><span class="ga-cat-nom">' + c.nombre + '</span><span class="ga-cat-monto ga-roll"><span></span></span></span><span class="ga-pildora ga-roll"><span></span></span><span class="ga-barra"><i></i></span>';
      b.addEventListener('click', () => selecciona(i));
      b.addEventListener('pointerenter', () => anillo.hoverea(i));
      b.addEventListener('pointerleave', () => anillo.hoverea(-1));
      $('[data-cats]').appendChild(b);
      return { el: b, monto: b.querySelector('.ga-cat-monto'), pildora: b.querySelector('.ga-pildora'), barra: b.querySelector('.ga-barra i') };
    });
    let pasado = [0, 0, 0, 0, 0, 0];
    function pintaCats(anim) {
      const t = porCat(mes), tt = suma(t);
      cats.forEach((c, i) => {
        const dir = t[i] >= pasado[i] ? 1 : -1;
        if (anim) { rueda(c.monto, fmt(t[i]), dir); rueda(c.pildora, (tt ? Math.round(t[i] / tt * 100) : 0) + ' %', dir); }
        else { c.monto.firstElementChild.textContent = fmt(t[i]); c.pildora.firstElementChild.textContent = (tt ? Math.round(t[i] / tt * 100) : 0) + ' %'; }
        c.barra.style.setProperty('--w', (tt ? t[i] / tt : 0).toFixed(4));
        c.el.setAttribute('aria-label', CATS[i].nombre + ': ' + fmt(t[i]) + ', ' + (tt ? Math.round(t[i] / tt * 100) : 0) + ' % del mes');
      });
      pasado = t;
    }

    /* ── el centro del anillo ──────────────────────────────────────── */
    function pintaCentro(anim, dirTexto) {
      const t = porCat(mes), tt = suma(t), n = del(mes).length;
      const cantidad = sel >= 0 ? t[sel] : tt;
      const filas = sel >= 0 ? del(mes).filter(x => x.cat === sel).length : n;
      const et = sel >= 0 ? CATS[sel].nombre : 'Gastado en ' + MESES[mes].toLowerCase();
      const sub = sel >= 0 ? (tt ? Math.round(t[sel] / tt * 100) : 0) + ' % del mes · ' + filas + (filas === 1 ? ' movimiento' : ' movimientos') : n + ' movimientos';
      total.pon(fmt(cantidad), anim);
      cambiaTexto($('[data-c-et]'), et, dirTexto || 1); cambiaTexto($('[data-c-sub]'), sub, dirTexto || 1);
    }
    function pintaCompara(anim) {
      const caja = $('[data-compara]'), tt = suma(porCat(mes));
      let clase = '', html;
      if (mes === 0) { clase = 'is-igual'; html = 'Primer mes del historial'; }
      else {
        const prev = suma(porCat(mes - 1)), pct = prev ? Math.round((tt - prev) / prev * 100) : 0;
        const nombre = MESES[mes - 1].toLowerCase();
        if (pct < 0) html = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M1 3h10L6 10z"/></svg>' + Math.abs(pct) + ' % menos que en ' + nombre;
        else if (pct > 0) { clase = 'is-mas'; html = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M1 9h10L6 2z"/></svg>' + pct + ' % más que en ' + nombre; }
        else { clase = 'is-igual'; html = 'Igual que en ' + nombre; }
      }
      const igual = caja.innerHTML === html && caja.className === 'ga-compara ' + clase;
      caja.className = 'ga-compara ' + clase; caja.innerHTML = html;
      if (anim && !igual) anima(caja, [{ opacity: 0, transform: 'translateY(8px) scale(.94)' }, { opacity: 1, transform: 'none' }], SALTO.ms, SALTO.ease);
    }
    function pintaMes(dir) { cambiaTexto(mesCaja, nombreMes(mes), dir || 1, 'X'); $$('[data-mes]').forEach(b => { b.disabled = (+b.dataset.mes < 0 && mes === 0) || (+b.dataset.mes > 0 && mes === MESES.length - 1); }); }

    /* ── los movimientos, con FLIP ─────────────────────────────────── */
    const lista = $('[data-lista]'), nodos = new Map();
    const diaTxt = m => (m.hoy ? 'Hoy' : m.dia + ' ' + ABREV[mes]);
    function creaLi(m) {
      const li = el('li', 'ga-mov ga-c' + (m.cat + 1));
      li.innerHTML = '<span class="ga-mov-i">' + icono(CATS[m.cat].id) + '</span><span class="ga-mov-t"><span class="ga-mov-n"></span><span class="ga-mov-f"></span></span><span class="ga-mov-m"></span>';
      li.querySelector('.ga-mov-n').textContent = m.concepto;
      li.querySelector('.ga-mov-f').textContent = CATS[m.cat].nombre + ' · ' + diaTxt(m);
      li.querySelector('.ga-mov-m').textContent = fmt(m.monto);
      li._id = m.id; nodos.set(m.id, li);
      return li;
    }
    // una fila que se va: se limpia del todo para poder volver a usarla
    function retira(li) { li.getAnimations().forEach(a => a.cancel()); li.classList.remove('is-fuera'); li.style.top = li.style.height = ''; li.remove(); }
    const visibles = () => del(mes).filter(m => sel < 0 || m.cat === sel);
    function actualizaLista(anim) {
      const deseados = visibles(), quiero = new Set(deseados.map(m => m.id));
      const previos = new Map();
      lista.querySelectorAll('.ga-mov:not(.is-fuera)').forEach(li => previos.set(li, li.getBoundingClientRect()));
      const caja = lista.getBoundingClientRect(), scroll = lista.scrollTop;
      // los que sobran se van de su sitio sin mover a los demás
      previos.forEach((r, li) => {
        if (quiero.has(li._id)) return;
        li.classList.add('is-fuera');
        li.style.top = (r.top - caja.top + scroll) + 'px'; li.style.height = r.height + 'px';
        if (!anim || reduce) { retira(li); return; }
        const a = li.animate([{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateX(-18px) scale(.96)' }], { duration: 260, easing: 'cubic-bezier(.5, 0, .75, 0)', fill: 'forwards' });
        a.onfinish = () => retira(li);
        luego(() => { if (li.classList.contains('is-fuera')) retira(li); }, 300);
      });
      // los que quedan o entran, en su orden
      let cursor = lista.querySelector('.ga-mov:not(.is-fuera)');
      deseados.forEach(m => {
        let li = nodos.get(m.id);
        if (!li) li = creaLi(m);
        if (li.classList.contains('is-fuera')) { li.getAnimations().forEach(a => a.cancel()); li.classList.remove('is-fuera'); li.style.top = li.style.height = ''; }
        if (li === cursor) { cursor = nextVis(cursor); return; }
        lista.insertBefore(li, cursor);
      });
      if (!deseados.length && !lista.querySelector('.ga-vacio')) { const v = el('li', 'ga-vacio', 'Aún no hay movimientos aquí.'); lista.appendChild(v); }
      if (deseados.length) lista.querySelectorAll('.ga-vacio').forEach(v => v.remove());
      if (!anim || reduce) return;
      let k = 0;
      deseados.forEach(m => {
        const li = nodos.get(m.id), a = previos.get(li);
        if (a) {
          const b = li.getBoundingClientRect(), dy = a.top - b.top;
          if (Math.abs(dy) > .5) li.animate([{ transform: 'translateY(' + dy + 'px)' }, { transform: 'none' }], { duration: SALTO.ms, easing: SALTO.ease });
        } else {
          li.animate([{ opacity: 0, transform: 'translateY(-14px) scale(.96)' }, { opacity: 1, transform: 'none' }], { duration: SALTO.ms, easing: SALTO.ease, delay: Math.min(k++, 6) * 40, fill: 'backwards' });
        }
      });
    }
    const nextVis = li => { let n = li && li.nextElementSibling; while (n && n.classList.contains('is-fuera')) n = n.nextElementSibling; return n; };
    function llenaLista() {            // reemplaza la lista entera (cambio de mes)
      lista.textContent = ''; nodos.clear(); lista.scrollTop = 0;
      actualizaLista(false);
    }

    /* ── elegir una categoría ──────────────────────────────────────── */
    const filtro = $('[data-filtro]');
    function selecciona(i) {
      if (ocupado) return;
      sel = i === sel ? -1 : i;
      cuerpo.classList.toggle('is-filtra', sel >= 0);
      cats.forEach((c, k) => c.el.setAttribute('aria-pressed', String(k === sel)));
      anillo.selecciona(sel);
      pintaCentro(true, sel >= 0 ? 1 : -1);
      filtro.hidden = sel < 0;
      if (sel >= 0) { filtro.className = 'ga-filtro ga-c' + (sel + 1); $('[data-filtro-t]').textContent = CATS[sel].nombre; filtro.setAttribute('aria-label', 'Quitar el filtro de ' + CATS[sel].nombre); }
      lista.scrollTop = 0;
      actualizaLista(true);
      avisa(sel >= 0 ? CATS[sel].nombre + ': ' + fmt(porCat(mes)[sel]) + '. Se muestran sus movimientos.' : 'Se muestran todos los movimientos.');
    }
    filtro.addEventListener('click', () => selecciona(sel));

    /* ── cambiar de mes ────────────────────────────────────────────── */
    function aplicaMes(desdeCero) {
      pintaCats(false); pintaMes(0);
      pintaCompara(false);
      const partes = porCat(mes).map(x => x / (suma(porCat(mes)) || 1));
      anillo.pon(partes, desdeCero);
      llenaLista();
    }
    function cambiaMes(d) {
      const nuevo = mes + d;
      if (nuevo < 0 || nuevo >= MESES.length || ocupado) return;
      ocupado = true;
      cierraForm(true); oculta();
      const salida = anima(cuerpo, [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateX(' + -d * 64 + 'px)' }], 240, 'cubic-bezier(.5, 0, .75, 0)', { fill: 'forwards' });
      cambiaTexto(mesCaja, nombreMes(nuevo), d, 'X');
      luego(() => {
        mes = nuevo; sel = -1;
        cuerpo.classList.remove('is-filtra'); filtro.hidden = true;
        cats.forEach(c => c.el.setAttribute('aria-pressed', 'false')); anillo.selecciona(-1);
        $$('[data-mes]').forEach(b => { b.disabled = (+b.dataset.mes < 0 && mes === 0) || (+b.dataset.mes > 0 && mes === MESES.length - 1); });
        pintaCats(true); pintaCompara(true); pintaCentro(true, d);
        const partes = porCat(mes).map(x => x / (suma(porCat(mes)) || 1));
        anillo.pon(partes, true);
        llenaLista();
        if (salida) { salida.cancel(); }
        anima(cuerpo, [{ opacity: 0, transform: 'translateX(' + d * 64 + 'px)' }, { opacity: 1, transform: 'none' }], ENTRA.ms, ENTRA.ease, { fill: 'backwards' });
        // los segmentos se dibujan uno tras otro
        anillo.arcos.forEach((a, i) => { if (reduce) return; const m = a.lar.meta; a.lar.meta = 0; luego(() => { a.lar.meta = m; anillo.despierta(); }, 90 + i * 75); });
        if (reduce) anillo.salta();
        luego(() => { ocupado = false; }, reduce ? 0 : 280);
        avisa(nombreMes(mes) + ': gastado ' + fmt(suma(porCat(mes))) + '. ' + $('[data-compara]').textContent);
        if (o.alCambiar) o.alCambiar({ mes, total: suma(porCat(mes)), categorias: porCat(mes) });
      }, reduce ? 0 : 240);
    }
    $$('[data-mes]').forEach(b => b.addEventListener('click', () => cambiaMes(+b.dataset.mes)));

    /* ── añadir un gasto ───────────────────────────────────────────── */
    const caja = $('[data-form-caja]'), form = $('[data-form]'), importe = $('[data-importe]'), ok = $('[data-ok]'), abre = $('[data-abre]'), sub = $('[data-form-sub]');
    const chipsEl = $('[data-chips]');
    let catForm = 1;
    const chips = CATS.map((c, i) => {
      const b = el('button', 'ga-chip ga-c' + (i + 1), icono(c.id));
      b.type = 'button'; b.setAttribute('role', 'radio'); b.setAttribute('aria-label', c.nombre); b.title = c.nombre; b.tabIndex = i === catForm ? 0 : -1;
      b.addEventListener('click', () => poneCat(i, true));
      b.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); form.requestSubmit(); return; }
        const d = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
        if (!d) return;
        e.preventDefault(); e.stopPropagation(); poneCat((i + d + CATS.length) % CATS.length, true);
      });
      chipsEl.appendChild(b);
      return b;
    });
    function poneCat(i, foco) {
      catForm = i;
      chips.forEach((b, k) => { b.setAttribute('aria-checked', String(k === i)); b.tabIndex = k === i ? 0 : -1; });
      sub.textContent = 'en ' + CATS[i].nombre + ' · Intro para añadir';
      if (foco) chips[i].focus({ preventScroll: true });
    }
    poneCat(catForm);
    function valida() { ok.disabled = !(+importe.value > 0); }
    importe.addEventListener('input', () => { importe.value = importe.value.replace(/\D/g, '').replace(/^0+(?=\d)/, '').slice(0, 5); valida(); });
    function abreForm() {
      if (ocupado) return;
      if (sel >= 0 && caja.classList.contains('is-abierto') === false) poneCat(sel);
      caja.classList.add('is-abierto'); abre.setAttribute('aria-expanded', 'true');
      form.inert = false; importe.value = ''; valida();
      importe.focus({ preventScroll: true });
    }
    function cierraForm(sinFoco) {
      if (!caja.classList.contains('is-abierto')) return;
      caja.classList.remove('is-abierto'); abre.setAttribute('aria-expanded', 'false');
      form.inert = true;
      if (!sinFoco) abre.focus({ preventScroll: true });
    }
    form.inert = true;
    abre.addEventListener('click', () => (caja.classList.contains('is-abierto') ? cierraForm() : abreForm()));
    $('[data-cancela]').addEventListener('click', () => cierraForm());
    form.addEventListener('submit', e => {
      e.preventDefault();
      const monto = +importe.value;
      if (!(monto > 0)) { form.classList.remove('is-error'); void form.offsetWidth; form.classList.add('is-error'); importe.focus(); return; }
      agrega(catForm, monto);
      cierraForm();
    });
    form.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); cierraForm(); } });

    function agrega(cat, monto) {
      if (ocupado) return;
      const m = { id: ++ids, cat, concepto: CATS[cat].nuevo, monto: Math.round(monto), dia: diaDe(mes), hoy: mes === MESES.length - 1, nuevo: true };
      del(mes).unshift(m);
      ultimoAdd = { m, mes };
      if (sel >= 0 && sel !== cat) { sel = -1; cuerpo.classList.remove('is-filtra'); filtro.hidden = true; cats.forEach(c => c.el.setAttribute('aria-pressed', 'false')); anillo.selecciona(-1); }
      refresca(cat, 1);
      const li = nodos.get(m.id); if (li) { li.classList.add('is-nuevo'); luego(() => li.classList.remove('is-nuevo'), 2200); }
      muestra('Gasto añadido · ' + CATS[cat].nombre + ' ' + fmt(m.monto));
      avisa('Gasto añadido: ' + m.concepto + ' ' + fmt(m.monto) + '. Total ' + fmt(suma(porCat(mes))));
    }
    function deshace() {
      if (!ultimoAdd || ultimoAdd.mes !== mes) { oculta(); return; }
      const { m } = ultimoAdd, i = del(mes).indexOf(m);
      if (i < 0) { oculta(); return; }
      del(mes).splice(i, 1); ultimoAdd = null;
      refresca(m.cat, -1);
      oculta();
      avisa('Gasto deshecho. Total ' + fmt(suma(porCat(mes))));
    }
    // todo lo que depende de los datos, con animación
    function refresca(cat, signo) {
      const t = porCat(mes), tt = suma(t);
      anillo.pon(t.map(x => x / (tt || 1)), false);
      anillo.pulso(cat); if (signo < 0) { anillo.arcos[cat].gro.v -= 150; }
      pintaCats(true); pintaCentro(true, signo); pintaCompara(true);
      actualizaLista(true);
      if (o.alCambiar) o.alCambiar({ mes, total: tt, categorias: t });
    }
    $('[data-deshacer]').addEventListener('click', deshace);

    // el aviso con «Deshacer»
    const aviso = $('[data-aviso]');
    let relojAviso = 0;
    function muestra(texto) {
      $('[data-aviso-t]').textContent = texto;
      aviso.hidden = false; raiz.classList.add('is-aviso');
      anima(aviso, [{ opacity: 0, transform: 'translateY(24px) scale(.9)' }, { opacity: 1, transform: 'none' }], SALTO.ms, SALTO.ease);
      clearTimeout(relojAviso); relojes.delete(relojAviso);
      relojAviso = luego(oculta, 5200);
    }
    function oculta() {
      if (aviso.hidden) return;
      clearTimeout(relojAviso);
      const fin = () => { aviso.hidden = true; raiz.classList.remove('is-aviso'); };
      const a = anima(aviso, [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateY(16px) scale(.95)' }], 240, 'ease-in', { fill: 'forwards' });
      if (a) { a.onfinish = () => { a.cancel(); fin(); }; luego(fin, 280); } else fin();
    }

    /* ── teclado ───────────────────────────────────────────────────── */
    document.addEventListener('keydown', e => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const t = e.target, escribe = t.matches && t.matches('input, textarea');
      if (e.key === 'Escape') {
        if (caja.classList.contains('is-abierto')) cierraForm();
        else if (sel >= 0) selecciona(sel);
        else oculta();
        return;
      }
      if (escribe) return;
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { if (t.closest && t.closest('.ga-chips')) return; e.preventDefault(); cambiaMes(e.key === 'ArrowLeft' ? -1 : 1); return; }
      if (/^[1-6]$/.test(e.key)) { e.preventDefault(); selecciona(+e.key - 1); return; }
      if (e.key === 'a' || e.key === 'A') { e.preventDefault(); abreForm(); }
    });

    /* ── al empezar ────────────────────────────────────────────────── */
    ['[data-c-et]', '[data-c-sub]'].forEach(sl => { const c = $(sl); c.innerHTML = '<span></span>'; });
    pintaCats(false); pintaMes(0); pintaCompara(false);
    pintaCentro(false);
    total.pon(fmt(0), false);
    llenaLista();
    const arranca = () => {
      const t = porCat(mes), tt = suma(t);
      anillo.pon(t.map(x => x / tt), true);
      anillo.arcos.forEach((a, i) => { if (reduce) return; const m = a.lar.meta; a.lar.meta = 0; luego(() => { a.lar.meta = m; anillo.despierta(); }, 160 + i * 70); });
      if (reduce) anillo.salta();
      total.pon(fmt(tt), !reduce);
    };
    luego(arranca, reduce ? 0 : 140);
    return { selecciona, cambiaMes, agrega, deshace, abreForm, cierraForm };
  }

  window.Gastos = Gastos;
  const raiz = document.querySelector('[data-gastos]');
  if (raiz) window.gastos = Gastos(raiz);
})();
