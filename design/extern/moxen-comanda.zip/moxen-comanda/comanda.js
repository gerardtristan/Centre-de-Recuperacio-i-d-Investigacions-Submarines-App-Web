/* =====================================================================
   Comanda · Moxen
   La app del mesero dentro de un teléfono dibujado con un contenedor (no un marco). Las pantallas son HTML de verdad con
   navegación: Salón (las mesas con su estado) → Mesa (comensales, pedido por enviar y estado de cada plato) → Carta → la hoja del
   plato (modificadores con reglas), con «Atrás» que conserva lo elegido. No hay precios: es la herramienta de la sala.

   Lo que se calcula de verdad (no hay estados escritos a mano en la pantalla):
   · cada plato de la carta trae sus reglas: grupos de opciones con un mínimo y un máximo («elige 2 acompañamientos», «punto de
     cocción: 1»), ingredientes que se pueden quitar («sin cebolla») y pares que no van juntos (papas fritas y puré). La función
     `valida` es la única que decide si un plato está completo; la hoja la consulta en cada toque: el botón «Agregar al pedido»
     no se enciende hasta que todo vale, dice qué falta y, aunque alguien lo fuerce por la API, un plato incompleto ni entra al
     pedido ni sale a cocina (`envia` vuelve a validar cada línea);
   · la cocina avanza sola: cada plato enviado tiene su tiempo de preparación (`min`) y un reloj simulado (un minuto cada
     `ritmo` milisegundos) lo pasa de «en cocina» a «listo». Cuando está listo suena el aviso y el mesero lo marca «servido»;
   · el estado de una mesa sale de sus platos, nunca se guarda: sin comensales es «libre»; si algún plato está listo, «para
     servir»; si alguno está en cocina, «en cocina»; si todos están servidos, «servida»; y si no hay nada enviado, «sentados».
     Lo que está por enviar (el borrador) no cambia el estado de la mesa hasta que sale a cocina;
   · cada envío es una comanda con su número, y «Liberar mesa» solo se ofrece cuando no queda nada en cocina ni por servir.

   Montaje (se inicia solo sobre [data-comanda]; el HTML es la plantilla y la carta sale de la opción `carta`):
     const c = Comanda(document.querySelector('[data-comanda]'), {
       ahora: '20:12',                   // la hora del turno: el reloj de cocina parte de aquí
       ritmo: 650,                       // milisegundos reales por cada minuto de cocina (la demo corre rápido)
       arranque: 'gesto',                // 'gesto': la cocina empieza al primer toque, tecla o cursor sobre el teléfono; 'ya': al cargar; 'manual': solo con avanza()
       carta: [ { id: 'lomo', cat: 'fondos', nombre: 'Lomo a la plancha', desc: '…', min: 12,
                  grupos: [ { id: 'acomp', titulo: 'Acompañamientos', unidad: ['acompañamiento', 'acompañamientos'],
                              min: 2, max: 2, defecto: 'papas',
                              opciones: [ { id: 'papas', n: 'Papas fritas' }, … ] } ],
                  sin: [ { id: 'cebolla', n: 'cebolla' } ],
                  incompatibles: [ ['papas', 'pure', 'Papas fritas y puré son los dos de papa: elige solo uno.'] ] } ],
       mesas: [ { id: 1, cap: 4, personas: 0, desde: 0, lineas: [], borrador: [] } ],   // si no, el turno de ejemplo de comanda.js
       alEnviar: comanda => {},          // {n, mesa, hora, platos:[{plato, sel}]}: aquí va tu cocina real
     });
     c.valida('lomo', { g: { acomp: ['papas', 'arroz'] }, sin: ['cebolla'] });   // → { ok, errores: [{ tipo, grupo, texto }] }
     c.sienta(4, 3);  c.agrega(4, 'lomo', sel);  c.envia(4);  c.avanza(12);  c.sirve(4, 'L21');  c.cierra(4);  c.estado();  c.reinicia();
     Comanda.valida(plato, sel);        // la misma regla, suelta

   `sel` es { g: { <grupo>: [ids elegidos] }, sin: [ids quitados] }. Teclado: Tab e Intro en todo, ← → entre las categorías y entre
   las opciones de «elige 1», Esc para cerrar la hoja o volver. Todo lo que se mueve es transform u opacity. No usa Date (la hora es
   aritmética sobre minutos) y el azar del riel de la escena tiene semilla, así que la página y el vídeo muestran lo mismo.
   ===================================================================== */
(function () {
  'use strict';

  const dos = v => (v < 10 ? '0' : '') + v;
  const hm = m => dos(Math.floor(m / 60) % 24) + ':' + dos(m % 60);       // las horas son minutos desde la medianoche: 1212 = 20:12
  const aMin = h => { const p = h.split(':').map(Number); return p[0] * 60 + p[1]; };
  const plural = (n, uno, varios) => n + ' ' + (n === 1 ? uno : varios);
  const mayus = t => t.charAt(0).toUpperCase() + t.slice(1);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const copia = x => JSON.parse(JSON.stringify(x));
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  function mulberry32(s) {                                // azar con semilla: la página y el vídeo coinciden
    return () => {
      s = s + 0x6D2B79F5 | 0;
      let t = Math.imul(s ^ s >>> 15, 1 | s);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  /* ── la carta de ejemplo ──────────────────────────────────────────
     Un grupo es «elige entre min y max»; con `defecto` ya viene marcada una opción (el punto de la carne, el tamaño). Lo que
     se puede quitar va en `sin`, y `incompatibles` lista pares de opciones que no se pueden llevar juntas, con su motivo. */
  const CARTA = [
    { id: 'croquetas', cat: 'entradas', nombre: 'Croquetas de queso', desc: 'Seis piezas crujientes con una salsa a tu gusto.', min: 5,
      grupos: [{ id: 'salsa', titulo: 'Salsa', corto: 'la salsa', min: 1, max: 1, opciones: [{ id: 'miel', n: 'Miel y mostaza' }, { id: 'tomate', n: 'Tomate asado' }, { id: 'alioli', n: 'Alioli' }] }],
      sin: [] },
    { id: 'ensalada', cat: 'entradas', nombre: 'Ensalada de la casa', desc: 'Hojas frescas, tomate y semillas tostadas.', min: 4,
      grupos: [{ id: 'aderezo', titulo: 'Aderezo', corto: 'el aderezo', min: 1, max: 1, defecto: 'limon', opciones: [{ id: 'limon', n: 'Limón y aceite' }, { id: 'vinagreta', n: 'Vinagreta' }, { id: 'aparte', n: 'Aparte' }] }],
      sin: [{ id: 'cebolla', n: 'cebolla' }, { id: 'tomate', n: 'tomate' }] },
    { id: 'sopa', cat: 'entradas', nombre: 'Sopa del día', desc: 'Pregunta por la de hoy; viene con pan tostado.', min: 6,
      grupos: [], sin: [{ id: 'cebolla', n: 'cebolla' }, { id: 'pan', n: 'pan' }] },
    { id: 'lomo', cat: 'fondos', nombre: 'Lomo a la plancha', desc: 'Corte magro con dos guarniciones a elección.', min: 12,
      grupos: [
        { id: 'punto', titulo: 'Punto de cocción', corto: 'el punto de cocción', min: 1, max: 1, defecto: 'punto', opciones: [{ id: 'jugoso', n: 'Jugoso' }, { id: 'punto', n: 'A punto' }, { id: 'cocido', n: 'Bien cocido' }] },
        { id: 'acomp', titulo: 'Acompañamientos', unidad: ['acompañamiento', 'acompañamientos'], min: 2, max: 2,
          opciones: [{ id: 'papas', n: 'Papas fritas' }, { id: 'pure', n: 'Puré' }, { id: 'arroz', n: 'Arroz' }, { id: 'ensalada', n: 'Ensalada' }, { id: 'verduras', n: 'Verduras salteadas' }] }],
      sin: [{ id: 'cebolla', n: 'cebolla' }, { id: 'ajo', n: 'ajo' }, { id: 'sal', n: 'sal' }],
      incompatibles: [['papas', 'pure', 'Papas fritas y puré son los dos de papa: elige solo uno.']] },
    { id: 'pasta', cat: 'fondos', nombre: 'Pasta fresca', desc: 'Hecha en la casa, al dente, con la salsa que elijas.', min: 10,
      grupos: [
        { id: 'salsa', titulo: 'Salsa', corto: 'la salsa', min: 1, max: 1, opciones: [{ id: 'bolo', n: 'Boloñesa' }, { id: 'quesos', n: 'Cuatro quesos' }, { id: 'pomodoro', n: 'Pomodoro' }] },
        { id: 'extra', titulo: 'Extra', corto: 'el extra', min: 0, max: 1, opciones: [{ id: 'rallado', n: 'Queso rallado' }] }],
      sin: [{ id: 'cebolla', n: 'cebolla' }, { id: 'ajo', n: 'ajo' }] },
    { id: 'pescado', cat: 'fondos', nombre: 'Pescado del día', desc: 'A la plancha con limón y hierbas.', min: 11,
      grupos: [{ id: 'acomp', titulo: 'Acompañamiento', unidad: ['acompañamiento', 'acompañamientos'], min: 1, max: 1, opciones: [{ id: 'arroz', n: 'Arroz' }, { id: 'papas', n: 'Papas cocidas' }, { id: 'ensalada', n: 'Ensalada' }, { id: 'verduras', n: 'Verduras' }] }],
      sin: [{ id: 'sal', n: 'sal' }, { id: 'limon', n: 'limón' }] },
    { id: 'hamburguesa', cat: 'fondos', nombre: 'Hamburguesa de la casa', desc: 'Pan de masa madre, carne jugosa y papas.', min: 9,
      grupos: [
        { id: 'punto', titulo: 'Punto de cocción', corto: 'el punto de cocción', min: 1, max: 1, opciones: [{ id: 'jugoso', n: 'Jugoso' }, { id: 'punto', n: 'A punto' }, { id: 'cocido', n: 'Bien cocido' }] },
        { id: 'extras', titulo: 'Extras', corto: 'los extras', min: 0, max: 2, opciones: [{ id: 'queso', n: 'Queso extra' }, { id: 'tocino', n: 'Tocino' }, { id: 'huevo', n: 'Huevo' }, { id: 'palta', n: 'Palta' }] }],
      sin: [{ id: 'cebolla', n: 'cebolla' }, { id: 'pepinillos', n: 'pepinillos' }] },
    { id: 'flan', cat: 'postres', nombre: 'Flan casero', desc: 'Suave, con la salsa de tu elección.', min: 3,
      grupos: [{ id: 'salsa', titulo: 'Salsa', corto: 'la salsa', min: 1, max: 1, defecto: 'caramelo', opciones: [{ id: 'caramelo', n: 'Caramelo' }, { id: 'dulce', n: 'Dulce de leche' }] }],
      sin: [] },
    { id: 'helado', cat: 'postres', nombre: 'Helado artesanal', desc: 'Dos bolas, sabores a elegir.', min: 2,
      grupos: [{ id: 'sabores', titulo: 'Sabores', unidad: ['sabor', 'sabores'], min: 2, max: 2, opciones: [{ id: 'vainilla', n: 'Vainilla' }, { id: 'chocolate', n: 'Chocolate' }, { id: 'frutilla', n: 'Frutilla' }, { id: 'limon', n: 'Limón' }] }],
      sin: [] },
    { id: 'limonada', cat: 'bebidas', nombre: 'Limonada', desc: 'Exprimida al momento, con menta.', min: 2,
      grupos: [{ id: 'tamano', titulo: 'Tamaño', corto: 'el tamaño', min: 1, max: 1, defecto: 'vaso', opciones: [{ id: 'vaso', n: 'Vaso' }, { id: 'jarra', n: 'Jarra' }] }],
      sin: [{ id: 'hielo', n: 'hielo' }, { id: 'azucar', n: 'azúcar' }] },
    { id: 'agua', cat: 'bebidas', nombre: 'Agua mineral', desc: 'Botella de 500 ml, bien fría.', min: 1,
      grupos: [{ id: 'tipo', titulo: 'Tipo', corto: 'el tipo', min: 1, max: 1, defecto: 'singas', opciones: [{ id: 'singas', n: 'Sin gas' }, { id: 'congas', n: 'Con gas' }] }],
      sin: [] },
    { id: 'cafe', cat: 'bebidas', nombre: 'Café', desc: 'De grano, molido en el momento.', min: 3,
      grupos: [{ id: 'tipo', titulo: 'Tipo', corto: 'el tipo', min: 1, max: 1, opciones: [{ id: 'espresso', n: 'Espresso' }, { id: 'cortado', n: 'Cortado' }, { id: 'americano', n: 'Americano' }] }],
      sin: [{ id: 'azucar', n: 'azúcar' }] },
  ];
  const CATEGORIAS = [['fondos', 'Fondos'], ['entradas', 'Entradas'], ['postres', 'Postres'], ['bebidas', 'Bebidas']];
  const ETQ = { libre: 'Libre', sentados: 'Sentados', cocina: 'En cocina', servir: 'Para servir', servida: 'Servida' };

  /* ── las reglas de un plato ───────────────────────────────────────
     La única función que dice si un plato está completo. Revisa cada grupo (que solo haya opciones del grupo, sin repetir, entre
     el mínimo y el máximo), los pares incompatibles y que lo que se quita exista. Devuelve la lista de errores con su texto. */
  const textoFalta = (gr, k) => gr.unidad ? 'Falta elegir ' + k + ' ' + (k === 1 ? gr.unidad[0] : gr.unidad[1]) : 'Falta elegir ' + (gr.corto || gr.titulo.toLowerCase());
  function valida(plato, sel) {
    const errores = [], g = (sel && sel.g) || {}, sin = (sel && sel.sin) || [];
    plato.grupos.forEach(gr => {
      const ids = g[gr.id] || [], validos = gr.opciones.map(o => o.id), n = ids.length;
      if (ids.some(id => validos.indexOf(id) < 0) || n !== new Set(ids).size) errores.push({ tipo: 'invalida', grupo: gr.id, texto: 'Hay una opción que no existe en ' + gr.titulo.toLowerCase() });
      if (n < gr.min) errores.push({ tipo: 'faltan', grupo: gr.id, texto: textoFalta(gr, gr.min - n) });
      if (n > gr.max) errores.push({ tipo: 'sobran', grupo: gr.id, texto: 'Elegiste de más en ' + gr.titulo.toLowerCase() + ': el máximo es ' + gr.max });
    });
    Object.keys(g).forEach(k => { if (g[k].length && !plato.grupos.some(gr => gr.id === k)) errores.push({ tipo: 'invalida', grupo: k, texto: 'Ese grupo no existe en este plato' }); });
    const todas = [].concat.apply([], plato.grupos.map(gr => g[gr.id] || []));
    (plato.incompatibles || []).forEach(par => { if (todas.indexOf(par[0]) >= 0 && todas.indexOf(par[1]) >= 0) errores.push({ tipo: 'incompatible', grupo: null, texto: par[2] }); });
    const quitables = plato.sin.map(s => s.id);
    if (sin.some(id => quitables.indexOf(id) < 0) || sin.length !== new Set(sin).size) errores.push({ tipo: 'invalida', grupo: 'sin', texto: 'Ese ingrediente no se puede quitar' });
    return { ok: errores.length === 0, errores };
  }
  // la selección con la que abre un plato: solo las opciones que traen `defecto`
  function selInicial(plato) {
    const g = {};
    plato.grupos.forEach(gr => { g[gr.id] = gr.defecto ? [gr.defecto] : []; });
    return { g, sin: [] };
  }
  // el texto de lo elegido, en el orden de la carta: «A punto · Papas fritas, Ensalada» y aparte «Sin cebolla, sin ajo»
  function textoMods(plato, sel) {
    const partes = [];
    plato.grupos.forEach(gr => {
      const ids = (sel.g && sel.g[gr.id]) || [], nombres = gr.opciones.filter(o => ids.indexOf(o.id) >= 0).map(o => o.n);
      if (nombres.length) partes.push(nombres.join(', '));
    });
    const quita = plato.sin.filter(s => (sel.sin || []).indexOf(s.id) >= 0).map(s => 'sin ' + s.n);
    return { base: partes.join(' · '), sin: quita.length ? mayus(quita.join(', ')) : '' };
  }
  // por qué una opción no se puede marcar ahora (o '' si se puede)
  function razonNo(plato, sel, gr, op) {
    const ids = (sel.g && sel.g[gr.id]) || [];
    if (ids.indexOf(op.id) >= 0) return '';
    if (gr.max > 1 && ids.length >= gr.max) return 'Ya elegiste ' + gr.max + ': quita uno para cambiar.';
    const todas = [].concat.apply([], plato.grupos.map(x => (sel.g && sel.g[x.id]) || []));
    const par = (plato.incompatibles || []).find(p => (p[0] === op.id && todas.indexOf(p[1]) >= 0) || (p[1] === op.id && todas.indexOf(p[0]) >= 0));
    return par ? par[2] : '';
  }
  // lo que dice cada grupo de «cuánto elegir»
  const reglaTexto = (gr, n) => {
    if (n > 0 && gr.max > 1) return n + ' de ' + (gr.min === gr.max ? gr.max : 'hasta ' + gr.max);
    if (gr.min === 0) return 'Opcional' + (gr.max > 1 ? ' · hasta ' + gr.max : '');
    return gr.min === 1 && gr.max === 1 ? 'Elige 1' : 'Elige ' + gr.min;
  };
  // el resumen de lo obligatorio, para la carta: «Elige 2 acompañamientos»
  function resumenReglas(plato) {
    const req = plato.grupos.filter(gr => gr.min > 0 && !gr.defecto);
    if (!req.length) return plato.sin.length ? 'Se puede quitar ingredientes' : '';
    return 'Elige ' + req.map(gr => gr.unidad ? (gr.min > 1 ? gr.min + ' ' + gr.unidad[1] : gr.unidad[0]) : (gr.corto || gr.titulo.toLowerCase()).replace(/^(el|la|los|las) /, '')).join(' y ');
  }

  /* ── el turno de ejemplo ──────────────────────────────────────────
     Son las 20:12. Cada línea trae cuándo se envió (`env`) y su plato; la cocina la pasa a «listo» al cumplirse el tiempo del plato.
     La mesa 6 tiene un plato que sale en dos minutos y las mesas 3 y 8 uno de doce, para que se vea cómo se mueve el salón. */
  function turnoDeEjemplo(carta) {
    let n = 0;
    const L = (plato, g, sin, estado, env, servido) => {
      const p = carta.find(x => x.id === plato);
      return { id: 'L' + (++n), plato, sel: { g, sin: sin || [] }, estado, env, min: p.min, listo: estado === 'cocina' ? null : env + p.min, servido: estado === 'servido' ? servido : null, com: 0 };
    };
    return [
      { id: 1, cap: 2, personas: 0, desde: 0, lineas: [], borrador: [] },
      { id: 2, cap: 4, personas: 4, desde: 1145, borrador: [], lineas: [
        L('sopa', {}, ['cebolla'], 'servido', 1150, 1158), L('pasta', { salsa: ['bolo'], extra: [] }, [], 'servido', 1162, 1175),
        L('hamburguesa', { punto: ['punto'], extras: ['queso'] }, [], 'servido', 1162, 1174), L('pasta', { salsa: ['quesos'], extra: ['rallado'] }, [], 'servido', 1162, 1175)] },
      { id: 3, cap: 4, personas: 3, desde: 1192, borrador: [], lineas: [
        L('croquetas', { salsa: ['miel'] }, [], 'servido', 1196, 1203),
        L('lomo', { punto: ['jugoso'], acomp: ['arroz', 'ensalada'] }, [], 'cocina', 1212),
        L('lomo', { punto: ['punto'], acomp: ['papas', 'verduras'] }, ['cebolla'], 'cocina', 1212)] },
      { id: 4, cap: 4, personas: 4, desde: 1209, lineas: [], borrador: [] },
      { id: 5, cap: 2, personas: 0, desde: 0, lineas: [], borrador: [] },
      { id: 6, cap: 6, personas: 5, desde: 1170, borrador: [], lineas: [
        L('ensalada', { aderezo: ['limon'] }, [], 'servido', 1176, 1182), L('sopa', {}, [], 'servido', 1176, 1184),
        L('pescado', { acomp: ['arroz'] }, ['sal'], 'cocina', 1203)] },
      { id: 7, cap: 2, personas: 0, desde: 0, lineas: [], borrador: [] },
      { id: 8, cap: 4, personas: 2, desde: 1200, borrador: [], lineas: [L('lomo', { punto: ['cocido'], acomp: ['pure', 'verduras'] }, ['ajo'], 'cocina', 1212)] },
      { id: 9, cap: 6, personas: 3, desde: 1208, lineas: [], borrador: [] },
    ];
  }

  function Comanda(raiz, opciones) {
    const o = Object.assign({ ahora: '20:12', ritmo: 650, arranque: 'gesto', carta: CARTA, mesas: null, alEnviar: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const $$ = s => Array.from(raiz.querySelectorAll(s));
    const vistas = {};
    $$('[data-vista]').forEach(v => { vistas[v.dataset.vista] = v; });
    const titulo = $('[data-titulo]'), atras = $('[data-atras]'), campana = $('[data-campana]'), cuenta = $('[data-cuenta]'), reloj = $('[data-reloj]');
    const barra = $('.co-barra'), pie = $('[data-pie]'), cta = $('[data-cta]'), toast = $('[data-toast]'), aviso = $('[data-aviso]'), hoja = $('[data-hoja]'), panel = $('[data-hoja-panel]');
    const grilla = $('[data-grilla]'), resumen = $('[data-resumen]'), servir = $('[data-servir]');
    const hMesa = $('[data-h-mesa]'), cuerpoMesa = $('[data-mesa-cuerpo]'), hCarta = $('[data-h-carta]'), cats = $('[data-cats]'), platos = $('[data-platos]');
    const carta = o.carta;
    const platoPor = id => carta.find(p => p.id === id);
    const ICONO = id => '<svg class="co-i" aria-hidden="true"><use href="#co-i-' + id + '"/></svg>';

    /* ── el estado ─────────────────────────────────────────────────── */
    let ahora = aMin(o.ahora), mesas, seq = 0, comN = 410, vista = 'salon', mesaId = null, cat = 'fondos';
    let corre = false, intervalo = 0, avisoT = 0, notaT = 0, temporizador = 0, hojaAct = null, foco = null;
    const ORDEN = { salon: 0, mesa: 1, carta: 2 };
    const mesaPor = id => mesas.find(m => m.id === +id);
    const mesaAct = () => (mesaId === null ? null : mesaPor(mesaId));

    function arrancaEstado() {
      mesas = copia(o.mesas || turnoDeEjemplo(carta));
      mesas.forEach(m => { m.borrador = m.borrador || []; m.lineas = m.lineas || []; m.personas = m.personas || 0; m.desde = m.desde || 0; });
      seq = 100;                                           // los números de las líneas nuevas parten de aquí (las del turno de ejemplo son L1…L11)
      ahora = aMin(o.ahora);
    }
    arrancaEstado();

    // el estado de una mesa sale de sus platos enviados: nunca se guarda
    function estadoMesa(m) {
      if (!m.personas) return 'libre';
      if (m.lineas.some(l => l.estado === 'listo')) return 'servir';
      if (m.lineas.some(l => l.estado === 'cocina')) return 'cocina';
      if (m.lineas.length && m.lineas.every(l => l.estado === 'servido')) return 'servida';
      return 'sentados';
    }
    const restante = l => Math.max(0, l.env + l.min - ahora);
    const espera = l => Math.max(0, ahora - (l.listo === null ? ahora : l.listo));
    const nombreDe = l => platoPor(l.plato).nombre;
    const listos = () => { const r = []; mesas.forEach(m => m.lineas.forEach(l => { if (l.estado === 'listo') r.push({ m, l }); })); return r.sort((a, b) => espera(b.l) - espera(a.l) || a.m.id - b.m.id); };
    function detalle(m, e) {
      if (e === 'libre') return 'Para ' + m.cap;
      if (e === 'sentados') return plural(m.personas, 'persona', 'personas');
      if (e === 'cocina') { const r = Math.min(...m.lineas.filter(l => l.estado === 'cocina').map(restante)); return 'listo en ' + r + ' min'; }
      if (e === 'servir') { const w = Math.max(...m.lineas.filter(l => l.estado === 'listo').map(espera)); return w < 1 ? 'recién salió' : 'espera ' + w + ' min'; }
      return plural(m.lineas.length, 'plato', 'platos');
    }
    function progresoMesa(m) {
      const c = m.lineas.filter(l => l.estado === 'cocina');
      if (!c.length) return 0;
      const l = c.slice().sort((a, b) => restante(a) - restante(b))[0];
      return Math.max(.06, Math.min(1, (ahora - l.env) / l.min));
    }

    /* ── navegar entre pantallas ───────────────────────────────────── */
    function ir(v, dir) {
      if (v === vista) return;
      const nueva = vistas[v], vieja = vistas[vista];
      if (dir === undefined) dir = ORDEN[v] >= ORDEN[vista] ? 1 : -1;
      nueva.style.transition = 'none';
      nueva.dataset.pos = dir > 0 ? 'der' : 'izq';
      void nueva.offsetWidth;
      nueva.style.transition = '';
      nueva.dataset.pos = 'activa'; nueva.inert = false;
      vieja.dataset.pos = dir > 0 ? 'izq' : 'der'; vieja.inert = true;
      nueva.classList.remove('is-entra'); void nueva.offsetWidth; nueva.classList.add('is-entra');
      nueva.scrollTop = 0;
      toast.dataset.ver = '0';
      vista = v;
      marco();
      const h = nueva.querySelector('.co-h');
      if (h) h.focus({ preventScroll: true });
    }
    // la barra de arriba y el botón de abajo
    function marco() {
      const m = mesaAct();
      const t = vista === 'salon' ? 'Salón' : vista === 'mesa' ? 'Pedido' : 'Carta';
      if (titulo.textContent !== t) {
        titulo.textContent = t;
        titulo.classList.remove('is-cambia'); void titulo.offsetWidth; titulo.classList.add('is-cambia');
      }
      raiz.dataset.pantalla = vista;
      atras.hidden = vista === 'salon';
      let texto = '', ver = false;
      if (m && vista === 'mesa' && m.borrador.length) { texto = 'Enviar a cocina · ' + plural(m.borrador.length, 'plato', 'platos'); ver = true; }
      if (m && vista === 'carta' && m.borrador.length) { texto = 'Volver al pedido · ' + plural(m.borrador.length, 'plato', 'platos'); ver = true; }
      if (texto) cta.textContent = texto;
      pie.dataset.ver = ver ? '1' : '0';
      pie.inert = !ver || !!hojaAct;
    }
    function vuelve() {
      if (hojaAct) return cierraHoja();
      if (vista === 'carta') { pintaMesa(true); ir('mesa', -1); }
      else if (vista === 'mesa') { ir('salon', -1); }
    }

    /* ── 1 · el salón ──────────────────────────────────────────────── */
    function construyeGrilla() {
      grilla.innerHTML = mesas.map((m, i) =>
        '<li data-c style="--i:' + (i + 2) + '"><button type="button" class="co-mesa" data-mesa="' + m.id + '">' +
        '<span class="co-m-ico" data-ico aria-hidden="true"></span><b class="co-m-num">' + m.id + '</b>' +
        '<span class="co-m-sillas" aria-hidden="true">' + '<i></i>'.repeat(m.cap) + '</span>' +
        '<span class="co-m-et"><span data-et></span><small data-det></small></span><i class="co-m-barra" aria-hidden="true"><i data-barra></i></i></button></li>').join('');
      mesas.forEach(actualizaMesa);
    }
    const ICO_ESTADO = { sentados: 'persona', cocina: 'fuego', servir: 'campana', servida: 'tilde' };
    function actualizaMesa(m) {
      const b = grilla.querySelector('[data-mesa="' + m.id + '"]');
      if (!b) return;
      const e = estadoMesa(m), det = detalle(m, e);
      if (b.dataset.e !== e) {
        const primera = !b.dataset.e;
        b.dataset.e = e;
        b.querySelector('[data-ico]').innerHTML = ICO_ESTADO[e] ? ICONO(ICO_ESTADO[e]) : '';
        if (!primera) { b.classList.remove('is-cambia'); void b.offsetWidth; b.classList.add('is-cambia'); }
      }
      b.querySelector('[data-et]').textContent = ETQ[e];
      b.querySelector('[data-det]').textContent = det;
      b.querySelectorAll('.co-m-sillas i').forEach((s, k) => s.classList.toggle('on', k < m.personas));
      b.querySelector('[data-barra]').style.setProperty('--p', e === 'cocina' ? progresoMesa(m).toFixed(3) : '0');
      b.setAttribute('aria-label', 'Mesa ' + m.id + ', ' + ETQ[e] + ', ' + det);
    }
    function pintaResumen() {
      const c = { servir: 0, cocina: 0, sentados: 0, servida: 0, libre: 0 };
      mesas.forEach(m => { c[estadoMesa(m)]++; });
      const chip = (k, n, t) => '<span class="co-r" data-k="' + k + '" data-n="' + n + '"><i></i><b>' + n + '</b> ' + t + '</span>';
      const html = chip('servir', c.servir, 'para servir') + chip('cocina', c.cocina, 'en cocina') + chip('libre', c.libre, c.libre === 1 ? 'libre' : 'libres');
      if (resumen.dataset.k !== html) { resumen.innerHTML = html; resumen.dataset.k = html; }
    }
    // lo que cocina ya dejó listo, con el botón que lo marca servido
    let firmaServir = null;
    function pintaServir() {
      const r = listos(), firma = r.map(x => x.l.id).join(',');
      cuenta.textContent = r.length; campana.dataset.n = r.length;
      campana.setAttribute('aria-label', 'Platos listos para servir: ' + r.length);
      if (firma !== firmaServir) {
        firmaServir = firma;
        servir.innerHTML = '<p class="co-grupo">Para servir ahora</p>' + (r.length
          ? '<ul class="co-s-lista">' + r.map(x => {
            return '<li class="co-s-fila" data-sl="' + x.l.id + '"><button type="button" class="co-s-abre" data-abre-mesa="' + x.m.id + '" aria-label="Abrir la mesa ' + x.m.id + '"><span class="co-s-mesa">' + x.m.id + '</span>' +
              '<span class="co-txt"><b>' + esc(nombreDe(x.l)) + '</b><small data-s-det></small></span></button>' +
              '<button type="button" class="co-servido" data-servido="' + x.l.id + '" data-m="' + x.m.id + '" aria-label="Marcar servido: ' + esc(nombreDe(x.l)) + ', mesa ' + x.m.id + '">' + ICONO('tilde') + 'Servido</button></li>';
          }).join('') + '</ul>'
          : '<p class="co-nada">Nada por servir ahora. Cocina sigue trabajando.</p>');
      }
      r.forEach(x => {
        const f = servir.querySelector('[data-sl="' + x.l.id + '"] [data-s-det]');
        if (f) { const w = espera(x.l), t = textoMods(platoPor(x.l.plato), x.l.sel); f.textContent = (w < 1 ? 'Recién salió' : 'Hace ' + w + ' min') + [t.base.split(' · ').pop(), t.sin.toLowerCase()].filter(Boolean).map(v => ' · ' + v).join(''); }
      });
    }
    function refrescaSalon() { mesas.forEach(actualizaMesa); pintaResumen(); pintaServir(); }

    /* ── 2 · la mesa ───────────────────────────────────────────────── */
    const ICO_LINEA = { cocina: 'fuego', listo: 'campana', servido: 'tilde' };
        function textoLinea(l) {
      if (l.estado === 'cocina') return 'En cocina · listo en ' + restante(l) + ' min';
      if (l.estado === 'listo') { const w = espera(l); return w < 1 ? 'Listo · recién salió' : 'Listo · espera ' + w + ' min'; }
      return 'Servido ' + hm(l.servido);
    }
    function htmlModificadores(p, sel) {
      const t = textoMods(p, sel);
      return (t.base ? '<small>' + esc(t.base) + '</small>' : '') + (t.sin ? '<small class="co-sin">' + esc(t.sin) + '</small>' : '');
    }
    // `anima`: las piezas entran en cascada solo al llegar a la pantalla; al cambiar algo dentro (un +, un plato listo) no se repite
    function pintaMesa(anima) {
      const m = mesaAct();
      if (!m) return;
      const e = estadoMesa(m), dc = i => (anima ? ' data-c style="--i:' + i + '"' : '');
      hMesa.innerHTML = '<span class="co-h-num">' + m.id + '</span><span>Mesa ' + m.id + '</span>';
      let html = '<div class="co-mcab"' + dc(1) + '><span class="co-chip" data-e="' + e + '">' + ETQ[e] + '</span>' +
        '<span class="co-mcab-t">' + (m.personas ? 'desde las ' + hm(m.desde) + ' · cap. ' + m.cap : 'Capacidad para ' + m.cap) + '</span></div>';
      if (!m.personas) {
        html += '<div class="co-sentar"' + dc(2) + '><p class="co-sentar-t">¿Cuántos son?</p><div class="co-ncs" style="--n:' + m.cap + '" role="group" aria-label="Cantidad de comensales">' +
          Array.from({ length: m.cap }, (_, k) => '<button type="button" class="co-nc" data-sienta="' + (k + 1) + '" aria-label="' + plural(k + 1, 'persona', 'personas') + '">' + (k + 1) + '</button>').join('') + '</div>' +
          '<p class="co-sentar-n">Toca el número de personas para abrir la mesa.</p></div>';
      } else {
        html += '<div class="co-pers"' + dc(2) + '><span>' + ICONO('persona') + 'Comensales</span><div class="co-paso" role="group" aria-label="Comensales">' +
          '<button type="button" data-pers="-1" aria-label="Una persona menos"' + (m.personas <= 1 ? ' disabled' : '') + '>' + ICONO('menos') + '</button><output data-pers-n>' + m.personas + '</output>' +
          '<button type="button" data-pers="1" aria-label="Una persona más"' + (m.personas >= m.cap ? ' disabled' : '') + '>' + ICONO('mas') + '</button></div></div>';
        if (m.borrador.length) {
          html += '<h3 class="co-sec"' + dc(3) + '>Por enviar<span>' + plural(m.borrador.length, 'plato', 'platos') + '</span></h3><ul class="co-lineas"' + dc(4) + '>' +
            m.borrador.map(b => { const p = platoPor(b.plato); return '<li class="co-linea co-borr" data-b="' + b.id + '"><span class="co-l-ico">' + ICONO('ticket') + '</span>' +
              '<button type="button" class="co-txt co-l-edita" data-edita="' + b.id + '" aria-label="Cambiar ' + esc(p.nombre) + '"><b>' + esc(p.nombre) + '</b>' + htmlModificadores(p, b.sel) + '</button>' +
              '<button type="button" class="co-l-quita" data-quita="' + b.id + '" aria-label="Quitar ' + esc(p.nombre) + ' del pedido">' + ICONO('cerrar') + '</button></li>'; }).join('') + '</ul>';
        }
        if (!m.borrador.length && !m.lineas.length) {
          html += '<div class="co-vacio"' + dc(3) + '><span class="co-vacio-ico">' + ICONO('ticket') + '</span><p>Aún no hay pedido en esta mesa.</p>' +
            '<button type="button" class="co-boton co-boton-lleno" data-carta>' + ICONO('mas') + 'Tomar pedido</button></div>';
        } else {
          html += '<button type="button" class="co-boton co-boton-linea co-agrega" data-carta' + dc(5) + '>' + ICONO('mas') + 'Agregar plato</button>';
        }
        if (m.lineas.length) {
          const orden = { listo: 0, cocina: 1, servido: 2 };
          const ls = m.lineas.slice().sort((a, b) => orden[a.estado] - orden[b.estado] || (a.estado === 'servido' ? b.servido - a.servido : restante(a) - restante(b)));
          html += '<h3 class="co-sec"' + dc(6) + '>En la mesa<span>' + plural(m.lineas.length, 'plato', 'platos') + '</span></h3><ul class="co-lineas" data-lista-env>' +
            ls.map((l, k) => {
              const p = platoPor(l.plato);
              return '<li class="co-linea' + (l.nuevo ? ' is-nueva' : '') + '" data-l="' + l.id + '" data-e="' + l.estado + '" style="--i:' + k + '">' +
                '<span class="co-l-ico">' + ICONO(ICO_LINEA[l.estado]) + '</span>' +
                '<span class="co-txt"><b>' + esc(p.nombre) + '</b>' + htmlModificadores(p, l.sel) + '<em class="co-l-est" data-est>' + textoLinea(l) + '</em></span>' +
                (l.estado === 'listo' ? '<button type="button" class="co-servido" data-servido="' + l.id + '" data-m="' + m.id + '" aria-label="Marcar servido: ' + esc(p.nombre) + '">' + ICONO('tilde') + 'Servido</button>' : '') +
                (l.estado === 'cocina' ? '<i class="co-l-barra" aria-hidden="true"><i style="--p:' + Math.min(1, (ahora - l.env) / l.min).toFixed(3) + '"></i></i>' : '') + '</li>';
            }).join('') + '</ul>';
        }
        const libera = !m.lineas.some(l => l.estado !== 'servido');
        if (libera) html += '<button type="button" class="co-boton co-boton-texto" data-cierra>' + ICONO('reinicio') + 'Liberar mesa</button>';
      }
      cuerpoMesa.innerHTML = html;
      cuerpoMesa.dataset.firma = firmaMesa(m);
      m.lineas.forEach(l => { delete l.nuevo; });
      marco();
    }
    // si cambia algo estructural (estado de un plato, borrador…) la mesa se vuelve a pintar; si no, solo avanzan los minutos
    const firmaMesa = m => m.personas + '|' + m.borrador.map(b => b.id).join(',') + '|' + m.lineas.map(l => l.id + l.estado).join(',');
    function refrescaMesa() {
      const m = mesaAct();
      if (!m || vista !== 'mesa') return;
      if (cuerpoMesa.dataset.firma !== firmaMesa(m)) { pintaMesa(); return; }
      m.lineas.forEach(l => {
        const li = cuerpoMesa.querySelector('[data-l="' + l.id + '"]');
        if (!li) return;
        const t = li.querySelector('[data-est]'); if (t) t.textContent = textoLinea(l);
        const b = li.querySelector('.co-l-barra i'); if (b) b.style.setProperty('--p', Math.min(1, (ahora - l.env) / l.min).toFixed(3));
      });
    }

    /* ── 3 · la carta ──────────────────────────────────────────────── */
    function pintaCarta() {
      const m = mesaAct();
      hCarta.textContent = m ? '¿Qué pide la mesa ' + m.id + '?' : 'Carta';
      cats.innerHTML = CATEGORIAS.filter(c => carta.some(p => p.cat === c[0])).map(c =>
        '<button type="button" role="tab" class="co-cat" data-cat="' + c[0] + '" aria-selected="' + (c[0] === cat) + '" tabindex="' + (c[0] === cat ? 0 : -1) + '">' + c[1] + '</button>').join('');
      platos.innerHTML = carta.filter(p => p.cat === cat).map((p, i) => {
        const regla = resumenReglas(p);
        return '<li data-c style="--i:' + (i + 2) + '"><button type="button" class="co-plato" data-plato="' + p.id + '"><span class="co-p-main"><b>' + esc(p.nombre) + '</b><small>' + esc(p.desc) + '</small>' +
          '<span class="co-p-meta"><span>' + ICONO('reloj') + '~' + p.min + ' min</span>' + (regla ? '<em>' + esc(regla) + '</em>' : '') + '</span></span><span class="co-p-mas" aria-hidden="true">' + ICONO('mas') + '</span></button></li>';
      }).join('');
      if (m) marco();
    }
    function eligeCat(c) {
      cat = c;
      pintaCarta();
    }

    /* ── la hoja del plato ─────────────────────────────────────────── */
    function abreHoja(platoId, editaId) {
      const m = mesaAct(), p = platoPor(platoId);
      if (!m || !p) return;
      const borr = editaId ? m.borrador.find(b => b.id === editaId) : null;
      hojaAct = { plato: p, sel: borr ? copia(borr.sel) : selInicial(p), edita: editaId || null, intento: false };
      foco = document.activeElement;
      const radio = gr => gr.max === 1;
      panel.innerHTML = '<i class="co-hoja-asa" aria-hidden="true"></i>' +
        '<header class="co-hoja-cab"><div><h2 id="co-h-hoja" tabindex="-1">' + esc(p.nombre) + '</h2><p>' + esc(p.desc) + '</p></div>' +
        '<button type="button" class="co-hoja-x" data-cierra-hoja aria-label="Cerrar sin agregar">' + ICONO('cerrar') + '</button></header>' +
        '<div class="co-hoja-cuerpo">' +
        p.grupos.map(gr => '<section class="co-grupo" data-grupo="' + gr.id + '"><div class="co-g-cab"><h3 id="co-g-' + gr.id + '">' + esc(gr.titulo) + '</h3><em class="co-regla" data-regla></em></div>' +
          '<div class="co-ops" style="--cols:' + (gr.opciones.length === 3 ? 3 : 2) + '" role="' + (radio(gr) ? 'radiogroup' : 'group') + '" aria-labelledby="co-g-' + gr.id + '">' +
          gr.opciones.map(op => '<button type="button" class="co-op" role="' + (radio(gr) ? 'radio' : 'checkbox') + '" data-op="' + op.id + '" aria-checked="false"><span>' + esc(op.n) + '</span>' + ICONO('tilde') + '</button>').join('') + '</div></section>').join('') +
        (p.sin.length ? '<section class="co-grupo co-grupo-sin" data-grupo="sin"><div class="co-g-cab"><h3 id="co-g-sin">Quitar</h3><em class="co-regla" data-regla></em></div>' +
          '<div class="co-ops co-ops-sin" role="group" aria-labelledby="co-g-sin">' + p.sin.map(s => '<button type="button" class="co-op co-op-sin" role="checkbox" data-op="' + s.id + '" aria-checked="false"><span>Sin ' + esc(s.n) + '</span>' + ICONO('cerrar') + '</button>').join('') + '</div></section>' : '') +
        '</div><footer class="co-hoja-pie"><p class="co-falta" data-falta aria-live="polite"></p>' +
        '<button type="button" class="co-boton co-boton-lleno" data-agrega aria-disabled="true">' + (editaId ? 'Guardar cambios' : 'Agregar al pedido') + '</button></footer>';
      hoja.dataset.ver = '1'; hoja.setAttribute('aria-hidden', 'false');
      Object.keys(vistas).forEach(k => { vistas[k].inert = true; });
      barra.inert = true; pie.inert = true;                 // detrás de la hoja no se llega con Tab
      actualizaHoja();
      const h = panel.querySelector('#co-h-hoja');
      temporizador = setTimeout(() => h && h.focus({ preventScroll: true }), reduce ? 0 : 60);
    }
    function actualizaHoja() {
      if (!hojaAct) return;
      const p = hojaAct.plato, sel = hojaAct.sel, v = valida(p, sel);
      p.grupos.forEach(gr => {
        const sec = panel.querySelector('[data-grupo="' + gr.id + '"]'), ids = sel.g[gr.id] || [];
        sec.querySelectorAll('.co-op').forEach(b => {
          const op = gr.opciones.find(x => x.id === b.dataset.op), on = ids.indexOf(op.id) >= 0, razon = razonNo(p, sel, gr, op);
          b.setAttribute('aria-checked', String(on));
          b.tabIndex = gr.max === 1 ? (on || (!ids.length && b === sec.querySelector('.co-op')) ? 0 : -1) : 0;
          b.classList.toggle('is-no', !!razon); b.setAttribute('aria-disabled', String(!!razon));
          if (razon) b.title = razon; else b.removeAttribute('title');
        });
        const cumple = ids.length >= gr.min && ids.length <= gr.max, r = sec.querySelector('[data-regla]');
        r.textContent = (cumple && ids.length && gr.min > 0 ? '✓ ' : '') + reglaTexto(gr, ids.length);
        r.dataset.e = gr.min > 0 && cumple ? 'listo' : ids.length ? 'curso' : (hojaAct.intento && gr.min > 0 ? 'error' : 'idle');
      });
      const sinSec = panel.querySelector('[data-grupo="sin"]');
      if (sinSec) {
        sinSec.querySelectorAll('.co-op').forEach(b => b.setAttribute('aria-checked', String(sel.sin.indexOf(b.dataset.op) >= 0)));
        const r = sinSec.querySelector('[data-regla]'); r.textContent = sel.sin.length ? sel.sin.length + (sel.sin.length === 1 ? ' ingrediente' : ' ingredientes') : 'Opcional';
        r.dataset.e = sel.sin.length ? 'sin' : 'idle';
      }
      const falta = panel.querySelector('[data-falta]'), boton = panel.querySelector('[data-agrega]');
      if (v.ok) {
        const t = textoMods(p, sel);
        falta.textContent = [t.base, t.sin].filter(Boolean).join(' · ') || 'Sin cambios';
        falta.dataset.e = 'ok';
      } else {
        falta.textContent = v.errores[0].texto + (v.errores.length > 1 ? ' (y ' + (v.errores.length - 1) + ' más)' : '');
        falta.dataset.e = 'falta';
      }
      boton.setAttribute('aria-disabled', String(!v.ok));
    }
    function pulsaOp(b) {
      if (!hojaAct) return;
      const p = hojaAct.plato, sel = hojaAct.sel, sec = b.closest('[data-grupo]'), gid = sec.dataset.grupo, id = b.dataset.op;
      if (gid === 'sin') {
        const k = sel.sin.indexOf(id);
        if (k >= 0) sel.sin.splice(k, 1); else sel.sin.push(id);
        sel.sin.sort((x, y) => p.sin.findIndex(s => s.id === x) - p.sin.findIndex(s => s.id === y));
        return actualizaHoja();
      }
      const gr = p.grupos.find(x => x.id === gid), op = gr.opciones.find(x => x.id === id), ids = sel.g[gid] || (sel.g[gid] = []), on = ids.indexOf(id) >= 0;
      if (b.getAttribute('aria-disabled') === 'true') { avisa(razonNo(p, sel, gr, op)); sacude(sec); return; }
      if (gr.max === 1) sel.g[gid] = on && gr.min === 0 ? [] : [id];
      else if (on) ids.splice(ids.indexOf(id), 1);
      else { ids.push(id); ids.sort((x, y) => gr.opciones.findIndex(s => s.id === x) - gr.opciones.findIndex(s => s.id === y)); }
      actualizaHoja();
    }
    function sacude(el) { el.classList.remove('is-rechaza'); void el.offsetWidth; el.classList.add('is-rechaza'); }
    // el botón «Agregar al pedido»: si falta algo no hace nada salvo decir qué y mover el grupo que falta
    function agregaDesdeHoja() {
      if (!hojaAct) return;
      const p = hojaAct.plato, v = valida(p, hojaAct.sel);
      if (!v.ok) {
        hojaAct.intento = true; actualizaHoja();
        const e = v.errores[0], sec = e.grupo ? panel.querySelector('[data-grupo="' + e.grupo + '"]') : null;
        if (sec) { sacude(sec); const b = sec.querySelector('.co-op:not(.is-no)'); if (b) b.focus({ preventScroll: false }); }
        avisa(e.texto);
        return;
      }
      const m = mesaAct(), edita = hojaAct.edita, sel = copia(hojaAct.sel);
      const r = edita ? edita_(m.id, edita, p.id, sel) : agrega(m.id, p.id, sel);
      if (!r.ok) return avisa(r.motivo);
      cierraHoja(true);
      pintaMesa(vista === 'carta');
      if (vista === 'carta') ir('mesa', -1);
      avisa(p.nombre + (edita ? ' actualizado' : ' en el pedido'));
    }
    function cierraHoja(sinFoco) {
      if (!hojaAct) return;
      clearTimeout(temporizador);
      hojaAct = null;
      hoja.dataset.ver = '0'; hoja.setAttribute('aria-hidden', 'true');
      Object.keys(vistas).forEach(k => { vistas[k].inert = k !== vista; });
      barra.inert = false;
      marco();
      if (!sinFoco && foco && foco.focus && document.contains(foco)) foco.focus({ preventScroll: true });
      foco = null;
    }

    /* ── lo que se hace con una mesa (la API y la pantalla usan lo mismo) ── */
    function sienta(id, n) {
      const m = mesaPor(id);
      if (!m) return { ok: false, motivo: 'No existe esa mesa' };
      n = Math.round(+n);
      if (!(n >= 1 && n <= m.cap)) return { ok: false, motivo: 'Esa mesa es para ' + m.cap + ' personas como máximo' };
      if (!m.personas) m.desde = ahora;
      m.personas = n;
      return { ok: true };
    }
    function cierra(id) {
      const m = mesaPor(id);
      if (!m) return { ok: false, motivo: 'No existe esa mesa' };
      if (m.lineas.some(l => l.estado !== 'servido')) return { ok: false, motivo: 'Aún hay platos en cocina o por servir' };
      m.personas = 0; m.desde = 0; m.lineas = []; m.borrador = [];
      return { ok: true };
    }
    // un plato entra al pedido solo si la regla dice que está completo (y la mesa tiene comensales)
    function agrega(id, platoId, sel) {
      const m = mesaPor(id), p = platoPor(platoId);
      if (!m || !p) return { ok: false, motivo: 'No existe esa mesa o ese plato' };
      if (!m.personas) return { ok: false, motivo: 'Primero siéntalos: la mesa está libre' };
      const v = valida(p, sel);
      if (!v.ok) return { ok: false, motivo: v.errores[0].texto, errores: v.errores };
      const b = { id: 'B' + (++seq), plato: p.id, sel: { g: copia(sel.g || {}), sin: (sel.sin || []).slice() } };
      m.borrador.push(b);
      return { ok: true, id: b.id };
    }
    function edita_(id, bId, platoId, sel) {
      const m = mesaPor(id), p = platoPor(platoId), b = m && m.borrador.find(x => x.id === bId);
      if (!b) return { ok: false, motivo: 'Esa línea ya salió o no existe' };
      const v = valida(p, sel);
      if (!v.ok) return { ok: false, motivo: v.errores[0].texto, errores: v.errores };
      b.sel = { g: copia(sel.g || {}), sin: (sel.sin || []).slice() };
      return { ok: true, id: b.id };
    }
    function quita(id, bId) {
      const m = mesaPor(id), k = m ? m.borrador.findIndex(b => b.id === bId) : -1;
      if (k < 0) return { ok: false, motivo: 'Esa línea no está por enviar' };
      m.borrador.splice(k, 1);
      return { ok: true };
    }
    /* Enviar a cocina vuelve a validar CADA línea: nada incompleto sale, aunque el borrador lo haya armado otro código. */
    function envia(id) {
      const m = mesaPor(id);
      if (!m) return { ok: false, motivo: 'No existe esa mesa' };
      if (!m.personas) return { ok: false, motivo: 'La mesa está libre' };
      if (!m.borrador.length) return { ok: false, motivo: 'No hay platos por enviar' };
      for (const b of m.borrador) {
        const v = valida(platoPor(b.plato), b.sel);
        if (!v.ok) return { ok: false, motivo: platoPor(b.plato).nombre + ': ' + v.errores[0].texto, linea: b.id };
      }
      const n = ++comN, enviados = [];
      m.borrador.forEach(b => {
        const p = platoPor(b.plato), l = { id: 'L' + (++seq), plato: b.plato, sel: b.sel, estado: 'cocina', env: ahora, min: p.min, listo: null, servido: null, com: n, nuevo: true };
        m.lineas.push(l); enviados.push({ plato: b.plato, sel: copia(b.sel) });
      });
      m.borrador = [];
      if (o.alEnviar) o.alEnviar({ n, mesa: m.id, hora: hm(ahora), platos: enviados });
      return { ok: true, n, platos: enviados.length };
    }
    function sirve(id, lId) {
      const m = mesaPor(id), l = m && m.lineas.find(x => x.id === lId);
      if (!l) return { ok: false, motivo: 'Ese plato no está en la mesa' };
      if (l.estado !== 'listo') return { ok: false, motivo: l.estado === 'servido' ? 'Ya está servido' : 'Cocina aún no lo termina' };
      l.estado = 'servido'; l.servido = ahora;
      return { ok: true };
    }

    /* ── la cocina: un reloj simulado ──────────────────────────────── */
    function pasaMinuto() {
      ahora++;
      const nuevos = [];
      mesas.forEach(m => m.lineas.forEach(l => {
        if (l.estado === 'cocina' && ahora >= l.env + l.min) { l.estado = 'listo'; l.listo = l.env + l.min; nuevos.push({ m, l }); }
      }));
      return nuevos;
    }
    function tick(minutos) {
      let nuevos = [];
      for (let k = 0; k < (minutos || 1); k++) nuevos = nuevos.concat(pasaMinuto());
      reloj.textContent = hm(ahora);
      refrescaSalon(); refrescaMesa();
      if (nuevos.length) {
        const u = nuevos[nuevos.length - 1];
        notifica(u.m, u.l, nuevos.length);
        marco();
      }
    }
    function arranca() {
      if (corre || o.arranque === 'manual') return;
      corre = true;
      intervalo = setInterval(() => tick(1), o.ritmo);
    }
    // el aviso de cocina: baja desde arriba como una notificación y se va solo
    function notifica(m, l, otros) {
      const p = platoPor(l.plato);
      aviso.innerHTML = '<span class="co-av-ico">' + ICONO('campana') + '</span><span class="co-txt"><b>Mesa ' + m.id + ' · ' + esc(p.nombre) + '</b><small>Listo para servir' + (otros > 1 ? ' · y ' + (otros - 1) + ' más' : '') + '</small></span>';
      aviso.dataset.ver = '1';
      clearTimeout(notaT);
      notaT = setTimeout(() => { aviso.dataset.ver = '0'; }, 2600);
    }
    function avisa(texto) {
      toast.textContent = texto;
      toast.dataset.ver = '1';
      clearTimeout(avisoT);
      avisoT = setTimeout(() => { toast.dataset.ver = '0'; }, 2400);
    }
    function reinicia() {
      cierraHoja(true);
      arrancaEstado();
      mesaId = null; cat = 'fondos'; firmaServir = null;
      reloj.textContent = hm(ahora);
      construyeGrilla(); pintaResumen(); pintaServir();
      ir('salon', -1);
    }

    /* ── ratón, dedo y teclado ─────────────────────────────────────── */
    function abreMesa(id) {
      mesaId = +id;
      pintaMesa(true);
      ir('mesa', 1);
    }
    raiz.addEventListener('click', e => {
      if (e.target.closest('.co-hoja-fondo')) return cierraHoja();
      const t = e.target.closest('button');
      if (!t || t.disabled) return;
      const d = t.dataset, m = mesaAct();
      if (d.mesa) return abreMesa(d.mesa);
      if (d.abreMesa) return abreMesa(d.abreMesa);
      if ('atras' in d) return vuelve();
      if ('campana' in d) {
        if (hojaAct) return;
        if (vista !== 'salon') ir('salon', -1);
        servir.scrollIntoView({ block: 'center', behavior: reduce ? 'auto' : 'smooth' });
        const b = servir.querySelector('.co-servido') || servir; if (b.focus) b.focus({ preventScroll: true });
        return;
      }
      if ('reinicia' in d) return reinicia();
      if (d.servido) {
        const mm = mesaPor(d.m), id = d.servido, r = sirve(mm.id, id);
        if (r.ok) { const nombre = nombreDe(mm.lineas.find(l => l.id === id)); avisa('Servido: ' + nombre + ', mesa ' + mm.id); }
        refrescaSalon(); if (vista === 'mesa') pintaMesa();
        return;
      }
      if (d.sienta) { sienta(m.id, +d.sienta); pintaMesa(); return; }
      if (d.pers) { sienta(m.id, m.personas + +d.pers); pintaMesa(); const b = cuerpoMesa.querySelector('[data-pers="' + d.pers + '"]'); if (b && !b.disabled) b.focus({ preventScroll: true }); return; }
      if ('cierra' in d) { const r = cierra(m.id); if (r.ok) { avisa('Mesa ' + m.id + ' libre'); refrescaSalon(); ir('salon', -1); } else avisa(r.motivo); return; }
      if ('carta' in d) { pintaCarta(); ir('carta', 1); return; }
      if (d.quita) { quita(m.id, d.quita); pintaMesa(); return; }
      if (d.edita) { const b = m.borrador.find(x => x.id === d.edita); if (b) abreHoja(b.plato, b.id); return; }
      if (d.cat) return eligeCat(d.cat);
      if (d.plato) return abreHoja(d.plato);
      if ('cierraHoja' in d) return cierraHoja();
      if ('agrega' in d) return agregaDesdeHoja();
      if (t.classList.contains('co-op')) return pulsaOp(t);
      if ('cta' in d) {
        if (vista === 'carta') { pintaMesa(true); return ir('mesa', -1); }
        const r = envia(m.id);
        if (!r.ok) return avisa(r.motivo);
        avisa('Comanda N.º ' + r.n + ' enviada a cocina');
        pintaMesa(); refrescaSalon();
      }
    });
    // la cocina empieza con el primer gesto sobre el teléfono (así la página y el vídeo parten del mismo punto)
    ['pointerenter', 'pointerdown', 'keydown', 'focusin'].forEach(ev => $('[data-tel]').addEventListener(ev, arranca, { once: true }));
    const alEsc = e => {
      if (hojaAct) { e.preventDefault(); cierraHoja(); return; }
      if (!atras.hidden) { e.preventDefault(); vuelve(); }
    };
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && (!document.activeElement || document.activeElement === document.body)) alEsc(e); });   // si el foco se perdió, Esc sigue valiendo
    raiz.addEventListener('keydown', e => {
      if (e.key === 'Escape') { alEsc(e); return; }
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight' && e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
      const lado = e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 1;
      const tab = e.target.closest && e.target.closest('[role="tab"]');
      if (tab) {                                           // las categorías: las flechas mueven y eligen
        const bs = Array.from(cats.querySelectorAll('[role="tab"]')), sig = bs[(bs.indexOf(tab) + lado + bs.length) % bs.length];
        e.preventDefault(); eligeCat(sig.dataset.cat);
        const nuevo = cats.querySelector('[data-cat="' + sig.dataset.cat + '"]'); if (nuevo) nuevo.focus();
        return;
      }
      const op = e.target.closest && e.target.closest('[role="radio"]');
      if (op) {                                            // «elige 1»: las flechas eligen la opción vecina
        const bs = Array.from(op.parentNode.querySelectorAll('[role="radio"]')), sig = bs[(bs.indexOf(op) + lado + bs.length) % bs.length];
        e.preventDefault(); pulsaOp(sig); sig.focus();
      }
    });

    // el riel de la escena: comandas de papel colgadas, cada una con su balanceo (azar con semilla: siempre las mismas)
    function dibujaRiel() {
      const svg = $('[data-riel]');
      if (!svg) return;
      const r = mulberry32(844);
      let html = '<path class="co-riel-l" d="M0 118H1280"/><path class="co-riel-l co-riel-l2" d="M0 126H1280"/>';
      for (let x = 26; x < 1250; x += 78) {
        const w = 58, h = 120 + Math.round(r() * 120), giro = (r() * 2.2 + .6).toFixed(2), dur = (5 + r() * 4).toFixed(1), ret = (-r() * 6).toFixed(1);
        let diente = '', lineas = '';
        for (let i = 0; i <= 7; i++) diente += ' L' + (w - i * w / 7).toFixed(1) + ' ' + (h + (i % 2 ? 6 : 0));      // el borde de abajo, en diente de sierra
        for (let i = 0, n = 3 + Math.floor(r() * 4); i < n; i++) lineas += '<rect x="8" y="' + (22 + i * 18) + '" width="' + (20 + Math.round(r() * 28)) + '" height="4" rx="2"/>';
        html += '<g transform="translate(' + x + ' 126)"><g class="co-tk" style="--r:' + giro + 'deg;--t:' + dur + 's;--d:' + ret + 's"><path class="co-tk-papel" d="M0 0 H' + w + ' V' + h + diente + ' Z"/>' +
          '<g class="co-tk-lin">' + lineas + '</g><circle class="co-tk-gancho" cx="' + (w / 2) + '" cy="-4" r="3.500"/></g></g>';
      }
      svg.innerHTML = html;
    }

    /* ── arranque ─────────────────────────────────────────────────── */
    Object.keys(vistas).forEach(k => { vistas[k].dataset.pos = k === 'salon' ? 'activa' : 'der'; vistas[k].inert = k !== 'salon'; });
    vistas.salon.classList.add('is-entra');
    reloj.textContent = hm(ahora);
    dibujaRiel();
    construyeGrilla(); pintaResumen(); pintaServir(); marco();
    if (o.arranque === 'ya') arranca();

    // la API deja la pantalla al día: lo que se haga por código se ve igual que lo que se hace con el dedo
    const refrescaTodo = () => { refrescaSalon(); if (vista === 'mesa') pintaMesa(); marco(); };
    const conPantalla = f => function () { const r = f.apply(null, arguments); refrescaTodo(); return r; };
    const estadoLinea = l => ({ id: l.id, plato: l.plato, estado: l.estado, env: hm(l.env), listo: l.listo === null ? null : hm(l.listo), servido: l.servido === null ? null : hm(l.servido), com: l.com });
    return {
      platos: () => copia(carta),
      valida: (platoId, sel) => valida(platoPor(platoId), sel),
      sienta: conPantalla(sienta), cierra: conPantalla(cierra), agrega: conPantalla(agrega), quita: conPantalla(quita), envia: conPantalla(envia), sirve: conPantalla(sirve),
      avanza: minutos => tick(Math.max(1, Math.round(minutos))),
      estado: () => ({ vista, hoja: hojaAct ? hojaAct.plato.id : null, ahora: hm(ahora), mesas: mesas.map(m => ({ id: m.id, cap: m.cap, personas: m.personas, estado: estadoMesa(m), borrador: m.borrador.length, lineas: m.lineas.map(estadoLinea) })) }),
      reinicia,
    };
  }

  Comanda.valida = valida;
  window.Comanda = Comanda;
})();
