# Marcador · Moxen

Al guardar, la cinta de marcapáginas se suelta desde el canto de la tarjeta y cae con su peso: se estira, rebota, se balancea y la tinta la empapa de arriba abajo. Al quitarlo, se vacía y se enrolla hacia arriba; la tela es una cadena con física de verdad.

## Qué trae

- `index.html` — la demostración
- `marcador.css`
- `marcador.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `marcador.css` y `marcador.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

On save, the bookmark ribbon drops from the edge of the card with real weight: it stretches, bounces, sways and ink soaks it from top to bottom. On removing it, it drains and rolls back up; the fabric is a chain with real physics.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
