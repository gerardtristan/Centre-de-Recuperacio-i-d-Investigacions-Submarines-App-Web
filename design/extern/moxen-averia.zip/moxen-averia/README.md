# Avería · Moxen

Eliges el equipo y respondes las preguntas de ese equipo, que cada uno trae las suyas, cuentas qué pasa y subes fotos: cada una se achica en el navegador con un lienzo y su tarjeta muestra el peso antes y después, y la ubicación oculta de la foto se borra. Un archivo que no es una imagen se rechaza mirando su contenido y no su nombre, y al elegir una franja con cupo sale un folio como AV-2810-T03 que ya dice el día, la franja y tu lugar en ella.

## Qué trae

- `index.html` — la demostración
- `averia.css`
- `averia.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `averia.css` y `averia.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

You pick the appliance and answer the questions for that appliance, since each one brings its own, say what is wrong and add photos: each one is shrunk in the browser with a canvas and its card shows the weight before and after, and the photo’s hidden location data is erased. A file that is not an image is rejected by looking at its content, not its name, and choosing a time slot with room gives an ID like AV-2810-T03 that already says the day, the slot and your place in it.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
