# Teletipo · Moxen

Al soltar un archivo de feed o un OPML, cada fuente entra en el lateral con su contador y sus artículos se imprimen en el rollo como tiras de teletipo; al abrir uno se muestra limpio, sin scripts ni rastreadores, y su tira pasa a gris. J y K recorren, M marca, S guarda, y «Todo leído» vacía los contadores con un ✓ rojo.

## Qué trae

- `index.html` — la demostración
- `teletipo.css`
- `teletipo-nucleo.js`
- `teletipo-ejemplos.js`
- `teletipo.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `teletipo.css` y `teletipo-nucleo.js` y `teletipo-ejemplos.js` y `teletipo.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Drop a feed file or an OPML and each source enters the sidebar with its counter while its articles print onto the roll as teletype strips; opening one shows it clean, with no scripts or trackers, and its strip turns grey. J and K step through, M marks, S saves, and «Mark all read» empties the counters with a red ✓.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
