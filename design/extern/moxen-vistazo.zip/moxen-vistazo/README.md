# Vistazo · Moxen

Al pasar el cursor por la lista aparece una ventana con la foto que lo sigue con un leve retraso, se inclina según la velocidad y crece con un rebote. Al cambiar de fila, la foto nueva entra con una cortina desde el lado por el que llegas; en el teléfono, el primer toque la muestra y el segundo abre el enlace.

## Qué trae

- `index.html` — la demostración
- `vistazo.css`
- `vistazo.js`
- `img/` — las fotos de la demostración (Unsplash; reemplázalas por las tuyas)
- `CREDITOS.md` — autor y enlace de cada foto
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `vistazo.css` y `vistazo.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

As the cursor moves over the list, a window with the photo follows it with a slight lag, tilts with speed and grows with a bounce. Switching rows, the new photo enters with a curtain from the side you come from; on a phone, the first tap shows it and the second opens the link.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
