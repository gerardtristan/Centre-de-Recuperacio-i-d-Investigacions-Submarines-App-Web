/* =====================================================================
   Emisor · Moxen
   Boleta o factura en un paso. Eliges el documento y, si es factura, el formulario se despliega y pide RUT, razón
   social, giro y dirección; la hoja de la derecha se rellena a medida que escribes. La empresa se guarda en el navegador:
   la próxima vez basta con escribir su RUT (o elegirla en la lista) y el resto se completa solo.

   · El RUT se da formato mientras escribes (puntos y guion, sin mover el cursor) y se comprueba con el módulo 11: cada
     cifra del cuerpo, de derecha a izquierda, se multiplica por 2, 3, 4, 5, 6, 7, 2, 3…; lo que le falta a la suma para
     el siguiente múltiplo de 11 es el dígito (11 → 0 y 10 → K). Si no cuadra, el campo dice cuál debería ser.
   · Las empresas guardadas viven en localStorage («moxen-emisor-empresas»). Al escribir el RUT aparecen las que empiezan
     igual (flechas, Intro y Esc; o un toque), y si el RUT completo es de una guardada se rellena el resto. Al emitir una
     factura con «Guardar esta empresa» activo, se guarda o se actualiza. Si no hay localStorage, funciona igual hasta
     recargar. Las tres empresas que vienen de ejemplo son inventadas, con RUT válidos.
   · El botón se enciende solo cuando el documento está completo. Emitir deja caer el sello sobre la hoja, asigna el
     folio y, si corresponde, guarda la empresa; «Nuevo documento» (o cambiar de tipo) vuelve a empezar con el folio siguiente.
   · No hay importes: el pedido solo trae cantidades. Lo que se muestra es el documento y sus datos.

   Montaje (se inicia solo sobre [data-emisor]; el HTML de la demo es la plantilla):
     <main data-emisor> … </main>
     const e = Emisor(document.querySelector('[data-emisor]'), {
       clave: 'moxen-emisor-empresas',   // dónde se guardan las empresas
       ejemplos: [{ rut, razon, giro, dir }],   // con lo que arranca si aún no hay nada guardado
       alEmitir: ({ tipo, folio, empresa }) => {},
     });
     e.tipo('factura');  e.rut('76123456-0');  e.emite();  e.empresas();  e.restablece();
     Emisor.dv('76123456');  Emisor.valida('76.123.456-0');  Emisor.formatea('761234560');

   Qué cambia qué: los colores son variables al principio de emisor.css (azul = acciones y ✓, rojo = error y sello; la hoja
   tiene las suyas, --ei-h-…). Sin azar (el timbre de la hoja usa una semilla fija) y sin dependencias; el tiempo viene de
   requestAnimationFrame, setTimeout y transiciones CSS (nada de Date para animar).
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const miles = c => String(c).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

  /* ── el RUT, sin animación ─────────────────────────────────────────── */
  // lo escrito, sin nada que no sea cifra; la K solo vale al final (el dígito) y caben nueve caracteres
  const limpia = t => String(t == null ? '' : t).toUpperCase().replace(/[^0-9K]/g, '').replace(/K(?=.)/g, '').replace(/^K/, '').slice(0, 9);
  function dv(cuerpo) {
    const s = String(cuerpo).replace(/\D/g, '');
    let suma = 0, m = 2;
    for (let i = s.length - 1; i >= 0; i--) { suma += +s[i] * m; m = m === 7 ? 2 : m + 1; }
    const r = 11 - suma % 11;
    return r === 11 ? '0' : r === 10 ? 'K' : String(r);
  }
  /* Lee lo escrito como venga: «76.123.456-0», «761234560» o «76123456-0». Sin guion, el dígito se deduce: una K al final,
     o la novena cifra (el cuerpo tiene a lo más ocho). Con ocho cifras justas puede ser un cuerpo de ocho o uno de siete
     con su dígito: si las siete primeras ya cuadran con la octava, es lo segundo, así quien tiene un RUT de siete cifras
     no está obligado a escribir el guion. */
  function lee(t) {
    const s = limpia(t);
    let cuerpo = s, d = '';
    if (s.length > 1 && s.slice(-1) === 'K') { cuerpo = s.slice(0, -1); d = 'K'; }
    else if (s.length === 9) { cuerpo = s.slice(0, 8); d = s[8]; }
    else if (s.length === 8 && dv(s.slice(0, 7)) === s[7]) { cuerpo = s.slice(0, 7); d = s[7]; }
    return { cuerpo, dv: d };
  }
  const formatea = t => { const r = lee(t); return miles(r.cuerpo) + (r.dv ? '-' + r.dv : ''); };
  // el cuerpo debe tener al menos siete cifras (un millón en adelante) y el dígito debe cuadrar
  function valida(t) {
    const r = lee(t);
    return r.cuerpo.length >= 7 && /^\d+$/.test(r.cuerpo) && r.dv !== '' && dv(r.cuerpo) === r.dv;
  }

  /* ── las empresas de ejemplo: inventadas, con RUT que pasan el módulo 11 ── */
  const EJEMPLOS = [
    { rut: '76.123.456-0', razon: 'Distribuidora Ejemplo SpA', giro: 'Venta al por mayor de artículos de oficina', dir: 'Calle Ejemplo 1250, Oficina 301' },
    { rut: '77.654.321-7', razon: 'Imprenta de Muestra Ltda.', giro: 'Impresión y servicios de diseño gráfico', dir: 'Pasaje Demostración 88' },
    { rut: '78.901.230-K', razon: 'Taller de Ejemplo SpA', giro: 'Carpintería y reparación de muebles', dir: 'Avenida Muestra 4520, Local 2' }
  ];
  const CLAVE = 'moxen-emisor-empresas';

  const ICONO_OK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5.5 12.5 4.2 4.2 8.8-9.4" pathLength="1"/></svg>';
  const ICONO_X = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 7 10 10M17 7 7 17"/></svg>';

  function Emisor(raiz, opciones) {
    const op = Object.assign({ clave: CLAVE, ejemplos: EJEMPLOS, alEmitir: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const form = $('[data-form]'), tipoEl = $('[data-tipo]'), hoja = $('[data-hoja]');
    const radios = [].slice.call(tipoEl.querySelectorAll('[role="radio"]'));
    const paneles = { boleta: $('[data-panel="boleta"]'), factura: $('[data-panel="factura"]') };
    const recep = { boleta: $('[data-recep="boleta"]'), factura: $('[data-recep="factura"]') };
    const campos = {}; [].forEach.call(raiz.querySelectorAll('[data-f]'), el => { campos[el.dataset.f] = el; });
    const dd = {}; [].forEach.call(raiz.querySelectorAll('[data-d]'), el => { dd[el.dataset.d] = el; });
    const msj = { rut: $('[data-m="rut"]'), correo: $('[data-m="correo"]') };
    const rutCaja = $('[data-rut]'), lista = $('[data-sug]'), chips = $('[data-guardadas]');
    const btn = $('[data-emitir]'), btnT = $('[data-emitir-t]'), aviso = $('[data-aviso]');
    const guarda = $('[data-guarda]'), docTit = $('[data-doc-titulo]'), docFolio = $('[data-doc-folio]');
    const textoRut0 = msj.rut.textContent, textoCorreo0 = msj.correo.textContent;

    const E = { tipo: 'boleta', rut: '', razon: '', giro: '', dir: '', correo: '', guardar: true, emitido: false, emitidoTipo: null, folio: { boleta: 3891, factura: 125 }, ultima: null };
    const TEXTOS = { boleta: 'BOLETA ELECTRÓNICA', factura: 'FACTURA ELECTRÓNICA' };
    const folioTxt = t => String(E.folio[t]).padStart(t === 'factura' ? 4 : 1, '0');

    /* ── el almacén de empresas ─────────────────────────────────────────── */
    const clona = l => l.map(e => Object.assign({}, e));
    function leeAlmacen() {
      try { const j = JSON.parse(localStorage.getItem(op.clave)); if (Array.isArray(j)) return j.filter(e => e && valida(e.rut)); } catch (e) { /* sin almacén: se sigue en memoria */ }
      return null;
    }
    function escribeAlmacen() { try { localStorage.setItem(op.clave, JSON.stringify(empresas)); } catch (e) { /* idem */ } }
    let empresas = leeAlmacen() || clona(op.ejemplos);
    const buscaPorRut = r => empresas.find(e => limpia(e.rut) === limpia(r));

    /* ── lo que se ve en la hoja ────────────────────────────────────────── */
    function pintaHoja() {
      dd.razon.textContent = E.razon.trim();
      dd.rut.textContent = formatea(E.rut);
      dd.giro.textContent = E.giro.trim();
      dd.dir.textContent = E.dir.trim();
      dd.correo.textContent = E.correo.trim();
    }
    function pintaTitulo(t) {
      docTit.textContent = TEXTOS[t];
      docFolio.textContent = folioTxt(t);
    }

    /* ── lo que falta para poder emitir ─────────────────────────────────── */
    const correoOk = c => !c || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(c);
    function falta() {
      if (E.tipo === 'boleta') return correoOk(E.correo.trim()) ? '' : 'El correo no parece completo.';
      if (!valida(E.rut)) return 'Falta un RUT válido.';
      if (E.razon.trim().length < 3) return 'Falta la razón social.';
      if (E.giro.trim().length < 3) return 'Falta el giro.';
      if (E.dir.trim().length < 3) return 'Falta la dirección.';
      return '';
    }

    function textoAviso(txt, tipo, conOk) {
      aviso.textContent = '';
      aviso.className = 'ei-aviso' + (tipo ? ' es-' + tipo : '');
      if (conOk) aviso.insertAdjacentHTML('beforeend', ICONO_OK);
      aviso.appendChild(document.createTextNode(txt));
    }

    /* el RUT y su mensaje: vacío, incompleto, válido (con o sin empresa guardada) o con el dígito mal */
    function pintaRut() {
      const r = lee(E.rut), ok = valida(E.rut);
      const mal = !ok && r.dv !== '' && /^\d{7,}$/.test(r.cuerpo);
      rutCaja.classList.toggle('es-valido', ok);
      rutCaja.classList.toggle('es-error', mal);
      campos.rut.setAttribute('aria-invalid', String(mal));
      const m = msj.rut;
      if (ok) { m.textContent = buscaPorRut(E.rut) ? 'RUT válido · empresa guardada, el resto se completó solo.' : 'RUT válido.'; m.className = 'ei-msj es-bien'; }
      else if (mal) { m.textContent = 'El dígito verificador de ' + miles(r.cuerpo) + ' es ' + dv(r.cuerpo) + ', no ' + r.dv + '.'; m.className = 'ei-msj es-error'; }
      else { m.textContent = r.cuerpo.length >= 7 ? 'Falta el dígito verificador, el que va después del guion.' : r.cuerpo ? 'Sigue escribiendo: el RUT lleva su dígito al final.' : textoRut0; m.className = 'ei-msj'; }
    }
    function pintaCorreo() {
      const c = E.correo.trim(), bien = correoOk(c);
      msj.correo.textContent = !c ? textoCorreo0 : bien ? 'La boleta se enviará a ese correo.' : 'Ese correo no parece completo.';
      msj.correo.className = 'ei-msj' + (c && !bien ? ' es-error' : c ? ' es-bien' : '');
    }

    function actualiza() {
      const f = falta();
      btn.disabled = !E.emitido && !!f;
      btn.classList.toggle('es-nuevo', E.emitido);
      btnT.textContent = E.emitido ? 'Nuevo documento' : 'Emitir ' + E.tipo;
      pintaRut(); pintaCorreo();
      if (!E.emitido) {
        const vacia = E.tipo === 'factura' && !limpia(E.rut) && !E.razon && !E.giro && !E.dir;
        textoAviso(f && !vacia ? f : f ? 'Completa los datos de la empresa para emitir.' : E.tipo === 'factura' ? 'Todo listo: la factura sale con estos datos.' : 'Todo listo: la boleta no pide nada más.', f ? '' : 'bien');
      }
      chips.querySelectorAll('.ei-chip').forEach(c => c.classList.toggle('es-activa', E.tipo === 'factura' && valida(E.rut) && limpia(c.dataset.rut) === limpia(E.rut)));
    }

    /* ── el tipo de documento ───────────────────────────────────────────── */
    function aplicaTipo(t, sinAnimar) {
      tipoEl.dataset.sel = t; form.dataset.sel = t; hoja.dataset.tipoDoc = t;
      radios.forEach(r => { const on = r.dataset.v === t; r.setAttribute('aria-checked', String(on)); r.tabIndex = on ? 0 : -1; });
      ['boleta', 'factura'].forEach(k => {
        const on = k === t;
        paneles[k].classList.toggle('es-abierto', on); recep[k].classList.toggle('es-abierto', on);
        paneles[k].inert = !on; paneles[k].setAttribute('aria-hidden', String(!on));
      });
            if (sinAnimar || quieto()) pintaTitulo(t);
      else { hoja.classList.add('es-cambia'); setTimeout(() => { pintaTitulo(t); hoja.classList.remove('es-cambia'); }, 230); }
    }
    function ponTipo(t) {
      if (t === E.tipo) return;
      if (E.emitido) nuevo();
      E.tipo = t;
      aplicaTipo(t);
      cierraLista();
      actualiza();
    }

    /* ── autocompletar: un campo que se escribe solo ────────────────────── */
    const corriendo = {};
    function cancela(k) { if (corriendo[k]) { cancelAnimationFrame(corriendo[k]); corriendo[k] = 0; } }
    function llena(k, texto, espera) {
      cancela(k);
      const pon = v => { E[k] = v; campos[k].value = v; pintaHoja(); };
      if (quieto() || !texto) { pon(texto); return; }
      const dur = Math.max(260, texto.length * 15);
      let ini = null;
      pon('');
      const paso = t => {
        if (ini == null) ini = t + espera;
        const u = lim((t - ini) / dur, 0, 1);
        pon(texto.slice(0, Math.ceil(u * texto.length)));
        if (u < 1) corriendo[k] = requestAnimationFrame(paso); else { corriendo[k] = 0; actualiza(); }
      };
      corriendo[k] = requestAnimationFrame(paso);
    }
    function completa(emp) {
      llena('razon', emp.razon, 0); llena('giro', emp.giro, 130); llena('dir', emp.dir, 260);
    }

    /* ── la lista de sugerencias ────────────────────────────────────────── */
    let sug = [], activa = -1;
    function coincidencias() {
      const q = limpia(E.rut);
      return empresas.filter(e => limpia(e.rut).indexOf(q) === 0);
    }
    function pintaLista() {
      const q = limpia(E.rut);
      sug = coincidencias();
      const exacta = valida(E.rut) && sug.length === 1 && limpia(sug[0].rut) === q;
      const abre = document.activeElement === campos.rut && E.tipo === 'factura' && !E.emitido && sug.length && !exacta;
      lista.textContent = '';
      if (!abre) { lista.hidden = true; campos.rut.setAttribute('aria-expanded', 'false'); campos.rut.removeAttribute('aria-activedescendant'); activa = -1; return; }
      sug.forEach((e, i) => {
        const li = h('li'); li.id = 'ei-sug-' + i; li.setAttribute('role', 'option'); li.setAttribute('aria-selected', String(i === activa));
        const r = h('span', 'ei-sug-r'), f = formatea(e.rut);
        // lo ya escrito va en negrita: se ve por qué esta empresa coincide
        const n = (q.match(/./g) || []).length; let marcados = 0, corte = 0;
        for (let k = 0; k < f.length && marcados < n; k++) { if (/[0-9K]/.test(f[k])) marcados++; corte = k + 1; }
        if (n) { const b = h('b', '', f.slice(0, corte)); r.append(b, document.createTextNode(f.slice(corte))); } else r.textContent = f;
        li.append(h('span', 'ei-sug-n', e.razon), r, h('span', 'ei-sug-g', e.giro));
        li.addEventListener('pointerdown', ev => { ev.preventDefault(); elige(e); });
        lista.appendChild(li);
      });
      lista.hidden = false;
      campos.rut.setAttribute('aria-expanded', 'true');
      if (activa >= 0) campos.rut.setAttribute('aria-activedescendant', 'ei-sug-' + activa); else campos.rut.removeAttribute('aria-activedescendant');
    }
    function cierraLista() { activa = -1; lista.hidden = true; lista.textContent = ''; campos.rut.setAttribute('aria-expanded', 'false'); }
    function elige(emp) {
      E.rut = formatea(emp.rut); campos.rut.value = E.rut;
      activa = -1; completa(emp); pintaHoja(); actualiza(); pintaLista();
    }

    /* ── las empresas guardadas, como etiquetas ─────────────────────────── */
    function pintaChips(anima) {
      chips.textContent = '';
      if (!empresas.length) {
        const p = h('p'); p.append('Aún no hay empresas guardadas: emite una factura y quedará aquí. ');
        const b = h('button', '', 'Cargar los ejemplos'); b.type = 'button';
        b.addEventListener('click', () => { empresas = clona(op.ejemplos); escribeAlmacen(); pintaChips(true); actualiza(); });
        p.appendChild(b); chips.appendChild(p); return;
      }
      chips.appendChild(h('span', 'ei-gt', 'Guardadas'));
      empresas.forEach((e, i) => {
        const c = h('span', 'ei-chip'); c.dataset.rut = e.rut;
        if (!anima || i) c.style.animation = 'none';
        const t = h('button', '', e.razon); t.type = 'button'; t.title = e.razon + ' · ' + e.rut;
        t.setAttribute('aria-label', 'Usar ' + e.razon + ', RUT ' + e.rut);
        t.addEventListener('click', () => { if (!E.emitido) { elige(e); campos.rut.focus(); } });
        const x = h('button', 'ei-quita'); x.type = 'button'; x.innerHTML = ICONO_X; x.setAttribute('aria-label', 'Olvidar ' + e.razon);
        x.addEventListener('click', () => { empresas = empresas.filter(k => k !== e); escribeAlmacen(); pintaChips(); actualiza(); pintaLista(); });
        c.append(t, x); chips.appendChild(c);
      });
    }

    /* ── emitir ─────────────────────────────────────────────────────────── */
    function bloquea(b) { ['rut', 'razon', 'giro', 'dir', 'correo'].forEach(k => { campos[k].readOnly = b; }); guarda.disabled = b; }
    function emite() {
      if (E.emitido || falta()) return false;
      E.emitido = true; E.emitidoTipo = E.tipo;
      ['razon', 'giro', 'dir', 'correo'].forEach(cancela);
      let nota = '';
      const empresa = E.tipo === 'factura' ? { rut: formatea(E.rut), razon: E.razon.trim(), giro: E.giro.trim(), dir: E.dir.trim() } : null;
      if (empresa && E.guardar) {
        const i = empresas.findIndex(e => limpia(e.rut) === limpia(empresa.rut));
        if (i >= 0) { const igual = ['razon', 'giro', 'dir'].every(k => empresas[i][k] === empresa[k]); empresas[i] = empresa; nota = igual ? ' · la empresa ya estaba guardada' : ' · datos de la empresa actualizados'; } else { empresas.unshift(empresa); nota = ' · empresa guardada para la próxima'; }
        escribeAlmacen(); pintaChips(true);
      }
      bloquea(true); cierraLista();
      hoja.classList.add('es-emitida', 'es-golpe');
      setTimeout(() => hoja.classList.remove('es-golpe'), 480);
      raiz.dataset.emitido = E.tipo + '-' + folioTxt(E.tipo);
      actualiza();
      const correo = E.tipo === 'boleta' && E.correo.trim() ? ' · enviada a ' + E.correo.trim() : '';
      textoAviso((E.tipo === 'factura' ? 'Factura' : 'Boleta') + ' n.º ' + folioTxt(E.tipo) + ' emitida' + nota + correo, 'bien', true);
      if (op.alEmitir) op.alEmitir({ tipo: E.tipo, folio: E.folio[E.tipo], empresa });
      return true;
    }
    // empezar otro documento: el folio de lo emitido avanza y los campos quedan vacíos
    function nuevo() {
      if (E.emitido) E.folio[E.emitidoTipo]++;
      E.emitido = false; E.emitidoTipo = null;
      ['razon', 'giro', 'dir', 'correo'].forEach(cancela);
      E.rut = E.razon = E.giro = E.dir = E.correo = '';
      ['rut', 'razon', 'giro', 'dir', 'correo'].forEach(k => { campos[k].value = ''; });
      bloquea(false);
      hoja.classList.remove('es-emitida', 'es-golpe');
      delete raiz.dataset.emitido;
      pintaTitulo(E.tipo); pintaHoja(); actualiza();
    }

    /* ── los eventos ────────────────────────────────────────────────────── */
    radios.forEach((r, i) => {
      r.addEventListener('click', () => ponTipo(r.dataset.v));
      r.addEventListener('keydown', ev => {
        const d = ev.key === 'ArrowRight' || ev.key === 'ArrowDown' ? 1 : ev.key === 'ArrowLeft' || ev.key === 'ArrowUp' ? -1 : 0;
        if (!d) return;
        ev.preventDefault(); const sig = radios[(i + d + radios.length) % radios.length]; ponTipo(sig.dataset.v); sig.focus();
      });
    });

    // el RUT: formato en vivo con el cursor en su sitio, y la empresa guardada si coincide
    campos.rut.addEventListener('input', () => {
      const el = campos.rut, pos = el.selectionStart == null ? el.value.length : el.selectionStart;
      const antes = (el.value.slice(0, pos).toUpperCase().match(/[0-9K]/g) || []).length;
      const f = formatea(el.value);
      el.value = f; E.rut = f;
      let n = 0, i = 0; while (i < f.length && n < antes) { if (/[0-9K]/.test(f[i])) n++; i++; }
      if (document.activeElement === el) el.setSelectionRange(i, i);
      activa = -1;
      const emp = valida(f) ? buscaPorRut(f) : null;
      if (emp) completa(emp);
      pintaHoja(); actualiza(); pintaLista();
    });
    campos.rut.addEventListener('focus', () => { marca('rut', true); pintaLista(); });
    campos.rut.addEventListener('blur', () => { marca('rut', false); cierraLista(); });
    campos.rut.addEventListener('keydown', ev => {
      if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
        if (lista.hidden) { pintaLista(); if (lista.hidden) return; }
        ev.preventDefault();
        activa = lim(activa + (ev.key === 'ArrowDown' ? 1 : -1), 0, sug.length - 1);
        pintaLista();
      } else if (ev.key === 'Enter' && !lista.hidden && activa >= 0) { ev.preventDefault(); elige(sug[activa]); }
      else if (ev.key === 'Escape' && !lista.hidden) { ev.preventDefault(); ev.stopPropagation(); cierraLista(); }
    });

    ['razon', 'giro', 'dir', 'correo'].forEach(k => {
      campos[k].addEventListener('input', () => { cancela(k); E[k] = campos[k].value; pintaHoja(); actualiza(); });
      campos[k].addEventListener('focus', () => marca(k, true));
      campos[k].addEventListener('blur', () => marca(k, false));
    });
    // el dato que se está escribiendo se marca también en la hoja
    function marca(k, on) { const f = hoja.querySelector('[data-c="' + k + '"]'); if (f) f.classList.toggle('es-foco', on); }

    $('[data-a-factura]').addEventListener('click', () => { ponTipo('factura'); campos.rut.focus(); });
    guarda.addEventListener('change', () => { E.guardar = guarda.checked; });
    form.addEventListener('submit', ev => { ev.preventDefault(); if (E.emitido) { nuevo(); campos[E.tipo === 'factura' ? 'rut' : 'correo'].focus(); } else emite(); });

    /* ── el timbre de la hoja: barras de una semilla fija ──────────────── */
    (function () {
      const svg = $('[data-codigo]'), r = mulberry32(802);
      let x = 0, d = '';
      while (x < 236) { const w = 1 + Math.floor(r() * 3), g = 1 + Math.floor(r() * 2.4); d += 'M' + x + ' 0h' + w + 'v34h-' + w + 'z'; x += w + g; }
      const p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', d); svg.appendChild(p);
    })();

    // arranque: boleta, las empresas del almacén y la hoja vacía
    aplicaTipo('boleta', true);
    pintaChips(); pintaHoja(); actualiza();

    return {
      tipo: ponTipo,
      rut: t => { ponTipo('factura'); campos.rut.value = ''; campos.rut.focus(); campos.rut.value = t; campos.rut.dispatchEvent(new Event('input')); },
      emite, nuevo,
      empresas: () => clona(empresas),
      restablece: () => { empresas = clona(op.ejemplos); escribeAlmacen(); pintaChips(true); actualiza(); },
      estado: () => ({ tipo: E.tipo, rut: E.rut, razon: E.razon, giro: E.giro, dir: E.dir, correo: E.correo, emitido: E.emitido, folio: Object.assign({}, E.folio) }),
    };
  }

  Emisor.dv = dv;
  Emisor.valida = valida;
  Emisor.formatea = formatea;
  window.Emisor = Emisor;
  document.querySelectorAll('[data-emisor]').forEach(el => { window.emisor = Emisor(el); });
})();
