# Créditos de las fotos · Desfile

Las fotos de `img/` son de [Unsplash](https://unsplash.com) (licencia
Unsplash: uso gratuito, sin atribución obligatoria) y se incluyen solo como
material de demostración: reemplázalas por las tuyas. Sin rostros ni marcas.

| Archivo | Autor | Foto |
|---|---|---|
| `img/arq-blanco-v.jpg` | Joel Filipe | https://unsplash.com/es/fotos/edificio-de-cemento-moderno-blanco-bajo-cielo-azul-RFDP7_80v5A |
| `img/arq-contrapicado.jpg` | Massimiliano Morosinotto | https://unsplash.com/es/fotos/fotografia-de-contrapicado-de-edificios-YMPUJexvNa8 |
| `img/arq-curvo.jpg` | Pascal Meier | https://unsplash.com/es/fotos/una-foto-en-blanco-y-negro-de-un-edificio-curvo-wGuw8HoJ1bE |
| `img/arq-hormigon.jpg` | Simone Hutsch | https://unsplash.com/es/fotos/fotografia-de-paisaje-de-un-edificio-de-hormigon-gris-XK0faa4_mCQ |
| `img/arq-copenhague-v.jpg` | Joakim Nådell | https://unsplash.com/es/fotos/arquitectura-de-las-torres-axel-en-copenhague-K67sBVqLLuw |
| `img/escalera.jpg` | Masjid MABA | https://unsplash.com/es/fotos/una-escalera-en-un-edificio-MsCipqna2bM |
| `img/torre.jpg` | Ricardo Gomez Angel | https://unsplash.com/es/fotos/fotografia-de-arquitectura-de-gray-building-KRVXMkiTc7U |
| `img/carretera-desierto.jpg` | Andrew Svk | https://unsplash.com/es/fotos/un-camino-vacio-en-medio-de-un-desierto-1cD6Dm7VcgA |
