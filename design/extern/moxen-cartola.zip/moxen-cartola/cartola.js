/* =====================================================================
   Cartola · Moxen
   La cartola de lo que te deben: una fila por cliente y tres columnas por antigüedad (0–30, 31–60 y más de 60 días), con cada
   documento pendiente como una ficha. A la vista se ve desde cuándo se debe: lo viejo se vuelve rojo. Aquí no hay montos: es la
   lista de documentos, su antigüedad y su estado. Lo que hace de verdad:

   · La antigüedad es una resta de fechas: los días entre la emisión y «hoy» (aquí, un viernes 23 de octubre de 2026, fijo para que
     la página y el vídeo coincidan), con aritmética de calendario propia y sin Date. Un documento cae en el tramo de 0 a 30 días si
     tiene hasta 30, en el de 31 a 60 si tiene de 31 a 60 y en el de más de 60 desde los 61. El día 30 y el 31, y el 60 y el 61, caen
     en tramos distintos, y el documento de hoy (0 días) cae en el primero.
   · El estado sale de la fecha de vencimiento: «Por vencer» si vence hoy o después y «Vencido» si ya pasó; «En disputa» es una marca
     que se pone y se quita con el botón del detalle (y gana sobre las otras dos). La antigüedad y el estado son independientes: un
     documento reciente puede estar vencido (plazo corto) y uno de 50 días, por vencer (plazo largo).
   · Los filtros son dos y se combinan: por estado (los cuatro botones de arriba) y por cliente (tocar un nombre lo aísla; tocarlo de
     nuevo, o la etiqueta de arriba, lo suelta). Lo que no cumple se apaga en su lugar, sin mover nada, y deja de poder tocarse. Las
     cifras de cada tramo, de cada cliente y de cada estado se recalculan siempre desde los documentos.
   · «Exportar CSV» descarga de verdad lo que se ve (una fila por documento, de más viejo a más nuevo, con su tramo y su estado).
   · Teclado: Tab recorre los filtros, los clientes y los documentos; Intro o Espacio eligen; Esc suelta el documento elegido.

   Montaje (se inicia solo sobre [data-cartola]; el HTML de la demo es la plantilla):
     const c = Cartola(document.querySelector('[data-cartola]'), { hoy: '2026-10-23', clientes: CLIENTES, documentos: DOCUMENTOS,
                                                                  alExportar: ({ csv, filas }) => {} });
     c.estado();  c.filtra({ estado: 'vencido', cliente: 'c1' });  c.elige(5040);  c.disputa(5040);  c.csv();
   Cartola.nucleo expone el cálculo sin interfaz: edadDe(emision, hoy), tramoDe(edad), estadoDe(doc, hoy, enDisputa).
   Qué cambia qué: CLIENTES y DOCUMENTOS (arriba de este archivo) son todo lo que se lee y se exporta; los tramos están en TRAMOS;
   los colores, las variables --ct-* de cartola.css (--ct-azul es lo reciente y --ct-rojo, lo viejo). El tiempo sale de WAAPI,
   setTimeout y transiciones CSS (sin Date). Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';
  const RESORTE = 'cubic-bezier(.34, 1.5, .64, 1)';

  const HOY = '2026-10-23';                               // viernes: la fecha de «hoy» de la demo
  const DIA_CORTO = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
  const MES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  // Los tres tramos de antigüedad (en días desde la emisión). El último no tiene tope.
  const TRAMOS = [
    { id: 't1', hasta: 30,       etq: '0–30 días',       corto: '0–30' },
    { id: 't2', hasta: 60,       etq: '31–60 días',      corto: '31–60' },
    { id: 't3', hasta: Infinity, etq: 'Más de 60 días',  corto: '+60' }
  ];
  const ESTADOS = [
    { id: 'todos',     etq: 'Todos',      ico: '' },
    { id: 'porvencer', etq: 'Por vencer', ico: 'reloj' },
    { id: 'vencido',   etq: 'Vencidos',   ico: 'aviso' },
    { id: 'disputa',   etq: 'En disputa', ico: 'bandera' }
  ];
  const ETQ_ESTADO = { porvencer: 'Por vencer', vencido: 'Vencido', disputa: 'En disputa' };
  // Clientes de ejemplo: razones sociales genéricas e identificadores, nunca empresas reales.
  const CLIENTES = [
    { id: 'c1', nombre: 'Distribuidora Ejemplo' },
    { id: 'c2', nombre: 'Cliente 0412' },
    { id: 'c3', nombre: 'Constructora Ejemplo' },
    { id: 'c4', nombre: 'Cliente 0577' },
    { id: 'c5', nombre: 'Ferretería Ejemplo' },
    { id: 'c6', nombre: 'Cliente 0630' }
  ];
  // Los documentos pendientes: número, tipo, cliente, fecha de emisión y de vencimiento. `disputa: true` los deja en disputa al empezar.
  const DOCUMENTOS = [
    { n: 5040, tipo: 'Factura', c: 'c5', emision: '2026-07-18', vence: '2026-09-16', disputa: true },
    { n: 5044, tipo: 'Factura', c: 'c1', emision: '2026-07-27', vence: '2026-08-26', disputa: true },
    { n: 5046, tipo: 'Factura', c: 'c3', emision: '2026-08-10', vence: '2026-09-24' },
    { n: 5050, tipo: 'Nota de débito', c: 'c3', emision: '2026-08-18', vence: '2026-09-17', disputa: true },
    { n: 5052, tipo: 'Factura', c: 'c6', emision: '2026-08-22', vence: '2026-10-06' },
    { n: 5056, tipo: 'Factura', c: 'c1', emision: '2026-08-23', vence: '2026-10-22' },
    { n: 5058, tipo: 'Factura', c: 'c2', emision: '2026-08-24', vence: '2026-09-23' },
    { n: 5062, tipo: 'Factura', c: 'c3', emision: '2026-08-26', vence: '2026-10-25' },
    { n: 5064, tipo: 'Factura', c: 'c2', emision: '2026-09-01', vence: '2026-10-31' },
    { n: 5068, tipo: 'Factura', c: 'c1', emision: '2026-09-06', vence: '2026-10-21', disputa: true },
    { n: 5070, tipo: 'Nota de débito', c: 'c4', emision: '2026-09-08', vence: '2026-11-07' },
    { n: 5074, tipo: 'Factura', c: 'c5', emision: '2026-09-12', vence: '2026-10-12' },
    { n: 5076, tipo: 'Factura', c: 'c3', emision: '2026-09-18', vence: '2026-10-03' },
    { n: 5080, tipo: 'Factura', c: 'c1', emision: '2026-09-20', vence: '2026-10-20' },
    { n: 5082, tipo: 'Factura', c: 'c4', emision: '2026-09-22', vence: '2026-10-22' },
    { n: 5086, tipo: 'Factura', c: 'c1', emision: '2026-09-23', vence: '2026-10-23' },
    { n: 5088, tipo: 'Factura', c: 'c6', emision: '2026-09-24', vence: '2026-10-24' },
    { n: 5092, tipo: 'Nota de débito', c: 'c1', emision: '2026-09-25', vence: '2026-10-10' },
    { n: 5094, tipo: 'Factura', c: 'c4', emision: '2026-09-29', vence: '2026-10-29' },
    { n: 5098, tipo: 'Factura', c: 'c5', emision: '2026-10-01', vence: '2026-10-16' },
    { n: 5100, tipo: 'Factura', c: 'c2', emision: '2026-10-04', vence: '2026-10-19' },
    { n: 5104, tipo: 'Factura', c: 'c6', emision: '2026-10-08', vence: '2026-11-07', disputa: true },
    { n: 5106, tipo: 'Factura', c: 'c1', emision: '2026-10-11', vence: '2026-11-10' },
    { n: 5110, tipo: 'Factura', c: 'c3', emision: '2026-10-15', vence: '2026-11-14' },
    { n: 5112, tipo: 'Nota de débito', c: 'c5', emision: '2026-10-18', vence: '2026-11-17' },
    { n: 5116, tipo: 'Factura', c: 'c2', emision: '2026-10-23', vence: '2026-11-22' }
  ];

  /* ── el núcleo, sin interfaz: fechas con aritmética de días propia ─── */
  // días desde 1970-01-01 (algoritmo de calendario civil proléptico gregoriano)
  function deCivil(a, m, d) {
    a -= m <= 2 ? 1 : 0;
    const era = Math.floor(a / 400), yoe = a - era * 400;
    const doy = Math.floor((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1;
    return era * 146097 + yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy - 719468;
  }
  const aDias = iso => { const p = iso.split('-'); return deCivil(+p[0], +p[1], +p[2]); };
  const diaSemana = iso => (((aDias(iso) + 4) % 7) + 7) % 7;        // 0 = domingo (el 1 de enero de 1970 fue jueves)
  const corta = iso => { const p = iso.split('-'); return DIA_CORTO[diaSemana(iso)] + ' ' + (+p[2]) + ' ' + MES[+p[1] - 1]; };
  const plural = (n, uno, varios) => n + ' ' + (n === 1 ? uno : varios);

  /* Los días que tiene un documento: de la emisión a hoy. */
  const edadDe = (emision, hoy) => aDias(hoy) - aDias(emision);
  /* El tramo (0, 1 o 2): hasta 30 días, hasta 60 o más. */
  const tramoDe = edad => TRAMOS.findIndex(t => edad <= t.hasta);
  /* Por vencer si vence hoy o después, vencido si ya pasó; la disputa gana sobre las dos. */
  const estadoDe = (doc, hoy, enDisputa) => enDisputa ? 'disputa' : doc.vence >= hoy ? 'porvencer' : 'vencido';
  const ICO = id => '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#ct-i-' + id + '"/></svg>';
  const ICONO_ESTADO = { porvencer: 'reloj', vencido: 'aviso', disputa: 'bandera' };
  const csvCelda = v => /[",\r\n]/.test(String(v)) ? '"' + String(v).replace(/"/g, '""') + '"' : String(v);

  function Cartola(raiz, opciones) {
    const op = Object.assign({ hoy: HOY, clientes: CLIENTES, documentos: DOCUMENTOS, alExportar: null }, opciones);
    const el = {
      hoy: $('[data-hoy]', raiz), estados: $('[data-estados]', raiz), quitaCli: $('[data-quita-cli]', raiz), cliT: $('[data-cli-t]', raiz), exporta: $('[data-exporta]', raiz),
      exportaT: $('[data-exporta-t]', raiz), cols: $('[data-cols]', raiz), filas: $('[data-filas]', raiz), nClientes: $('[data-n-clientes]', raiz), detalle: $('[data-detalle]', raiz),
      detT: $('[data-det-t]', raiz), detD: $('[data-det-d]', raiz), hechos: $('[data-hechos]', raiz), hEmi: $('[data-h-emi]', raiz), hVen: $('[data-h-ven]', raiz),
      hAnt: $('[data-h-ant]', raiz), hEst: $('[data-h-est]', raiz), disputa: $('[data-disputa]', raiz), disputaT: $('[data-disputa-t]', raiz), vivo: $('[data-vivo]', raiz)
    };
    const cliente = id => op.clientes.find(c => c.id === id);
    const docs = op.documentos.map(d => Object.assign({}, d, { edad: edadDe(d.emision, op.hoy), tramo: tramoDe(edadDe(d.emision, op.hoy)) }));
    const S = { estado: 'todos', cliente: null, sel: null, disp: new Set(docs.filter(d => d.disputa).map(d => d.n)), flash: false };
    let tFlash = 0;
    const anuncia = t => { el.vivo.textContent = ''; setTimeout(() => { el.vivo.textContent = t; }, 30); };
    el.hoy.textContent = 'Cartola al ' + corta(op.hoy);

    const estadoDoc = d => estadoDe(d, op.hoy, S.disp.has(d.n));
    const cumpleEstado = d => S.estado === 'todos' || estadoDoc(d) === S.estado;
    const cumpleCliente = d => !S.cliente || d.c === S.cliente;
    const visibles = () => docs.filter(d => cumpleEstado(d) && cumpleCliente(d));
    const tramoEtq = d => TRAMOS[d.tramo].etq;

    /* ── el esqueleto: cabeceras de tramo, una fila por cliente y una ficha por documento ─ */
    const colEl = [];
    TRAMOS.forEach((t, i) => {
      const c = h('div', 'ct-col'); c.dataset.t = i;
      c.innerHTML = '<span class="ct-col-e"></span><b class="ct-col-n"></b><span class="ct-col-d"></span><i class="ct-bar"><i></i></i>';
      $('.ct-col-e', c).textContent = t.etq;
      el.cols.append(c); colEl.push(c);
    });
    const filaEl = {}, fichas = {};
    op.clientes.forEach(cl => {
      const fila = h('div', 'ct-fila'); fila.dataset.c = cl.id; fila.setAttribute('role', 'group');
      const b = h('button', 'ct-cl'); b.type = 'button'; b.dataset.cl = cl.id; b.setAttribute('aria-pressed', 'false');
      b.innerHTML = '<span class="ct-cl-n"></span><span class="ct-cl-d"></span>';
      $('.ct-cl-n', b).textContent = cl.nombre;
      b.addEventListener('click', () => filtra({ cliente: S.cliente === cl.id ? null : cl.id }));
      fila.append(b);
      const celdas = TRAMOS.map((t, i) => { const c = h('div', 'ct-celda'); c.dataset.t = i; c.dataset.etq = t.corto + ' días'; fila.append(c); return c; });
      docs.filter(d => d.c === cl.id).sort((a, b) => a.edad - b.edad || a.n - b.n).forEach(d => {
        const f = h('button', 'ct-ficha'); f.type = 'button'; f.dataset.n = d.n; f.dataset.t = d.tramo;
        f.innerHTML = '<span class="ct-f-n"></span><span class="ct-f-e"></span><span class="ct-f-i"></span>';
        $('.ct-f-n', f).textContent = d.n; $('.ct-f-e', f).textContent = d.edad + ' d';
        f.addEventListener('click', () => elige(S.sel === d.n ? null : d.n));
        celdas[d.tramo].append(f); fichas[d.n] = f;
      });
      el.filas.append(fila); filaEl[cl.id] = fila;
    });

    /* ── los botones de estado ─────────────────────────────────────────── */
    const chips = {};
    ESTADOS.forEach(e => {
      const b = h('button', 'ct-chip'); b.type = 'button'; b.dataset.estado = e.id; b.setAttribute('aria-pressed', 'false');
      b.innerHTML = (e.ico ? ICO(e.ico) : '') + '<span></span><b></b>'; $('span', b).textContent = e.etq;
      b.addEventListener('click', () => filtra({ estado: e.id }));
      el.estados.append(b); chips[e.id] = b;
    });

    /* ── filtrar, elegir y marcar ──────────────────────────────────────── */
    function filtra(f) {
      const antes = S.estado + '|' + S.cliente;
      if (f.estado != null && ESTADOS.some(e => e.id === f.estado)) S.estado = f.estado;
      if (f.cliente !== undefined) S.cliente = f.cliente && cliente(f.cliente) ? f.cliente : null;
      if (S.estado + '|' + S.cliente === antes) return false;
      if (S.sel != null) { const d = docs.find(x => x.n === S.sel); if (!cumpleEstado(d) || !cumpleCliente(d)) S.sel = null; }
      pinta(true);
      const n = visibles().length;
      anuncia(plural(n, 'documento', 'documentos') + (S.cliente ? ' de ' + cliente(S.cliente).nombre : '') + (S.estado !== 'todos' ? ', ' + ESTADOS.find(e => e.id === S.estado).etq.toLowerCase() : '') + '.');
      return true;
    }
    function elige(n) {
      if (n == null) { if (S.sel == null) return false; S.sel = null; pinta(); return true; }
      const d = docs.find(x => x.n === n);
      if (!d || !cumpleEstado(d) || !cumpleCliente(d)) return false;
      S.sel = n; pinta();
      return true;
    }
    function disputa(n) {
      const d = docs.find(x => x.n === (n != null ? n : S.sel));
      if (!d) return false;
      if (S.disp.has(d.n)) S.disp.delete(d.n); else S.disp.add(d.n);
      if (S.sel === d.n && !cumpleEstado(d)) S.sel = null;       // si el filtro ya no lo deja ver, se suelta
      pinta(true);
      anuncia('Documento ' + d.n + (S.disp.has(d.n) ? ' en disputa.' : ': disputa quitada.'));
      return true;
    }
    el.disputa.addEventListener('click', () => disputa());
    el.quitaCli.addEventListener('click', () => filtra({ cliente: null }));
    raiz.addEventListener('keydown', e => { if (e.key === 'Escape' && S.sel != null) { S.sel = null; pinta(); } });

    /* ── el CSV: lo que se ve, de más viejo a más nuevo ────────────────── */
    function filasCsv() {
      return visibles().slice().sort((a, b) => b.edad - a.edad || a.n - b.n).map(d => [d.n, d.tipo, cliente(d.c).nombre, d.emision, d.vence, d.edad, tramoEtq(d), ETQ_ESTADO[estadoDoc(d)]]);
    }
    function csv() {
      const cab = ['documento', 'tipo', 'cliente', 'emision', 'vencimiento', 'antiguedad_dias', 'tramo', 'estado'];
      return [cab].concat(filasCsv()).map(f => f.map(csvCelda).join(',')).join('\r\n');
    }
    function exporta() {
      const filas = filasCsv();
      if (!filas.length) return false;
      const texto = csv();
      const blob = new Blob(['﻿' + texto], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob), a = document.createElement('a');
      a.href = url; a.download = 'cartola.csv'; document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      S.flash = true; clearTimeout(tFlash); tFlash = setTimeout(() => { S.flash = false; pintaExporta(); }, 1700);
      pintaExporta(); anuncia('Cartola exportada: ' + plural(filas.length, 'documento', 'documentos') + '.');
      if (op.alExportar) op.alExportar({ csv: texto, filas: filas.length });
      return true;
    }
    el.exporta.addEventListener('click', exporta);
    function pintaExporta() {
      const n = visibles().length;
      el.exporta.setAttribute('aria-disabled', n ? 'false' : 'true');
      el.exporta.classList.toggle('es-lista', S.flash);
      $('svg use', el.exporta).setAttribute('href', S.flash ? '#ct-i-tilde' : '#ct-i-bajar');
      el.exportaT.textContent = S.flash ? 'Exportado · ' + plural(n, 'fila', 'filas') : 'Exportar CSV';
    }

    /* ── pintar ───────────────────────────────────────────────────────── */
    const previo = { n: [] };
    function pop(e) { if (!quieto() && e.animate) e.animate([{ transform: 'scale(1.18)' }, { transform: 'none' }], { duration: 460, easing: RESORTE }); }
    function pintaFichas(anima) {
      docs.forEach(d => {
        const f = fichas[d.n], est = estadoDoc(d), v = cumpleEstado(d) && cumpleCliente(d), antes = f.dataset.v;
        f.dataset.e = est; f.dataset.v = v ? '1' : '0';
        f.inert = !v;
        f.classList.toggle('es-sel', S.sel === d.n);
        f.setAttribute('aria-pressed', S.sel === d.n ? 'true' : 'false');
        $('.ct-f-i', f).innerHTML = ICO(ICONO_ESTADO[est]);
        f.setAttribute('aria-label', (d.tipo === 'Factura' ? 'Factura ' : 'Nota de débito ') + d.n + ', ' + cliente(d.c).nombre + ': ' + d.edad + ' días, ' + ETQ_ESTADO[est].toLowerCase());
        if (anima && v && antes === '0' && !quieto() && f.animate) f.animate([{ transform: 'scale(.82)', opacity: .3 }, { transform: 'none', opacity: 1 }], { duration: 520, easing: RESORTE });
      });
    }
    function pintaCols(anima) {
      const vis = visibles(), total = vis.length;
      TRAMOS.forEach((t, i) => {
        const n = vis.filter(d => d.tramo === i).length, c = colEl[i], out = $('.ct-col-n', c);
        const cambio = out.textContent !== String(n);
        out.textContent = n;
        $('.ct-col-d', c).textContent = n === 1 ? 'documento' : 'documentos';
        $('.ct-bar i', c).style.transform = 'scaleX(' + (total ? n / total : 0) + ')';
        c.setAttribute('aria-label', t.etq + ': ' + plural(n, 'documento', 'documentos'));
        if (anima && cambio) pop(out);
      });
      const filasConDocs = op.clientes.filter(cl => vis.some(d => d.c === cl.id)).length;
      el.nClientes.textContent = plural(filasConDocs, 'cliente', 'clientes');
    }
    function pintaFilas() {
      op.clientes.forEach(cl => {
        const fila = filaEl[cl.id], b = $('.ct-cl', fila);
        const suyos = docs.filter(d => d.c === cl.id && cumpleEstado(d)), n = suyos.length;
        const viejo = suyos.reduce((m, d) => Math.max(m, d.edad), -1);
        fila.dataset.v = !S.cliente || S.cliente === cl.id ? '1' : '0';
        fila.dataset.vacia = n ? '0' : '1';
        b.setAttribute('aria-pressed', S.cliente === cl.id ? 'true' : 'false');
        $('.ct-cl-d', b).textContent = n ? plural(n, 'documento', 'documentos') + ' · el más viejo, ' + viejo + ' d' : 'sin documentos';
        b.setAttribute('aria-label', cl.nombre + ': ' + (n ? plural(n, 'documento', 'documentos') + ', el más viejo de ' + viejo + ' días' : 'sin documentos') + (S.cliente === cl.id ? ' (aislado)' : ''));
      });
    }
    function pintaChips() {
      ESTADOS.forEach(e => {
        const n = docs.filter(d => cumpleCliente(d) && (e.id === 'todos' || estadoDoc(d) === e.id)).length;
        const b = chips[e.id];
        $('b', b).textContent = n; b.setAttribute('aria-pressed', S.estado === e.id ? 'true' : 'false');
        b.setAttribute('aria-label', e.etq + ': ' + plural(n, 'documento', 'documentos'));
      });
      el.quitaCli.hidden = !S.cliente;
      if (S.cliente) { el.cliT.textContent = cliente(S.cliente).nombre; el.quitaCli.setAttribute('aria-label', 'Quitar el filtro de cliente: ' + cliente(S.cliente).nombre); }
    }
    function pintaDetalle() {
      const d = S.sel != null ? docs.find(x => x.n === S.sel) : null;
      el.detalle.dataset.modo = d ? 'doc' : 'resumen';
      el.hechos.hidden = !d; el.disputa.hidden = !d;
      if (d) {
        const est = estadoDoc(d), dv = aDias(d.vence) - aDias(op.hoy);
        el.detalle.dataset.e = est;
        el.detT.textContent = d.tipo + ' ' + d.n;
        el.detD.textContent = cliente(d.c).nombre;
        el.hEmi.textContent = corta(d.emision);
        el.hVen.textContent = corta(d.vence) + ' · ' + (dv > 0 ? 'en ' + plural(dv, 'día', 'días') : dv === 0 ? 'vence hoy' : 'hace ' + plural(-dv, 'día', 'días'));
        el.hAnt.textContent = plural(d.edad, 'día', 'días') + ' · tramo ' + TRAMOS[d.tramo].corto;
        el.hEst.textContent = ETQ_ESTADO[est];
        el.disputaT.textContent = S.disp.has(d.n) ? 'Quitar disputa' : 'Marcar en disputa';
      } else {
        const vis = visibles(), viejo = vis.slice().sort((a, b) => b.edad - a.edad || a.n - b.n)[0];
        el.detalle.dataset.e = '';
        if (!vis.length) { el.detT.textContent = 'Sin documentos con este filtro'; el.detD.textContent = 'Cambia el estado o suelta el cliente'; }
        else {
          el.detT.textContent = plural(vis.length, 'documento pendiente', 'documentos pendientes');
          el.detD.textContent = 'El más viejo: ' + viejo.tipo.toLowerCase() + ' ' + viejo.n + ' de ' + cliente(viejo.c).nombre + ', ' + plural(viejo.edad, 'día', 'días') + '. Toca un documento para ver su detalle.';
        }
      }
    }
    function pinta(anima) { pintaFichas(anima); pintaCols(anima); pintaFilas(); pintaChips(); pintaDetalle(); pintaExporta(); }
    function reinicia() {
      clearTimeout(tFlash);
      Object.assign(S, { estado: 'todos', cliente: null, sel: null, disp: new Set(docs.filter(d => d.disputa).map(d => d.n)), flash: false });
      pinta();
    }

    reinicia();
    return {
      filtra, elige, disputa, csv, exporta, reinicia,
      estado: () => {
        const vis = visibles();
        return {
          hoy: op.hoy, estado: S.estado, cliente: S.cliente, seleccion: S.sel,
          documentos: docs.map(d => ({ n: d.n, tipo: d.tipo, cliente: d.c, emision: d.emision, vence: d.vence, edad: d.edad, tramo: d.tramo, estado: estadoDoc(d), visible: cumpleEstado(d) && cumpleCliente(d) })),
          porTramo: TRAMOS.map((_, i) => vis.filter(d => d.tramo === i).length),
          porCliente: Object.fromEntries(op.clientes.map(cl => [cl.id, TRAMOS.map((_, i) => vis.filter(d => d.c === cl.id && d.tramo === i).length)])),
          porEstado: Object.fromEntries(ESTADOS.map(e => [e.id, docs.filter(d => cumpleCliente(d) && (e.id === 'todos' || estadoDoc(d) === e.id)).length])),
          total: vis.length
        };
      }
    };
  }
  Cartola.nucleo = { edadDe, tramoDe, estadoDe, aDias, corta, TRAMOS, HOY };
  window.Cartola = Cartola;

  const raiz = $('[data-cartola]');
  if (raiz) raiz.__cartola = window.cartola = Cartola(raiz);
})();
