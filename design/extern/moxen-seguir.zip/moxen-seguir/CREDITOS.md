# Créditos de las fotos · Seguir

Las fotos de `img/` son de [Unsplash](https://unsplash.com) (licencia
Unsplash: uso gratuito, sin atribución obligatoria) y se incluyen solo como
material de demostración: reemplázalas por las tuyas. Sin rostros ni marcas.

| Archivo | Autor | Foto |
|---|---|---|
| `img/arq-curvo.jpg` | Pascal Meier | https://unsplash.com/es/fotos/una-foto-en-blanco-y-negro-de-un-edificio-curvo-wGuw8HoJ1bE |
