# Pregón · Moxen

Escribes el título y la descripción y tres tarjetas (chat, red social y correo) se reescriben a la vez, letra a letra, cada una con su propio recorte y un anillo de caracteres que pasa de azul a ámbar. Arrastras un punto focal sobre la imagen y las tres miniaturas se recomponen con resorte a su proporción; una lista se marca con ✓ y «Copiar etiquetas» entrega el bloque meta.

## Qué trae

- `index.html` — la demostración
- `pregon.css`
- `pregon.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `pregon.css` y `pregon.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Type a title and description and three cards (chat, social network and email) rewrite themselves at once, letter by letter, each with its own crop and a character ring that goes from blue to amber. Drag a focal point over the image and the three thumbnails recompose on a spring to their own ratio; a checklist ticks itself off and “Copy tags” hands over the meta block.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
