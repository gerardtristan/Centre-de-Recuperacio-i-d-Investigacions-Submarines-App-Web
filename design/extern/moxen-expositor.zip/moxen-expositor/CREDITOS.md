# Créditos de las fotos · Expositor

Las fotos de `img/` son de [Unsplash](https://unsplash.com) (licencia
Unsplash: uso gratuito, sin atribución obligatoria) y se incluyen solo como
material de demostración: reemplázalas por las tuyas. Sin rostros ni marcas.

| Archivo | Autor | Foto |
|---|---|---|
| `img/cer-cuenco-v.jpg` | Frédéric Dupont | https://unsplash.com/es/fotos/cuenco-de-ceramica-blanca-y-marron-X2TRduCQgOQ |
| `img/cer-azul.jpg` | 五玄土 ORIENTO | https://unsplash.com/es/fotos/fotografia-de-jarron-de-ceramica-azul-sobre-fondo-blanco-l0ah3UBLppo |
| `img/vasijas.jpg` | Tamara Harhai | https://unsplash.com/es/fotos/un-par-de-jarrones-sentados-encima-de-una-mesa-tSkPbVkiCqY |
| `img/jarron.jpg` | Anton Sukhinov | https://unsplash.com/es/fotos/jarron-de-ceramica-marron-sobre-mantel-blanco-y-negro-4GvsTa3Y-5I |
| `img/bodegon.jpg` | Harper Sunday | https://unsplash.com/es/fotos/una-mesa-cubierta-con-vasos-y-una-botella-de-liquido-o09l6wRwIX8 |
| `img/marmol.jpg` | Madison Bracaglia | https://unsplash.com/es/fotos/superficie-de-marmol-blanco-con-vetas-grises-fcWAwPKpkTU |
| `img/jarron-naranja.jpg` | Cindy Bartillon | https://unsplash.com/es/fotos/un-jarron-naranja-sentado-sobre-una-mesa-blanca-THtfRdrK0nI |
