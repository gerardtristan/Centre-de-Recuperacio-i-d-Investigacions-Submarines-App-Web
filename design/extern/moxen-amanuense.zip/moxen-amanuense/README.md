# Amanuense · Moxen

Mantén el micrófono y lo que dices entra en el campo en vivo: lo provisional en gris, que el reconocedor corrige solo, y lo definitivo en tinta, con «coma», «punto» y «nuevo párrafo» convertidos en signos. Al soltar, las palabras dudosas quedan subrayadas a puntos con sus alternativas, «Deshacer dictado» borra solo lo último y, sin permiso o sin soporte, suena una voz de ejemplo.

## Qué trae

- `index.html` — la demostración
- `amanuense.css`
- `amanuense.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `amanuense.css` y `amanuense.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Hold the microphone and what you say flows into the field live: provisional text in gray, which the recognizer corrects by itself, then final text in ink, with “comma”, “period” and “new paragraph” turned into marks. On release, doubtful words are dotted-underlined with their alternatives, “Undo dictation” removes only the last take and, without permission or support, a sample voice plays instead.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
