/* =====================================================================
   Marcador · Moxen
   Guardar con una cinta de marcapáginas de tela. Al guardar, la cinta
   se suelta desde el canto de la tarjeta y cae con su peso: se estira,
   rebota, se balancea y se asienta, y la tinta la empapa de arriba
   abajo. Al quitarlo, se vacía y se enrolla hacia arriba.

     const m = Marcador(document.querySelector('.mc-boton'), { hecho: 'Guardado' });
     m.guarda();      m.quita();      m.alterna();

   La cinta es una cadena de puntos con física de Verlet (cada punto
   recuerda dónde estaba y la gravedad tira de él; unas restricciones
   mantienen la distancia entre vecinos). La restricción no es del todo
   rígida: por eso la tela da de sí al frenar y rebota. Se dibuja en un
   canvas, con el canutillo de la tela, su sombra y la muesca en V.
   ===================================================================== */
(function () {
  'use strict';

  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const N = 13;                   // puntos de la cadena
  const PASO = 1 / 120;
  const GRAVEDAD = 1900;

  function Marcador(boton, opciones) {
    const o = Object.assign({
      hecho: boton.dataset.hecho || 'Guardado',
      colgado: boton.closest('[data-marcador-tarjeta]') || boton,   // de qué cuelga la cinta
      ancho: 38,       // px de la cinta
      largo: 176,      // px que mide desplegada
      recogida: 14,    // px que asoma cuando no está guardado
      margen: 58,      // px desde el canto derecho
    }, opciones);

    /* ── el botón: el ícono y las dos palabras, una encima de otra ──── */
    const palabra = Array.from(boton.childNodes).find(n => n.nodeType === 3 && n.textContent.trim());
    const texto = document.createElement('span');
    texto.className = 'mc-texto';
    texto.innerHTML = '<span></span><span></span>';
    texto.firstChild.textContent = palabra ? palabra.textContent.trim() : 'Guardar';
    texto.lastChild.textContent = o.hecho;
    if (palabra) palabra.replaceWith(texto); else boton.appendChild(texto);
    boton.setAttribute('aria-pressed', 'false');

    /* ── la cinta ────────────────────────────────────────────────────── */
    const lienzo = document.createElement('canvas');
    lienzo.className = 'mc-cinta';
    lienzo.setAttribute('aria-hidden', 'true');
    o.colgado.appendChild(lienzo);
    const g = lienzo.getContext('2d');
    const css = getComputedStyle(o.colgado);
    const lee = (n, d) => (css.getPropertyValue(n) || d).trim();
    const C = { tela: lee('--mc-tela', 'rgba(255,255,255,.2)'), tinta: lee('--mc-tinta', '#f4f4f4'), hilo: lee('--mc-hilo', 'rgba(0,0,0,.12)') };
    const LW = 150, LH = o.largo + 70, AX = LW / 2, AY = 12;   // el ancla, dentro del lienzo
    function mide() {
      const k = Math.min(2, devicePixelRatio || 1);
      lienzo.width = LW * k; lienzo.height = LH * k;
      lienzo.style.width = LW + 'px'; lienzo.style.height = LH + 'px';
      lienzo.style.right = (o.margen - LW / 2) + 'px';
      g.setTransform(k, 0, 0, k, 0, 0);
    }
    mide();

    const px = new Float32Array(N), py = new Float32Array(N), qx = new Float32Array(N), qy = new Float32Array(N);
    let tramo = o.recogida / (N - 1), metaTramo = tramo;
    for (let i = 0; i < N; i++) { px[i] = qx[i] = AX; py[i] = qy[i] = AY + i * tramo; }
    let tinta = 0, metaTinta = 0, guardado = false, raf = 0, ultimo = null, reposo = 0;

    function simula(h) {
      // el largo de cada tramo persigue su meta: así se enrolla o se suelta
      tramo += (metaTramo - tramo) * Math.min(1, h * (metaTramo > tramo ? 40 : 9));
      for (let i = 1; i < N; i++) {
        const vx = (px[i] - qx[i]) * .992, vy = (py[i] - qy[i]) * .992;   // un poco de aire
        qx[i] = px[i]; qy[i] = py[i];
        px[i] += vx; py[i] += vy + GRAVEDAD * h * h;
      }
      // tres pasadas de restricciones, al 85 %: la tela da un poco de sí
      for (let k = 0; k < 3; k++) {
        px[0] = AX; py[0] = AY;
        for (let i = 1; i < N; i++) {
          const dx = px[i] - px[i - 1], dy = py[i] - py[i - 1], d = Math.hypot(dx, dy) || 1e-4;
          if (d <= tramo) continue;              // una tela no empuja: solo tira
          const f = (d - tramo) / d * .85;
          if (i === 1) { px[i] -= dx * f; py[i] -= dy * f; }
          else { px[i] -= dx * f * .5; py[i] -= dy * f * .5; px[i - 1] += dx * f * .5; py[i - 1] += dy * f * .5; }
        }
      }
      tinta += Math.sign(metaTinta - tinta) * Math.min(Math.abs(metaTinta - tinta), h * 1.8);
    }

    // la cinta como polígono: los dos cantos a media anchura de la línea central
    function cantos() {
      const izq = [], der = [], w = o.ancho / 2;
      for (let i = 0; i < N; i++) {
        const a = Math.max(0, i - 1), b = Math.min(N - 1, i + 1);
        let tx = px[b] - px[a], ty = py[b] - py[a];
        const l = Math.hypot(tx, ty) || 1; tx /= l; ty /= l;
        izq.push([px[i] - ty * w, py[i] + tx * w]); der.push([px[i] + ty * w, py[i] - tx * w]);
      }
      return { izq, der };
    }

    function dibuja() {
      g.clearRect(0, 0, LW, LH);
      const { izq, der } = cantos();
      const total = tramo * (N - 1);
      const pico = Math.min(13, total * .45);
      // la punta: la muesca en V entra hacia dentro desde el último punto
      const ux = px[N - 1] - px[N - 2], uy = py[N - 1] - py[N - 2], ul = Math.hypot(ux, uy) || 1;
      const muesca = [px[N - 1] - ux / ul * pico, py[N - 1] - uy / ul * pico];
      const forma = () => {
        g.beginPath();
        g.moveTo(izq[0][0], izq[0][1]);
        for (let i = 1; i < N; i++) g.lineTo(izq[i][0], izq[i][1]);
        g.lineTo(muesca[0], muesca[1]);
        for (let i = N - 1; i >= 0; i--) g.lineTo(der[i][0], der[i][1]);
        g.closePath();
      };
      // la sombra sobre la tarjeta
      g.save();
      g.shadowColor = 'rgba(0, 0, 0, .45)'; g.shadowBlur = 10; g.shadowOffsetX = 3; g.shadowOffsetY = 5;
      forma(); g.fillStyle = C.tela; g.fill();
      g.restore();
      forma(); g.fillStyle = C.tela; g.fill();
      // la tinta: empapa desde arriba hasta «tinta» del largo
      if (tinta > 0) {
        g.save(); forma(); g.clip();
        const hasta = AY + (total + pico) * tinta;
        g.beginPath();
        // un borde de tinta algo ondulado, como algo que se empapa
        g.moveTo(0, 0); g.lineTo(LW, 0); g.lineTo(LW, hasta);
        for (let x = LW; x >= 0; x -= 6) g.lineTo(x, hasta + Math.sin(x * .3 + tinta * 9) * 2.2);
        g.closePath();
        g.fillStyle = C.tinta; g.fill();
        g.restore();
      }
      // el canutillo: hilos paralelos al largo, y los cantos un poco más oscuros
      g.save(); forma(); g.clip();
      g.strokeStyle = C.hilo; g.lineWidth = 1;
      for (const f of [-.66, -.33, 0, .33, .66]) {
        g.beginPath();
        for (let i = 0; i < N; i++) {
          const x = izq[i][0] + (der[i][0] - izq[i][0]) * (.5 + f / 2), y = izq[i][1] + (der[i][1] - izq[i][1]) * (.5 + f / 2);
          i ? g.lineTo(x, y) : g.moveTo(x, y);
        }
        g.stroke();
      }
      const borde = g.createLinearGradient(AX - o.ancho / 2, 0, AX + o.ancho / 2, 0);
      borde.addColorStop(0, 'rgba(0,0,0,.22)'); borde.addColorStop(.2, 'rgba(0,0,0,0)');
      borde.addColorStop(.8, 'rgba(0,0,0,0)'); borde.addColorStop(1, 'rgba(0,0,0,.26)');
      g.fillStyle = borde; g.fillRect(0, 0, LW, LH);
      // el doblez del canto: la tela sale de detrás de la tarjeta
      const doblez = g.createLinearGradient(0, AY - 2, 0, AY + 12);
      doblez.addColorStop(0, 'rgba(0,0,0,.45)'); doblez.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = doblez; g.fillRect(0, 0, LW, AY + 12);
      g.restore();
    }

    function paso(ts) {
      if (ultimo === null) ultimo = ts;
      const dt = Math.min(1 / 30, (ts - ultimo) / 1000);
      ultimo = ts;
      for (let t = dt; t > 1e-6; t -= PASO) simula(PASO);
      dibuja();
      // ¿quieta? la velocidad de todos los puntos, casi nula durante medio segundo
      let v = 0;
      for (let i = 1; i < N; i++) v += Math.abs(px[i] - qx[i]) + Math.abs(py[i] - qy[i]);
      reposo = v < .02 && tinta === metaTinta && Math.abs(tramo - metaTramo) < .01 ? reposo + dt : 0;
      if (reposo > .5) { raf = 0; ultimo = null; return; }
      raf = requestAnimationFrame(paso);
    }
    const anda = () => { if (!raf) raf = requestAnimationFrame(paso); };

    let espera = 0;
    function guarda() {
      if (guardado) return;
      guardado = true;
      boton.classList.add('is-guardado');
      boton.setAttribute('aria-pressed', 'true');
      clearTimeout(espera);
      metaTramo = o.largo / (N - 1);
      if (reduce) { tramo = metaTramo; tinta = metaTinta = 1; for (let i = 0; i < N; i++) { px[i] = qx[i] = AX; py[i] = qy[i] = AY + i * tramo; } return dibuja(); }
      // un empujón de lado, hacia dentro de la tarjeta: al caer, se balancea
      for (let i = 1; i < N; i++) qx[i] = px[i] + i / N * 1.6;
      metaTinta = 0;
      espera = setTimeout(() => { if (guardado) { metaTinta = 1; anda(); } }, 420);
      anda();
    }

    function quita() {
      if (!guardado) return;
      guardado = false;
      boton.classList.remove('is-guardado');
      boton.setAttribute('aria-pressed', 'false');
      clearTimeout(espera);
      if (reduce) { tramo = metaTramo = o.recogida / (N - 1); tinta = metaTinta = 0; for (let i = 0; i < N; i++) { px[i] = qx[i] = AX; py[i] = qy[i] = AY + i * tramo; } return dibuja(); }
      metaTinta = 0;
      // primero se vacía; luego se enrolla hacia arriba con un pequeño vaivén
      espera = setTimeout(() => { if (!guardado) { metaTramo = o.recogida / (N - 1); for (let i = 1; i < N; i++) qx[i] = px[i] + i / N * 2; anda(); } }, 380);
      anda();
    }

    const alterna = () => guardado ? quita() : guarda();
    boton.addEventListener('click', alterna);
    dibuja();
    return { guarda, quita, alterna, guardado: () => guardado };
  }

  window.Marcador = Marcador;
})();
