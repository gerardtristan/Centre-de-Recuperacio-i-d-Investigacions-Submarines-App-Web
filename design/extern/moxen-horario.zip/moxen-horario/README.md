# Horario · Moxen

Eliges la sección de cada ramo y, si dos clases se pisan, las horas exactas del choque se rayan en naranja en la semana y el panel te dice qué ramos chocan; antes de tocar una sección, su contorno punteado y una marca avisan si chocaría. Además busca todas las combinaciones sin tope que respetan lo que ya elegiste, las muestra una a una y te deja usar la que prefieras con un toque.

## Qué trae

- `index.html` — la demostración
- `horario.css`
- `horario.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `horario.css` y `horario.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Pick a section for each course and, if two classes overlap, the exact hours of the clash are striped in orange on the week while the panel tells you which courses collide; before you tap a section, its dotted outline and a mark warn you if it would clash. It also finds every clash-free combination that respects what you already chose, shows them one by one and lets you use your favourite with a tap.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
