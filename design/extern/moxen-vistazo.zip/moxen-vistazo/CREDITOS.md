# Créditos de las fotos · Vistazo

Las fotos de `img/` son de [Unsplash](https://unsplash.com) (licencia
Unsplash: uso gratuito, sin atribución obligatoria) y se incluyen solo como
material de demostración: reemplázalas por las tuyas. Sin rostros ni marcas.

| Archivo | Autor | Foto |
|---|---|---|
| `img/montana-niebla.jpg` | Brice Cooper | https://unsplash.com/es/fotos/una-montana-cubierta-de-niebla-con-arboles-en-primer-plano-yj4Jjl2sCL0 |
| `img/mar-aereo.jpg` | Andrzej Kryszpiniuk | https://unsplash.com/es/fotos/vista-aerea-de-las-olas-del-mar-4wFqHZ1ONnM |
| `img/arq-copenhague-v.jpg` | Joakim Nådell | https://unsplash.com/es/fotos/arquitectura-de-las-torres-axel-en-copenhague-K67sBVqLLuw |
| `img/carretera-desierto.jpg` | Andrew Svk | https://unsplash.com/es/fotos/un-camino-vacio-en-medio-de-un-desierto-1cD6Dm7VcgA |
| `img/jarron-naranja.jpg` | Cindy Bartillon | https://unsplash.com/es/fotos/un-jarron-naranja-sentado-sobre-una-mesa-blanca-THtfRdrK0nI |
| `img/niebla-bosque.jpg` | Inggrid Koe | https://unsplash.com/es/fotos/bosque-gris-con-niebla-kbKEuU-YEIw |
