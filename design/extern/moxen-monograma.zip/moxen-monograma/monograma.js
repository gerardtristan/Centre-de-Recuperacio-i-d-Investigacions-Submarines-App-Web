/* =====================================================================
   Monograma · Moxen
   Un generador de avatares abstractos a partir de un texto. El mismo texto da
   siempre la misma imagen: el texto se convierte en una semilla (un hash de 53
   bits) y de ella sale todo con un generador de azar determinista (mulberry32),
   sin ningún azar de verdad.

   · Cuatro estilos, todos SVG dentro de un círculo: «Iniciales» (las letras sobre
     un degradado con manchas de luz), «Bloques» (una cuadrícula de 3 × 3 con
     formas redondeadas y simetría), «Ondas» (un sol y cuatro capas de olas) y
     «Mosaico» (una trama simétrica de 5 × 5).
   · Al escribir, el avatar se RECOMPONE EN VIVO: cada estilo describe su imagen como
     una lista de números (posiciones, radios, canales de color) y la transición
     interpola esos números con un rebote y un escalonado: las formas y los tonos
     viajan, no se cortan. Si cambias el texto a mitad de una transición, parte de
     donde estaba.
   · Cambiar de estilo voltea el avatar grande (media vuelta, cambio de estilo,
     media vuelta). «Otra variante» lo sacude y cambia la semilla (texto + número de
     variante); la fila de paletas recolorea el conjunto sin cambiar la forma.
   · «Copiar SVG» y «Descargar» entregan el avatar como un SVG suelto, sin
     dependencias, y se vuelven ✓.

   Cómo se monta (ver index.html):
     <main data-monograma> … </main>
     const m = Monograma(document.querySelector('[data-monograma]'), {
       texto: 'Estudio creativo',    // o el value del campo
       estilo: 'iniciales',          // 'iniciales' | 'bloques' | 'ondas' | 'mosaico'
       paleta: 'durazno',            // 'durazno' | 'niebla' | 'lila'
       otros: ['Equipo Norte', 'Plataforma', 'Estudio Sur', 'Mesa de ayuda'],   // la pila de «En contexto»
       alCambiar: ({ texto, estilo, paleta, variante, semilla }) => {},
     });
     m.svg();                         // el SVG del avatar actual, como texto
     m.pon({ texto: 'Mesa de ayuda', estilo: 'ondas' });

   Qué se personaliza:
   · PALETAS (más abajo): cinco colores por paleta —el principal, uno claro, uno
     profundo, un acento y un pálido— y los tintes del escenario. Los generadores
     eligen colores por posición, así que cambiar una paleta recolorea todo.
   · Cada estilo es un objeto de ESTILOS con crea() (los nodos), gen() (los números
     a partir del azar) y pinta() (números → atributos). Agregar un estilo es
     agregar uno de esos objetos.
   · Los colores de la interfaz están al inicio del CSS. ?tema=oscuro los redefine.
   · Sin dependencias, sin Date y sin azar de verdad.
   ===================================================================== */
(function () {
  'use strict';

  const reduceMQ = matchMedia('(prefers-reduced-motion: reduce)');
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const NS = 'http://www.w3.org/2000/svg';
  const svgEl = (t, at) => { const e = document.createElementNS(NS, t); if (at) Object.keys(at).forEach(k => e.setAttribute(k, at[k])); return e; };
  let contador = 0;

  // un resorte convertido en curva CSS linear(), para el volteo y los rebotes
  function muelle(k, c) {
    if (!(window.CSS && CSS.supports && CSS.supports('animation-timing-function', 'linear(0, 1)'))) return 'cubic-bezier(.34, 1.4, .64, 1)';
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const out = [];
    for (let i = 0; i <= 40; i++) out.push(pts[Math.round(i / 40 * (pts.length - 1))].toFixed(4));
    out[40] = '1';
    return 'linear(' + out.join(', ') + ')';
  }

  /* ── del texto a la semilla: un hash de 53 bits y un generador determinista ─ */
  function cyrb53(str) {
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  }
  function mulberry32(s) {
    return () => {
      s = s + 0x6D2B79F5 | 0;
      let t = Math.imul(s ^ s >>> 15, 1 | s);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const hex = h => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const rgb = c => 'rgb(' + Math.round(lim(c[0], 0, 255)) + ',' + Math.round(lim(c[1], 0, 255)) + ',' + Math.round(lim(c[2], 0, 255)) + ')';
  const lum = c => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]); };
  const TINTA = hex('#231f2b'), BLANCO = hex('#fffdfa');
  const contraste = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
  const ease = t => { const c1 = 1.25, c3 = c1 + 1, u = t - 1; return 1 + c3 * u * u * u + c1 * u * u; };   // easeOutBack: pasa un poco y vuelve

  /* ── las paletas: [principal, claro, profundo, acento, pálido] ────── */
  const PALETAS = {
    durazno: { nombre: 'Durazno', cols: ['#f2a98a', '#f8cdb8', '#e7826d', '#b8a7e8', '#fff1e6'], tinte: { claro: ['#fbe9de', '#f6d6c5'], oscuro: ['#3b2a33', '#4a3340'] } },
    niebla: { nombre: 'Niebla', cols: ['#8fb0e8', '#bcd0f2', '#5f86d6', '#f2a98a', '#eaf1fc'], tinte: { claro: ['#e6eefb', '#d4e1f6'], oscuro: ['#27304a', '#303b5c'] } },
    lila: { nombre: 'Lila', cols: ['#b8a7e8', '#d8cdf3', '#8d79d0', '#8fb0e8', '#f1edfb'], tinte: { claro: ['#eee9fa', '#ddd4f3'], oscuro: ['#32294a', '#3d3358'] } },
  };
  Object.keys(PALETAS).forEach(k => { PALETAS[k].rgb = PALETAS[k].cols.map(hex); });
  const pick = (r, n) => Math.min(n - 1, Math.floor(r() * n));

  /* =====================================================================
     Los estilos. Cada uno devuelve su imagen como una lista de números (gen),
     sabe crear sus nodos (crea) y volcar los números en ellos (pinta).
     retardo(i) dice cuánto espera el número i antes de moverse (escalonado).
     ===================================================================== */
  // un rectángulo de esquinas redondeadas con un radio distinto en cada una (las que no caben se reducen)
  function rr(x, y, s, a, b, c, d) {
    a = lim(a, 0, s); b = lim(b, 0, s); c = lim(c, 0, s); d = lim(d, 0, s);
    const f = Math.min(1, s / Math.max(.001, a + b), s / Math.max(.001, b + c), s / Math.max(.001, c + d), s / Math.max(.001, d + a));
    a *= f; b *= f; c *= f; d *= f;
    const arco = (r, x2, y2) => r > .05 ? 'A' + r.toFixed(2) + ' ' + r.toFixed(2) + ' 0 0 1 ' + x2.toFixed(2) + ' ' + y2.toFixed(2) : 'L' + x2.toFixed(2) + ' ' + y2.toFixed(2);
    return 'M' + (x + a).toFixed(2) + ' ' + y.toFixed(2) + 'H' + (x + s - b).toFixed(2) + arco(b, x + s, y + b) + 'V' + (y + s - c).toFixed(2) + arco(c, x + s - c, y + s) +
      'H' + (x + d).toFixed(2) + arco(d, x, y + s - d) + 'V' + (y + a).toFixed(2) + arco(a, x + a, y) + 'Z';
  }

  const ESTILOS = {
    /* ── Iniciales: un degradado con tres manchas de luz y las letras ── */
    iniciales: {
      n: 31,
      gen(r, pal, letras) {
        const ang = r() * 360, ia = [0, 2, 3, 0, 2][pick(r, 5)], resto = [0, 2, 3, 1, 0, 3].filter(i => i !== ia), ib = resto[pick(r, resto.length)];
        const P = [ang, ...pal[ia], ...pal[ib]];
        for (let k = 0; k < 3; k++) { const c = pal[pick(r, 5)]; P.push(18 + r() * 84, 18 + r() * 84, 30 + r() * 36, c[0], c[1], c[2], .35 + r() * .45); }
        const medio = [(pal[ia][0] + pal[ib][0]) / 2, (pal[ia][1] + pal[ib][1]) / 2, (pal[ia][2] + pal[ib][2]) / 2];
        P.push(...(contraste(TINTA, medio) >= contraste(BLANCO, medio) ? TINTA : BLANCO));
        return P;
      },
      retardo: i => i >= 7 && i < 28 ? .05 + Math.floor((i - 7) / 7) * .07 : 0,
      crea(defs, g, uid) {
        const R = { gr: svgEl('linearGradient', { id: uid + 'g', gradientUnits: 'userSpaceOnUse' }), s0: svgEl('stop', { offset: 0 }), s1: svgEl('stop', { offset: 1 }), blobs: [] };
        R.gr.append(R.s0, R.s1); defs.appendChild(R.gr);
        g.appendChild(svgEl('rect', { width: 120, height: 120, fill: 'url(#' + uid + 'g)' }));
        for (let k = 0; k < 3; k++) {
          const rg = svgEl('radialGradient', { id: uid + 'b' + k }), a = svgEl('stop', { offset: 0 }), b = svgEl('stop', { offset: 1 });
          rg.append(a, b); defs.appendChild(rg);
          const c = svgEl('circle', { fill: 'url(#' + uid + 'b' + k + ')' });
          g.appendChild(c); R.blobs.push({ rg, a, b, c });
        }
        const brillo = svgEl('radialGradient', { id: uid + 'h', cx: .3, cy: .2, r: .7 });
        brillo.innerHTML = '<stop offset="0" stop-color="#fff" stop-opacity=".42"/><stop offset="1" stop-color="#fff" stop-opacity="0"/>';
        defs.appendChild(brillo);
        g.appendChild(svgEl('rect', { width: 120, height: 120, fill: 'url(#' + uid + 'h)' }));
        const t = { 'text-anchor': 'middle', 'dominant-baseline': 'central', 'font-family': "Gabarito, 'Helvetica Neue', Arial, sans-serif", 'font-weight': 700, x: 60, y: 62 };
        R.tA = svgEl('text', t); R.tB = svgEl('text', t);
        g.append(R.tA, R.tB);
        return R;
      },
      pinta(R, P, ex) {
        const a = P[0] * Math.PI / 180, cx = Math.cos(a) * 60, cy = Math.sin(a) * 60;
        R.gr.setAttribute('x1', 60 - cx); R.gr.setAttribute('y1', 60 - cy); R.gr.setAttribute('x2', 60 + cx); R.gr.setAttribute('y2', 60 + cy);
        R.s0.setAttribute('stop-color', rgb(P.slice(1, 4))); R.s1.setAttribute('stop-color', rgb(P.slice(4, 7)));
        R.blobs.forEach((b, k) => {
          const o = 7 + k * 7, col = rgb(P.slice(o + 3, o + 6));
          b.c.setAttribute('cx', P[o].toFixed(2)); b.c.setAttribute('cy', P[o + 1].toFixed(2)); b.c.setAttribute('r', Math.max(1, P[o + 2]).toFixed(2));
          b.a.setAttribute('stop-color', col); b.a.setAttribute('stop-opacity', lim(P[o + 6], 0, 1).toFixed(3)); b.b.setAttribute('stop-color', col); b.b.setAttribute('stop-opacity', 0);
        });
        const col = rgb(P.slice(28, 31)), m = lim(ex.mezcla, 0, 1);
        const pon = (t, letras, op, esc) => {
          t.textContent = letras; t.setAttribute('fill', col); t.setAttribute('font-size', letras.length > 1 ? 44 : 54); t.setAttribute('letter-spacing', letras.length > 1 ? -1.5 : 0);
          t.setAttribute('opacity', op.toFixed(3)); t.setAttribute('transform', 'translate(60 62) scale(' + esc.toFixed(3) + ') translate(-60 -62)');
        };
        pon(R.tA, ex.letrasDe, 1 - m, 1 + m * .14); pon(R.tB, ex.letras, m, .84 + m * .16);
      },
    },

    /* ── Bloques: 3 × 3 formas redondeadas, simétricas ─────────────── */
    bloques: {
      n: 66,
      gen(r, pal) {
        const bg = pal[4], P = [...bg];
        // formas como radios de esquina (en unidades de medio lado): cuadrado, círculo, cuarto, hoja y cúpula
        const FORMAS = [[0, 0, 0, 0], [1, 1, 1, 1], [1, 1, 1, 1], [2, 0, 0, 0], [0, 2, 0, 0], [0, 0, 2, 0], [0, 0, 0, 2], [2, 0, 2, 0], [0, 2, 0, 2], [1, 1, 0, 0], [0, 1, 1, 0], [0, 0, 1, 1], [1, 0, 0, 1]];
        const celdas = [];
        for (let f = 0; f < 3; f++) for (let c = 0; c < 2; c++) { const forma = FORMAS[pick(r, FORMAS.length)], col = pal[[0, 1, 2, 3, 0, 2][pick(r, 6)]]; celdas[f * 3 + c] = { forma, col }; }
        for (let f = 0; f < 3; f++) { const o = celdas[f * 3]; celdas[f * 3 + 2] = { forma: [o.forma[1], o.forma[0], o.forma[3], o.forma[2]], col: o.col }; }   // la tercera columna es el espejo de la primera
        celdas.forEach(c => P.push(c.forma[0] * 20, c.forma[1] * 20, c.forma[2] * 20, c.forma[3] * 20, ...c.col));
        return P;
      },
      retardo: i => i >= 3 ? Math.floor((i - 3) / 7) * .04 : 0,
      crea(defs, g) {
        const R = { bg: svgEl('rect', { width: 120, height: 120 }), c: [] };
        g.appendChild(R.bg);
        for (let k = 0; k < 9; k++) { const p = svgEl('path'); g.appendChild(p); R.c.push(p); }
        return R;
      },
      pinta(R, P) {
        R.bg.setAttribute('fill', rgb(P.slice(0, 3)));
        R.c.forEach((p, k) => { const o = 3 + k * 7, x = (k % 3) * 40, y = Math.floor(k / 3) * 40; p.setAttribute('d', rr(x, y, 40, P[o], P[o + 1], P[o + 2], P[o + 3])); p.setAttribute('fill', rgb(P.slice(o + 4, o + 7))); });
      },
    },

    /* ── Ondas: un sol y cuatro capas de olas ───────────────────────── */
    ondas: {
      n: 40,
      gen(r, pal) {
        const P = [...pal[4], ...pal[1]];
        P.push(24 + r() * 72, 24 + r() * 26, 15 + r() * 12, ...pal[[0, 3, 2][pick(r, 3)]]);
        const cs = [1, 0, 3, 2];
        for (let i = 0; i < 4; i++) P.push(46 + i * 17 + r() * 8, 5 + r() * 10, 1.1 + r() * 1.5, r() * 6.283, ...pal[cs[i]]);
        return P;
      },
      retardo: i => i >= 12 ? .03 + Math.floor((i - 12) / 7) * .07 : (i >= 6 ? .02 : 0),
      crea(defs, g, uid) {
        const R = { gr: svgEl('linearGradient', { id: uid + 'f', x1: 0, y1: 0, x2: 0, y2: 1 }), s0: svgEl('stop', { offset: 0 }), s1: svgEl('stop', { offset: 1 }), ol: [] };
        R.gr.append(R.s0, R.s1); defs.appendChild(R.gr);
        g.appendChild(svgEl('rect', { width: 120, height: 120, fill: 'url(#' + uid + 'f)' }));
        R.sol = svgEl('circle'); g.appendChild(R.sol);
        for (let i = 0; i < 4; i++) { const p = svgEl('path'); g.appendChild(p); R.ol.push(p); }
        return R;
      },
      pinta(R, P) {
        R.s0.setAttribute('stop-color', rgb(P.slice(0, 3))); R.s1.setAttribute('stop-color', rgb(P.slice(3, 6)));
        R.sol.setAttribute('cx', P[6].toFixed(2)); R.sol.setAttribute('cy', P[7].toFixed(2)); R.sol.setAttribute('r', Math.max(1, P[8]).toFixed(2)); R.sol.setAttribute('fill', rgb(P.slice(9, 12)));
        R.ol.forEach((p, i) => {
          const o = 12 + i * 7, y0 = P[o], amp = P[o + 1], fr = P[o + 2], ph = P[o + 3];
          let d = '';
          for (let x = -3; x <= 123; x += 3) d += (d ? 'L' : 'M') + x + ' ' + (y0 + amp * Math.sin(6.2832 * fr * x / 120 + ph)).toFixed(2);
          p.setAttribute('d', d + 'L123 123L-3 123Z'); p.setAttribute('fill', rgb(P.slice(o + 4, o + 7)));
        });
      },
    },

    /* ── Mosaico: una trama simétrica de 5 × 5 ─────────────────────── */
    mosaico: {
      n: 128,
      gen(r, pal) {
        const P = [...pal[4]], celdas = [];
        let enc = 0;
        for (let f = 0; f < 5; f++) for (let c = 0; c < 3; c++) { const on = r() < .68; if (on) enc++; celdas[f * 5 + c] = { on, rad: [.22, .5, .5, .35][pick(r, 4)], col: pal[[0, 1, 2, 3, 0, 2][pick(r, 6)]] }; }
        if (enc < 5) for (let f = 0; f < 5; f++) celdas[f * 5 + 1].on = true;
        for (let f = 0; f < 5; f++) { celdas[f * 5 + 3] = celdas[f * 5 + 1]; celdas[f * 5 + 4] = celdas[f * 5]; }
        celdas.forEach(c => P.push(c.on ? .84 : 0, c.rad, ...c.col));
        return P;
      },
      retardo: i => { if (i < 3) return 0; const k = Math.floor((i - 3) / 5); return ((k / 5 | 0) + k % 5) * .025; },
      crea(defs, g) {
        const R = { bg: svgEl('rect', { width: 120, height: 120 }), c: [] };
        g.appendChild(R.bg);
        for (let k = 0; k < 25; k++) { const p = svgEl('rect'); g.appendChild(p); R.c.push(p); }
        return R;
      },
      pinta(R, P) {
        R.bg.setAttribute('fill', rgb(P.slice(0, 3)));
        R.c.forEach((p, k) => {
          const o = 3 + k * 5, esc = Math.max(0, P[o]), s = 24 * esc, x = (k % 5) * 24 + (24 - s) / 2, y = Math.floor(k / 5) * 24 + (24 - s) / 2;
          p.setAttribute('x', x.toFixed(2)); p.setAttribute('y', y.toFixed(2)); p.setAttribute('width', s.toFixed(2)); p.setAttribute('height', s.toFixed(2));
          p.setAttribute('rx', (lim(P[o + 1], 0, .5) * s).toFixed(2)); p.setAttribute('fill', rgb(P.slice(o + 2, o + 5)));
        });
      },
    },
  };

  /* ── las letras que salen de un texto ─────────────────────────────── */
  function iniciales(t) {
    const limpio = t.trim().replace(/[^\p{L}\p{N}\s]/gu, ''), pal = limpio.split(/\s+/).filter(Boolean);
    if (!pal.length) return '?';
    if (pal.length === 1) return Array.from(pal[0]).slice(0, 2).join('').toUpperCase();
    return (Array.from(pal[0])[0] + Array.from(pal[pal.length - 1])[0]).toUpperCase();
  }

  /* =====================================================================
     Un avatar: un SVG con un estilo y la lista de números que se interpola
     ===================================================================== */
  const DUR = .95, TOTAL = 1.4;                      // lo que dura el recorrido de cada número, y el total con los escalonados
  function Avatar(host) {
    const uid = 'mo' + (++contador) + '-';
    const svg = svgEl('svg', { viewBox: '0 0 120 120', 'aria-hidden': 'true', focusable: 'false' }), defs = svgEl('defs'), g = svgEl('g');
    const clip = svgEl('clipPath', { id: uid + 'c' }); clip.appendChild(svgEl('circle', { cx: 60, cy: 60, r: 60 }));
    defs.appendChild(clip); g.setAttribute('clip-path', 'url(#' + uid + 'c)');
    svg.append(defs, g); host.appendChild(svg);
    const A = { estilo: null, refs: null, de: null, a: null, actual: null, u: TOTAL, letras: '?', letrasDe: '?', mezcla: 1 };

    function monta(estilo) {
      while (defs.childNodes.length > 1) defs.removeChild(defs.lastChild);
      while (g.firstChild) g.removeChild(g.firstChild);
      A.estilo = estilo; A.refs = ESTILOS[estilo].crea(defs, g, uid);
    }
    // fija el estado de llegada; si anima, parte de donde esté ahora mismo (aunque sea a mitad de una transición)
    A.pon = function (estilo, P, letras, anima) {
      const cambio = estilo !== A.estilo || !A.actual || A.actual.length !== P.length;
      if (estilo !== A.estilo) monta(estilo);
      const antes = A.letras;
      A.letras = letras;
      if (cambio || !anima) {
        A.de = P.slice(); A.a = P; A.actual = P.slice(); A.u = TOTAL; A.mezcla = 1; A.letrasDe = letras;
        ESTILOS[estilo].pinta(A.refs, A.actual, { letras, letrasDe: letras, mezcla: 1 });
        return;
      }
      A.letrasDe = antes; A.de = A.actual.slice(); A.a = P; A.u = 0; A.mezcla = antes === letras ? 1 : 0;
    };
    A.paso = function (dt) {
      if (A.u >= TOTAL) return false;
      A.u = Math.min(TOTAL, A.u + dt / DUR);
      const est = ESTILOS[A.estilo], n = A.a.length, act = A.actual;
      for (let i = 0; i < n; i++) { const e = ease(lim(A.u - est.retardo(i), 0, 1)); act[i] = A.de[i] + (A.a[i] - A.de[i]) * e; }
      A.mezcla = A.letras === A.letrasDe ? 1 : lim(A.u / .6, 0, 1);
      est.pinta(A.refs, act, { letras: A.letras, letrasDe: A.letrasDe, mezcla: A.mezcla });
      return A.u < TOTAL;
    };
    A.termina = function () { if (A.u < TOTAL) { A.u = TOTAL - .0001; A.paso(.001); } };
    // el SVG final, suelto y sin dependencias (para copiar o descargar)
    A.exporta = function (tam, titulo) {
      const s = svgEl('svg', { viewBox: '0 0 120 120', width: tam, height: tam, role: 'img' });
      const d = svgEl('defs'), gg = svgEl('g'), cl = svgEl('clipPath', { id: 'm-c' });
      cl.appendChild(svgEl('circle', { cx: 60, cy: 60, r: 60 })); d.appendChild(cl); gg.setAttribute('clip-path', 'url(#m-c)');
      const t = svgEl('title'); t.textContent = titulo; s.append(t, d, gg);
      const refs = ESTILOS[A.estilo].crea(d, gg, 'm-'); ESTILOS[A.estilo].pinta(refs, A.a, { letras: A.letras, letrasDe: A.letras, mezcla: 1 });
      // el texto de las iniciales se queda sin la B (opacidad 0)
      Array.from(s.querySelectorAll('text')).forEach(x => { if (x.getAttribute('opacity') === '0.000') x.remove(); });
      return new XMLSerializer().serializeToString(s);
    };
    return A;
  }

  /* =====================================================================
     El componente
     ===================================================================== */
  function Monograma(raiz, opciones) {
    const $ = s => raiz.querySelector(s);
    const campoEl = $('[data-texto]'), campoCaja = campoEl.closest('.mo-campo');
    const o = Object.assign({ texto: campoEl.value, estilo: 'iniciales', paleta: 'durazno', otros: ['Equipo Norte', 'Plataforma', 'Estudio Sur', 'Mesa de ayuda'], alCambiar: null }, opciones);
    const reduce = () => reduceMQ.matches;
    const grande = $('[data-grande]'), caja = $('[data-caja]'), escenario = $('[data-escenario]'), semillaEl = $('[data-semilla]'), vivo = $('[data-vivo]');
    const estilosEl = $('[data-estilos]'), marca = $('[data-marca-estilo]'), paletasEl = $('[data-paletas]'), perfilEl = $('[data-perfil]'), perfilNombre = $('[data-perfil-nombre]'), pilaEl = $('[data-pila]');
    const btnOtra = $('[data-otra]'), btnCopiar = $('[data-copiar]'), btnDesc = $('[data-descargar]'), limpia = $('[data-limpia]');
    const avisa = s => { vivo.textContent = ''; vivo.textContent = s; };
    const relojes = new Set();
    const luego = (fn, ms) => { const id = setTimeout(() => { relojes.delete(id); fn(); }, ms); relojes.add(id); return id; };
    const CURVA = muelle(190, 16);
    raiz.style.setProperty('--mo-muelle', muelle(230, 15));

    const E = { texto: o.texto, variante: 0, estilo: ESTILOS[o.estilo] ? o.estilo : 'iniciales', paleta: PALETAS[o.paleta] ? o.paleta : 'durazno' };
    const NOMBRES = { iniciales: 'Iniciales', bloques: 'Bloques', ondas: 'Ondas', mosaico: 'Mosaico' };

    /* ── los avatares: el grande, uno por estilo, el del perfil y la pila ─ */
    const aGrande = Avatar(grande), aPerfil = Avatar(perfilEl), aEstilos = {}, aPila = [], aTam = [];
    const fichas = Object.keys(NOMBRES).map((id, i) => {
      const b = document.createElement('button');
      b.className = 'mo-estilo'; b.type = 'button'; b.dataset.estilo = id; b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', String(id === E.estilo)); b.tabIndex = id === E.estilo ? 0 : -1; b.style.setProperty('--k', i);
      b.innerHTML = '<span class="mo-avatar" aria-hidden="true"></span><span>' + NOMBRES[id] + '</span>';
      estilosEl.appendChild(b); aEstilos[id] = Avatar(b.firstChild);
      return b;
    });
    const chips = Object.keys(PALETAS).map((id, i) => {
      const p = PALETAS[id], b = document.createElement('button');
      b.className = 'mo-paleta'; b.type = 'button'; b.dataset.paleta = id; b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', String(id === E.paleta)); b.tabIndex = id === E.paleta ? 0 : -1; b.style.setProperty('--k', i + 4);
      b.innerHTML = '<span class="mo-pts" aria-hidden="true">' + [0, 3, 1].map(k => '<i style="--c:' + p.cols[k] + '"></i>').join('') + '</span><span>' + p.nombre + '</span><span class="mo-pt-ok" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M5.5 12.5l4.2 4.2 8.8-9.2"/></svg></span>';
      paletasEl.appendChild(b);
      return b;
    });
    o.otros.slice(0, 4).forEach(() => { const d = document.createElement('div'); d.className = 'mo-avatar'; d.setAttribute('aria-hidden', 'true'); pilaEl.appendChild(d); aPila.push(Avatar(d)); });
    $('.mo-ctx').style.setProperty('--k', 7);
    [80, 56, 40, 32, 24].forEach(px => {
      const f = document.createElement('figure'), d = document.createElement('div');
      d.className = 'mo-avatar'; d.style.setProperty('--s', px + 'px'); d.setAttribute('aria-hidden', 'true');
      const c = document.createElement('figcaption'); c.textContent = px;
      f.append(d, c); $('[data-tamanos]').appendChild(f); aTam.push(Avatar(d));
    });

    /* ── de la semilla a la imagen ───────────────────────────────────── */
    const semillaDe = (texto, variante) => cyrb53(texto.trim().toLowerCase() + '|' + variante);
    function imagen(estilo, texto, variante) {
      const s = semillaDe(texto, variante), r = mulberry32(s >>> 0 ^ Math.floor(s / 4294967296));
      return ESTILOS[estilo].gen(r, PALETAS[E.paleta].rgb, iniciales(texto));
    }
    const hexSemilla = (texto, variante) => (semillaDe(texto, variante) % 65536).toString(16).toUpperCase().padStart(4, '0');

    function pinta(anima, saltos) {
      const l = iniciales(E.texto), an = anima && !reduce();
      aGrande.pon(E.estilo, imagen(E.estilo, E.texto, E.variante), l, an);
      Object.keys(aEstilos).forEach(id => aEstilos[id].pon(id, imagen(id, E.texto, E.variante), l, an));
      aPerfil.pon(E.estilo, imagen(E.estilo, E.texto, E.variante), l, an);
      o.otros.slice(0, 4).forEach((t, i) => aPila[i].pon(E.estilo, imagen2(E.estilo, t), iniciales(t), an));
      aTam.forEach(a => a.pon(E.estilo, imagen(E.estilo, E.texto, E.variante), l, an));
      semillaEl.textContent = 'semilla ' + hexSemilla(E.texto, E.variante);
      perfilNombre.textContent = E.texto.trim() || 'Sin nombre';
      grande.setAttribute('aria-label', 'Avatar de «' + (E.texto.trim() || 'texto vacío') + '», estilo ' + NOMBRES[E.estilo]);
      if (reduce()) todos.forEach(a => a.termina());
      despierta();
    }
    function imagen2(estilo, texto) { return imagen(estilo, texto, 0); }
    const todos = [aGrande, aPerfil].concat(Object.keys(aEstilos).map(k => aEstilos[k]), aPila, aTam);

    function ponTinte() {
      const oscuro = document.documentElement.dataset.tema === 'oscuro', t = PALETAS[E.paleta].tinte[oscuro ? 'oscuro' : 'claro'];
      raiz.style.setProperty('--mo-tinte', t[0]); raiz.style.setProperty('--mo-tinte-2', t[1]);
    }
    function emite() { if (typeof o.alCambiar === 'function') o.alCambiar({ texto: E.texto, estilo: E.estilo, paleta: E.paleta, variante: E.variante, semilla: hexSemilla(E.texto, E.variante) }); }

    function ponLleno() { const l = !!campoEl.value; campoCaja.classList.toggle('is-lleno', l); limpia.tabIndex = l ? 0 : -1; limpia.setAttribute('aria-hidden', String(!l)); }
    /* ── el texto: el avatar se recompone con cada letra ─────────────── */
    campoEl.addEventListener('input', () => {
      E.texto = campoEl.value; E.variante = 0;
      ponLleno();
      pinta(true); emite();
    });
    campoEl.addEventListener('change', () => avisa('Avatar de «' + (E.texto.trim() || 'texto vacío') + '».'));
    limpia.addEventListener('click', () => { campoEl.value = ''; campoEl.dispatchEvent(new Event('input')); campoEl.focus(); });

    /* ── «Otra variante»: se sacude y cambia la semilla con un rebote ── */
    let giro = 0;
    btnOtra.addEventListener('click', () => {
      E.variante++;
      giro += 180; btnOtra.querySelector('svg').style.transform = 'rotate(' + giro + 'deg)';
      if (!reduce()) { grande.classList.remove('is-sacude'); void grande.offsetWidth; grande.classList.add('is-sacude'); luego(() => grande.classList.remove('is-sacude'), 700); }
      luego(() => { pinta(true); emite(); }, reduce() ? 0 : 150);
      avisa('Otra variante: ' + E.variante + '.');
    });

    /* ── el estilo: un volteo del avatar grande, y la marca que viaja ─── */
    function marcaEn(btn, anima) {
      if (!btn.offsetWidth) return;
      marca.style.width = btn.offsetWidth + 'px'; marca.style.height = btn.offsetHeight + 'px';
      if (!anima) marca.style.transition = 'none';
      marca.style.transform = 'translate(' + btn.offsetLeft + 'px, ' + btn.offsetTop + 'px)';
      if (!anima) { void marca.offsetWidth; marca.style.transition = TR; }
    }
    const TR = 'transform .65s var(--mo-muelle), width .4s, height .4s';
    marca.style.transition = TR;
    function cambiaEstilo(id, enfoca) {
      if (id === E.estilo || !ESTILOS[id]) return;
      E.estilo = id;
      fichas.forEach(f => { const on = f.dataset.estilo === id; f.setAttribute('aria-checked', String(on)); f.tabIndex = on ? 0 : -1; if (on) { marcaEn(f, true); if (enfoca) f.focus(); } });
      const aplica = () => { pinta(false); emite(); };
      if (reduce()) aplica();
      else {
        const a = grande.animate([{ transform: 'rotateY(0deg)' }, { transform: 'rotateY(90deg) scale(.94)' }], { duration: 200, easing: 'cubic-bezier(.5, 0, .9, .6)', fill: 'forwards' });
        luego(() => {
          aplica(); a.cancel();
          grande.animate([{ transform: 'rotateY(-90deg) scale(.94)' }, { transform: 'rotateY(0deg)' }], { duration: 640, easing: CURVA });
          [aPerfil.estilo !== undefined && perfilEl].concat(Array.from(pilaEl.children)).forEach(el => { if (!el) return; el.classList.remove('mo-pop'); void el.offsetWidth; el.classList.add('mo-pop'); luego(() => el.classList.remove('mo-pop'), 650); });
        }, 205);
      }
      avisa('Estilo ' + NOMBRES[id] + '.');
    }
    fichas.forEach((f, i) => {
      f.addEventListener('click', () => cambiaEstilo(f.dataset.estilo));
      f.addEventListener('keydown', ev => {
        const d = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[ev.key];
        if (!d) return;
        ev.preventDefault(); cambiaEstilo(fichas[(i + d + fichas.length) % fichas.length].dataset.estilo, true);
      });
    });

    /* ── la paleta: el conjunto se recolorea sin cambiar de forma ────── */
    function cambiaPaleta(id, enfoca) {
      if (id === E.paleta || !PALETAS[id]) return;
      E.paleta = id;
      chips.forEach(c => { const on = c.dataset.paleta === id; c.setAttribute('aria-checked', String(on)); c.tabIndex = on ? 0 : -1; if (on && enfoca) c.focus(); });
      ponTinte(); pinta(true); emite();
      avisa('Paleta ' + PALETAS[id].nombre + '.');
    }
    chips.forEach((c, i) => {
      c.addEventListener('click', () => cambiaPaleta(c.dataset.paleta));
      c.addEventListener('keydown', ev => {
        const d = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[ev.key];
        if (!d) return;
        ev.preventDefault(); cambiaPaleta(chips[(i + d + chips.length) % chips.length].dataset.paleta, true);
      });
    });

    /* ── copiar y descargar el SVG ───────────────────────────────────── */
    const svgActual = () => aGrande.exporta(256, 'Avatar de ' + (E.texto.trim() || 'texto vacío'));
    function marcaOk(btn, txt, ahora, antes) {
      btn.classList.add('is-ok'); txt.textContent = ahora;
      clearTimeout(btn._t); btn._t = luego(() => { btn.classList.remove('is-ok'); txt.textContent = antes; }, 1100);
    }
    btnCopiar.addEventListener('click', async () => {
      const s = svgActual();
      let ok = false;
      try { await navigator.clipboard.writeText(s); ok = true; } catch (_) {
        try { const t = document.createElement('textarea'); t.value = s; t.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(t); t.select(); ok = document.execCommand('copy'); t.remove(); } catch (_2) { ok = false; }
      }
      marcaOk(btnCopiar, $('[data-copiar-txt]'), 'Copiado', 'Copiar SVG');
      avisa(ok ? 'SVG copiado.' : 'SVG listo para copiar.');
    });
    btnDesc.addEventListener('click', () => {
      const s = svgActual(), blob = new Blob([s], { type: 'image/svg+xml' }), url = URL.createObjectURL(blob), a = document.createElement('a');
      const nombre = (E.texto.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'avatar');
      a.href = url; a.download = 'avatar-' + nombre + '.svg'; document.body.appendChild(a); a.click(); a.remove();
      luego(() => URL.revokeObjectURL(url), 1000);
      marcaOk(btnDesc, $('[data-descargar-txt]'), 'Listo', 'Descargar');
      avisa('Avatar descargado como ' + a.download + '.');
    });

    /* ── el bucle: solo corre mientras algún avatar se transforma ─────── */
    let raf = 0, previo = 0;
    function cuadro(ms) {
      raf = 0;
      if (document.hidden) return;
      const dt = previo ? Math.min(.1, (ms - previo) / 1000) : 0;
      previo = ms;
      let viva = false;
      todos.forEach(a => { if (a.paso(dt)) viva = true; });
      if (viva || !dt) raf = requestAnimationFrame(cuadro);
    }
    function despierta() { if (!raf) { previo = 0; raf = requestAnimationFrame(cuadro); } }
    document.addEventListener('visibilitychange', () => { previo = 0; if (!document.hidden) despierta(); });
    new MutationObserver(ponTinte).observe(document.documentElement, { attributes: true, attributeFilter: ['data-tema'] });
    if (window.ResizeObserver) new ResizeObserver(() => { const on = fichas.find(f => f.getAttribute('aria-checked') === 'true'); if (on) marcaEn(on, false); }).observe(estilosEl);

    /* ── al empezar ──────────────────────────────────────────────────── */
    ponLleno();
    ponTinte(); pinta(false);
    if (!reduce()) {
      raiz.classList.add('is-entra'); luego(() => { raiz.classList.remove('is-entra'); caja.classList.add('is-flota'); }, 1500);
    }
    if (document.fonts) document.fonts.ready.then(() => { const on = fichas.find(f => f.getAttribute('aria-checked') === 'true'); if (on) marcaEn(on, false); });
    const on0 = fichas.find(f => f.getAttribute('aria-checked') === 'true'); marcaEn(on0, false);
    despierta();

    return {
      svg: svgActual,
      pon: v => {
        if (v.texto !== undefined) { E.texto = v.texto; E.variante = 0; campoEl.value = v.texto; ponLleno(); }
        if (v.paleta) cambiaPaleta(v.paleta);
        if (v.estilo) cambiaEstilo(v.estilo);
        pinta(true); emite();
      },
    };
  }

  window.Monograma = Monograma;
})();
