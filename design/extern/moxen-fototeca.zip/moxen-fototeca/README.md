# Fototeca · Moxen

Arrastras un recuadro elástico sobre el fondo para elegir fotos (con Mayús sumas y restas), las llevas a una carpeta y salen en abanico hacia ella mientras su cifra sube y un aviso deja deshacer. Pulsar una foto abre un panel de detalles con nombre y etiquetas editables, y soltar un archivo crea una miniatura con su anillo de carga.

## Qué trae

- `index.html` — la demostración
- `fototeca.css`
- `fototeca.js`
- `img/` — las fotos de la demostración (Unsplash; reemplázalas por las tuyas)
- `CREDITOS.md` — autor y enlace de cada foto
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `fototeca.css` y `fototeca.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Drag an elastic box over the background to pick photos (Shift adds and subtracts), carry them to a folder and they fan out towards it while its count rolls up and a notice lets you undo. Tapping a photo slides in a details panel with an editable name and tags, and dropping a file creates a thumbnail with its own loading ring.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
