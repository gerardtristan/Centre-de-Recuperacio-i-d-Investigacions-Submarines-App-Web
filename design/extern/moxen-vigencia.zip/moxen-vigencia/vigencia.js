/* =====================================================================
   Vigencia · Moxen
   Que ninguna licencia, permiso, seguro o certificado se venza sin aviso:
   cada documento muestra cuántos días le quedan en una regla de 60 días
   con las alertas de 30, 15 y 7 marcadas, la lista se ordena por urgencia
   y renovar (con una nueva fecha) manda el documento al final. Abajo a
   la derecha se descargan los avisos como un .ics, con un VALARM por cada
   alerta que todavía falta por sonar.

   Qué es real (nada está simulado):
   · Días restantes = fecha de vencimiento − hoy, contados en días enteros
     de calendario (sin horas ni husos), así que cuadran con cualquier
     cálculo de fechas. «Hoy» es una fecha de ejemplo; el deslizador la
     adelanta hasta 120 días para ver cómo se van encendiendo las alertas.
   · Etapa de cada documento: más de 30 días (al día), hasta 30, hasta 15,
     hasta 7 o vencido. Los umbrales salen de `alertas`.
   · Orden: por días restantes de menor a mayor (lo vencido primero) y, a
     igualdad, por nombre.
   · Renovar: la nueva fecha cuenta desde el vencimiento actual (o desde
     hoy si ya venció) más 6, 12 o 24 meses, o la fecha que elijas si es
     posterior. Los meses cortos se recortan al último día (31 de agosto +
     6 meses = 28 de febrero).
   · El .ics lleva un evento de día completo por documento y un VALARM por
     cada alerta cuyo día todavía no pasó (días restantes ≥ umbral), con un
     TRIGGER relativo al inicio del evento que cae a la hora de aviso.

   Cómo se monta (ver index.html):
     <section data-vigencia> … <ol data-lista></ol> … </section>
     const v = Vigencia(document.querySelector('[data-vigencia]'), {
       hoy: '2026-10-23',  alertas: [30, 15, 7],  horaAviso: 9,
       documentos: [ { nombre: 'Licencia comercial', tipo: 'licencia', vence: '2026-10-29' }, … ],
       alCambiar: ({ hoy, documentos, alertas }) => {},
     });
     v.pasa(10);  v.renueva('d1', '2027-10-29');  v.alterna(15);  v.estado();  v.ics();  v.restablece();
     Vigencia.restan('2026-10-29', '2026-10-23')    // 6: el cálculo de días solo
     Vigencia.sumaMeses('2026-08-31', 6)            // '2027-02-28'

   Teclado: Tab recorre el deslizador del tiempo, los días de aviso y cada «Renovar»; en el
   deslizador, flechas, Inicio, Fin y RePág; dentro de «Renovar», Esc cierra y Intro en la fecha
   confirma. Qué se personaliza: los colores están al principio del CSS (--vg-azul es lo que está
   al día, --vg-ambar lo que se acerca y --vg-rojo lo urgente o vencido). Sin dependencias, sin azar
   y sin Date para animar (Date solo calcula fechas y sella el .ics al descargar).
   ===================================================================== */
(function () {
  'use strict';

  const quieto = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
  const dos = n => (n < 10 ? '0' : '') + n;
  const escapa = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const DIAS3 = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
  const MES3 = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const TIPO_NOMBRE = { licencia: 'Licencia', permiso: 'Permiso', seguro: 'Seguro', certificado: 'Certificado' };

  // un resorte convertido en curva CSS linear(): las filas viajan a su sitio con ella
  function muelle(k, c) {
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const out = [];
    for (let i = 0; i <= 40; i++) out.push(pts[Math.round(i / 40 * (pts.length - 1))].toFixed(4));
    out[40] = '1';
    return 'linear(' + out.join(', ') + ')';
  }
  const MUELLE = muelle(200, 20);

  const ICONO = {
    licencia: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5.5" width="17" height="13" rx="3"/><circle cx="9" cy="10.8" r="2"/><path d="M6.4 15.6c.6-1.4 1.6-2 2.6-2s2 .6 2.6 2M14 10h3.8M14 13h2.6"/></svg>',
    permiso: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5h7.4L19 8v12.5H7z"/><path d="M14 3.8v4.7h4.8"/><path d="m9.8 14.4 1.9 1.9 3.5-3.9"/></svg>',
    seguro: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.4 5.4 6v5.4c0 4.2 2.7 7.2 6.6 9 3.9-1.8 6.6-4.8 6.6-9V6z"/><path d="m9.2 12.2 2 2 3.6-4"/></svg>',
    certificado: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="9.4" r="5.4"/><path d="m9.6 9.6 1.8 1.8 3-3.3M9.2 14l-1.5 6.2L12 18.2l4.3 2L14.8 14"/></svg>',
  };

  /* ── fechas: días enteros desde 1970, sin horas ni husos ───────────
     Se trabaja con el número de día (UTC) para que restar dé días exactos
     aunque haya cambios de hora entre medio. */
  const diaDe = (a, m, d) => Math.floor(Date.UTC(a, m - 1, d) / 86400000);
  const delIso = s => { const [a, m, d] = s.split('-').map(Number); return diaDe(a, m, d); };
  const partes = n => { const f = new Date(n * 86400000); return { a: f.getUTCFullYear(), m: f.getUTCMonth(), d: f.getUTCDate(), w: f.getUTCDay() }; };
  const aIso = n => { const p = partes(n); return p.a + '-' + dos(p.m + 1) + '-' + dos(p.d); };
  const larga = n => { const p = partes(n); return DIAS3[p.w] + ' ' + p.d + ' ' + MES3[p.m] + ' ' + p.a; };
  // sumar meses recortando al último día del mes (31 ago + 6 meses = 28 feb)
  function sumaMesesN(n, meses) {
    const p = partes(n);
    let y = p.a, m = p.m + meses;
    y += Math.floor(m / 12); m = ((m % 12) + 12) % 12;
    const ult = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    return diaDe(y, m + 1, Math.min(p.d, ult));
  }

  function Vigencia(raiz, opc) {
    const o = Object.assign({ hoy: '2026-10-23', alertas: [30, 15, 7], horaAviso: 9, escala: 60, meses: [6, 12, 24], documentos: [], alCambiar() {} }, opc);
    const $ = s => raiz.querySelector(s);
    const U = o.alertas.slice().sort((a, b) => b - a);          // los umbrales, de mayor a menor
    const HOY0 = delIso(o.hoy), ESC = o.escala;
    const inicial = o.documentos.map((d, i) => ({ id: 'd' + (i + 1), nombre: d.nombre, tipo: d.tipo, vence: delIso(d.vence) }));
    let docs = inicial.map(d => Object.assign({}, d));
    let off = 0, abierto = null, opcion = null;
    const relojes = {};
    const on = new Set(U);
    const hoy = () => HOY0 + off;
    const corta = n => { const p = partes(n); return p.d + ' ' + MES3[p.m] + (p.a !== partes(HOY0).a ? ' ' + p.a : ''); };
    const restan = d => d.vence - hoy();
    // etapa: 0 al día, 1.. cada umbral cruzado, y una más para lo vencido
    const nivel = r => (r < 0 ? U.length + 1 : U.filter(t => r <= t).length);
    const ETAPA = ['Al día', 'Por vencer', 'Pronto', 'Urgente', 'Vencido'];
    const ETAPA_LARGA = ['Más de ' + U[0] + ' días', 'Hasta ' + U[0] + ' días', 'Hasta ' + U[1] + ' días', 'Hasta ' + U[2] + ' días', 'Vencidos'];
    const orden = (a, b) => (a.vence - b.vence) || a.nombre.localeCompare(b.nombre, 'es');
    const unidad = r => (Math.abs(r) === 1 ? 'día' : 'días');

    // las zonas de la regla (azul, ámbar, ámbar fuerte y rojo) a partir de los umbrales
    const pos = r => (1 - Math.min(Math.max(r, 0), ESC) / ESC) * 100;
    raiz.style.setProperty('--vg-zonas', 'linear-gradient(90deg, var(--vg-azul-suave) 0 ' + pos(U[0]).toFixed(2) + '%, var(--vg-ambar-suave) ' + pos(U[0]).toFixed(2) + '% ' + pos(U[1]).toFixed(2) + '%, var(--vg-ambar2-suave) ' + pos(U[1]).toFixed(2) + '% ' + pos(U[2]).toFixed(2) + '%, var(--vg-rojo-suave) ' + pos(U[2]).toFixed(2) + '% 100%)');

    /* ── la plantilla de cada fila, creada una sola vez ────────────── */
    const lista = $('[data-lista]');
    const filas = new Map();
    function creaFila(d) {
      const li = document.createElement('li');
      li.className = 'vg-doc'; li.dataset.id = d.id;
      li.innerHTML =
        '<div class="vg-fila"><span class="vg-tipo" aria-hidden="true">' + ICONO[d.tipo] + '</span>' +
        '<div class="vg-nom"><b></b><small></small><span class="vg-sr"></span></div>' +
        '<div class="vg-pista" aria-hidden="true">' + U.map(t => '<i class="vg-tick" style="left:' + pos(t).toFixed(2) + '%"></i>').join('') + '<i class="vg-relleno"></i><i class="vg-marca"></i></div>' +
        '<div class="vg-dias"><b class="vg-n"></b><small class="vg-u"></small></div>' +
        '<button class="vg-renovar" type="button" aria-expanded="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 8.5A7.5 7.5 0 0 0 5.6 7.2M5 15.5a7.5 7.5 0 0 0 13.4 1.3"/><path d="M5.2 3.6v3.9h3.9M18.8 20.4v-3.9h-3.9"/></svg><span>Renovar</span></button></div>' +
        '<div class="vg-renueva" role="group"><p class="vg-renueva-t"><b></b><small></small></p>' +
        '<div class="vg-opc">' + o.meses.map(m => '<button type="button" class="vg-op" data-meses="' + m + '" aria-pressed="false"><b>' + (m % 12 === 0 ? '+' + m / 12 + (m === 12 ? ' año' : ' años') : '+' + m + ' meses') + '</b><small></small></button>').join('') + '</div>' +
        '<label class="vg-fecha"><span>o elige otra fecha</span><input type="date" class="vg-fecha-in"></label>' +
        '<p class="vg-err" role="alert"></p>' +
        '<div class="vg-renueva-acc"><button type="button" class="vg-confirmar">Confirmar renovación</button><button type="button" class="vg-cancelar">Cancelar</button></div></div>';
      filas.set(d.id, li);
      return li;
    }
    inicial.forEach(d => creaFila(d));

    /* ── pintar una fila con lo que dicen los días ─────────────────── */
    function pintaFila(d, anuncia) {
      const li = filas.get(d.id), r = restan(d), niv = nivel(r);
      li.dataset.nivel = niv; li.dataset.restan = r;
      li.querySelector('.vg-nom b').textContent = d.nombre;
      li.querySelector('.vg-nom small').textContent = TIPO_NOMBRE[d.tipo] + ' · ' + (r < 0 ? 'venció el ' : 'vence el ') + larga(d.vence);
      const p = r < 0 ? 100 : pos(r);
      li.style.setProperty('--p', p.toFixed(2));
      li.classList.toggle('is-fuera', r > ESC);
      const n = li.querySelector('.vg-n'), u = li.querySelector('.vg-u');
      const tn = r < 0 ? 'Vencido' : r === 0 ? 'Hoy' : String(r);
      const tu = r < 0 ? 'hace ' + (-r) + ' ' + unidad(r) : r === 0 ? 'vence' : unidad(r) + ' · ' + ETAPA[niv];
      if (n.textContent !== tn) { n.textContent = tn; if (anuncia && !quieto()) n.animate([{ transform: 'translateY(30%)', opacity: .2 }, { transform: 'none', opacity: 1 }], { duration: 260, easing: 'cubic-bezier(.22, 1, .36, 1)' }); }
      u.textContent = tu;
      li.querySelector('.vg-sr').textContent = (r < 0 ? 'Vencido hace ' + (-r) + ' ' + unidad(r) : r === 0 ? 'Vence hoy' : 'Quedan ' + r + ' ' + unidad(r)) + ', ' + ETAPA[niv] + '.';
      li.querySelector('.vg-renovar').setAttribute('aria-label', 'Renovar ' + d.nombre);
      if (abierto === d.id) pintaRenueva(d);
    }

    /* ── lo que se renueva: base, opciones y fecha elegida ─────────── */
    const baseDe = d => (restan(d) >= 0 ? d.vence : hoy());       // si ya venció, la renovación cuenta desde hoy
    function pintaRenueva(d) {
      const li = filas.get(d.id), base = baseDe(d);
      li.querySelector('.vg-renueva-t b').textContent = 'Renovar «' + d.nombre + '»';
      li.querySelector('.vg-renueva-t small').textContent = restan(d) < 0 ? 'Ya venció: la cuenta parte de hoy, ' + corta(hoy()) + '.' : 'La cuenta parte del vencimiento, ' + corta(base) + '.';
      li.querySelectorAll('.vg-op').forEach(b => {
        const nuevo = sumaMesesN(base, +b.dataset.meses);
        b.querySelector('small').textContent = larga(nuevo);
        b.setAttribute('aria-pressed', !!(opcion && opcion.meses === +b.dataset.meses));
      });
      const inp = li.querySelector('.vg-fecha-in');
      inp.min = aIso(base + 1);
      if (opcion && opcion.meses) inp.value = aIso(sumaMesesN(base, opcion.meses));
    }
    function abre(id) {
      if (abierto && abierto !== id) cierra(false);
      abierto = id; opcion = { meses: o.meses.includes(12) ? 12 : o.meses[0] };
      const d = docs.find(x => x.id === id), li = filas.get(id);
      pintaRenueva(d);
      li.classList.add('is-abierto');
      li.classList.toggle('is-arriba', Array.from(lista.children).indexOf(li) >= lista.children.length - 3);
      li.querySelector('.vg-renovar').setAttribute('aria-expanded', 'true');
      li.querySelector('.vg-err').textContent = '';
      const sel = li.querySelector('.vg-op[aria-pressed="true"]');
      if (sel) sel.focus({ preventScroll: true });
    }
    function cierra(devuelveFoco) {
      if (!abierto) return;
      const li = filas.get(abierto);
      li.classList.remove('is-abierto');
      li.querySelector('.vg-renovar').setAttribute('aria-expanded', 'false');
      if (devuelveFoco) li.querySelector('.vg-renovar').focus({ preventScroll: true });
      abierto = null; opcion = null;
    }

    /* ── ordenar: las filas se reubican con FLIP ───────────────────── */
    const rectas = () => { const m = new Map(); filas.forEach((li, id) => m.set(id, li.getBoundingClientRect())); return m; };
    function ordena(anima) {
      const antes = anima ? rectas() : null;
      docs.slice().sort(orden).forEach(d => lista.appendChild(filas.get(d.id)));
      if (!antes || quieto()) return;
      filas.forEach((li, id) => {
        const a = antes.get(id), b = li.getBoundingClientRect(), dy = a.top - b.top;
        if (Math.abs(dy) > 1) li.animate([{ transform: 'translateY(' + dy + 'px)' }, { transform: 'none' }], { duration: 760, easing: MUELLE });
      });
    }

    /* ── los avisos y el .ics ──────────────────────────────────────── */
    const alertasDe = d => U.filter(t => on.has(t) && restan(d) >= t);               // las que todavía faltan por sonar
    function proximos() {
      const lista2 = [];
      docs.forEach(d => U.filter(t => on.has(t) && d.vence - t >= hoy()).forEach(t => lista2.push({ d, t, dia: d.vence - t })));
      return lista2.sort((a, b) => a.dia - b.dia || a.t - b.t || a.d.nombre.localeCompare(b.d.nombre, 'es'));
    }
    // un TRIGGER que cae a la hora de aviso: t días antes del inicio (a las 0:00) menos la hora → −P(t−1)DT(24−h)H
    function trigger(t) {
      const min = t * 1440 - Math.round(o.horaAviso * 60), dd = Math.floor(min / 1440), r = min % 1440, hh = Math.floor(r / 60), mm = r % 60;
      return '-P' + (dd ? dd + 'D' : '') + (hh || mm ? 'T' + (hh ? hh + 'H' : '') + (mm ? mm + 'M' : '') : '');
    }
    const esc = s => String(s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
    const dobla = l => { const t = []; let r = l; while (r.length > 70) { t.push(r.slice(0, 70)); r = ' ' + r.slice(70); } t.push(r); return t.join('\r\n'); };
    const ymd = n => aIso(n).replace(/-/g, '');
    function construyeIcs() {
      const sello = (o.sello || new Date().toISOString()).replace(/[-:]/g, '').replace(/\.\d+/, '');        // la hora real de la descarga: no anima nada
      const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Moxen//Vigencia//ES', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH'];
      docs.slice().sort(orden).forEach(d => {
        L.push('BEGIN:VEVENT', 'UID:vigencia-' + d.id + '-' + ymd(d.vence) + '@documentos.ejemplo', 'DTSTAMP:' + sello,
          'DTSTART;VALUE=DATE:' + ymd(d.vence), 'DTEND;VALUE=DATE:' + ymd(d.vence + 1),
          'SUMMARY:' + esc('Vence: ' + d.nombre), 'DESCRIPTION:' + esc(TIPO_NOMBRE[d.tipo] + ' con vencimiento el ' + larga(d.vence) + '.'), 'TRANSP:TRANSPARENT');
        alertasDe(d).forEach(t => L.push('BEGIN:VALARM', 'TRIGGER:' + trigger(t), 'ACTION:DISPLAY', 'DESCRIPTION:' + esc('Faltan ' + t + ' días: ' + d.nombre), 'END:VALARM'));
        L.push('END:VEVENT');
      });
      L.push('END:VCALENDAR');
      return L.map(dobla).join('\r\n') + '\r\n';
    }

    /* ── pintar todo ───────────────────────────────────────────────── */
    const voz = $('[data-voz]');
    function pinta(anuncia) {
      docs.forEach(d => pintaFila(d, anuncia));
      // la leyenda: cuántos documentos hay en cada etapa
      const cuentas = [0, 0, 0, 0, 0];
      docs.forEach(d => { cuentas[nivel(restan(d))]++; });
      const orden2 = [4, 3, 2, 1, 0];
      $('[data-leyenda]').innerHTML = orden2.map(n => '<li data-nivel="' + n + '"><i></i><span>' + ETAPA_LARGA[n] + '</span><b>' + cuentas[n] + '</b></li>').join('');
      const atencion = docs.filter(d => restan(d) <= U[0]).length;
      $('[data-sub]').textContent = docs.length + ' documentos · ' + (atencion ? atencion + (atencion === 1 ? ' pide atención' : ' piden atención') : 'todos al día');
      const txt = off === 0 ? 'Hoy · ' + larga(hoy()) : 'En ' + off + ' ' + unidad(off) + ' · ' + larga(hoy());
      $('[data-hoy-tx]').textContent = txt;
      const rango = $('[data-hoy]'); rango.value = off; rango.setAttribute('aria-valuetext', txt);
      rango.style.setProperty('--p', (off / (+rango.max) * 100).toFixed(2) + '%');
      // los chips de alerta
      $('[data-alertas]').innerHTML = U.map(t => '<button type="button" class="vg-alerta" data-t="' + t + '" aria-pressed="' + on.has(t) + '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 12.6l3.6 3.7 7.4-8.4"/></svg><span>' + t + ' días</span></button>').join('');
      // los próximos avisos
      const pr = proximos();
      $('[data-prox]').innerHTML = pr.length ? pr.slice(0, 4).map(a => {
        const p = partes(a.dia), en = a.dia - hoy();
        return '<li' + (en === 0 ? ' class="is-hoy"' : '') + '><span class="vg-prox-f"><b>' + p.d + '</b><small>' + MES3[p.m] + '</small></span><div><b>' + escapa(a.d.nombre) + '</b><small>' + a.t + ' días antes · ' + (en === 0 ? 'hoy' : 'en ' + en + ' ' + unidad(en)) + '</small></div></li>';
      }).join('') : '<li class="vg-prox-vacio">Ya no quedan avisos por sonar con estas opciones.</li>';
      const nAl = docs.reduce((s, d) => s + alertasDe(d).length, 0);
      $('[data-ics-n]').textContent = nAl + (nAl === 1 ? ' aviso' : ' avisos') + ' (VALARM) en ' + docs.length + ' eventos';
      raiz.dataset.fechaHoy = aIso(hoy()); raiz.dataset.avisos = nAl;
      if (anuncia) o.alCambiar({ hoy: aIso(hoy()), documentos: estado().documentos, alertas: U.filter(t => on.has(t)) });
    }
    const estado = () => ({
      hoy: aIso(hoy()), off, abierto, alertas: U.filter(t => on.has(t)),
      documentos: docs.slice().sort(orden).map(d => ({ id: d.id, nombre: d.nombre, tipo: d.tipo, vence: aIso(d.vence), restan: restan(d), etapa: ETAPA[nivel(restan(d))] })),
    });

    /* ── acciones ──────────────────────────────────────────────────── */
    function pasa(n) { off = Math.max(0, Math.min(+$('[data-hoy]').max, n)); pinta(true); }
    function renueva(id, iso) {
      const d = docs.find(x => x.id === id), nuevo = delIso(iso);
      if (!d || !(nuevo > baseDe(d))) return false;
      const antes = d.vence;
      d.vence = nuevo;
      cierra(false);
      pinta(true);
      ordena(true);
      const li = filas.get(id);
      li.classList.add('is-renovado');
      li.querySelector('.vg-nom small').textContent = '✓ Renovado hasta el ' + larga(d.vence);
      li.dataset.renovado = '1';
      // pasado un rato se quita la marca; se repinta con el documento de ahora (si hubo «Restablecer» entre medio, no es el mismo objeto)
      clearTimeout(relojes[id]);
      relojes[id] = setTimeout(() => { li.classList.remove('is-renovado'); delete li.dataset.renovado; const hoyD = docs.find(x => x.id === id); if (hoyD) pintaFila(hoyD, false); }, 3200);
      voz.textContent = d.nombre + ' renovado hasta el ' + larga(d.vence) + '. Pasa al final de la lista: quedan ' + restan(d) + ' días.';
      const f = li.querySelector('.vg-renovar'); if (document.activeElement === document.body) f.focus({ preventScroll: true });
      void antes;
      return true;
    }
    function alterna(t) { if (!U.includes(t)) return; if (on.has(t)) on.delete(t); else on.add(t); pinta(true); }
    function restablece() {
      cierra(false);
      docs = inicial.map(d => Object.assign({}, d)); off = 0; U.forEach(t => on.add(t));
      filas.forEach((li, id) => { li.classList.remove('is-renovado'); delete li.dataset.renovado; clearTimeout(relojes[id]); });
      pinta(true); ordena(true);
    }

    // el deslizador, los avisos y las filas
    $('[data-hoy]').addEventListener('input', e => { off = +e.target.value; pinta(true); });
    $('[data-alertas]').addEventListener('click', e => { const b = e.target.closest('.vg-alerta'); if (b) { alterna(+b.dataset.t); const n = $('[data-alertas] [data-t="' + b.dataset.t + '"]'); if (n) n.focus({ preventScroll: true }); } });
    $('[data-restablecer]').addEventListener('click', restablece);
    lista.addEventListener('click', e => {
      const li = e.target.closest('.vg-doc'); if (!li) return;
      const id = li.dataset.id, d = docs.find(x => x.id === id);
      if (e.target.closest('.vg-renovar')) { if (abierto === id) cierra(true); else abre(id); return; }
      const op = e.target.closest('.vg-op');
      if (op) { opcion = { meses: +op.dataset.meses }; li.querySelector('.vg-err').textContent = ''; pintaRenueva(d); return; }
      if (e.target.closest('.vg-cancelar')) { cierra(true); return; }
      if (e.target.closest('.vg-confirmar')) confirma(li, d);
    });
    function confirma(li, d) {
      const inp = li.querySelector('.vg-fecha-in'), err = li.querySelector('.vg-err');
      const iso = inp.value;
      if (!iso) { err.textContent = 'Elige una fecha o una de las opciones.'; return; }
      if (!(delIso(iso) > baseDe(d))) { err.textContent = 'La fecha tiene que ser posterior al ' + larga(baseDe(d)) + '.'; return; }
      renueva(d.id, iso);
    }
    lista.addEventListener('input', e => {
      const inp = e.target.closest('.vg-fecha-in'); if (!inp) return;
      opcion = { fecha: inp.value };                                  // una fecha propia: se apagan las opciones
      const li = inp.closest('.vg-doc'); li.querySelector('.vg-err').textContent = '';
      li.querySelectorAll('.vg-op').forEach(b => b.setAttribute('aria-pressed', 'false'));
    });
    lista.addEventListener('keydown', e => {
      if (e.key === 'Escape' && abierto) { e.preventDefault(); cierra(true); return; }
      if (e.key === 'Enter' && e.target.closest('.vg-fecha-in')) { e.preventDefault(); const li = e.target.closest('.vg-doc'); confirma(li, docs.find(x => x.id === li.dataset.id)); }
    });
    document.addEventListener('pointerdown', e => { if (abierto && !e.target.closest('.vg-doc.is-abierto')) cierra(false); });

    const bDesc = $('[data-descargar]');
    let reloj = 0;
    bDesc.addEventListener('click', () => {
      const blob = new Blob([construyeIcs()], { type: 'text/calendar;charset=utf-8' });
      const url = URL.createObjectURL(blob), a = document.createElement('a');
      a.href = url; a.download = 'vencimientos.ics';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      bDesc.classList.add('is-hecho'); clearTimeout(reloj);
      reloj = setTimeout(() => bDesc.classList.remove('is-hecho'), 2400);
      voz.textContent = 'Descargado: ' + $('[data-ics-n]').textContent + '.';
    });
    $('[data-hora]').textContent = o.horaAviso + ':00';

    docs.slice().sort(orden).forEach(d => lista.appendChild(filas.get(d.id)));
    docs.forEach(d => pintaRenueva(d));            // el cuadro de renovar ya trae su texto: no cambia de tamaño al abrirse
    // la regla de arriba: las marcas de 60, 30, 15, 7 y 0 días sobre la columna de las reglas
    $('[data-escala]').innerHTML = [ESC].concat(U, [0]).map(t => '<i style="left:' + pos(t).toFixed(2) + '%">' + (t === ESC ? t + '+' : t) + '</i>').join('');
    pinta(false);
    return { pasa, renueva, alterna, restablece, estado, ics: construyeIcs, abre, cierra: () => cierra(false) };
  }

  Vigencia.restan = (vence, hoy) => delIso(vence) - delIso(hoy);
  Vigencia.sumaMeses = (iso, m) => aIso(sumaMesesN(delIso(iso), m));
  window.Vigencia = Vigencia;
})();
