/* =====================================================================
   Reasigna · Moxen
   Cuando un profesional falta, sus citas del día se reparten solas entre quienes dan el mismo servicio y tienen la hora libre.
   Marcas «Falta hoy» en una columna y sus citas se levantan y vuelan, una tras otra, a la columna que las atiende; las que no
   tienen dónde caer se quedan marcadas «sin lugar» y se pueden pasar a otro día. La propuesta se confirma o se cambia a mano (con
   el botón de cada fila o tocando la cita), y el margen de hora (misma hora, ± 30 min, ± 1 h) decide cuánto se puede mover cada una.

   Funciona de verdad (nada simulado salvo las agendas de ejemplo de AGENDA y OTROS_DIAS):
   · Asignación óptima. asigna() prueba, con ramificación y poda, todas las formas de repartir las citas del que falta: una cita solo
     va a quien da ese servicio, dentro del horario, fuera del almuerzo, sin pisar ninguna cita de esa persona ni otra cita que
     también se esté moviendo. Entre todas las repartos posibles elige el que coloca más citas; a igual cantidad, el que menos
     las mueve de su hora; y, a igual movimiento, el que reparte la carga entre más personas.
   · Sin lugar. Una cita que no cabe en ninguna columna queda marcada con su motivo («nadie más da ese servicio» o «nadie tiene esa
     hora libre»). otroDia() busca, día a día, el primer día en que alguien que da el servicio tiene un hueco, y de ese día toma el
     más cercano a la hora original.
   · A mano. Cada cambio a mano se elige entre las opciones válidas de esa cita en ese momento (descontando lo que ya ocupan las
     demás propuestas), así que ninguna cita queda encima de otra ni con alguien que no da el servicio.

   Cómo se monta (ver index.html): se inicia solo sobre [data-reasigna].
     const r = Reasigna(document.querySelector('[data-reasigna]'));
     r.falta('A');  r.margen(30);  r.cambia('02');  r.pasaDia('05');  r.confirma();  r.deshace();  r.estado();
     Reasigna.asigna(datos, 'A', 30);   // la función pura, sin pantalla: la usan las pruebas
   Teclado: cada «Falta hoy» y cada cita que se mueve se alcanzan con Tab; Intro cambia el destino de una cita; el margen es un
   grupo de radio (← →); R lo deshace todo. Qué se personaliza: los colores y los píxeles por minuto (--ra-px), al principio de
   reasigna.css; los profesionales, los servicios y las agendas, en PROS, SERVICIOS y AGENDA; el horario, en ABRE, CIERRA y ALMUERZO.
   Nada de Date: las horas son minutos desde medianoche; el movimiento sale de WAAPI y de transiciones CSS. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };

  /* ── el día: minutos desde medianoche ───────────────────────────────────────────── */
  const ABRE = 9 * 60, CIERRA = 17 * 60, ALMUERZO = [13 * 60, 14 * 60], PASO = 15;
  const dos = n => (n < 10 ? '0' : '') + n;
  const hm = t => dos(Math.floor(t / 60)) + ':' + dos(t % 60);
  const aMin = s => +s.slice(0, 2) * 60 + +s.slice(3);

  const SERVICIOS = { con: 'Consulta', ctl: 'Control', cur: 'Curación', ter: 'Terapia', eco: 'Ecografía' };
  // quién da qué: Ecografía solo la da el profesional A, así que sus dos ecografías no caben nunca en otra columna
  const PROS = [
    { id: 'A', nombre: 'Profesional A', servicios: ['con', 'ctl', 'eco'] },
    { id: 'B', nombre: 'Profesional B', servicios: ['con', 'cur', 'ter'] },
    { id: 'C', nombre: 'Profesional C', servicios: ['ctl', 'cur', 'ter'] },
    { id: 'D', nombre: 'Profesional D', servicios: ['con', 'ctl', 'cur'] },
  ];
  // las citas de hoy: [inicio, fin, servicio]; los números de cita se dan en orden, de A a D
  const AGENDA_TXT = {
    A: [['09:00', '09:30', 'con'], ['10:00', '10:30', 'ctl'], ['10:30', '11:15', 'eco'], ['11:30', '12:00', 'con'], ['14:00', '14:30', 'ctl'], ['15:00', '15:45', 'eco'], ['16:00', '16:30', 'con']],
    B: [['09:30', '10:15', 'cur'], ['10:45', '11:45', 'ter'], ['12:00', '12:30', 'con'], ['14:00', '14:30', 'con'], ['15:00', '15:45', 'cur'], ['16:15', '17:00', 'ter']],
    C: [['09:00', '09:45', 'cur'], ['10:00', '11:00', 'ter'], ['11:15', '11:45', 'ctl'], ['14:30', '15:30', 'ter'], ['15:45', '16:15', 'ctl'], ['16:30', '17:00', 'cur']],
    D: [['09:15', '09:45', 'ctl'], ['10:00', '10:30', 'con'], ['11:00', '11:30', 'ctl'], ['12:15', '13:00', 'cur'], ['14:00', '14:30', 'con'], ['15:30', '16:00', 'ctl'], ['16:30', '17:00', 'con']],
  };
  // los días siguientes, para cuando una cita no cabe hoy: solo las franjas ocupadas de cada profesional
  const OTROS_DIAS_TXT = [
    { id: 'vie', corto: 'vie 13', largo: 'viernes 13', ag: { A: ['09:30-10:30', '10:45-11:30', '14:30-15:15'], B: ['09:00-10:00', '11:00-12:30', '15:00-16:30'], C: ['09:30-11:00', '14:00-15:30'], D: ['10:00-11:00', '11:30-12:30', '15:00-16:00'] } },
    { id: 'lun', corto: 'lun 16', largo: 'lunes 16', ag: { A: ['09:00-10:00', '11:00-12:00', '14:00-16:00'], B: ['10:00-12:00', '14:30-16:00'], C: ['09:00-10:30', '15:00-16:30'], D: ['09:30-11:30', '14:00-15:00'] } },
  ];
  const construye = () => {
    let n = 0;
    const ag = {};
    PROS.forEach(p => { ag[p.id] = AGENDA_TXT[p.id].map(([a, b, s]) => ({ id: dos(++n), pro: p.id, ini: aMin(a), dur: aMin(b) - aMin(a), s })); });
    const otros = OTROS_DIAS_TXT.map(d => { const a = {}; for (const p in d.ag) a[p] = d.ag[p].map(x => { const [i, f] = x.split('-'); return [aMin(i), aMin(f)]; }); return { id: d.id, corto: d.corto, largo: d.largo, ag: a }; });
    return { pros: PROS, ag, otros, abre: ABRE, cierra: CIERRA, alm: ALMUERZO };
  };

  /* ── la asignación: el corazón de reasigna ──────────────────────────────────────── */
  /* Un tramo [a, b] está libre para un profesional si cae dentro del horario, no cruza el almuerzo y no pisa ninguna de sus citas
     ni las que ya se le han propuesto (extra). */
  function libre(d, pro, a, b, extra) {
    if (a < d.abre || b > d.cierra || (a < d.alm[1] && b > d.alm[0])) return false;
    for (const c of d.ag[pro]) if (a < c.ini + c.dur && b > c.ini) return false;
    if (extra) for (const x of extra) if (a < x[1] && b > x[0]) return false;
    return true;
  }
  // los lugares válidos de una cita hoy, del más cercano a su hora al más lejano; ocup: lo que ya ocupan otras propuestas
  function opciones(d, falta, c, margen, ocup) {
    const r = [];
    d.pros.forEach((p, k) => {
      if (p.id === falta || !p.servicios.includes(c.s)) return;
      for (let sh = -margen; sh <= margen; sh += PASO) {
        const a = c.ini + sh;
        if (libre(d, p.id, a, a + c.dur, ocup && ocup[p.id])) r.push({ pro: p.id, ini: a, sh, k });
      }
    });
    return r.sort((x, y) => Math.abs(x.sh) - Math.abs(y.sh) || x.sh - y.sh || x.k - y.k);
  }
  // el primer día en que alguien que da el servicio tiene un hueco, y el más cercano a la hora original
  function otroDia(d, c) {
    for (const dia of d.otros) {
      let mejor = null;
      for (const p of d.pros) {
        if (!p.servicios.includes(c.s)) continue;
        for (let a = d.abre; a + c.dur <= d.cierra; a += PASO) {
          const b = a + c.dur;
          if ((a < d.alm[1] && b > d.alm[0]) || dia.ag[p.id].some(x => a < x[1] && b > x[0])) continue;
          const dist = Math.abs(a - c.ini);
          if (!mejor || dist < mejor.dist || (dist === mejor.dist && a < mejor.ini)) mejor = { t: 'dia', dia: dia.id, corto: dia.corto, pro: p.id, ini: a, dist };
        }
      }
      if (mejor) return mejor;
    }
    return null;
  }
  /* Ramificación y poda: cada cita elige uno de sus lugares o se queda sin lugar. Se compara (citas colocadas, minutos movidos,
     reparto de la carga) y se poda la rama que ya no puede mejorar lo mejor encontrado. */
  function asigna(d, falta, margen) {
    const citas = d.ag[falta].slice().sort((a, b) => a.ini - b.ini);
    const ops = citas.map(c => opciones(d, falta, c, margen));
    const orden = citas.map((_, i) => i).sort((a, b) => ops[a].length - ops[b].length || a - b);
    const ocupa = {}, carga = {}, sel = citas.map(() => null);
    d.pros.forEach(p => { ocupa[p.id] = []; carga[p.id] = 0; });
    let mejor = null;
    function rec(k, col, disp, posibles) {
      if (mejor && (col + posibles < mejor.col || (col + posibles === mejor.col && disp > mejor.disp))) return;
      if (k === orden.length) {
        const bal = d.pros.reduce((n, p) => n + carga[p.id] * carga[p.id], 0);
        if (!mejor || col > mejor.col || (col === mejor.col && (disp < mejor.disp || (disp === mejor.disp && bal < mejor.bal)))) mejor = { col, disp, bal, sel: sel.slice() };
        return;
      }
      const i = orden[k], c = citas[i], resto = posibles - (ops[i].length ? 1 : 0);
      for (const o of ops[i]) {
        const oc = ocupa[o.pro];
        if (oc.some(x => o.ini < x[1] && o.ini + c.dur > x[0])) continue;
        oc.push([o.ini, o.ini + c.dur]); sel[i] = o; carga[o.pro]++;
        rec(k + 1, col + 1, disp + Math.abs(o.sh), resto);
        oc.pop(); sel[i] = null; carga[o.pro]--;
      }
      rec(k + 1, col, disp, resto);
    }
    rec(0, 0, 0, ops.filter(o => o.length).length);
    const dest = {};
    citas.forEach((c, i) => { const o = mejor.sel[i]; dest[c.id] = o ? { t: 'hoy', pro: o.pro, ini: o.ini, sh: o.sh } : null; });
    return { citas, dest, colocadas: mejor.col, disp: mejor.disp, opciones: ops.map(o => o.length) };
  }

  const CAL = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="5.5" width="16" height="14" rx="3"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/></svg>';

  function Reasigna(raiz, opts) {
    const o = Object.assign({ margen: 0, datos: construye() }, opts || {});
    const D = o.datos;
    const pista = $('[data-pista]', raiz), cabs = $('[data-cabs]', raiz), filas = $('[data-filas]', raiz), barra = $('[data-barra]', raiz), voz = $('[data-voz]', raiz);
    const segM = $('[data-margen]', raiz), bConf = $('[data-confirma]', raiz), bConfT = $('[data-confirma-t]', raiz), bDesh = $('[data-deshace]', raiz);
    const elEtq = $('[data-etq]', raiz), elTit = $('[data-titulo]', raiz), elSub = $('[data-sub]', raiz);
    const est = { falta: null, margen: o.margen, plan: {}, conf: false, sel: null };
    const todas = [].concat(...D.pros.map(p => D.ag[p.id]));
    const vistas = new Map(), vistasFila = new Map();
    let px = 1;
    const nombre = id => D.pros.find(p => p.id === id).nombre;
    const lee = () => { px = parseFloat(getComputedStyle(raiz).getPropertyValue('--ra-px')) || 1; };
    const col = id => D.pros.findIndex(p => p.id === id);
    const citaDe = id => todas.find(c => c.id === id);
    const delFalta = () => (est.falta ? D.ag[est.falta].slice().sort((a, b) => a.ini - b.ini) : []);
    const dice = t => { voz.textContent = ''; setTimeout(() => { voz.textContent = t; }, 30); };

    /* ── el esqueleto: las columnas, las horas y el almuerzo ───────────────────────── */
    D.pros.forEach((p, i) => {
      const c = h('div', 'ra-cab-col'); c.dataset.pro = p.id;
      c.innerHTML = '<div class="ra-quien"><span class="ra-ini"></span><b></b></div><p class="ra-servs"></p><button type="button" class="ra-falta" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8.5" r="3.6"/><path d="M5 19.5c.8-3.6 3.6-5.4 7-5.4s6.2 1.8 7 5.4M4.5 4.5l15 15"/></svg><span>Falta hoy</span></button>';
      $('.ra-ini', c).textContent = p.id; $('b', c).textContent = p.nombre;
      $('.ra-servs', c).textContent = p.servicios.map(s => SERVICIOS[s]).join(' · ');
      const b = $('.ra-falta', c);
      b.setAttribute('aria-label', p.nombre + ' falta hoy');
      b.addEventListener('click', () => falta(est.falta === p.id ? null : p.id));
      cabs.append(c);
      const f = h('div', 'ra-fondo'); f.dataset.pro = p.id; f.style.left = (i * 25) + '%'; pista.append(f);
    });
    for (let t = ABRE; t <= CIERRA; t += 60) { const e = h('span', 'ra-hora', hm(t)); e.style.top = ((t - ABRE) * px) + 'px'; e.dataset.t = t; pista.append(e); }
    const alm = h('div', 'ra-alm'); alm.append(h('span', '', 'Almuerzo')); pista.append(alm);

    /* ── las citas: un bloque por cita, que se coloca por columna y minuto ──────────── */
    function creaVista(c) {
      const el = h('button', 'ra-cita'); el.type = 'button'; el.dataset.id = c.id; el.setAttribute('role', 'listitem');
      el.innerHTML = '<span class="ra-n"></span><span class="ra-h"><s></s><time></time></span>';
      $('.ra-n', el).textContent = SERVICIOS[c.s];
      el.addEventListener('click', () => { if (est.falta === c.pro) cambia(c.id); });
      pista.append(el);
      const v = { el, tipo: '' };
      vistas.set(c.id, v);
      return v;
    }
    todas.forEach(creaVista);

    // dónde está cada cita ahora: su lugar de hoy, el que se le propone o, si no tiene, el suyo con la marca de «sin lugar»
    function lugarDe(c) {
      if (est.falta !== c.pro) return { pro: c.pro, ini: c.ini, tipo: '' };
      const d = est.plan[c.id];
      if (d && d.t === 'hoy') return { pro: d.pro, ini: d.ini, tipo: est.conf ? 'conf' : 'prop' };
      if (d && d.t === 'dia') return { pro: c.pro, ini: c.ini, tipo: 'dia' };
      return { pro: c.pro, ini: c.ini, tipo: 'sin' };
    }
    function pinta(animar) {
      const antes = new Map();
      if (animar && !quieto()) vistas.forEach((v, id) => antes.set(id, v.el.getBoundingClientRect()));
      todas.forEach(c => {
        const v = vistas.get(c.id), l = lugarDe(c), d = est.plan[c.id];
        const movida = l.pro !== c.pro || l.ini !== c.ini;
        v.el.style.left = 'calc(' + (col(l.pro) * 25) + '% + 4px)';
        v.el.style.top = ((l.ini - ABRE) * px) + 'px';
        v.el.style.height = Math.max(24, c.dur * px - 3) + 'px';
        v.el.className = 'ra-cita' + (l.tipo ? ' ra-' + l.tipo : '');
        if (l.tipo === 'dia') v.el.classList.add('ra-sin-hora');
        v.el.dataset.pro = l.pro; v.el.dataset.ini = l.ini; v.el.dataset.estado = l.tipo || 'normal';
        $('s', v.el).textContent = movida && l.ini !== c.ini ? hm(c.ini) : '';
        $('time', v.el).innerHTML = l.tipo === 'dia' ? CAL + '<span></span>' : '';
        if (l.tipo === 'dia') $('time span', v.el).textContent = d.corto + ' · ' + hm(d.ini);
        else $('time', v.el).textContent = hm(l.ini);
        v.el.disabled = est.falta !== c.pro;
        v.el.tabIndex = est.falta === c.pro ? 0 : -1;
        v.el.setAttribute('aria-label', SERVICIOS[c.s] + ', cita ' + c.id + ', ' + (l.tipo === 'dia' ? 'pasa al ' + d.largo + ' a las ' + hm(d.ini) : l.tipo === 'sin' ? 'sin lugar hoy' : (movida ? 'pasa a ' + nombre(l.pro) + ' a las ' + hm(l.ini) : nombre(l.pro) + ' a las ' + hm(l.ini))));
        v.tipo = l.tipo;
        if (est.sel === c.id) v.el.classList.add('ra-sel');
      });
      // las que cambiaron de lugar vuelan (FLIP), de arriba abajo: la primera sale y las demás la siguen
      if (animar && !quieto()) {
        let rank = 0;
        todas.slice().sort((a, b) => a.ini - b.ini).forEach(c => {
          const v = vistas.get(c.id), a = antes.get(c.id);
          if (!a) return;
          const b = v.el.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top;
          if (Math.abs(dx) < .5 && Math.abs(dy) < .5) return;
          v.el.style.zIndex = 8;
          const an = v.el.animate([
            { transform: 'translate(' + dx + 'px,' + dy + 'px) scale(1)' },
            { transform: 'translate(' + (dx * .45) + 'px,' + (dy * .45 - 16) + 'px) scale(1.045)', offset: .42 },
            { transform: 'none' },
          ], { duration: 760, delay: rank * 85, easing: CURVA, fill: 'backwards' });
          an.onfinish = () => { v.el.style.zIndex = ''; };
          rank++;
        });
      }
      $$('.ra-fondo', pista).forEach(f => f.classList.toggle('ra-ausente', f.dataset.pro === est.falta));
      $$('.ra-cab-col', cabs).forEach(c => {
        const on = c.dataset.pro === est.falta;
        c.classList.toggle('ra-ausente', on);
        $('.ra-falta', c).setAttribute('aria-pressed', on);
      });
    }

    /* ── el plan: la propuesta y lo que se cambia a mano ────────────────────────────── */
    function calcula() {
      est.plan = {}; est.sel = null; est.conf = false;
      if (!est.falta) return;
      const r = asigna(D, est.falta, est.margen);
      delFalta().forEach(c => { est.plan[c.id] = r.dest[c.id]; });
    }
    // las opciones de una cita ahora: lo válido hoy (sin pisar a las demás propuestas) y, al final, otro día
    function opcionesDe(c) {
      const ocup = {};
      D.pros.forEach(p => { ocup[p.id] = []; });
      delFalta().forEach(x => { const d = est.plan[x.id]; if (x.id !== c.id && d && d.t === 'hoy') ocup[d.pro].push([d.ini, d.ini + x.dur]); });
      const r = opciones(D, est.falta, c, est.margen, ocup).map(x => ({ t: 'hoy', pro: x.pro, ini: x.ini, sh: x.sh }));
      const dia = otroDia(D, c);
      if (dia) r.push(dia);
      return r;
    }
    const mismo = (a, b) => !!a && !!b && a.t === b.t && a.pro === b.pro && a.ini === b.ini && a.dia === b.dia;
    function cambia(id) {
      const c = citaDe(id);
      if (!c || est.falta !== c.pro) return;
      const ops = opcionesDe(c);
      if (!ops.length) { dice('La cita ' + id + ' no tiene otro lugar.'); return; }
      const i = ops.findIndex(x => mismo(x, est.plan[id]));
      est.plan[id] = ops[(i + 1) % ops.length]; est.conf = false; est.sel = id;
      refresca(true); dice(textoDestino(c));
    }
    function pasaDia(id) {
      const c = citaDe(id);
      if (!c || est.falta !== c.pro) return;
      const d = otroDia(D, c);
      if (!d) return;
      est.plan[id] = d; est.conf = false; est.sel = id;
      refresca(true); dice(textoDestino(c));
    }
    function textoDestino(c) {
      const d = est.plan[c.id];
      return SERVICIOS[c.s] + ' ' + c.id + ': ' + (!d ? 'sin lugar hoy' : d.t === 'dia' ? 'pasa al ' + d.corto + ' a las ' + hm(d.ini) : nombre(d.pro) + ' a las ' + hm(d.ini));
    }
    function falta(id) {
      est.falta = id; calcula();
      refresca(true, true);
      dice(id ? nombre(id) + ' falta hoy. ' + cuenta().hoy + ' de ' + delFalta().length + ' citas tienen lugar.' : 'Todo en orden.');
    }
    function margen(m) {
      est.margen = m; $$('button', segM).forEach(b => { const on = +b.dataset.m === m; b.setAttribute('aria-checked', on); b.tabIndex = on ? 0 : -1; });
      calcula(); refresca(true);
      if (est.falta) dice('Margen de ' + (m ? m + ' minutos' : 'misma hora') + '. ' + cuenta().hoy + ' citas con lugar hoy.');
    }
    function confirma() {
      if (!est.falta || est.conf) return;
      const n = cuenta();
      if (!n.hoy && !n.dia) return;
      est.conf = true; est.sel = null; refresca(true);
      dice('Listo: ' + (n.hoy + n.dia) + ' citas reubicadas.');
    }
    function deshace() { est.falta = null; est.margen = o.margen; $$('button', segM).forEach(b => { const on = +b.dataset.m === est.margen; b.setAttribute('aria-checked', on); b.tabIndex = on ? 0 : -1; }); calcula(); refresca(true, true); dice('Todo volvió a como estaba.'); }

    const cuenta = () => {
      let hoy = 0, dia = 0, sin = 0;
      delFalta().forEach(c => { const d = est.plan[c.id]; if (!d) sin++; else if (d.t === 'dia') dia++; else hoy++; });
      return { hoy, dia, sin, total: hoy + dia + sin };
    };

    /* ── el panel: el resumen, la barra y una fila por cita ─────────────────────────── */
    function motivo(c) {
      const dan = D.pros.filter(p => p.id !== est.falta && p.servicios.includes(c.s));
      if (!dan.length) return 'Nadie más da ' + SERVICIOS[c.s];
      return 'Nadie tiene esa hora libre' + (est.margen ? ' (± ' + (est.margen === 60 ? '1 h' : est.margen + ' min') + ')' : '');
    }
    function creaFilas() {
      filas.textContent = ''; vistasFila.clear();
      delFalta().forEach((c, i) => {
        const li = h('li', 'ra-fila'); li.dataset.id = c.id; li.style.setProperty('--i', i);
        li.innerHTML = '<div class="ra-f-a"><b></b><span></span></div><div class="ra-f-b"><span class="ra-f-d"></span><small></small></div><button type="button" class="ra-f-btn"></button>';
        $('b', li).textContent = SERVICIOS[c.s]; $('.ra-f-a span', li).textContent = hm(c.ini) + ' · cita ' + c.id;
        li.addEventListener('click', e => { if (!e.target.closest('button')) { est.sel = est.sel === c.id ? null : c.id; pintaFilas(); pinta(false); } });
        filas.append(li); vistasFila.set(c.id, li);
      });
    }
    function pintaFilas() {
      delFalta().forEach(c => {
        const li = vistasFila.get(c.id), d = est.plan[c.id], b = $('.ra-f-btn', li);
        li.className = 'ra-fila' + (!d ? ' ra-f-sin' : d.t === 'dia' ? ' ra-f-dia' : ' ra-f-ok') + (est.sel === c.id ? ' ra-f-sel' : '') + (est.conf ? ' ra-f-conf' : '');
        const dd = $('.ra-f-d', li), peq = $('small', li);
        if (!d) { dd.textContent = 'Sin lugar hoy'; peq.textContent = motivo(c); }
        else if (d.t === 'dia') { dd.textContent = d.corto + ' · ' + hm(d.ini); peq.textContent = 'Pasa a otro día · ' + nombre(d.pro); }
        else { dd.textContent = nombre(d.pro); peq.textContent = hm(d.ini) + (d.sh ? ' · ' + (d.sh > 0 ? '+' : '−') + Math.abs(d.sh) + ' min' : ' · misma hora'); }
        const ops = opcionesDe(c), primera = ops[0];
        if (!d && primera && primera.t === 'dia') { b.className = 'ra-f-btn ra-f-pasa'; b.innerHTML = CAL + '<span></span>'; $('span', b).textContent = primera.corto; b.setAttribute('aria-label', 'Pasar la cita ' + c.id + ' al ' + OTROS(primera.dia).largo + ' a las ' + hm(primera.ini)); b.title = 'Pasar a otro día'; b.hidden = false; b.onclick = () => pasaDia(c.id); }
        else if (!d && primera) { b.className = 'ra-f-btn ra-f-cambia'; b.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h13M13.5 5.5 17 9l-3.5 3.5M20 15H7M10.5 11.5 7 15l3.5 3.5"/></svg>'; b.setAttribute('aria-label', 'Dar un lugar hoy a la cita ' + c.id); b.title = 'Dar un lugar hoy'; b.hidden = false; b.onclick = () => cambia(c.id); }
        else if (d && ops.length > 1) { b.className = 'ra-f-btn ra-f-cambia'; b.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h13M13.5 5.5 17 9l-3.5 3.5M20 15H7M10.5 11.5 7 15l3.5 3.5"/></svg>'; b.setAttribute('aria-label', 'Cambiar el destino de la cita ' + c.id + ' (' + ops.length + ' opciones)'); b.title = 'Otro lugar (' + ops.length + ' opciones)'; b.hidden = false; b.onclick = () => cambia(c.id); }
        else { b.hidden = true; b.onclick = null; }
      });
    }
    const OTROS = id => D.otros.find(x => x.id === id);
    function pintaResumen() {
      const n = cuenta(), tot = delFalta().length;
      barra.textContent = '';
      delFalta().forEach(c => { const d = est.plan[c.id], s = h('i', !d ? 'ra-b-sin' : d.t === 'dia' ? 'ra-b-dia' : 'ra-b-ok'); barra.append(s); });
      barra.classList.toggle('ra-vacia', !tot);
      if (!est.falta) {
        elEtq.textContent = 'Todo en orden'; elTit.textContent = 'Marca a quién falta hoy';
        elSub.textContent = 'Sus citas se reparten entre quienes dan el mismo servicio y tienen la hora libre.';
      } else if (est.conf) {
        elEtq.textContent = nombre(est.falta) + ' falta hoy';
        elTit.textContent = (n.hoy + n.dia) + (n.hoy + n.dia === 1 ? ' cita reubicada' : ' citas reubicadas');
        elSub.textContent = n.sin ? (n.sin === 1 ? 'Una cita sigue sin lugar: hay que llamar a su cliente.' : n.sin + ' citas siguen sin lugar: hay que llamar a sus clientes.') : 'Ninguna cita se pierde.';
      } else {
        elEtq.textContent = nombre(est.falta) + ' falta hoy';
        elTit.textContent = n.hoy + ' de ' + tot + (n.hoy === 1 ? ' cita tiene lugar hoy' : ' citas tienen lugar hoy');
        elSub.textContent = [n.dia ? n.dia + (n.dia === 1 ? ' pasa a otro día' : ' pasan a otro día') : '', n.sin ? n.sin + ' sin lugar' : ''].filter(Boolean).join(' · ') || (n.hoy === tot ? 'Se repartió todo el día.' : '');
        if (n.sin && !n.dia) elSub.textContent = n.sin + (n.sin === 1 ? ' cita no cabe hoy: pásala a otro día.' : ' citas no caben hoy: pásalas a otro día.');
      }
      const mover = n.hoy + n.dia;
      bConf.disabled = !est.falta || est.conf || !mover;
      bConfT.textContent = est.conf ? 'Confirmado' : mover ? 'Confirmar ' + mover + (mover === 1 ? ' cambio' : ' cambios') : 'Confirmar cambios';
      bConf.classList.toggle('ra-hecho', est.conf);
      bDesh.disabled = !est.falta;
      raiz.classList.toggle('ra-con-falta', !!est.falta);
      raiz.classList.toggle('ra-confirmado', est.conf);
    }
    function refresca(animar, nuevas) {
      if (nuevas) creaFilas();
      pinta(animar); pintaFilas(); pintaResumen();
      if (nuevas && est.falta) $$('.ra-fila', filas).forEach(f => { f.classList.remove('ra-entra'); void f.offsetWidth; if (!quieto()) f.classList.add('ra-entra'); });
    }

    /* ── los controles ──────────────────────────────────────────────────────────────── */
    segM.addEventListener('click', e => { const b = e.target.closest('button'); if (b) margen(+b.dataset.m); });
    segM.addEventListener('keydown', e => {
      if (!/^Arrow(Left|Right|Up|Down)$/.test(e.key)) return;
      const bs = $$('button', segM), i = bs.findIndex(b => b.getAttribute('aria-checked') === 'true'), j = Math.max(0, Math.min(bs.length - 1, i + (/Left|Up/.test(e.key) ? -1 : 1)));
      e.preventDefault(); margen(+bs[j].dataset.m); bs[j].focus();
    });
    bConf.addEventListener('click', confirma);
    bDesh.addEventListener('click', deshace);
    raiz.addEventListener('keydown', e => {
      if (e.ctrlKey || e.metaKey || e.altKey || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
      if (e.key.toLowerCase() === 'r') deshace();
    });
    window.addEventListener('resize', () => { lee(); pinta(false); });

    /* ── arranque ───────────────────────────────────────────────────────────────────── */
    lee();
    $$('.ra-hora', pista).forEach(e => { e.style.top = ((+e.dataset.t - ABRE) * px) + 'px'; });
    alm.style.top = ((ALMUERZO[0] - ABRE) * px) + 'px'; alm.style.height = ((ALMUERZO[1] - ALMUERZO[0]) * px) + 'px';
    $$('button', segM).forEach(b => { const on = +b.dataset.m === est.margen; b.setAttribute('aria-checked', on); b.tabIndex = on ? 0 : -1; });
    refresca(false, true);

    const api = {
      falta, margen, cambia, pasaDia, confirma, deshace, datos: D,
      estado: () => ({
        falta: est.falta, margen: est.margen, confirmado: est.conf, ...cuenta(),
        citas: todas.map(c => { const d = est.plan[c.id]; const l = lugarDe(c); return { id: c.id, pro0: c.pro, ini0: c.ini, dur: c.dur, s: c.s, pro: l.pro, ini: l.ini, tipo: est.falta === c.pro ? (!d ? 'sin' : d.t) : 'normal', dia: d && d.t === 'dia' ? d.dia : null, diaPro: d && d.t === 'dia' ? d.pro : null, diaIni: d && d.t === 'dia' ? d.ini : null }; }),
      }),
    };
    raiz.__reasigna = api;
    return api;
  }

  Reasigna.asigna = asigna; Reasigna.opciones = opciones; Reasigna.otroDia = otroDia; Reasigna.construye = construye;
  window.Reasigna = Reasigna;
  $$('[data-reasigna]').forEach(el => Reasigna(el));
})();
