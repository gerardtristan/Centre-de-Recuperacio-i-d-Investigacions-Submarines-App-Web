/* =====================================================================
   Teletipo · Moxen
   Un lector de suscripciones que lee de verdad los archivos que se le sueltan: RSS 2.0, Atom, JSON Feed y OPML (todo en
   teletipo-nucleo.js, que usa DOMParser). Nada sale del navegador:

   · Al soltar un archivo (o con «Usar los ejemplos», que son tres feeds escritos a mano, uno en cada formato), cada fuente
     entra en el lateral con su contador de no leídos que rueda y sus artículos se imprimen en el rollo como tiras de teletipo,
     de la más reciente a la más antigua, con la fecha relativa. Un OPML trae suscripciones sin artículos (Teletipo no descarga
     nada): quedan en el lateral esperando el archivo de su feed.
   · Abrir un artículo lo muestra a la derecha, limpio: el HTML se reescribe con una lista blanca (sin scripts, estilos,
     marcos ni imágenes, y con los parámetros de seguimiento de los enlaces quitados) y debajo se dice qué se quitó. Su tira
     pasa a gris y los contadores bajan. Lo leído y lo guardado se recuerda en localStorage por artículo.
   · j / k recorren y abren; m marca como leído o no leído; s guarda; u deja solo lo no leído; / busca dentro de los artículos
     (sin tildes ni mayúsculas, resaltando lo encontrado); «Todo leído» pone en gris lo que se ve, vacía los contadores y
     estampa un ✓ rojo de urgente.
   · «Exportar OPML» descarga las suscripciones; lo exportado vuelve a importar las mismas fuentes.

   Montaje (se inicia solo sobre [data-teletipo]; el HTML de la demo es la plantilla):
     const t = Teletipo(document.querySelector('[data-teletipo]'));
     t.ingesta(textoDelFeed, 'nombre.xml');  t.cargaEjemplos();  t.abre(id);  t.marca(id);  t.guarda(id);  t.todoLeido();
     t.exporta();  t.reinicia();  t.estado();  t.prueba();
     Teletipo.nucleo   // detecta, leeFeed, leeOpml, exportaOpml, sanea, fechaRelativa…: lo que lee, sin pantalla
   Teclado: j / k, m, s, u, / (buscar), Mayús + A (todo leído), E (exportar), R (reiniciar), Esc (vuelve del lector en pantalla
   estrecha o vacía la búsqueda). Tab recorre las tiras y Intro abre la enfocada.

   Qué cambia qué: el rojo de urgente y el azul de lo guardado, al principio de teletipo.css (--tt-rojo, --tt-azul). Los feeds de
   ejemplo, en teletipo-ejemplos.js. El tiempo sale de requestAnimationFrame, setTimeout y animaciones; lo que se limpia al
   terminar una animación va con un setTimeout, nunca con `onfinish`. La fecha relativa usa la hora del sistema (solo para el
   texto «hace 5 min»). Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const N = window.TeletipoNucleo, E = window.TeletipoEjemplos;
  const mq = typeof matchMedia === 'function' ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  const quieto = () => mq.matches;
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const anima = (el, kf, op) => (quieto() || !el || !el.animate) ? null : el.animate(kf, op);
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';
  const REBOTE = 'cubic-bezier(.3, 1.3, .5, 1)';
  const CLAVE = 'teletipo-v1';
  const MAXLISTA = 300;                                    // tiras que se pintan a la vez
  const FORMATO = { rss: 'RSS', atom: 'Atom', json: 'JSON Feed', opml: 'OPML' };

  function Teletipo(raiz, opc) {
    opc = opc || {};
    const q = s => raiz.querySelector(s);
    const els = {
      app: q('[data-app]'), fuentes: q('[data-fuentes]'), anade: q('[data-anade]'), exporta: q('[data-exporta]'), archivos: q('[data-archivos]'),
      vistaT: q('[data-vista-t]'), vistaN: q('[data-vista-n]'), todo: q('[data-todo]'), q: q('[data-q]'), solo: q('[data-solo]'),
      papel: q('[data-papel]'), lista: q('[data-lista]'), aviso: q('[data-aviso]'), nada: q('[data-nada]'), vacio: q('[data-vacio]'), sello: q('[data-sello]'),
      ejemplos: q('[data-ejemplos]'), elegir: q('[data-elegir]'), soltar: q('[data-soltar]'), vivo: q('[data-vivo]'),
      lector: q('[data-lector]'), hueco: q('[data-lector-hueco]'), cuerpo: q('[data-lector-cuerpo]'), atras: q('[data-atras]'),
      lFuente: q('[data-l-fuente]'), lFecha: q('[data-l-fecha]'), lTitulo: q('[data-l-titulo]'), lAutor: q('[data-l-autor]'), lTexto: q('[data-l-texto]'),
      lLimpio: q('[data-l-limpio]'), lLeido: q('[data-l-leido]'), lGuarda: q('[data-l-guarda]'), lOriginal: q('[data-l-original]'),
    };
    const est = { fuentes: [], vista: 'todas', solo: false, q: '', sel: null, pegadas: new Set(), leidos: new Set(), guardados: new Set(), visibles: [], orden: 0 };
    const porId = new Map();
    const temp = {};
    let anims = [];
    const pon = (clave, f, ms) => { clearTimeout(temp[clave]); temp[clave] = setTimeout(f, ms); };
    const anim = (el, kf, op) => { const a = anima(el, kf, op); if (a) anims.push(a); return a; };
    const dice = t => { els.vivo.textContent = ''; setTimeout(() => { els.vivo.textContent = t; }, 30); };
    const ahora = () => Date.now();

    /* ------------------------------------------------------------------
       Lo leído y lo guardado se recuerda por artículo
       ------------------------------------------------------------------ */
    function leeAlmacen() {
      try {
        const j = JSON.parse(localStorage.getItem(CLAVE) || 'null');
        if (j) { est.leidos = new Set(j.leidos || []); est.guardados = new Set(j.guardados || []); }
      } catch (e) { /* sin almacenamiento: se lee igual, pero no se recuerda */ }
    }
    function guardaAlmacen() {
      try { localStorage.setItem(CLAVE, JSON.stringify({ leidos: Array.from(est.leidos).slice(-5000), guardados: Array.from(est.guardados).slice(-2000) })); } catch (e) { /* idem */ }
    }

    /* ------------------------------------------------------------------
       Datos: fuentes y artículos
       ------------------------------------------------------------------ */
    const fuente = id => est.fuentes.find(f => f.id === id);
    const todos = () => est.fuentes.reduce((l, f) => l.concat(f.articulos), []);
    const noLeidos = lista => lista.reduce((n, a) => n + (est.leidos.has(a.id) ? 0 : 1), 0);

    function prepara(f, a) {
      const id = f.id + '|' + a.guid;
      const san = N.sanea(a.html, f.web);
      const res = a.resumen ? N.sanea(a.resumen, f.web).texto : '';
      const art = Object.assign({}, a, { id, fuenteId: f.id, orden: est.orden++, _san: san, texto: san.texto, resumenTxt: (res || san.texto).slice(0, 220) });
      porId.set(id, art);
      return art;
    }
    function fusiona(feed) {
      let f = fuente(feed.id);
      const nueva = !f;
      if (!f) { f = { id: feed.id, titulo: feed.titulo, url: feed.url || '', web: feed.web || '', formato: feed.formato, carpeta: '', articulos: [], vacia: false }; est.fuentes.push(f); }
      f.titulo = feed.titulo || f.titulo; f.formato = feed.formato; f.web = feed.web || f.web; f.url = feed.url || f.url; f.vacia = false;
      const vistos = new Set(f.articulos.map(a => a.guid));
      let nuevos = 0;
      feed.articulos.forEach(a => { if (!vistos.has(a.guid)) { vistos.add(a.guid); f.articulos.push(prepara(f, a)); nuevos++; } });
      return { ok: true, tipo: feed.formato, fuente: f, nueva, nuevos };
    }
    function fusionaOpml(o) {
      let nuevas = 0, ya = 0;
      const ids = [];
      o.fuentes.forEach(s => {
        const id = N.slug(s.url);
        const f = fuente(id);
        if (f) { ya++; if (!f.carpeta && s.carpeta) f.carpeta = s.carpeta; return; }
        est.fuentes.push({ id, titulo: s.titulo, url: s.url, web: s.web, formato: '', carpeta: s.carpeta, articulos: [], vacia: true });
        nuevas++; ids.push(id);
      });
      return { ok: true, tipo: 'opml', nuevas, ya, total: o.fuentes.length, ids };
    }
    /* Un texto (feed u OPML) entra: devuelve lo que pasó, sin pintar nada. */
    function ingesta(texto, nombre) {
      const tipo = N.detecta(texto);
      try {
        if (tipo === 'opml') return fusionaOpml(N.leeOpml(texto));
        return fusiona(N.leeFeed(texto));
      } catch (e) {
        return { ok: false, error: (nombre ? nombre + ': ' : '') + e.message };
      }
    }

    /* ------------------------------------------------------------------
       Lo que se ve: filtros y orden
       ------------------------------------------------------------------ */
    const tokens = () => N.plano(est.q).split(/\s+/).filter(Boolean);
    function calcula() {
      let lista;
      if (est.vista === 'guardados') lista = todos().filter(a => est.guardados.has(a.id));
      else if (est.vista.slice(0, 2) === 'f:') { const f = fuente(est.vista.slice(2)); lista = f ? f.articulos.slice() : []; }
      else lista = todos();
      const toks = tokens();
      if (toks.length) lista = lista.filter(a => { const h = a._h || (a._h = N.plano(a.titulo + ' ' + a.texto + ' ' + a.autor + ' ' + a.etiquetas.join(' '))); return toks.every(t => h.indexOf(t) >= 0); });
      if (est.solo) lista = lista.filter(a => !est.leidos.has(a.id) || est.pegadas.has(a.id));
      lista.sort((a, b) => (b.fecha - a.fecha) || (a.orden - b.orden));
      est.visibles = lista;
      return lista;
    }
    function resalta(txt) {
      const toks = tokens();
      if (!toks.length) return esc(txt);
      const f = txt.split('').map(c => (c.normalize('NFD')[0] || c).toLowerCase()).join('');
      const rangos = [];
      toks.forEach(t => { let i = f.indexOf(t); while (i >= 0) { rangos.push([i, i + t.length]); i = f.indexOf(t, i + t.length); } });
      if (!rangos.length) return esc(txt);
      rangos.sort((a, b) => a[0] - b[0]);
      const fus = [];
      rangos.forEach(r => { const u = fus[fus.length - 1]; if (u && r[0] <= u[1]) u[1] = Math.max(u[1], r[1]); else fus.push([r[0], r[1]]); });
      let out = '', pos = 0;
      fus.forEach(([a, b]) => { out += esc(txt.slice(pos, a)) + '<mark>' + esc(txt.slice(a, b)) + '</mark>'; pos = b; });
      return out + esc(txt.slice(pos));
    }

    /* ------------------------------------------------------------------
       Contadores que ruedan
       ------------------------------------------------------------------ */
    function rueda(el, a, animar) {
      const de = el._v === undefined ? 0 : el._v;
      el._v = a;
      cancelAnimationFrame(el._raf);
      el.classList.toggle('cero', a === 0);
      if (!animar || quieto() || de === a) { el.textContent = a; return; }
      let ini = null;
      const paso = t => {
        if (ini === null) ini = t;
        const u = Math.min(1, (t - ini) / 560), e = 1 - Math.pow(1 - u, 3);
        el.textContent = Math.round(de + (a - de) * e);
        if (u < 1) el._raf = requestAnimationFrame(paso);
      };
      el._raf = requestAnimationFrame(paso);
    }
    function pintaContadores(animar) {
      const todas = todos();
      rueda(raiz.querySelector('[data-cont="todas"]'), noLeidos(todas), animar);
      rueda(raiz.querySelector('[data-cont="guardados"]'), todas.filter(a => est.guardados.has(a.id)).length, animar);
      est.fuentes.forEach(f => { const c = els.fuentes.querySelector('[data-cont-f="' + f.id + '"]'); if (c) rueda(c, noLeidos(f.articulos), animar); });
      pintaCab();
    }
    function nombreVista() {
      if (est.vista === 'guardados') return 'Guardados';
      if (est.vista.slice(0, 2) === 'f:') { const f = fuente(est.vista.slice(2)); return f ? f.titulo : 'Fuente'; }
      return 'Todas las novedades';
    }
    function pintaCab() {
      els.vistaT.textContent = nombreVista();
      if (!est.fuentes.length) { els.vistaN.textContent = 'Sin suscripciones'; els.todo.disabled = true; return; }
      const base = est.vista === 'guardados' ? todos().filter(a => est.guardados.has(a.id)) : est.vista.slice(0, 2) === 'f:' ? (fuente(est.vista.slice(2)) || { articulos: [] }).articulos : todos();
      const nl = noLeidos(base);
      els.vistaN.textContent = base.length ? (nl ? nl + ' sin leer de ' + base.length : 'Todo leído · ' + base.length + ' artículos') : (est.vista === 'guardados' ? 'Nada guardado todavía' : 'Sin artículos');
      els.todo.disabled = !est.visibles.some(a => !est.leidos.has(a.id));
      els.todo.querySelector('span').textContent = 'Todo leído';
    }

    /* ------------------------------------------------------------------
       El lateral
       ------------------------------------------------------------------ */
    function pintaFuentes(nuevas) {
      els.fuentes.innerHTML = !est.fuentes.length ? '<li class="tt-sin-fuentes">Las fuentes que añadas aparecen aquí, cada una con su contador de no leídos.</li>' : est.fuentes.map(f =>
        '<li><button type="button" class="tt-fila tt-fuente" data-f="' + esc(f.id) + '" aria-pressed="' + (est.vista === 'f:' + f.id) + '" title="' + esc(f.titulo) + '">' +
        '<i class="tt-punto" aria-hidden="true"></i><span class="tt-fuente-t">' + esc(f.titulo) + '<small>' + esc(f.vacia ? 'OPML · sin artículos' : FORMATO[f.formato] + ' · ' + f.articulos.length + ' artículos') + '</small></span>' +
        '<i class="tt-cont" data-cont-f="' + esc(f.id) + '">0</i></button></li>').join('');
      if (!est.fuentes.length) return;
      Array.from(els.fuentes.children).forEach((li, k) => {
        const f = est.fuentes[k], b = li.firstChild, c = b.querySelector('.tt-cont');
        c._v = undefined;
        const nuevo = nuevas && nuevas.indexOf(f.id) >= 0;
        rueda(c, noLeidos(f.articulos), nuevo);
        if (nuevo) anim(li, [{ transform: 'translateX(-28px)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 520, delay: 80 + nuevas.indexOf(f.id) * 110, easing: CURVA, fill: 'backwards' });
      });
    }
    function activaVista() {
      raiz.querySelectorAll('[data-ver]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.ver === est.vista)));
      els.fuentes.querySelectorAll('[data-f]').forEach(b => b.setAttribute('aria-pressed', String('f:' + b.dataset.f === est.vista)));
    }
    function ponVista(v) {
      est.vista = v; est.pegadas = new Set();
      activaVista();
      pintaLista({ flip: false, entrada: false });
      anim(els.lista, [{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 280, easing: CURVA });
      pintaCab();
      els.papel.scrollTop = 0;
    }

    /* ------------------------------------------------------------------
       El rollo: las tiras
       ------------------------------------------------------------------ */
    function htmlTira(a) {
      const f = fuente(a.fuenteId);
      const leida = est.leidos.has(a.id), guardada = est.guardados.has(a.id), activa = a.id === est.sel;
      return '<li class="tt-item" data-id="' + esc(a.id) + '"><button type="button" class="tt-tira' + (leida ? ' leida' : '') + (guardada ? ' guardada' : '') + (activa ? ' activa' : '') + '" data-id="' + esc(a.id) + '" aria-current="' + activa + '">' +
        '<span class="tt-roja" aria-hidden="true"></span>' +
        '<span class="tt-tira-cab"><span class="tt-slug">' + esc(f ? f.titulo : '') + '</span><time class="tt-hora" data-ms="' + a.fecha + '">' + esc(N.fechaRelativa(a.fecha, ahora())) + '</time></span>' +
        '<span class="tt-tit">' + resalta(a.titulo) + '</span><span class="tt-res">' + resalta(a.resumenTxt) + '</span>' +
        '<svg class="tt-mar" viewBox="0 0 24 24" aria-hidden="true"><use href="#tt-i-marcador"/></svg>' +
        '<span class="tt-oculto">' + (leida ? 'Leído' : 'No leído') + (guardada ? ', guardado' : '') + '</span></button></li>';
    }
    function pintaLista(op) {
      op = op || {};
      const lista = calcula();
      const antes = new Map();
      if (op.flip && !quieto()) Array.from(els.lista.children).forEach(li => antes.set(li.dataset.id, li.getBoundingClientRect().top));
      anims.forEach(a => { try { a.cancel(); } catch (e) { /* ya terminada */ } }); anims = [];
      els.lista.innerHTML = lista.slice(0, MAXLISTA).map(htmlTira).join('');
      const hayFuentes = est.fuentes.length > 0;
      raiz.dataset.vista = hayFuentes ? 'lista' : 'vacio';
      els.vacio.hidden = hayFuentes;
      pintaNada(lista);
      const items = Array.from(els.lista.children);
      if (op.entrada && !quieto()) {
        // las tiras se imprimen de arriba abajo, a saltos, como un teletipo
        items.slice(0, 10).forEach((li, k) => anim(li.firstChild, [{ clipPath: 'inset(0 0 100% 0)', transform: 'translateY(-10px)' }, { clipPath: 'inset(0 0 0 0)', transform: 'none' }], { duration: 560, delay: 160 + k * 85, easing: 'steps(8, end)', fill: 'backwards' }));
      } else if (op.flip && !quieto()) {
        items.forEach(li => {
          const t0 = antes.get(li.dataset.id);
          if (t0 === undefined) anim(li, [{ opacity: 0, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: 320, easing: CURVA, fill: 'backwards' });
          else { const dy = t0 - li.getBoundingClientRect().top; if (Math.abs(dy) > 1) anim(li, [{ transform: 'translateY(' + dy + 'px)' }, { transform: 'none' }], { duration: 420, easing: CURVA }); }
        });
      }
    }
    function pintaNada(lista) {
      const hay = est.fuentes.length > 0 && !lista.length;
      els.nada.hidden = !hay;
      if (!hay) return;
      if (est.q.trim()) els.nada.innerHTML = '<b>Nada coincide con «' + esc(est.q.trim()) + '»</b><span>Prueba con otra palabra. Se busca en títulos, textos, autores y etiquetas, sin tildes ni mayúsculas.</span>';
      else if (est.vista === 'guardados') els.nada.innerHTML = '<b>Nada guardado todavía</b><span>Pulsa <kbd>s</kbd> en un artículo para guardarlo aquí.</span>';
      else if (est.solo) els.nada.innerHTML = '<b class="tt-al-dia"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#tt-i-tilde"/></svg>Al día</b><span>No queda nada sin leer en esta vista. Quita el filtro para volver a verlo todo.</span>';
      else if (est.vista === 'todas' && est.fuentes.every(f => f.vacia)) els.nada.innerHTML = '<b>Suscripciones sin artículos</b><span>Un OPML solo lista las suscripciones: Teletipo no descarga nada. Suelta aquí el archivo de cada feed para leerlos.</span>';
      else { const f = est.vista.slice(0, 2) === 'f:' ? fuente(est.vista.slice(2)) : null; els.nada.innerHTML = f && f.vacia ? '<b>' + esc(f.titulo) + ' no trae artículos</b><span>Vino en un OPML, que solo lista suscripciones. Suelta aquí el archivo de su feed para leerla.</span>' : '<b>Sin artículos</b><span>Esta fuente no trae entradas.</span>'; }
    }
    function tiraDe(id) { return Array.from(els.lista.children).find(li => li.dataset.id === id); }
    function asegura(id) {
      const li = tiraDe(id); if (!li) return;
      const c = els.papel, top = li.offsetTop, h = li.offsetHeight;
      if (top < c.scrollTop + 6) c.scrollTop = Math.max(0, top - 6);
      else if (top + h > c.scrollTop + c.clientHeight - 6) c.scrollTop = top + h - c.clientHeight + 6;
    }
    function refrescaHoras() {
      const t = ahora();
      els.lista.querySelectorAll('.tt-hora').forEach(h => { h.textContent = N.fechaRelativa(+h.dataset.ms, t); });
      if (est.sel && porId.get(est.sel)) els.lFecha.textContent = N.fechaLarga(porId.get(est.sel).fecha) + ' · ' + N.fechaRelativa(porId.get(est.sel).fecha, t);
    }

    /* ------------------------------------------------------------------
       El lector
       ------------------------------------------------------------------ */
    function pintaLector(a) {
      const f = fuente(a.fuenteId);
      els.hueco.hidden = true; els.cuerpo.hidden = false;
      els.lFuente.textContent = f.titulo;
      els.lFecha.textContent = N.fechaLarga(a.fecha) ? N.fechaLarga(a.fecha) + ' · ' + N.fechaRelativa(a.fecha, ahora()) : 'sin fecha';
      els.lTitulo.textContent = a.titulo;
      els.lAutor.textContent = [a.autor ? 'Por ' + a.autor : '', a.etiquetas.length ? a.etiquetas.join(' · ') : ''].filter(Boolean).join('  ·  ');
      els.lAutor.hidden = !els.lAutor.textContent;
      els.lTexto.innerHTML = a._san.html || '<p class="tt-sin">Este artículo no trae texto: ábrelo en su sitio original.</p>';
      const fr = N.frase(a._san.informe);
      els.lLimpio.querySelector('span').textContent = fr ? 'Limpio: se quitó ' + fr : 'Limpio: no había nada que quitar';
      const enl = N.limpiaEnlace(a.url, f.web);
      if (enl) els.lOriginal.setAttribute('href', enl.href); else els.lOriginal.removeAttribute('href');
      els.lOriginal.hidden = !enl;
      pintaBotonesLector(a);
      els.lector.scrollTop = 0;
      if (!quieto()) {
        anim(els.lTitulo, [{ clipPath: 'inset(0 0 100% 0)' }, { clipPath: 'inset(0 0 0 0)' }], { duration: 420, easing: 'steps(7, end)' });
        anim(els.lTexto, [{ opacity: 0, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: 480, delay: 160, easing: CURVA, fill: 'backwards' });
        anim(els.lFuente.parentNode, [{ opacity: 0 }, { opacity: 1 }], { duration: 240 });
      }
    }
    function pintaBotonesLector(a) {
      const leido = est.leidos.has(a.id), g = est.guardados.has(a.id);
      els.lLeido.querySelector('span').textContent = leido ? 'Marcar no leído' : 'Marcar leído';
      els.lGuarda.setAttribute('aria-pressed', String(g));
      els.lGuarda.querySelector('span').textContent = g ? 'Guardado' : 'Guardar';
    }
    function ponTira(id) {
      const li = tiraDe(id); if (!li) return;
      const b = li.firstChild, a = porId.get(id);
      b.classList.toggle('leida', est.leidos.has(id));
      b.classList.toggle('guardada', est.guardados.has(id));
      b.querySelector('.tt-oculto').textContent = (est.leidos.has(id) ? 'Leído' : 'No leído') + (est.guardados.has(id) ? ', guardado' : '');
      if (a) b.setAttribute('aria-label', a.titulo);
    }
    function abre(id, op) {
      op = op || {};
      const a = porId.get(id); if (!a) return;
      const antes = est.sel;
      est.sel = id;
      if (est.solo) est.pegadas.add(id);
      if (!est.leidos.has(id)) { est.leidos.add(id); guardaAlmacen(); }
      if (antes) { const o = tiraDe(antes); if (o) { o.firstChild.classList.remove('activa'); o.firstChild.setAttribute('aria-current', 'false'); } }
      const li = tiraDe(id);
      if (li) { li.firstChild.classList.add('activa'); li.firstChild.setAttribute('aria-current', 'true'); }
      ponTira(id);
      pintaLector(a);
      pintaContadores(true);
      if (op.scroll !== false) asegura(id);
      raiz.dataset.lectura = '1';
      dice('Leyendo: ' + a.titulo);
    }
    function alternaLeido(id) {
      id = id || est.sel;
      const a = porId.get(id); if (!a) return;
      if (est.leidos.has(id)) est.leidos.delete(id); else est.leidos.add(id);
      if (est.solo) est.pegadas.add(id);
      guardaAlmacen();
      ponTira(id); pintaContadores(true);
      if (id === est.sel) pintaBotonesLector(a);
      dice((est.leidos.has(id) ? 'Marcado como leído: ' : 'Marcado como no leído: ') + a.titulo);
    }
    function alternaGuardado(id) {
      id = id || est.sel;
      const a = porId.get(id); if (!a) return;
      if (est.guardados.has(id)) est.guardados.delete(id); else est.guardados.add(id);
      guardaAlmacen();
      ponTira(id); pintaContadores(true);
      if (id === est.sel) pintaBotonesLector(a);
      const li = tiraDe(id);
      if (li && est.guardados.has(id)) anim(li.querySelector('.tt-mar'), [{ transform: 'translateY(-8px) scale(.4)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 420, easing: REBOTE });
      if (est.vista === 'guardados' && !est.guardados.has(id)) pon('quita', () => pintaLista({ flip: true }), 260);
      dice((est.guardados.has(id) ? 'Guardado: ' : 'Quitado de guardados: ') + a.titulo);
    }
    function mueve(d) {
      const lista = est.visibles; if (!lista.length) return;
      let i = lista.findIndex(a => a.id === est.sel);
      i = i < 0 ? (d > 0 ? 0 : lista.length - 1) : Math.max(0, Math.min(lista.length - 1, i + d));
      abre(lista[i].id);
    }

    /* ------------------------------------------------------------------
       Todo leído
       ------------------------------------------------------------------ */
    function todoLeido() {
      const lista = est.visibles.filter(a => !est.leidos.has(a.id));
      if (!lista.length) return 0;
      lista.forEach(a => est.leidos.add(a.id));
      guardaAlmacen();
      // las tiras se ponen grises en cascada desde la primera visible
      let k = 0;
      Array.from(els.lista.children).forEach(li => {
        const b = li.firstChild;
        if (b.classList.contains('leida')) return;
        if (!quieto() && k < 16) b.style.transitionDelay = k * 55 + 'ms';
        b.classList.add('leida');
        b.querySelector('.tt-oculto').textContent = 'Leído';
        k++;
      });
      pon('limpiaDelay', () => els.lista.querySelectorAll('.tt-tira').forEach(b => { b.style.transitionDelay = ''; }), 1400);
      if (est.sel && porId.get(est.sel)) pintaBotonesLector(porId.get(est.sel));
      pintaContadores(true);
      sella();
      if (est.solo) pon('alDia', () => { est.pegadas = new Set(); pintaLista({ flip: true }); pintaCab(); }, quieto() ? 0 : 1250);
      dice('Todo leído: ' + lista.length + ' artículos');
      return lista.length;
    }
    function sella() {
      els.sello.hidden = false;
      anim(els.sello, [{ opacity: 0, transform: 'translate(-50%, -50%) scale(2.4) rotate(-26deg)' }, { opacity: 1, transform: 'translate(-50%, -50%) scale(.94) rotate(-9deg)', offset: .5 }, { opacity: 1, transform: 'translate(-50%, -50%) scale(1) rotate(-9deg)', offset: .62 }, { opacity: 1, transform: 'translate(-50%, -50%) scale(1) rotate(-9deg)', offset: .86 }, { opacity: 0, transform: 'translate(-50%, -50%) scale(1.05) rotate(-9deg)' }], { duration: 1400, easing: CURVA });
      pon('sello', () => { els.sello.hidden = true; }, quieto() ? 900 : 1450);
    }

    /* ------------------------------------------------------------------
       Entrada de archivos
       ------------------------------------------------------------------ */
    function aviso(texto, tipo) {
      els.aviso.className = 'tt-aviso ' + (tipo || 'info');
      els.aviso.innerHTML = '<b>' + (tipo === 'error' ? 'Error' : 'Aviso') + '</b><span>' + esc(texto) + '</span>';
      els.aviso.hidden = false;
      anim(els.aviso, [{ transform: 'translateY(-100%)' }, { transform: 'none' }], { duration: 380, easing: 'steps(6, end)' });
      pon('aviso', () => { els.aviso.hidden = true; }, tipo === 'error' ? 6500 : 4200);
    }
    function ingestaVarios(items) {
      const informes = items.map(it => ingesta(it.texto, it.nombre));
      const nuevas = [];
      informes.forEach(r => { if (r.ok && r.tipo === 'opml') r.ids.forEach(i => nuevas.push(i)); else if (r.ok && r.nueva) nuevas.push(r.fuente.id); });
      const nFeeds = informes.filter(r => r.ok && r.tipo !== 'opml').length;
      const nuevosArt = informes.reduce((n, r) => n + (r.ok && r.tipo !== 'opml' ? r.nuevos : 0), 0);
      const errores = informes.filter(r => !r.ok);
      if (est.fuentes.length) {
        if (est.vista !== 'todas' && est.vista.slice(0, 2) !== 'f:' && est.vista !== 'guardados') est.vista = 'todas';
        pintaFuentes(nuevas);
        activaVista();
        pintaLista({ entrada: true });
        pintaContadores(true);
      }
      const op = informes.find(r => r.ok && r.tipo === 'opml');
      if (errores.length) aviso(errores[0].error + (errores.length > 1 ? ' (y ' + (errores.length - 1) + ' más)' : ''), 'error');
      else if (op && !nFeeds) aviso('OPML: ' + op.nuevas + ' suscripciones nuevas' + (op.ya ? ' (' + op.ya + ' ya estaban)' : '') + '. Sin artículos: suelta el archivo de cada feed para leerlos.', 'info');
      if (nFeeds || (op && op.nuevas)) dice('Añadido: ' + nFeeds + ' feeds, ' + nuevosArt + ' artículos' + (op ? ', ' + op.nuevas + ' suscripciones de OPML' : ''));
      return informes;
    }
    function cargaEjemplos() { return ingestaVarios(E.crea(ahora())); }
    function leeArchivos(files) {
      const lista = Array.from(files || []);
      if (!lista.length) return Promise.resolve([]);
      return Promise.all(lista.map(f => f.text().then(texto => ({ nombre: f.name, texto }), () => ({ nombre: f.name, texto: '' })))).then(ingestaVarios);
    }

    /* ------------------------------------------------------------------
       Exportar
       ------------------------------------------------------------------ */
    function descarga(nombre, texto, tipo) {
      const url = URL.createObjectURL(new Blob([texto], { type: tipo + ';charset=utf-8' }));
      const a = document.createElement('a');
      a.href = url; a.download = nombre; a.hidden = true;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    }
    function exporta() {
      if (!est.fuentes.length) { aviso('No hay suscripciones que exportar: suelta un feed o usa los ejemplos.', 'info'); return null; }
      const xml = N.exportaOpml(est.fuentes.map(f => ({ titulo: f.titulo, url: f.url || f.web || 'urn:teletipo:' + f.id, web: f.web, carpeta: f.carpeta })), 'Suscripciones de Teletipo');
      descarga('suscripciones.opml', xml, 'text/x-opml');
      aviso('Exportadas ' + est.fuentes.length + ' suscripciones en suscripciones.opml', 'info');
      dice('Exportadas ' + est.fuentes.length + ' suscripciones');
      return xml;
    }

    /* ------------------------------------------------------------------
       Eventos
       ------------------------------------------------------------------ */
    raiz.addEventListener('click', e => {
      const t = e.target.closest('.tt-tira'); if (t) { abre(t.dataset.id, { scroll: false }); return; }
      const v = e.target.closest('[data-ver]'); if (v) { ponVista(v.dataset.ver); return; }
      const f = e.target.closest('[data-f]'); if (f) { ponVista('f:' + f.dataset.f); return; }
    });
    els.ejemplos.addEventListener('click', cargaEjemplos);
    els.elegir.addEventListener('click', () => els.archivos.click());
    els.anade.addEventListener('click', () => els.archivos.click());
    els.archivos.addEventListener('change', () => { leeArchivos(els.archivos.files).then(() => { els.archivos.value = ''; }); });
    els.exporta.addEventListener('click', exporta);
    els.todo.addEventListener('click', todoLeido);
    els.solo.addEventListener('click', () => ponSolo(!est.solo));
    els.atras.addEventListener('click', () => { delete raiz.dataset.lectura; });
    els.lLeido.addEventListener('click', () => alternaLeido());
    els.lGuarda.addEventListener('click', () => alternaGuardado());
    els.q.addEventListener('input', () => { est.q = els.q.value; est.pegadas = new Set(); pintaLista({ flip: true }); pintaCab(); });
    function ponSolo(v) {
      est.solo = v; est.pegadas = new Set();
      els.solo.setAttribute('aria-pressed', String(v));
      pintaLista({ flip: true }); pintaCab();
      dice(v ? 'Solo no leídos' : 'Todos los artículos');
    }
    // soltar archivos en cualquier parte
    let profundo = 0;
    const llevaArchivos = e => e.dataTransfer && Array.from(e.dataTransfer.types || []).indexOf('Files') >= 0;
    document.addEventListener('dragenter', e => { if (!llevaArchivos(e)) return; e.preventDefault(); profundo++; els.soltar.hidden = false; });
    document.addEventListener('dragover', e => { if (llevaArchivos(e)) e.preventDefault(); });
    document.addEventListener('dragleave', e => { if (!llevaArchivos(e)) return; profundo = Math.max(0, profundo - 1); if (!profundo) els.soltar.hidden = true; });
    document.addEventListener('drop', e => { if (!llevaArchivos(e)) return; e.preventDefault(); profundo = 0; els.soltar.hidden = true; leeArchivos(e.dataTransfer.files); });
    // pegar el texto de un feed
    document.addEventListener('paste', e => {
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
      const txt = (e.clipboardData && e.clipboardData.getData('text')) || '';
      if (!txt.trim()) return;
      e.preventDefault();
      ingestaVarios([{ nombre: 'texto pegado', texto: txt }]);
    });
    // si se llegó a una tira con el ratón, los atajos no dejan un aro de teclado colgado en ella
    let porPuntero = false;
    document.addEventListener('pointerdown', () => { porPuntero = true; }, true);
    document.addEventListener('keydown', e => { if (e.key === 'Tab') porPuntero = false; }, true);
    document.addEventListener('keydown', e => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const t = e.target, escribiendo = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA');
      if (porPuntero && !escribiendo && t && t.blur && t.classList && (t.classList.contains('tt-tira') || t.classList.contains('tt-pildora') || t.classList.contains('tt-todo'))) t.blur();
      if (e.key === 'Escape') {
        if (escribiendo && t === els.q) { if (els.q.value) { els.q.value = ''; est.q = ''; pintaLista({ flip: true }); pintaCab(); } else els.q.blur(); return; }
        if (raiz.dataset.lectura) { delete raiz.dataset.lectura; return; }
        return;
      }
      if (escribiendo) return;
      const k = e.key;
      if (k === 'j' || k === 'ArrowDown' && t === document.body) { e.preventDefault(); mueve(1); }
      else if (k === 'k' || k === 'ArrowUp' && t === document.body) { e.preventDefault(); mueve(-1); }
      else if (k === 'm') alternaLeido();
      else if (k === 's') alternaGuardado();
      else if (k === 'u') ponSolo(!est.solo);
      else if (k === '/') { e.preventDefault(); els.q.focus(); }
      else if (k === 'A') todoLeido();
      else if (k === 'e') exporta();
      else if (k === 'r') { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); reinicia(); }
    });
    setInterval(refrescaHoras, 30000);

    /* ------------------------------------------------------------------
       Empezar de cero y estado
       ------------------------------------------------------------------ */
    function reinicia() {
      Object.keys(temp).forEach(k => { clearTimeout(temp[k]); delete temp[k]; });
      anims.forEach(a => { try { a.cancel(); } catch (e) { /* ya terminada */ } }); anims = [];
      est.fuentes = []; porId.clear(); est.vista = 'todas'; est.solo = false; est.q = ''; est.sel = null; est.pegadas = new Set();
      est.leidos = new Set(); est.guardados = new Set(); est.orden = 0;
      try { localStorage.removeItem(CLAVE); } catch (e) { /* sin almacenamiento */ }
      els.q.value = ''; els.solo.setAttribute('aria-pressed', 'false');
      els.aviso.hidden = true; els.sello.hidden = true;
      els.hueco.hidden = false; els.cuerpo.hidden = true;
      delete raiz.dataset.lectura;
      pintaFuentes([]); activaVista();
      pintaLista({});
      pintaContadores(false);
      els.papel.scrollTop = 0;
    }

    leeAlmacen();
    pintaFuentes([]); pintaLista({}); pintaContadores(false);

    return {
      ingesta: (t, n) => ingestaVarios([{ nombre: n || 'archivo', texto: t }])[0], cargaEjemplos, abre, marca: alternaLeido, guarda: alternaGuardado, todoLeido, exporta, reinicia,
      solo: ponSolo, busca: v => { els.q.value = v; est.q = v; pintaLista({ flip: true }); pintaCab(); }, vista: ponVista,
      estado: () => ({
        fuentes: est.fuentes.map(f => ({ id: f.id, titulo: f.titulo, formato: f.formato, articulos: f.articulos.length, noLeidos: noLeidos(f.articulos), vacia: f.vacia })),
        total: todos().length, noLeidos: noLeidos(todos()), guardados: todos().filter(a => est.guardados.has(a.id)).length, visibles: est.visibles.map(a => a.id), sel: est.sel, vista: est.vista, solo: est.solo, q: est.q,
      }),
      articulo: id => porId.get(id),
      prueba: N.comprueba,
    };
  }

  window.Teletipo = Teletipo;
  Teletipo.nucleo = N;
  const raiz = document.querySelector('[data-teletipo]');
  if (raiz) window.teletipo = Teletipo(raiz);
})();
