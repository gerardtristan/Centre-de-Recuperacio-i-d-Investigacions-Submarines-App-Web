/* =====================================================================
   Desfile · Moxen
   Un carrusel de proyectos que respeta a todos: se desplaza con el desplazamiento del propio navegador (dedo, trackpad, rueda,
   teclado) y cada tarjeta encaja; «‹ ›» se desactivan en los extremos; «3 / 8» y la barra de progreso siguen a la tarjeta real
   después de cualquier deslizamiento; el avance automático lleva un botón Pausa visible, se detiene cuando debe y dice por qué;
   las tarjetas que no se ven quedan inertes (Tab no entra en ellas). En pantalla ancha se ven tres tarjetas y en el teléfono 1,2
   (asoma la siguiente). Al recorrerlo entero, la barra se cierra con un ✓ rojo de etiqueta y el avance automático da la vuelta.

   Funciona de verdad (nada está simulado):
   · La pista es un contenedor con `overflow-x: auto` y `scroll-snap-type: x mandatory`: el desplazamiento y el imán son los del
     navegador. Los botones, el avance y el ratón (que no desplaza solo) mueven el `scrollLeft` con una animación propia
     (requestAnimationFrame) apagando un instante el imán; al terminar, el navegador lo recoge y encaja en la misma posición.
   · «3 / 8» no se cuenta: se calcula de la posición real, la última tarjeta que se ve entera, en cada evento `scroll`. Lo mismo la
     barra (lo ya recorrido del total), el ✓ (la última tarjeta entera) y la desactivación de «‹ ›». Tras un deslizamiento con el
     dedo, las cifras dicen lo que se ve. El evento `scrollend` (con respaldo en el propio `scroll`) reprograma el avance.
   · `IntersectionObserver` sobre la pista dice qué tarjetas se ven (más del 60 %); las demás llevan `inert`: no se enfocan, no se
     leen y Tab no entra en ellas. Si el foco estaba en una que se va, vuelve a la pista.
   · Patrón de carrusel de WAI-ARIA: región con `aria-roledescription="carrusel"`, tarjetas con «diapositiva» y «3 de 8», el control
     de pausa antes de la pista, y una región viva que solo habla cuando el avance está detenido.
   · El avance automático se detiene por cada razón y la dice en voz alta: botón Pausa, ratón encima (`pointerenter` y `leave`),
     foco de teclado dentro (`focusin` con `:focus-visible`), tacto o arrastre en curso, pestaña oculta (`visibilitychange`) y
     movimiento reducido (`prefers-reduced-motion`, que también lo cambia en vivo): con él no hay avance, pero todo se maneja.

   Cómo se monta (ver index.html): se inicia solo sobre [data-desfile]; el HTML es la plantilla (una <article class="ds-card"> por tarjeta).
     const d = Desfile(document.querySelector('[data-desfile]'), { paso: 2000 });
     d.estado();  d.va(5);  d.siguiente();  d.pausa(true);  d.reinicia();
   Teclado: Tab recorre los controles y las tarjetas que se ven; con la pista enfocada, ← → mueven una tarjeta y Inicio y Fin van a
   los extremos; R vuelve al principio (y quita lo guardado). data-paso="4000" en [data-desfile] cambia los milisegundos entre avances.
   Qué se personaliza: los colores, al principio de desfile.css (--ds-rojo es la etiqueta, --ds-azul el foco y lo que está en marcha);
   las tarjetas, en el HTML; los tiempos, en OPCIONES. El tiempo sale de requestAnimationFrame y setTimeout (sin Date); lo que se
   limpia al terminar una animación va con un setTimeout, nunca con `onfinish`. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const OPCIONES = { paso: 2000, esperaFin: 1000, dura: 640, vuelta: 800 };      // ms entre avances, espera en el final, un paso y la vuelta
  const TEXTOS = {
    '': 'Avance automático en marcha',
    pausa: 'En pausa',
    raton: 'Detenido: el ratón está encima',
    foco: 'Detenido: hay un control con el foco',
    arrastre: 'Detenido mientras arrastras',
    tacto: 'Detenido mientras lo tocas',
    oculta: 'Detenido: la pestaña está oculta',
    reducido: 'Sin avance automático: tu sistema pide menos movimiento'
  };

  function Desfile(raiz, opciones) {
    const o = Object.assign({}, OPCIONES, opciones);
    if (raiz.dataset.paso) o.paso = +raiz.dataset.paso || o.paso;
    const pista = $('#ds-pista', raiz), slides = $$('.ds-card', pista), N = slides.length;
    const ant = $('#ds-ant', raiz), sig = $('#ds-sig', raiz), pausaBtn = $('#ds-pausa', raiz);
    const progreso = $('#ds-progreso', raiz), cifras = $('.ds-cifras', raiz), estadoEl = $('#ds-estado', raiz), vivo = $('#ds-vivo', raiz);
    const zonas = [$('.ds-carrusel', raiz), $('.ds-controles', raiz)];

    let pausadoUsuario = false, bajoRaton = 0, focoDentro = false, tocando = false, arrastrando = false, oculta = document.hidden;
    let temporizador = 0, animacion = 0, completo = false, pendiente = false, ultimoN = 0;

    const paso = () => (slides[1].offsetLeft - slides[0].offsetLeft) || pista.clientWidth;
    const maximo = () => Math.max(0, pista.scrollWidth - pista.clientWidth);

    /* La última tarjeta que se ve entera: se calcula de la posición real, no se cuenta. */
    function ultimaEntera() {
      const w = pista.clientWidth, x = pista.scrollLeft;
      let n = 0;
      slides.forEach((s, i) => { if (s.offsetLeft - x + s.offsetWidth <= w + 2) n = i + 1; });
      return Math.max(1, n);
    }

    /* ── pintar lo que la pista sabe de sí misma ───────────────────────────────────────────────────────────── */
    function pinta() {
      const x = pista.scrollLeft, max = maximo(), n = ultimaEntera();
      progreso.style.setProperty('--p', ((x + pista.clientWidth) / pista.scrollWidth).toFixed(4));
      if (n !== ultimoN) { ultimoN = n; cifras.style.setProperty('--n', n - 1); progreso.setAttribute('aria-valuenow', n); }
      const alInicio = x <= 1, alFinal = x >= max - 1;
      if (ant.disabled !== alInicio && alInicio && document.activeElement === ant) sig.focus({ preventScroll: true });
      if (sig.disabled !== alFinal && alFinal && document.activeElement === sig) ant.focus({ preventScroll: true });
      ant.disabled = alInicio; sig.disabled = alFinal;
      const fin = n === N && alFinal;
      if (fin !== completo) { completo = fin; if (fin) progreso.dataset.completo = '1'; else delete progreso.dataset.completo; programa(); }
    }
    pista.addEventListener('scroll', () => {
      if (pendiente) return;
      pendiente = true;
      requestAnimationFrame(() => { pendiente = false; pinta(); });
    }, { passive: true });

    /* ── las tarjetas que no se ven quedan inertes ─────────────────────────────────────────────────────────── */
    const visibles = new Set();
    function aplicaInertes() {
      const foco = document.activeElement;
      slides.forEach((s, i) => {
        const ve = visibles.has(i);
        if (!ve && foco && s.contains(foco)) pista.focus({ preventScroll: true });       // el foco no se queda en una tarjeta que se va
        if (ve) s.removeAttribute('inert'); else s.setAttribute('inert', '');
      });
    }
    const io = new IntersectionObserver(entradas => {
      entradas.forEach(e => { const i = slides.indexOf(e.target); if (e.intersectionRatio >= .6) visibles.add(i); else visibles.delete(i); });
      aplicaInertes();
    }, { root: pista, threshold: [0, .3, .6, .9, 1] });
    slides.forEach(s => io.observe(s));

    /* ── mover la pista: la animación propia apaga el imán un instante ─────────────────────────────────────── */
    function irA(destino, dur) {
      destino = Math.max(0, Math.min(maximo(), Math.round(destino)));
      cancelAnimationFrame(animacion); animacion = 0;
      const x0 = pista.scrollLeft, d = destino - x0;
      if (Math.abs(d) < 1) { programa(); return; }
      if (quieto() || !dur) {                                             // sin movimiento: se llega de golpe
        pista.style.scrollSnapType = 'none'; pista.scrollLeft = destino; pista.style.scrollSnapType = ''; pinta(); programa(); return;
      }
      pista.style.scrollSnapType = 'none';
      let t0 = null;
      const cuadro = ts => {
        if (t0 === null) t0 = ts;
        const u = Math.min(1, (ts - t0) / dur), e = 1 - Math.pow(1 - u, 4);
        pista.scrollLeft = x0 + d * e;
        if (u < 1) { animacion = requestAnimationFrame(cuadro); return; }
        animacion = 0; pista.scrollLeft = destino; pista.style.scrollSnapType = ''; programa();
      };
      animacion = requestAnimationFrame(cuadro);
    }
    function mueve(dir) { const s = paso(), i = Math.round(pista.scrollLeft / s); irA((i + dir) * s, o.dura); }
    function va(i) { irA((Math.max(1, Math.min(N, i)) - 1) * paso(), o.dura); }        // lleva la tarjeta i (1 a N) al borde izquierdo
    ant.addEventListener('click', () => mueve(-1));
    sig.addEventListener('click', () => mueve(1));

    /* ── el ratón arrastra (el dedo ya desplaza solo) ──────────────────────────────────────────────────────── */
    let arr = null, movido = false;
    pista.addEventListener('pointerdown', e => {
      if (e.pointerType !== 'mouse' || e.button !== 0 || e.target.closest('button')) return;
      cancelAnimationFrame(animacion); animacion = 0;
      arr = { x0: e.clientX, s0: pista.scrollLeft }; movido = false;
      pista.setPointerCapture(e.pointerId);
    });
    pista.addEventListener('pointermove', e => {
      if (!arr) return;
      const dx = e.clientX - arr.x0;
      if (!movido && Math.abs(dx) > 4) { movido = true; arrastrando = true; pista.classList.add('ds-arrastra'); programa(); }
      if (movido) pista.scrollLeft = arr.s0 - dx;
    });
    function suelta(e) {
      if (!arr) return;
      const dx = (e ? e.clientX : arr.x0) - arr.x0, s = paso(), i0 = Math.round(arr.s0 / s);
      let i = Math.round(pista.scrollLeft / s);
      if (movido && i === i0 && Math.abs(dx) > 40) i += dx < 0 ? 1 : -1;      // un empujón de más de 40 px pasa a la siguiente
      arr = null; arrastrando = false; pista.classList.remove('ds-arrastra');
      if (movido) irA(i * s, o.dura); else programa();
      if (movido) setTimeout(() => { movido = false; }, 0);
    }
    // el dedo desplaza solo: aquí solo se avisa de que está tocando, para que el avance no se cruce con él
    pista.addEventListener('touchstart', () => { tocando = true; programa(); }, { passive: true });
    const sueltaDedo = () => { tocando = false; programa(); };
    pista.addEventListener('touchend', sueltaDedo, { passive: true });
    pista.addEventListener('touchcancel', sueltaDedo, { passive: true });
    pista.addEventListener('pointerup', suelta);
    pista.addEventListener('pointercancel', suelta);
    pista.addEventListener('click', e => { if (movido) { e.stopPropagation(); e.preventDefault(); } }, true);   // soltar tras arrastrar no es un clic

    /* ── teclado en la pista ───────────────────────────────────────────────────────────────────────────────── */
    pista.addEventListener('keydown', e => {
      if (e.target !== pista) return;
      if (e.key === 'ArrowRight') { e.preventDefault(); mueve(1); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); mueve(-1); }
      else if (e.key === 'Home') { e.preventDefault(); irA(0, o.vuelta); }
      else if (e.key === 'End') { e.preventDefault(); irA(maximo(), o.vuelta); }
    });

    /* ── el avance automático: se detiene por cada razón y la dice ─────────────────────────────────────────── */
    function razon() {
      if (quieto()) return 'reducido';
      if (pausadoUsuario) return 'pausa';
      if (arrastrando) return 'arrastre';
      if (tocando) return 'tacto';
      if (bajoRaton > 0) return 'raton';
      if (focoDentro) return 'foco';
      if (oculta) return 'oculta';
      return '';
    }
    function pintaEstado() {
      const r = razon();
      estadoEl.dataset.parado = r ? '1' : ''; estadoEl.dataset.marcha = r ? '' : '1'; estadoEl.dataset.razon = r;
      $('span', estadoEl).textContent = TEXTOS[r] + (!r && completo ? ' · vuelve al principio' : '');
      pausaBtn.dataset.pausado = pausadoUsuario ? '1' : '';
      pausaBtn.disabled = quieto();
      $('span', pausaBtn).textContent = quieto() ? 'Sin avance' : pausadoUsuario ? 'Seguir' : 'Pausa';
      $('use', pausaBtn).setAttribute('href', pausadoUsuario && !quieto() ? '#ds-i-seguir' : '#ds-i-pausa');
      vivo.setAttribute('aria-live', r ? 'polite' : 'off');                 // solo habla cuando el avance está detenido
    }
    function programa() {
      clearTimeout(temporizador); temporizador = 0;
      pintaEstado();
      if (razon() || animacion) return;
      temporizador = setTimeout(completo ? vuelta : avanza, completo ? o.esperaFin : o.paso);
    }
    function avanza() { temporizador = 0; if (!razon()) mueve(1); else programa(); }
    function vuelta() { temporizador = 0; if (!razon()) irA(0, o.vuelta); else programa(); }

    pausaBtn.addEventListener('click', () => { pausadoUsuario = !pausadoUsuario; programa(); });
    zonas.forEach(z => {
      z.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') { bajoRaton++; programa(); } });
      z.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') { bajoRaton = Math.max(0, bajoRaton - 1); programa(); } });
    });
    raiz.addEventListener('focusin', e => { focoDentro = e.target.matches(':focus-visible'); programa(); });
    raiz.addEventListener('focusout', e => { if (!e.relatedTarget || !raiz.contains(e.relatedTarget)) { focoDentro = false; programa(); } });
    document.addEventListener('visibilitychange', () => { oculta = document.hidden; programa(); });
    mq.addEventListener('change', programa);
    pista.addEventListener('scrollend', () => {
      pinta();
      const [a, b] = rango();
      if (razon()) vivo.textContent = 'Tarjetas ' + a + (b > a ? ' a ' + b : '') + ' de ' + N;   // solo se anuncia con el avance detenido
      programa();
    });
    function rango() { const v = Array.from(visibles).sort((x, y) => x - y); return v.length ? [v[0] + 1, v[v.length - 1] + 1] : [1, 1]; }

    /* ── guardar: el punto rojo de etiqueta ───────────────────────────────────────────────────────────────── */
    slides.forEach(s => {
      const b = $('.ds-guarda', s);
      b.addEventListener('click', () => {
        const on = b.getAttribute('aria-pressed') !== 'true';
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
        if (on) s.dataset.guardada = '1'; else delete s.dataset.guardada;
        b.textContent = on ? 'Guardada' : 'Guardar';
      });
    });

    function reinicia() {
      cancelAnimationFrame(animacion); animacion = 0; clearTimeout(temporizador);
      pausadoUsuario = false; arr = null; arrastrando = false; movido = false; pista.classList.remove('ds-arrastra');
      pista.style.scrollSnapType = 'none'; pista.scrollLeft = 0; pista.style.scrollSnapType = '';
      slides.forEach(s => { const b = $('.ds-guarda', s); b.setAttribute('aria-pressed', 'false'); b.textContent = 'Guardar'; delete s.dataset.guardada; });
      completo = false; delete progreso.dataset.completo; ultimoN = 0;
      pinta(); programa();
    }
    addEventListener('keydown', e => {
      if ((e.key === 'r' || e.key === 'R') && !e.metaKey && !e.ctrlKey && !e.altKey && !/^(input|textarea|select)$/i.test(e.target.tagName)) reinicia();
    });
    addEventListener('resize', pinta);

    pinta(); programa();

    return {
      va, siguiente: () => mueve(1), anterior: () => mueve(-1), reinicia,
      pausa: v => { pausadoUsuario = v !== false; programa(); },
      estado: () => ({
        n: ultimaEntera(), total: N, x: Math.round(pista.scrollLeft), max: Math.round(maximo()),
        antDeshabilitado: ant.disabled, sigDeshabilitado: sig.disabled, razon: razon(), completo, pausado: pausadoUsuario,
        visibles: Array.from(visibles).sort((a, b) => a - b).map(i => i + 1), inertes: slides.map((s, i) => s.hasAttribute('inert') ? i + 1 : 0).filter(Boolean),
        guardadas: slides.map((s, i) => s.dataset.guardada ? i + 1 : 0).filter(Boolean), texto: $('span', estadoEl).textContent
      })
    };
  }

  const raiz = document.querySelector('[data-desfile]');
  if (raiz) window.desfile = Desfile(raiz);
  window.Desfile = Desfile;
})();
