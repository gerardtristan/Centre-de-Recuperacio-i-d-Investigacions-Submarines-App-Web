# Errata · Moxen

Los errores aparecen al salir de cada campo, con mensajes concretos que salen del valor escrito; al enviar con fallos, el foco salta a un recuadro «Hay 3 errores» con un enlace por campo, y el índice del lado marca cada sección como incompleta, con errores o completa. El error del servidor entra en el mismo resumen y, al corregir el último, queda «Todo correcto» con el visto bueno a lápiz azul.

## Qué trae

- `index.html` — la demostración
- `errata.css`
- `errata.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `errata.css` y `errata.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Errors show up when you leave each field, with concrete messages built from what was typed; when you submit with mistakes, focus jumps to a «Hay 3 errores» box with one link per field, and the side index marks each section as incomplete, with errors or complete. The server error lands in the same summary and, once the last one is fixed, it reads «Todo correcto» with a blue-pencil approval.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
