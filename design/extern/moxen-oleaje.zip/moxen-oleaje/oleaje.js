/* =====================================================================
   Oleaje · Moxen
   Un cambio de sección como una marea. Al bajar, la sección siguiente
   sube desde abajo con el borde en ola, precedida por una franja de
   espuma; al subir, la de encima se escurre hacia abajo y deja ver la
   anterior. La ola se agita más cuanto más rápido sube el agua y se
   calma al llegar, y el contenido de cada sección se desplaza un poco
   más despacio que el agua (paralaje). Sin dependencias.

     const o = Oleaje(document.querySelector('[data-oleaje]'));
     o.ir(2);      o.sigue();      o.actual();

   El borde es un clip-path: path() que se recalcula a cada cuadro con
   dos senos que viajan a distinta velocidad, así la ola nunca se repite
   igual. También responde a la rueda del ratón y a las flechas.
   ===================================================================== */
(function () {
  'use strict';

  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  // el agua arranca con calma, empuja en el medio y se asienta al final
  const marea = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  const acota = (v, a, b) => Math.max(a, Math.min(b, v));

  function Oleaje(escena, opciones) {
    const o = Object.assign({
      dura: 1350,         // ms que tarda el agua en cruzar la pantalla
      desfase: 80,        // ms que la espuma va por delante
      ola: 44,            // px: la altura máxima de la ola
      paralaje: 90,       // px que se desplaza el contenido
      alCambiar: null,
    }, opciones);
    const vistas = Array.from(escena.querySelectorAll('[data-ola-vista]'));
    const sigue = escena.querySelector('[data-ola-sigue]');
    const puntos = Array.from(escena.querySelectorAll('[data-ola-ir]'));
    const espuma = document.createElement('div');
    espuma.className = 'ol-espuma';
    escena.appendChild(espuma);
    let actual = Math.max(0, vistas.findIndex(v => !v.hidden)), ocupado = false;

    /* El agua por debajo de una ola a la altura `nivel`. Dos senos de
       distinta longitud que viajan en sentidos opuestos: la suma no se
       repite y parece agua y no una sierra. */
    function agua(nivel, alto, fase, W, H) {
      const N = 48, k1 = 2 * Math.PI / (W * .62), k2 = 2 * Math.PI / (W * .27);
      let d = 'M0 ' + (H + alto + 10);
      for (let i = 0; i <= N; i++) {
        const x = W * i / N;
        const y = nivel + alto * (.62 * Math.sin(x * k1 + fase) + .38 * Math.sin(x * k2 - fase * 1.4 + 1.3));
        d += 'L' + x.toFixed(1) + ' ' + y.toFixed(1);
      }
      return "path('" + d + 'L' + W + ' ' + (H + alto + 10) + "Z')";
    }

    function marca(n) {
      puntos.forEach((p, i) => p.toggleAttribute('aria-current', i === n));
      escena.dataset.tono = vistas[n].dataset.tono || '';
      if (sigue) sigue.disabled = n === vistas.length - 1;
    }

    function ir(n) {
      if (ocupado || n === actual || n < 0 || n >= vistas.length) return;
      const de = vistas[actual], a = vistas[n], baja = n > actual;
      vistas.forEach(v => v.classList.remove('ol-activa'));
      a.hidden = false;
      a.classList.add('ol-activa');
      if (o.alCambiar) o.alCambiar(n);
      if (reduce) { de.hidden = true; actual = n; marca(n); return; }
      ocupado = true;

      /* Al bajar, la nueva va encima y sube; al subir, la vieja va encima
         y se escurre. La espuma siempre va entre las dos. */
      const arriba = baja ? a : de, abajo = baja ? de : a;
      arriba.style.zIndex = 3; abajo.style.zIndex = 1;
      espuma.style.visibility = 'visible';
      const cArriba = arriba.querySelector('.ol-contenido'), cAbajo = abajo.querySelector('.ol-contenido');
      const W = escena.clientWidth, H = escena.clientHeight;
      let t0 = null, cambiado = false;

      function cuadro(ahora) {
        if (t0 === null) t0 = ahora;
        const t = ahora - t0, fase = t * .0045;
        // la espuma va delante: al subir el agua, primero; al escurrirse, detrás
        const uA = acota((t - (baja ? o.desfase : 0)) / o.dura, 0, 1);
        const uE = acota((t - (baja ? 0 : o.desfase)) / o.dura, 0, 1);
        // la ola se agita con la velocidad del agua: nada al empezar y al terminar
        const alto = u => o.ola * Math.pow(Math.sin(Math.PI * u), .7) + 4;
        // de abajo (H) a fuera por arriba, o al revés
        const nivel = u => baja ? (H + o.ola) - (H + 2 * o.ola) * marea(u) : -o.ola + (H + 2 * o.ola) * marea(u);
        arriba.style.clipPath = agua(nivel(uA), alto(uA), fase, W, H);
        espuma.style.clipPath = agua(nivel(uE), alto(uE) * .8, fase + 1.7, W, H);

        // el contenido, más lento que el agua: la de arriba llega y la de abajo cede
        const m = marea(uA);
        if (baja) {
          cArriba.style.transform = 'translateY(' + ((1 - m) * o.paralaje).toFixed(1) + 'px)';
          cAbajo.style.transform = 'translateY(' + (-m * o.paralaje * .6).toFixed(1) + 'px)';
        } else {
          cArriba.style.transform = 'translateY(' + (m * o.paralaje).toFixed(1) + 'px)';
          cAbajo.style.transform = 'translateY(' + (-(1 - m) * o.paralaje * .6).toFixed(1) + 'px)';
        }
        // los mandos cambian de color cuando el agua pasa por la mitad
        if (!cambiado && m > .5) { cambiado = true; marca(n); }

        if (Math.min(uA, uE) < 1) { requestAnimationFrame(cuadro); return; }
        de.hidden = true;
        [arriba, abajo, espuma, cArriba, cAbajo].forEach(e => { e.style.clipPath = ''; e.style.zIndex = ''; e.style.transform = ''; });
        espuma.style.visibility = '';
        actual = n; ocupado = false;
      }
      requestAnimationFrame(cuadro);
    }

    if (sigue) sigue.addEventListener('click', () => ir(actual + 1));
    puntos.forEach((p, i) => p.addEventListener('click', () => ir(i)));
    // la rueda y las flechas: un paso por gesto
    let quieta = true;
    escena.addEventListener('wheel', e => {
      e.preventDefault();
      if (!quieta || Math.abs(e.deltaY) < 8) return;
      quieta = false;
      ir(actual + (e.deltaY > 0 ? 1 : -1));
      setTimeout(() => { quieta = true; }, o.dura + 250);
    }, { passive: false });
    addEventListener('keydown', e => {
      if (e.key === 'ArrowDown' || e.key === 'PageDown') ir(actual + 1);
      if (e.key === 'ArrowUp' || e.key === 'PageUp') ir(actual - 1);
    });
    marca(actual);

    return { ir, sigue: () => ir(actual + 1), actual: () => actual };
  }

  window.Oleaje = Oleaje;
})();
