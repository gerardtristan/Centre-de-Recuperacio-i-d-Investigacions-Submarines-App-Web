# Recoveco · Moxen

Las preguntas son paneles plegados por tema: buscar una palabra con ⌘F abre la respuesta que la contiene, la resalta y marca el tema en el índice, y abrir una pregunta cierra la anterior del mismo tema. «Copiar enlace a esta respuesta» arma una dirección que, al abrirse, despliega la pregunta y subraya la frase exacta; donde el navegador no busca dentro de lo plegado, un buscador propio lo hace y lo dice.

## Qué trae

- `index.html` — la demostración
- `recoveco.css`
- `recoveco.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `recoveco.css` y `recoveco.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

The questions are collapsed panels grouped by topic: searching a word with ⌘F opens the answer that contains it, highlights it and marks the topic in the index, and opening a question closes the previous one in the same topic. “Copy link to this answer” builds an address that, once opened, unfolds the question and underlines the exact phrase; where the browser cannot search inside collapsed content, a built-in search does it and says so.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
