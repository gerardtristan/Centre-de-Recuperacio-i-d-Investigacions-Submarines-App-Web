# Vigencia · Moxen

Cada licencia, permiso, seguro o certificado muestra los días exactos que le quedan sobre una regla de 60 días con las alertas de 30, 15 y 7 marcadas, y la lista se ordena sola por urgencia; al adelantar el tiempo con el deslizador las barras avanzan y cambian de color al cruzar cada alerta. «Renovar» suma 6, 12 o 24 meses (o la fecha que elijas) y manda el documento al final de la lista, y «Descargar avisos» baja un .ics con un VALARM por cada alerta que todavía falta por sonar.

## Qué trae

- `index.html` — la demostración
- `vigencia.css`
- `vigencia.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `vigencia.css` y `vigencia.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Every license, permit, insurance policy or certificate shows the exact days it has left on a 60-day ruler with the 30, 15 and 7-day alerts marked, and the list sorts itself by urgency; as you move time forward with the slider the bars advance and change color when they cross each alert. “Renew” adds 6, 12 or 24 months (or a date you pick) and sends the document to the end of the list, and “Download alerts” saves an .ics file with one VALARM for every alert that has yet to ring.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
