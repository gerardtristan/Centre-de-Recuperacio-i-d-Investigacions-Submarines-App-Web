# Camilla · Moxen

Una app de clínica dentro de un teléfono, con pantallas reales y navegación: eliges la especialidad (cada consulta dura distinto), al profesional o «cualquiera disponible» y un día, y la cuadrícula muestra las horas de su agenda con las ya tomadas apagadas. Escribes los datos del paciente con validación en vivo (nombre y apellido, una fecha de nacimiento que exista, teléfono, correo y autorización) y cada campo dice por qué falla; al confirmar aparece el ✓, «Agregar al calendario» descarga un .ics con la cita y sus avisos, la hora queda ocupada y desde «Mis citas» puedes cancelarla para liberarla, con «Atrás» siempre conservando lo elegido.

## Qué trae

- `index.html` — la demostración
- `camilla.css`
- `camilla.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `camilla.css` y `camilla.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

A clinic app inside a phone, with real screens and navigation: you pick the specialty (each consultation lasts differently), a professional or “anyone available” and a day, and the grid shows the times in their agenda with the already taken ones dimmed. You fill in the patient details with live validation (first and last name, a birth date that exists, phone, email and consent) and every field says why it fails; on confirming a ✓ appears, “Add to calendar” downloads an .ics with the appointment and its reminders, the time becomes busy and from “My appointments” you can cancel it to free it up, while “Back” always keeps what you chose.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
