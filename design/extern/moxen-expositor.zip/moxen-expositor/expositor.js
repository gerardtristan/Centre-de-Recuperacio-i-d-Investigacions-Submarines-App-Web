/* =====================================================================
   Expositor · Moxen
   La rejilla de fotos de un anuncio (un producto, una propiedad): subes varias a la vez, las ordenas arrastrando, eliges
   la portada y quitas las que sobran. Cada foto es una celda; el orden de la rejilla es el orden del anuncio.

   · Al soltar o elegir las fotos, cada una CAE en su celda y empieza su subida: la foto sale desenfocada y en gris y se
     revela con un anillo que avanza. Al llegar a 100 el anillo se resuelve en un ✓ bermellón y se va.
   · Si una foto es demasiado pequeña (menos de `minimo` px por lado) la subida se corta, su celda se RAYA en bermellón
     con un barrido y una tarjeta explica por qué («Muy pequeña · 640 × 960 · mínimo 800»). El estado de arriba
     pasa a «1 foto con problema» y «Publicar» sigue apagado.
   · Arrastrar una celda la levanta (sombra, un leve giro según hacia dónde la muevas) y las demás se APARTAN con
     resorte, también de una fila a otra; un hueco discontinuo marca dónde caerá y los números de cada celda ruedan
     a su cifra nueva. Con el teclado: Espacio toma la foto, las flechas la mueven (↑ ↓ saltan de fila), Espacio la
     suelta y Esc la devuelve a su sitio. En el teléfono se arrastra desde el asa de la esquina.
   · La primera foto lleva la etiqueta «Portada». «Hacer portada» en otra cruza las dos en vuelo (una por arriba y más
     grande, la otra por detrás) mientras la etiqueta salta al llegar la nueva. Quitar una (×) la encoge y la rejilla
     se cierra con resorte; «Quitar todas» las encoge en cascada y vuelve la zona de soltar.
   · Cuando no queda nada subiendo ni con problema, «6 fotos listas» rueda a su cifra con un ✓ bermellón y se enciende
     «Publicar anuncio».
   · Accesible: cada celda es un botón con su posición y su estado, el movimiento con teclado se anuncia («Foto movida a
     la posición 3 de 6»), «Hacer portada» y «Quitar» son botones aparte (y P / Supr sobre la foto hacen lo mismo),
     y con movimiento reducido todo cambia de golpe, sin viajar.

   Montaje (se inicia solo sobre [data-expositor]; el HTML de la demo es la plantilla):
     const x = Expositor(document.querySelector('[data-expositor]'), {
       demo: true,            // «Elegir fotos» reparte las de ejemplo; sin demo abre el selector de archivos
       minimo: 800,           // px mínimos por lado
       maximo: 8,             // fotos como máximo
       sube: (archivo, avance) => Promise,   // tu subida real: llama a avance(0..1); si no, se simula
       alCambiar: ({ fotos }) => {},         // las fotos en su orden: [{ nombre, src, estado }]
       alPublicar: ({ fotos }) => {},
     });
     x.agrega([{ src, w, h, nombre }]);  x.elegir();  x.portada(2);  x.mueve(3, 1);  x.quita(0);  x.vacia();

   Cómo conectarlo de verdad: suelta archivos sobre la zona (o usa «Elegir fotos» sin demo): se leen sus medidas, se
   validan y se suben con tu función `sube`. Las medidas mínimas y el máximo salen de las opciones; los colores,
   de las variables de expositor.css. Todo es determinista: sin Date ni azar; el tiempo es de requestAnimationFrame
   y setTimeout, los resortes son curvas `linear()` de CSS o resortes integrados cuadro a cuadro, y lo que se limpia
   al terminar una animación va con un setTimeout, nunca con `onfinish`. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const anima = (el, kf, op) => (quieto() || !el.animate) ? null : el.animate(kf, op);
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';
  const ease = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  const pad = n => String(n).padStart(2, '0');

  /* Un resorte convertido en curva `linear()` de CSS (y de Web Animations): devuelve la curva y lo que dura. */
  const APOYA = !!(window.CSS && CSS.supports && CSS.supports('transition-timing-function', 'linear(0, 1)'));
  function muelle(k, c) {
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const n = 40, out = [];
    for (let i = 0; i < n + 1; i++) out.push(pts[Math.round(i / n * (pts.length - 1))].toFixed(4));
    out[n] = '1';
    return { curva: 'linear(' + out.join(', ') + ')', ms: Math.round(t * 1000) };
  }
  const R1 = APOYA ? muelle(260, 21) : { curva: 'cubic-bezier(.34, 1.4, .64, 1)', ms: 520 };   // la caída de una foto, el ✓
  const R2 = APOYA ? muelle(380, 17) : { curva: 'cubic-bezier(.34, 1.7, .64, 1)', ms: 480 };   // lo que rebota más: el icono de estado

  /* Las fotos de ejemplo (de img/, con las medidas que dirían los archivos). La última se declara pequeña para que se vea el
     rechazo. `ms` es lo que tarda en subir. */
  const MUESTRAS = [
    { src: 'img/cer-cuenco-v.jpg', w: 933, h: 1400, nombre: 'cuenco-gres.jpg', ms: 1000 },
    { src: 'img/cer-azul.jpg', w: 1400, h: 987, nombre: 'jarron-azul.jpg', ms: 1250 },
    { src: 'img/vasijas.jpg', w: 934, h: 1400, nombre: 'vasijas.jpg', ms: 760 },
    { src: 'img/jarron.jpg', w: 1400, h: 1222, nombre: 'jarron-seco.jpg', ms: 1150 },
    { src: 'img/bodegon.jpg', w: 1260, h: 851, nombre: 'bodegon.jpg', ms: 1450 },
    { src: 'img/marmol.jpg', w: 1400, h: 933, nombre: 'marmol.jpg', ms: 900 },
    { src: 'img/jarron-naranja.jpg', w: 640, h: 960, nombre: 'jarron-naranja.jpg', ms: 1000 },
  ];

  /* Una cifra o un texto corto que rueda cuando cambia. */
  function Rod(el) {
    return {
      pon(txt, dir, sinAnim) {
        const viejo = el.lastElementChild;
        if (viejo && viejo.textContent === txt) return;
        const nuevo = h('span', null, txt);
        el.appendChild(nuevo);
        if (!viejo) return;
        if (sinAnim || quieto() || !dir) { viejo.remove(); return; }
        const s = dir > 0 ? 1 : -1;
        anima(viejo, [{ transform: 'translateY(0)', opacity: 1 }, { transform: 'translateY(' + (-120 * s) + '%)', opacity: 0 }], { duration: 380, easing: CURVA, fill: 'forwards' });
        anima(nuevo, [{ transform: 'translateY(' + (120 * s) + '%)', opacity: 0 }, { transform: 'translateY(0)', opacity: 1 }], { duration: 480, easing: CURVA });
        setTimeout(() => viejo.remove(), 420);      // sin onfinish: no llega si el reloj está controlado
      },
    };
  }

  const ICONOS = {
    gira: '<svg viewBox="0 0 22 22" class="gira"><circle cx="11" cy="11" r="8.500" fill="none" stroke="currentColor" stroke-opacity=".2" stroke-width="2.600"/><path d="M11 2.500a8.500 8.500 0 0 1 8.500 8.500" fill="none" stroke="currentColor" stroke-width="2.600" stroke-linecap="round"/></svg>',
    aviso: '<svg viewBox="0 0 22 22"><circle cx="11" cy="11" r="10" fill="currentColor"/><path d="M11 6.200v5.800" stroke="#fff" stroke-width="2.400" stroke-linecap="round"/><circle cx="11" cy="15.600" r="1.400" fill="#fff"/></svg>',
    listo: '<svg viewBox="0 0 22 22"><circle cx="11" cy="11" r="10" class="pop" style="fill:var(--ex-bermellon)"/><path d="m6.400 11.300 3.200 3.200 6-6.500" fill="none" stroke="#fff" stroke-width="2.400" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  };
  const ICO_X = '<svg viewBox="0 0 14 14" aria-hidden="true"><path d="m3 3 8 8M11 3l-8 8"/></svg>';
  const ICO_ESTRELLA = '<svg viewBox="0 0 14 14" aria-hidden="true"><path d="M7 .8l1.900 3.900 4.300.6-3.100 3 .7 4.300L7 10.600l-3.800 2 .7-4.300L.8 5.300l4.300-.6z"/></svg>';
  const ICO_ASA = '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="6" cy="4" r="1.300"/><circle cx="10" cy="4" r="1.300"/><circle cx="6" cy="8" r="1.300"/><circle cx="10" cy="8" r="1.300"/><circle cx="6" cy="12" r="1.300"/><circle cx="10" cy="12" r="1.300"/></svg>';

  function Expositor(raiz, opciones) {
    const op = Object.assign({ demo: raiz.hasAttribute('data-demo'), minimo: 800, maximo: 8, muestras: MUESTRAS, sube: null, alCambiar: null, alPublicar: null }, opciones || {});
    const $ = s => raiz.querySelector(s);
    const area = $('[data-area]'), vacio = $('[data-vacio]'), grid = $('[data-grid]'), tag = $('[data-tag]');
    const estadoEl = $('[data-estado]'), eiEl = $('[data-ei]'), pre = $('[data-pre]'), post = $('[data-post]'), post2 = $('[data-post2]');
    const vaciar = $('[data-vaciar]'), elegirBtn = $('[data-elegir]'), archivosEl = $('[data-archivos]'), publicar = $('[data-publicar]'), publicarT = $('[data-publicar-t]');
    const anuncio = $('[data-anuncio]'), pista = $('[data-pista]');
    const n1 = Rod($('[data-n1]')), n2 = Rod($('[data-n2]'));
    const S = { fotos: [], arr: null, tomada: null, orig: -1, portada: null, estado: '', k1: 0, k2: 0, tOculta: 0, tAnuncio: 0, tPub: 0, ult: 0, vx: 0, px: 0, uso: 0 };

    raiz.style.setProperty('--ex-r1', R1.curva);
    const decir = t => { anuncio.textContent = ''; setTimeout(() => { anuncio.textContent = t; }, 40); };
    const decirLuego = t => { clearTimeout(S.tAnuncio); S.tAnuncio = setTimeout(() => decir(t), 500); };

    /* El hueco discontinuo de la foto que arrastras y la celda «Añadir». */
    const hueco = h('div', 'ex-hueco'); hueco.setAttribute('aria-hidden', 'true'); grid.appendChild(hueco);
    const liMas = h('li', 'ex-celda ex-mas');
    const masB = h('button', 'ex-mas-b'); masB.type = 'button'; masB.setAttribute('aria-label', 'Añadir más fotos');
    masB.innerHTML = '<span class="ex-mas-c"><svg viewBox="0 0 18 18" aria-hidden="true"><path d="M9 3.500v11M3.500 9h11"/></svg></span>Añadir';
    liMas.appendChild(masB); grid.appendChild(liMas);

    /* ── la geometría de la rejilla ───────────────────────────────── */
    const cols = () => Math.max(1, getComputedStyle(grid).gridTemplateColumns.split(' ').length);
    function geom() {
      const c = cols(), g = parseFloat(getComputedStyle(grid).columnGap) || 14, w = (grid.clientWidth - g * (c - 1)) / c;
      return { c, g, w };
    }
    function slot(i) {
      const { c, g, w } = geom();
      return { x: (i % c) * (w + g), y: Math.floor(i / c) * (w + g), w, h: w };
    }
    const celdas = () => Array.from(grid.children).filter(el => el.classList.contains('ex-celda'));

    /* ── el motor de resortes de las celdas ───────────────────────── */
    const K = 340, C = 24;
    const st = li => li._st || (li._st = { x: 0, y: 0, vx: 0, vy: 0, s: 1, vs: 0, ts: 1, r: 0, vr: 0, tr: 0, drag: false, on: false });
    let raf = 0, tPrev = 0;
    function arranca() { if (!raf) { tPrev = 0; raf = requestAnimationFrame(bucle); } }
    function paso(li, s, dt) {
      const n = Math.max(1, Math.ceil(dt / (1 / 120))), d = dt / n;
      for (let i = 0; i < n; i++) {
        if (!s.drag) { s.vx += (-K * s.x - C * s.vx) * d; s.x += s.vx * d; s.vy += (-K * s.y - C * s.vy) * d; s.y += s.vy * d; }
        s.vs += (360 * (s.ts - s.s) - 22 * s.vs) * d; s.s += s.vs * d;
        s.vr += (300 * (s.tr - s.r) - 20 * s.vr) * d; s.r += s.vr * d;
      }
      const quietoYa = !s.drag && Math.abs(s.x) < .04 && Math.abs(s.y) < .04 && Math.abs(s.vx) < .08 && Math.abs(s.vy) < .08 && Math.abs(s.s - s.ts) < .0008 && Math.abs(s.vs) < .004 && Math.abs(s.r - s.tr) < .02 && Math.abs(s.vr) < .05;
      if (quietoYa && s.ts === 1 && s.tr === 0) { s.x = s.y = s.vx = s.vy = 0; s.s = 1; s.r = 0; s.on = false; li.style.transform = ''; return false; }
      li.style.transform = 'translate3d(' + s.x.toFixed(2) + 'px,' + s.y.toFixed(2) + 'px,0) rotate(' + s.r.toFixed(2) + 'deg) scale(' + s.s.toFixed(4) + ')';
      return true;
    }
    function bucle(t) {
      raf = 0;
      const dt = tPrev ? Math.min(.034, Math.max(.001, (t - tPrev) / 1000)) : 1 / 60; tPrev = t;
      let sigue = false;
      if (S.arr && S.arr.activo) {                         // el giro de la foto que arrastras sigue su velocidad lateral
        const vx = (S.px - S.ult) / dt; S.ult = S.px;
        S.vx += (vx - S.vx) * Math.min(1, dt * 12);
        st(S.arr.li).tr = lim(S.vx * .012, -7, 7);
      }
      celdas().forEach(li => { const s = li._st; if (s && s.on) sigue = paso(li, s, dt) || sigue; });
      S.fotos.forEach(f => { if (f.estado === 'subiendo') sigue = avanzaSubida(f, dt) || sigue; });
      if (S.arr && S.arr.activo) sigue = true;
      if (sigue) raf = requestAnimationFrame(bucle);
    }
    /* Cambiar el DOM y que las celdas que se mueven vayan de donde estaban a donde quedan, con resorte (FLIP). */
    function flip(mutar, excluir) {
      const ant = new Map();
      if (!quieto()) celdas().forEach(li => ant.set(li, [li.offsetLeft, li.offsetTop]));
      mutar();
      if (quieto()) return;
      celdas().forEach(li => {
        const a = ant.get(li);
        if (!a || (excluir && excluir.has(li))) return;
        const dx = a[0] - li.offsetLeft, dy = a[1] - li.offsetTop;
        if (dx || dy) { const s = st(li); s.x += dx; s.y += dy; s.on = true; }
      });
      arranca();
    }
    function sincroniza() {            // el DOM sigue el orden del modelo moviendo lo mínimo
      const act = document.activeElement;
      let ref = liMas;
      S.sinc = true;      // mover el nodo enfocado lo desenfoca un instante: eso no es soltar la foto
      for (let i = S.fotos.length - 1; i >= 0; i--) { const li = S.fotos[i].li; if (li.nextSibling !== ref) grid.insertBefore(li, ref); ref = li; }
      if (act && act !== document.activeElement && grid.contains(act)) act.focus({ preventScroll: true });
      S.sinc = false;
    }

    /* ── una foto ─────────────────────────────────────────────────── */
    function Foto(it, muestra) {
      const f = { src: it.src, w: it.w || 0, h: it.h || 0, nombre: it.nombre || 'foto', estado: 'subiendo', t: 0, p: 0, dur: Math.max(.5, (it.ms || 1000) / 1000), espera: 0, err: false, muestra, vivo: true, archivo: it.archivo || null };
      f.err = !!it.invalida || (f.w && f.h && Math.min(f.w, f.h) < op.minimo);
      const li = h('li', 'ex-celda'); li.dataset.estado = 'subiendo'; li.style.setProperty('--p', '0');
      li.innerHTML =
        '<div class="ex-marco"><img class="ex-img" alt="" draggable="false"><div class="ex-vel"></div><div class="ex-raya"></div><div class="ex-motivo"><b></b><small></small></div>' +
        '<div class="ex-anillo" aria-hidden="true"><svg viewBox="0 0 66 66"><circle class="pista" cx="33" cy="33" r="18"/><circle class="avance" cx="33" cy="33" r="18"/></svg><span class="ex-pct">0</span></div>' +
        '<div class="ex-ok" aria-hidden="true"><svg viewBox="0 0 26 26"><path d="m5.500 13.500 5 5 10-11"/></svg></div></div>' +
        '<button class="ex-foto" type="button"></button>' +
        '<button class="ex-portada-b" type="button">' + ICO_ESTRELLA + '<span class="ex-hacer">Hacer </span><span class="ex-pt">portada</span></button>' +
        '<button class="ex-x" type="button">' + ICO_X + '</button>' +
        '<span class="ex-num"></span><span class="ex-grip" aria-hidden="true">' + ICO_ASA + '</span>';
      li.querySelector('.ex-img').src = it.src;
      Object.assign(f, { li, marco: li.querySelector('.ex-marco'), btn: li.querySelector('.ex-foto'), portadaB: li.querySelector('.ex-portada-b'), x: li.querySelector('.ex-x'), numEl: li.querySelector('.ex-num'), grip: li.querySelector('.ex-grip'),
        avance: li.querySelector('.avance'), pct: li.querySelector('.ex-pct'), raya: li.querySelector('.ex-raya'), ok: li.querySelector('.ex-ok'), motivoEl: li.querySelector('.ex-motivo') });
      f.num = Rod(f.numEl); f.idx = -1;
      f.x.setAttribute('aria-label', 'Quitar la foto ' + f.nombre);
      f.portadaB.setAttribute('aria-label', 'Hacer portada la foto ' + f.nombre);
      // las manos: ratón (en toda la celda) y dedo (por el asa)
      f.btn.addEventListener('pointerdown', e => { if (e.pointerType !== 'touch') ponPuntero(e, f, false); });
      f.grip.addEventListener('pointerdown', e => ponPuntero(e, f, true));
      f.btn.addEventListener('keydown', e => teclaFoto(e, f));
      f.portadaB.addEventListener('click', () => portada(f));
      f.x.addEventListener('click', () => quita(f));
      return f;
    }
    function etiqueta(f, i) {
      const est = f.estado === 'lista' ? '' : f.estado === 'subiendo' ? ' Subiendo.' : ' Con problema: ' + textoMotivo(f) + '.';
      f.btn.setAttribute('aria-label', 'Foto ' + (i + 1) + ' de ' + S.fotos.length + ': ' + f.nombre + (i === 0 ? ', portada' : '') + '.' + est + (f.estado === 'subiendo' ? '' : ' Espacio para moverla, P para hacerla portada, Supr para quitarla.'));
      f.btn.setAttribute('aria-pressed', S.tomada === f ? 'true' : 'false');
    }
    const textoMotivo = f => f.w ? 'muy pequeña, ' + f.w + ' por ' + f.h + ' píxeles; el mínimo es ' + op.minimo : 'no se puede usar';

    /* La subida: el anillo avanza; una foto pequeña se corta a media subida y se raya. */
    function pintaSubida(f) {
      f.li.style.setProperty('--p', f.p.toFixed(3));
      f.avance.style.strokeDashoffset = (113.1 * (1 - f.p)).toFixed(2);
      f.pct.textContent = Math.round(f.p * 100);
    }
    function avanzaSubida(f, dt) {
      if (f.espera > 0) { f.espera -= dt; return true; }
      f.t = Math.min(1, f.t + dt / f.dur);
      f.p = .5 - .5 * Math.cos(Math.PI * f.t);
      if (f.err && f.p >= .45) { f.p = .45; pintaSubida(f); falla(f); return false; }
      pintaSubida(f);
      if (f.t >= 1) { termina(f); return false; }
      return true;
    }
    function termina(f) {
      f.estado = 'lista'; f.li.dataset.estado = 'lista'; f.li.style.removeProperty('--p');
      anima(f.ok, [{ opacity: 0, transform: 'scale(.2)' }, { opacity: 1, transform: 'scale(1.1)', offset: .32 }, { opacity: 1, transform: 'scale(1)', offset: .7 }, { opacity: 0, transform: 'scale(.9)' }], { duration: 900, easing: CURVA });
      anima(f.marco, [{ transform: 'scale(1)' }, { transform: 'scale(1.035)', offset: .3 }, { transform: 'scale(1)' }], { duration: 520, easing: CURVA });
      actualiza(); cambioFotos();
    }
    function falla(f) {
      f.estado = 'error'; f.li.dataset.estado = 'error'; f.li.style.removeProperty('--p');
      f.motivoEl.querySelector('b').textContent = f.w ? 'Muy pequeña' : 'No se puede usar';
      f.motivoEl.querySelector('small').textContent = f.w ? f.w + ' × ' + f.h + ' · mínimo ' + op.minimo : 'No es una imagen válida';
      anima(f.raya, [{ clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0 0 0)' }], { duration: 560, easing: CURVA });
      anima(f.motivoEl, [{ opacity: 0, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: 480, delay: 260, easing: R1.curva, fill: 'backwards' });
      anima(f.marco, [{ transform: 'translateX(0)' }, { transform: 'translateX(-5px)', offset: .2 }, { transform: 'translateX(5px)', offset: .4 }, { transform: 'translateX(-3px)', offset: .6 }, { transform: 'translateX(2px)', offset: .8 }, { transform: 'none' }], { duration: 480, easing: CURVA });
      actualiza(); decir('Foto con problema: ' + f.nombre + ', ' + textoMotivo(f));
    }

    /* ── añadir fotos ─────────────────────────────────────────────── */
    function agrega(items, tipo) {
      const libre = op.maximo - S.fotos.length;
      items = items.slice(0, Math.max(0, libre));
      if (!items.length) { decir('Ya tienes ' + op.maximo + ' fotos: es el máximo.'); return; }
      clearTimeout(S.tOculta);
      area.classList.add('con-fotos'); grid.hidden = false;
      const nuevos = [];
      flip(() => {
        items.forEach(it => { const f = Foto(it, it.muestra); S.fotos.push(f); grid.insertBefore(f.li, liMas); nuevos.push(f); });
      });
      nuevos.forEach((f, i) => {
        f.espera = .22 + i * .11;
        if (quieto()) { f.t = 1; f.p = 1; if (f.err) { f.p = .45; falla(f); } else termina(f); return; }
        anima(f.li, [{ opacity: 0, transform: 'translateY(-76px) scale(.72) rotate(' + (i % 2 ? 5 : -5) + 'deg)' }, { opacity: 1, transform: 'translateY(7px) scale(1.02) rotate(.6deg)', offset: .62 }, { opacity: 1, transform: 'none' }],
          { duration: 700, delay: 40 + i * 110, easing: CURVA, fill: 'backwards' });
      });
      actualiza();
      decir(nuevos.length + (nuevos.length === 1 ? ' foto añadida' : ' fotos añadidas') + (nuevos.some(f => f.err) ? '' : '. Subiendo.'));
      arranca();
    }
    function enUso() { return new Set(S.fotos.map(f => f.muestra)); }
    function elegir() {
      if (!op.demo) { archivosEl.click(); return; }
      const uso = enUso(), libres = op.muestras.map((m, i) => Object.assign({ muestra: i }, m)).filter(m => !uso.has(m.muestra));
      if (!libres.length) { decir('No quedan fotos de ejemplo.'); return; }
      agrega(S.fotos.length === 0 ? libres.slice(0, 7) : libres.slice(0, 1));
    }
    /* Archivos de verdad: se leen sus medidas y se suben con `sube` (o se simula la subida). */
    function leeArchivos(lista) {
      const imgs = Array.from(lista).filter(a => /^image\//.test(a.type));
      if (imgs.length < lista.length) decir('Se ignoraron los archivos que no son imágenes.');
      Promise.all(imgs.map(a => new Promise(res => {
        const url = URL.createObjectURL(a), im = new Image();
        im.onload = () => res({ src: url, w: im.naturalWidth, h: im.naturalHeight, nombre: a.name, ms: 700 + Math.min(1600, a.size / 900), archivo: a });
        im.onerror = () => res({ src: url, w: 0, h: 0, nombre: a.name, ms: 600, invalida: true, archivo: a });
      }))).then(its => agrega(its));
    }
    archivosEl.addEventListener('change', () => { if (archivosEl.files.length) leeArchivos(archivosEl.files); archivosEl.value = ''; });
    elegirBtn.addEventListener('click', elegir);
    masB.addEventListener('click', elegir);
    ['dragenter', 'dragover'].forEach(ev => area.addEventListener(ev, e => {
      if (!e.dataTransfer || !Array.from(e.dataTransfer.types || []).includes('Files')) return;
      e.preventDefault(); area.classList.add('arrastrando-archivos');
    }));
    ['dragleave', 'drop'].forEach(ev => area.addEventListener(ev, e => {
      if (ev === 'dragleave' && area.contains(e.relatedTarget)) return;
      area.classList.remove('arrastrando-archivos');
      if (ev === 'drop' && e.dataTransfer && e.dataTransfer.files.length) { e.preventDefault(); leeArchivos(e.dataTransfer.files); }
    }));

    /* ── el estado de arriba, los números y la etiqueta ───────────── */
    function actualiza() {
      const n = S.fotos.length, sub = S.fotos.filter(f => f.estado === 'subiendo').length, err = S.fotos.filter(f => f.estado === 'error').length, ok = S.fotos.filter(f => f.estado === 'lista').length;
      area.classList.toggle('con-fotos', n > 0);
      vaciar.hidden = n === 0;
      liMas.hidden = n === 0 || n >= op.maximo;
      const e = n === 0 ? 'vacio' : sub > 0 ? 'subiendo' : err > 0 ? 'error' : 'listo';
      const cambio = e !== S.estado, prev = S.estado;
      S.estado = e; estadoEl.dataset.e = e;
      if (e === 'vacio') { pre.textContent = 'Sin fotos'; post.textContent = ''; post2.textContent = ''; }
      else if (e === 'subiendo') { pre.textContent = 'Subiendo '; post.textContent = ' de '; post2.textContent = ''; }
      else if (e === 'error') { pre.textContent = ''; post.textContent = err === 1 ? ' foto con problema' : ' fotos con problema'; post2.textContent = ''; }
      else { pre.textContent = ''; post.textContent = ok === 1 ? ' foto lista' : ' fotos listas'; post2.textContent = ''; }
      const v1 = e === 'subiendo' ? ok : e === 'error' ? err : e === 'listo' ? ok : 0, v2 = e === 'subiendo' ? n : 0;
      n1.pon(String(v1), cambio ? 0 : (v1 > S.k1 ? 1 : -1)); n2.pon(String(v2), cambio ? 0 : (v2 > S.k2 ? 1 : -1));
      S.k1 = v1; S.k2 = v2;
      if (cambio) {
        eiEl.innerHTML = e === 'subiendo' ? ICONOS.gira : e === 'error' ? ICONOS.aviso : e === 'listo' ? ICONOS.listo : '';
        eiEl.style.color = e === 'error' ? 'var(--ex-bermellon)' : '';
        if (e === 'error' || e === 'listo') anima(eiEl, [{ transform: 'scale(0)' }, { transform: 'scale(1)' }], { duration: R2.ms, easing: R2.curva });
        if (e === 'listo' && prev !== 'listo') {            // la recompensa: el ✓ con un aro que se abre y «Publicar» que se enciende
          const aro = h('i'); aro.style.cssText = 'position:absolute;inset:0;border-radius:50%;pointer-events:none';
          eiEl.appendChild(aro);
          anima(aro, [{ boxShadow: '0 0 0 0 rgba(226, 73, 47, .55)' }, { boxShadow: '0 0 0 14px rgba(226, 73, 47, 0)' }], { duration: 720, easing: CURVA });
          setTimeout(() => aro.remove(), 760);
          anima(publicar, [{ transform: 'scale(1)' }, { transform: 'scale(1.06)', offset: .35 }, { transform: 'scale(1)' }], { duration: 520, delay: 160, easing: CURVA });
          decirLuego(ok + (ok === 1 ? ' foto lista' : ' fotos listas') + '. Ya puedes publicar.');
        }
      }
      publicar.disabled = !(n > 0 && sub === 0 && err === 0);
      renumera();
      colocaTag();
      if (n === 0) { clearTimeout(S.tOculta); S.tOculta = setTimeout(() => { if (!S.fotos.length) grid.hidden = true; }, 520); }
    }
    function renumera(sinAnim) {
      S.fotos.forEach((f, i) => {
        const dir = f.idx < 0 ? 0 : i > f.idx ? 1 : -1;
        f.num.pon(pad(i + 1), dir, sinAnim);
        f.li.classList.toggle('es-portada', i === 0);
        f.idx = i; etiqueta(f, i);
      });
    }
    function colocaTag() {
      const n = S.fotos.length;
      tag.classList.toggle('on', n > 0);
      if (!n) { S.portada = null; return; }
      const s = slot(0);
      tag.style.left = (s.x + 11) + 'px'; tag.style.top = (s.y + s.h - 37) + 'px';
      const p = S.fotos[0];
      if (S.portada !== p) {
        const nueva = S.portada === null;
        S.portada = p;
        if (nueva) anima(tag, [{ opacity: 0, transform: 'translateY(8px) scale(.6)' }, { opacity: 1, transform: 'none' }], { duration: R2.ms, delay: 500, easing: R2.curva, fill: 'backwards' });
        else saltaTag(S.retrasoTag || 0);
      }
    }
    function saltaTag(retraso) {
      anima(tag, [{ transform: 'translateY(0) scale(1, 1)' }, { transform: 'translateY(-20px) scale(1.06, 1.06)', offset: .4 }, { transform: 'translateY(0) scale(1.08, .84)', offset: .72 }, { transform: 'none' }], { duration: 600, delay: retraso, easing: 'ease-out' });
    }

    /* ── ordenar: mover una foto de sitio ─────────────────────────── */
    function mueve(de, a, excluir) {
      const f = typeof de === 'number' ? S.fotos[de] : de, i = S.fotos.indexOf(f);
      a = lim(a, 0, S.fotos.length - 1);
      if (!f || i < 0 || i === a) return false;
      flip(() => { S.fotos.splice(i, 1); S.fotos.splice(a, 0, f); sincroniza(); }, excluir);
      renumera(); colocaTag(); setHueco(a);
      return true;
    }
    function setHueco(i) {
      const s = slot(i);
      hueco.style.width = s.w + 'px'; hueco.style.height = s.h + 'px';
      hueco.style.transform = 'translate(' + s.x.toFixed(1) + 'px,' + s.y.toFixed(1) + 'px)';
    }
    function cambioFotos() { if (op.alCambiar) op.alCambiar({ fotos: S.fotos.map(f => ({ nombre: f.nombre, src: f.src, estado: f.estado })) }); }

    /* Con el ratón y con el dedo. Con el ratón se agarra desde cualquier punto de la celda tras unos píxeles; con el
       dedo, por el asa de la esquina (así la página se sigue pudiendo desplazar). */
    function ponPuntero(e, f, directo) {
      if (e.button > 0 || S.arr || f.estado === 'subiendo') return;
      const r = f.li.getBoundingClientRect();
      S.arr = { f, li: f.li, id: e.pointerId, x0: e.clientX, y0: e.clientY, ox: e.clientX - r.left, oy: e.clientY - r.top, activo: false, directo, idx0: S.fotos.indexOf(f), el: e.currentTarget };
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {}
      if (directo) { e.preventDefault(); toma(); }
    }
    function toma() {
      const a = S.arr; if (!a || a.activo) return;
      a.activo = true; S.px = a.x0; S.ult = a.x0; S.vx = 0;
      const s = st(a.li); s.drag = true; s.on = true; s.ts = 1.06;
      a.li.classList.add('tomada'); grid.classList.add('arrastrando');
      setHueco(a.f.idx); hueco.classList.add('on');
      decir('Foto ' + (a.f.idx + 1) + ' tomada');
      arranca();
    }
    grid.addEventListener('pointermove', e => {
      const a = S.arr; if (!a || e.pointerId !== a.id) return;
      if (!a.activo) { if (Math.hypot(e.clientX - a.x0, e.clientY - a.y0) < 5) return; toma(); }
      S.px = e.clientX;
      const g = grid.getBoundingClientRect(), sz = geom();
      const px = e.clientX - g.left, py = e.clientY - g.top;
      const cx = px - a.ox + sz.w / 2, cy = py - a.oy + sz.w / 2;
      const col = lim(Math.floor(cx / (sz.w + sz.g)), 0, sz.c - 1), fila = Math.max(0, Math.floor(cy / (sz.w + sz.g)));
      const idx = lim(fila * sz.c + col, 0, S.fotos.length - 1);
      if (idx !== a.f.idx) mueve(a.f, idx, new Set([a.li]));
      const s = st(a.li);
      s.x = px - a.ox - a.li.offsetLeft; s.y = py - a.oy - a.li.offsetTop;
      s.vx = s.vy = 0;
    });
    function suelta(e) {
      const a = S.arr; if (!a || (e && e.pointerId !== a.id)) return;
      S.arr = null;
      try { a.el.releasePointerCapture(a.id); } catch (_) {}
      if (!a.activo) return;
      const s = st(a.li); s.drag = false; s.ts = 1; s.tr = 0;
      a.li.classList.remove('tomada'); grid.classList.remove('arrastrando'); hueco.classList.remove('on');
      const i = a.f.idx;
      decir('Foto movida a la posición ' + (i + 1) + ' de ' + S.fotos.length);
      cambioFotos(); arranca();
    }
    grid.addEventListener('pointerup', suelta); grid.addEventListener('pointercancel', suelta);
    grid.addEventListener('lostpointercapture', e => { if (S.arr && e.pointerId === S.arr.id) suelta(e); });

    /* Con el teclado: Espacio toma, flechas mueven, Espacio suelta, Esc devuelve. */
    function teclaFoto(e, f) {
      const i = S.fotos.indexOf(f), n = S.fotos.length;
      if (S.tomada === f) {
        const c = cols();
        let a = i;
        if (e.key === 'ArrowLeft') a = i - 1; else if (e.key === 'ArrowRight') a = i + 1; else if (e.key === 'ArrowUp') a = i - c; else if (e.key === 'ArrowDown') a = i + c;
        else if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); sueltaTeclado(false); return; }
        else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); sueltaTeclado(true); return; }
        else return;
        e.preventDefault();
        a = lim(a, 0, n - 1);
        if (mueve(f, a)) { f.btn.focus({ preventScroll: true }); decirLuego('Foto movida a la posición ' + (a + 1) + ' de ' + n); }
        return;
      }
      if (e.key === ' ' && f.estado !== 'subiendo') {
        e.preventDefault();
        S.tomada = f; S.orig = i;
        const s = st(f.li); s.ts = 1.05; s.on = true; f.li.classList.add('tomada'); setHueco(i); hueco.classList.add('on'); arranca();
        etiqueta(f, i);
        decir('Foto ' + (i + 1) + ' tomada. Usa las flechas para moverla, Espacio para soltarla y Escape para devolverla.');
      } else if ((e.key === 'p' || e.key === 'P') && f.estado === 'lista') { e.preventDefault(); portada(f); }
      else if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); quita(f); }
      else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        const c = cols(), d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : e.key === 'ArrowDown' ? c : -c, sig = S.fotos[i + d];
        e.preventDefault(); if (sig) sig.btn.focus();
      }
    }
    function sueltaTeclado(devuelve) {
      const f = S.tomada; if (!f) return;
      S.tomada = null;
      if (devuelve && S.orig >= 0) mueve(f, S.orig);
      const s = st(f.li); s.ts = 1; s.on = true; f.li.classList.remove('tomada'); hueco.classList.remove('on'); arranca();
      const i = S.fotos.indexOf(f); etiqueta(f, i);
      decir(devuelve ? 'Foto devuelta a la posición ' + (i + 1) : 'Foto soltada en la posición ' + (i + 1) + ' de ' + S.fotos.length);
      if (!devuelve) cambioFotos();
    }
    grid.addEventListener('focusout', e => { if (S.tomada && !S.sinc && !grid.contains(e.relatedTarget)) sueltaTeclado(false); });

    /* ── hacer portada: las dos fotos se cruzan en vuelo ──────────── */
    function vuelo(f, desde, hasta, lado) {
      const dx = desde[0] - hasta[0], dy = desde[1] - hasta[1], d = Math.hypot(dx, dy);
      if (!d || quieto()) return;
      const nx = -dy / d, ny = dx / d, alto = Math.min(78, d * .3), N = 30, kf = [];
      for (let i = 0; i <= N; i++) {
        const t = i / N, e = ease(t), s = Math.sin(Math.PI * e), q = lado * alto * s;
        kf.push({ transform: 'translate(' + (dx * (1 - e) + nx * q).toFixed(2) + 'px,' + (dy * (1 - e) + ny * q).toFixed(2) + 'px) scale(' + (1 + lado * .1 * s).toFixed(3) + ') rotate(' + (lado * 4 * s).toFixed(2) + 'deg)', offset: t });
      }
      f.li.classList.add(lado > 0 ? 'vuela' : 'vuela-atras');
      f.li.animate(kf, { duration: 880, easing: 'linear' });
      setTimeout(() => f.li.classList.remove('vuela', 'vuela-atras'), 900);
    }
    function portada(f) {
      if (typeof f === 'number') f = S.fotos[f];
      const i = S.fotos.indexOf(f);
      if (!f || i <= 0 || f.estado !== 'lista') return;
      const a = S.fotos[0];
      const pa = [a.li.offsetLeft, a.li.offsetTop], pb = [f.li.offsetLeft, f.li.offsetTop];
      S.fotos[0] = f; S.fotos[i] = a; sincroniza();
      vuelo(f, pb, [f.li.offsetLeft, f.li.offsetTop], 1);
      vuelo(a, pa, [a.li.offsetLeft, a.li.offsetTop], -1);
      S.retrasoTag = 420;
      setTimeout(() => renumera(), quieto() ? 0 : 380);        // las cifras ruedan a mitad del vuelo
      S.fotos.forEach(x => { x.li.classList.toggle('es-portada', x === S.fotos[0]); });
      colocaTag(); S.retrasoTag = 0;
      cambioFotos();
      decir('Portada: ' + f.nombre + '. Pasa a la posición 1; ' + a.nombre + ' a la ' + (i + 1) + '.');
    }

    /* ── quitar ───────────────────────────────────────────────────── */
    function quita(f) {
      if (typeof f === 'number') f = S.fotos[f];
      const i = S.fotos.indexOf(f); if (i < 0) return;
      const li = f.li, g = h('div', 'ex-fantasma');
      g.style.cssText = 'left:' + li.offsetLeft + 'px;top:' + li.offsetTop + 'px;width:' + li.offsetWidth + 'px;height:' + li.offsetHeight + 'px';
      const copia = f.marco.cloneNode(true); copia.style.transition = 'none'; g.appendChild(copia);
      const foco = grid.contains(document.activeElement);
      f.vivo = false;
      if (S.tomada === f) { S.tomada = null; hueco.classList.remove('on'); }
      flip(() => { S.fotos.splice(i, 1); li.remove(); });
      if (!quieto()) {
        grid.appendChild(g);
        anima(g, [{ transform: 'scale(1) rotate(0)', opacity: 1 }, { transform: 'scale(.5) rotate(' + (i % 2 ? 6 : -6) + 'deg)', opacity: 0 }], { duration: 340, easing: CURVA, fill: 'forwards' });
        setTimeout(() => g.remove(), 360);
      }
      actualiza(); cambioFotos();
      decir('Foto quitada: ' + f.nombre + '. Quedan ' + S.fotos.length);
      if (foco) { const sig = S.fotos[Math.min(i, S.fotos.length - 1)]; (sig ? sig.btn : (S.fotos.length < op.maximo ? masB : elegirBtn)).focus({ preventScroll: true }); }
    }
    function vacia() {
      const fs = S.fotos.slice().reverse();
      fs.forEach((f, i) => setTimeout(() => quita(f), quieto() ? 0 : i * 95));
    }
    vaciar.addEventListener('click', vacia);

    publicar.addEventListener('click', () => {
      if (publicar.disabled || publicar.classList.contains('hecho')) return;
      publicar.classList.add('hecho'); publicarT.textContent = 'Anuncio publicado';
      decir('Anuncio publicado con ' + S.fotos.length + ' fotos.');
      if (op.alPublicar) op.alPublicar({ fotos: S.fotos.map(f => ({ nombre: f.nombre, src: f.src, estado: f.estado })) });
      clearTimeout(S.tPub); S.tPub = setTimeout(() => { publicar.classList.remove('hecho'); publicarT.textContent = 'Publicar anuncio'; }, 2000);
    });
    addEventListener('resize', () => { colocaTag(); });

    actualiza();
    return { agrega, elegir, portada, mueve: (a, b) => mueve(a, b), quita, vacia, fotos: () => S.fotos.map(f => ({ nombre: f.nombre, estado: f.estado })) };
  }

  window.Expositor = Expositor;
  document.querySelectorAll('[data-expositor]').forEach(el => { el._expositor = Expositor(el); });
})();
