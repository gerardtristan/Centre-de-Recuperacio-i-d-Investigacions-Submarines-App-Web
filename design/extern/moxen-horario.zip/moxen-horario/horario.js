/* =====================================================================
   Horario · Moxen
   Armar el horario de clases sin topes. A la izquierda están los ramos y, en cada uno, sus secciones; al tocar una se pone en la
   semana, y si choca con otra ya elegida, las horas del choque se rayan en naranja y el panel dice qué ramos se pisan y cuándo.
   Antes de elegir, basta señalar una sección para ver su contorno punteado en la semana (en naranja si chocaría). Y a la derecha, el
   buscador de combinaciones: las que no tienen ningún tope, con la elección que ya hiciste, una a una y con un toque para usarla.

   Funciona de verdad (nada simulado salvo los ramos y secciones de ejemplo de RAMOS):
   · Cada sección es una lista de bloques [día, desde, hasta] en minutos desde medianoche. Dos bloques chocan si son del mismo día y se
     pisan en el tiempo (desde < hasta del otro y al revés): terminar justo cuando empieza el otro no es tope. Un tope mide las horas
     exactas del solape.
   · Las combinaciones salen de recorrer TODAS las formas de elegir una sección por ramo con una búsqueda con retroceso (ramo a ramo,
     descartando apenas una sección choca con las ya puestas). Lo que ya elegiste se respeta: con Cálculo I · Sección 1 puesta, solo
     se buscan las combinaciones que la incluyen. Se ordenan por menos días de clase, luego por término más temprano.
   · Si tu elección ya tiene un tope no hay ninguna combinación: el panel lo dice y propone qué ramo soltar para recuperar opciones, con
     cuántas quedarían.
   · En cada sección, la marca «!» avisa que chocaría con lo que ya elegiste en otros ramos, antes de que la toques.

   Cómo se monta (ver index.html): se inicia solo sobre [data-horario].
     const h = Horario(document.querySelector('[data-horario]'));
     h.elige(0, 1);  h.suelta(0);  h.usa(2);  h.quitaTodos();  h.reinicia();  h.estado();
   Teclado: cada ramo es un grupo (← → ↑ ↓ pasan de una sección a otra; Intro o Espacio la eligen o la sueltan); señalar con el foco
   enseña el contorno punteado; los botones ‹ › recorren las combinaciones y R reinicia.
   Qué se personaliza: los colores, al principio de horario.css (--ho-azul, --ho-naranja y los cinco tonos --ho-r1 a --ho-r5); los
   ramos, secciones y la elección de partida, en RAMOS y DEFECTO; la semana visible, en ABRE y CIERRA. Nada de Date: las horas son
   minutos y el tiempo sale de transiciones, animaciones CSS y setTimeout. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const h = (tag, clase, html) => { const e = document.createElement(tag); if (clase) e.className = clase; if (html != null) e.innerHTML = html; return e; };

  /* ── la semana ───────────────────────────────────────────────────────────────── */
  const DIA = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie'], DIA2 = ['Lu', 'Ma', 'Mi', 'Ju', 'Vi'];
  const ABRE = 8 * 60, CIERRA = 20 * 60;
  const dos = n => (n < 10 ? '0' : '') + n;
  const hm = t => dos(Math.floor(t / 60)) + ':' + dos(t % 60);

  /* ── los datos de ejemplo: [día 0-4, desde, hasta] por bloque ─────────────────────── */
  // los módulos de la jornada: 08:30–10:00, 10:15–11:45, 12:00–13:30, 14:30–16:00, 16:15–17:45
  const MODULO = { 1: [510, 600], 2: [615, 705], 3: [720, 810], 4: [870, 960], 5: [975, 1065] };
  const LM = [0, 2], MJ = [1, 3];
  const m = (dias, k, extra) => dias.map(d => [d, MODULO[k][0], MODULO[k][1]]).concat(extra || []);
  const RAMOS = [
    { nombre: 'Cálculo I', sigla: 'CÁL', secs: [m(LM, 4), m(MJ, 2), m(LM, 5), m(MJ, 3)] },
    { nombre: 'Álgebra Lineal', sigla: 'ÁLG', secs: [m(LM, 4), m(LM, 5), m(MJ, 3)] },
    { nombre: 'Física I', sigla: 'FÍS', secs: [m(LM, 5), m(MJ, 4, [[4, 615, 705]]), m(LM, 2, [[4, 630, 720]])] },
    { nombre: 'Programación I', sigla: 'PRO', secs: [m(MJ, 3, [[4, 630, 720]]), m(LM, 4, [[4, 615, 705]]), m(LM, 1, [[4, 720, 810]])] },
    { nombre: 'Comunicación Escrita', corto: 'Comunicación', sigla: 'COM', secs: [[[2, 510, 600]], [[1, 615, 705]], [[4, 720, 810]]] },
  ];
  const DEFECTO = [0, 2, null, null, null];             // Cálculo I · Sección 1 y Álgebra Lineal · Sección 3
  const NR = RAMOS.length;

  const ICONO = {
    visto: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5.5 12.5 4.2 4.2 8.8-9"/></svg>',
    aviso: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 7v6.5M12 17.2v.1"/></svg>',
    izq: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14.5 6-6 6 6 6"/></svg>',
    der: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9.5 6 6 6-6 6"/></svg>',
  };
  const plural = (n, uno, varios) => n + ' ' + (n === 1 ? uno : varios);

  /* ── la regla: dos bloques chocan si comparten día y se pisan en el tiempo ─────────── */
  const solapa = (a, b) => a[0] === b[0] && a[1] < b[2] && b[1] < a[2];
  const chocan = (sa, sb) => sa.some(x => sb.some(y => solapa(x, y)));
  // choque[r][s][q][t]: ¿la sección s del ramo r pisa a la t del ramo q? (se calcula una vez)
  const CHOQUE = RAMOS.map((R, r) => R.secs.map((sa, s) => RAMOS.map((Q, q) => Q.secs.map((sb, t) => r !== q && chocan(sa, sb)))));

  /* Todas las combinaciones de una sección por ramo sin ningún tope, respetando lo ya elegido (picks[r] = sección o null).
     Búsqueda con retroceso: cada ramo prueba sus secciones y descarta la que choca con las ya puestas. */
  function combinaciones(picks) {
    const sal = [], cur = [];
    (function busca(r) {
      if (r === NR) { sal.push(cur.slice()); return; }
      const opciones = picks[r] != null ? [picks[r]] : RAMOS[r].secs.map((_, s) => s);
      for (const s of opciones) {
        if (cur.every((t, q) => !CHOQUE[q][t][r][s])) { cur.push(s); busca(r + 1); cur.pop(); }
      }
    })(0);
    const dias = c => new Set([].concat(...c.map((s, r) => RAMOS[r].secs[s].map(b => b[0])))).size;
    const fin = c => Math.max(...[].concat(...c.map((s, r) => RAMOS[r].secs[s].map(b => b[2]))));
    const lex = (a, b) => { for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return a[i] - b[i]; return 0; };
    return sal.sort((a, b) => dias(a) - dias(b) || fin(a) - fin(b) || lex(a, b));
  }
  // los topes de una elección: cada par de bloques que se pisan, con las horas exactas del solape
  function topesDe(picks) {
    const sal = [];
    for (let r = 0; r < NR; r++) for (let q = r + 1; q < NR; q++) {
      if (picks[r] == null || picks[q] == null) continue;
      RAMOS[r].secs[picks[r]].forEach(x => RAMOS[q].secs[picks[q]].forEach(y => {
        if (solapa(x, y)) sal.push({ a: [r, picks[r]], b: [q, picks[q]], dia: x[0], ini: Math.max(x[1], y[1]), fin: Math.min(x[2], y[2]) });
      }));
    }
    return sal;
  }
  // resumen corto de una sección para su botón: «Lu·Mi 14:30 +1»
  function resumen(bloques) {
    const g = {};
    bloques.forEach(b => { const k = b[1] + '-' + b[2]; (g[k] = g[k] || []).push(b[0]); });
    const claves = Object.keys(g).sort((a, b) => g[b].length - g[a].length), p = claves[0], ini = +p.split('-')[0];
    return g[p].map(d => DIA2[d]).join('·') + ' ' + hm(ini) + (bloques.length > g[p].length ? '+' + (bloques.length - g[p].length) : '');
  }
  const completo = bloques => bloques.map(b => DIA2[b[0]] + ' ' + hm(b[1]) + '–' + hm(b[2])).join(', ');

  function Horario(raiz, opts) {
    const o = Object.assign({ picks: DEFECTO }, opts || {});
    const ramosEl = $('[data-ramos]', raiz), gridEl = $('[data-grid]', raiz), estadoEl = $('[data-estado]', raiz), combosEl = $('[data-combos]', raiz), resumenEl = $('[data-resumen]', raiz);
    const est = { picks: o.picks.slice(), ver: 0 };
    const bloques = new Map(), topesEl = new Map(), cols = [];
    let px = .72, fantasmas = [], ultima = '';
    const lee = () => { px = parseFloat(getComputedStyle(raiz).getPropertyValue('--ho-px')) || .72; };
    const yDe = t => (t - ABRE) * px;

    /* ── los ramos y sus secciones ───────────────────────────────────────────────────── */
    const tarjetas = [];
    function montaRamos() {
      ramosEl.textContent = '';
      RAMOS.forEach((R, r) => {
        const card = h('section', 'ho-ramo'); card.dataset.r = r;
        card.innerHTML = '<div class="ho-ramo-t"><i></i><b></b><small></small></div><div class="ho-chips" role="group"></div>';
        $('b', card).textContent = R.nombre; $('small', card).textContent = plural(R.secs.length, 'sección', 'secciones');
        const grupo = $('.ho-chips', card); grupo.setAttribute('aria-label', R.nombre + ': secciones');
        const chips = R.secs.map((bs, s) => {
          const c = h('button', 'ho-chip', '<b></b><small></small>'); c.type = 'button'; c.dataset.s = s;
          $('b', c).textContent = 'Sec. ' + (s + 1); $('small', c).textContent = resumen(bs); c.title = R.nombre + ' · Sección ' + (s + 1) + ': ' + completo(bs);
          c.addEventListener('click', () => elige(r, s));
          c.addEventListener('pointerenter', e => { if (e.pointerType !== 'touch') muestra(r, s); });
          c.addEventListener('pointerleave', () => muestra(null));
          c.addEventListener('focus', () => muestra(r, s));
          c.addEventListener('blur', () => muestra(null));
          grupo.append(c); return c;
        });
        grupo.addEventListener('keydown', e => {
          if (!/^Arrow(Left|Right|Up|Down)$/.test(e.key)) return;
          const i = chips.indexOf(document.activeElement); if (i < 0) return;
          e.preventDefault(); const j = Math.max(0, Math.min(chips.length - 1, i + (/Left|Up/.test(e.key) ? -1 : 1)));
          chips.forEach((c, k) => { c.tabIndex = k === j ? 0 : -1; }); chips[j].focus();
        });
        ramosEl.append(card); tarjetas.push({ card, chips });
      });
    }
    function pintaRamos() {
      let n = 0;
      tarjetas.forEach(({ card, chips }, r) => {
        const p = est.picks[r]; if (p != null) n++;
        card.classList.toggle('hay', p != null);
        chips.forEach((c, s) => {
          const choca = est.picks.some((t, q) => q !== r && t != null && CHOQUE[r][s][q][t]);
          const con = choca ? RAMOS.filter((_, q) => q !== r && est.picks[q] != null && CHOQUE[r][s][q][est.picks[q]]).map(Q => Q.nombre) : [];
          c.setAttribute('aria-pressed', p === s); c.classList.toggle('choca', choca);
          c.setAttribute('aria-label', RAMOS[r].nombre + ', Sección ' + (s + 1) + ': ' + completo(RAMOS[r].secs[s]) + (p === s ? '. Elegida' : '') + (choca ? '. Choca con ' + con.join(' y ') : ''));
          if (choca) c.title = RAMOS[r].nombre + ' · Sección ' + (s + 1) + ': ' + completo(RAMOS[r].secs[s]) + ' · choca con ' + con.join(' y '); else c.title = RAMOS[r].nombre + ' · Sección ' + (s + 1) + ': ' + completo(RAMOS[r].secs[s]);
          c.tabIndex = (p != null ? p === s : s === 0) ? 0 : -1;
        });
      });
      resumenEl.textContent = n + ' de ' + NR + ' elegidos';
    }

    /* ── la semana: horas, columnas y bloques ────────────────────────────────────────── */
    function montaSemana() {
      gridEl.textContent = '';
      const dias = h('div', 'ho-dias'); dias.setAttribute('aria-hidden', 'true');
      DIA.forEach(d => dias.append(h('div', 'ho-dia-t', d)));
      const cuerpo = h('div', 'ho-cuerpo');
      const fondo = h('div', 'ho-fondo'); fondo.setAttribute('aria-hidden', 'true'); for (let i = 0; i < 5; i++) fondo.append(h('i'));
      cuerpo.append(fondo);
      const capa = h('div', 'ho-capa'); capa.setAttribute('role', 'list'); capa.setAttribute('aria-label', 'Clases de la semana');
      for (let d = 0; d < 5; d++) { const c = h('div', 'ho-col'); c.dataset.d = d; cols.push(c); capa.append(c); }
      const vacio = h('p', 'ho-vacio', 'Elige una sección de cada ramo<br>y aparece en tu semana.'); vacio.dataset.vacio = '';
      cuerpo.append(capa, vacio);
      gridEl.append(dias, cuerpo);
    }

    // reparte los bloques de un día que coinciden en el tiempo, lado a lado
    function reparte(lista) {
      const orden = lista.slice().sort((a, b) => a.ini - b.ini || a.fin - b.fin), sal = new Map();
      let grupo = [], fin = -1;
      const cierra = () => {
        const carriles = []; grupo.forEach(b => { let k = carriles.findIndex(f => f <= b.ini); if (k < 0) { k = carriles.length; carriles.push(0); } carriles[k] = b.fin; b.k = k; });
        grupo.forEach(b => sal.set(b.clave, { k: b.k, n: carriles.length }));
      };
      orden.forEach(b => { if (grupo.length && b.ini >= fin) { cierra(); grupo = []; fin = -1; } grupo.push(b); fin = Math.max(fin, b.fin); });
      if (grupo.length) cierra();
      return sal;
    }
    function pintaSemana() {
      const picks = est.picks, topes = topesDe(picks), vivos = new Set(), enTope = new Set();
      topes.forEach(t => { enTope.add(t.a.join('-') + '-' + t.dia); enTope.add(t.b.join('-') + '-' + t.dia); });
      const porDia = [[], [], [], [], []];
      picks.forEach((s, r) => { if (s != null) RAMOS[r].secs[s].forEach(b => porDia[b[0]].push({ r, s, ini: b[1], fin: b[2], clave: r + '-' + s + '-' + b[0] })); });
      porDia.forEach((lista, d) => {
        const lay = reparte(lista);
        lista.forEach(b => {
          let v = bloques.get(b.clave), nuevo = false;
          if (!v) {
            const el = h('div', 'ho-bloque', '<b class="nm"></b><b class="sg"></b><span><i class="sc"></i><i class="hr"></i></span>'); el.dataset.r = b.r; el.setAttribute('role', 'listitem');
            $('.nm', el).textContent = RAMOS[b.r].corto || RAMOS[b.r].nombre; $('.sg', el).textContent = RAMOS[b.r].sigla;
            $('.sc', el).textContent = 'Sec. ' + (b.s + 1); $('.hr', el).textContent = ' · ' + hm(b.ini) + '–' + hm(b.fin);
            el.setAttribute('aria-label', RAMOS[b.r].nombre + ', Sección ' + (b.s + 1) + ', ' + DIA[d] + ' de ' + hm(b.ini) + ' a ' + hm(b.fin));
            el.style.transition = 'none'; v = { el }; bloques.set(b.clave, v); cols[d].append(el); nuevo = true;
          }
          const el = v.el, l = lay.get(b.clave);
          el.style.top = '0px'; el.style.height = Math.max(20, (b.fin - b.ini) * px - 2) + 'px';
          el.style.transform = 'translateY(' + (yDe(b.ini) + 1) + 'px)';
          el.style.left = 'calc(' + (l.k * 100 / l.n) + '% + 3px)'; el.style.width = 'calc(' + (100 / l.n) + '% - 6px)';
          el.dataset.n = l.n; el.classList.toggle('en-tope', enTope.has(b.clave));
          if (nuevo) { void el.offsetWidth; el.style.transition = ''; if (!quieto()) { el.classList.add('nuevo'); setTimeout(() => el.classList.remove('nuevo'), 540); } }
          el.classList.remove('sale'); vivos.add(b.clave);
        });
      });
      bloques.forEach((v, clave) => { if (!vivos.has(clave)) { bloques.delete(clave); if (quieto()) v.el.remove(); else { v.el.classList.add('sale'); setTimeout(() => v.el.remove(), 320); } } });
      // las franjas de tope, con las horas exactas del solape
      const claves = new Set();
      topes.forEach(t => {
        const clave = t.dia + '-' + t.ini + '-' + t.fin + '-' + t.a + '-' + t.b; claves.add(clave);
        let el = topesEl.get(clave);
        if (!el) { el = h('div', 'ho-tope'); el.setAttribute('aria-hidden', 'true'); topesEl.set(clave, el); cols[t.dia].append(el); }
        el.style.height = Math.max(14, (t.fin - t.ini) * px - 2) + 'px'; el.style.transform = 'translateY(' + (yDe(t.ini) + 1) + 'px)';
      });
      topesEl.forEach((el, clave) => { if (!claves.has(clave)) { topesEl.delete(clave); el.remove(); } });
      $('[data-vacio]', gridEl).classList.toggle('oculto', picks.some(p => p != null));
    }

    // el contorno punteado de la sección que señalas
    function muestra(r, s) {
      fantasmas.forEach(f => f.remove()); fantasmas = [];
      if (r == null || est.picks[r] === s) return;
      const otros = est.picks.map((p, q) => (q !== r && p != null ? RAMOS[q].secs[p] : [])).reduce((a, b) => a.concat(b), []);
      RAMOS[r].secs[s].forEach(b => {
        const f = h('div', 'ho-fantasma', '<span></span>'); f.dataset.r = r; f.setAttribute('aria-hidden', 'true');
        f.classList.toggle('choca', otros.some(x => solapa(x, b)));
        $('span', f).textContent = 'Sec. ' + (s + 1) + ' · ' + hm(b[1]) + '–' + hm(b[2]);
        f.style.height = Math.max(20, (b[2] - b[1]) * px - 2) + 'px'; f.style.transform = 'translateY(' + (yDe(b[1]) + 1) + 'px)';
        cols[b[0]].append(f); fantasmas.push(f);
      });
    }

    /* ── el panel: topes y combinaciones ─────────────────────────────────────────────── */
    function pintaEstado(topes) {
      const n = est.picks.filter(p => p != null).length;
      estadoEl.classList.toggle('tope', topes.length > 0);
      let html = '<h2>Tu horario</h2>';
      if (topes.length) {
        html += '<p class="ho-estado-t">' + ICONO.aviso + '<span>' + plural(topes.length, 'tope', 'topes') + '</span></p><ul class="ho-topes">';
        topes.slice(0, 3).forEach(t => { html += '<li><b>' + DIA[t.dia] + ' ' + hm(t.ini) + '–' + hm(t.fin) + '</b> · ' + RAMOS[t.a[0]].nombre + ' (Sec. ' + (t.a[1] + 1) + ') con ' + RAMOS[t.b[0]].nombre + ' (Sec. ' + (t.b[1] + 1) + ')</li>'; });
        if (topes.length > 3) html += '<li>y ' + (topes.length - 3) + ' más</li>';
        html += '</ul>';
      } else if (n === NR) {
        const dias = new Set(), todas = [];
        est.picks.forEach((s, r) => RAMOS[r].secs[s].forEach(b => { dias.add(b[0]); todas.push(b); }));
        html += '<p class="ho-estado-t">' + ICONO.visto + '<span>Sin topes</span></p><p class="ho-estado-d">' + NR + ' ramos · clases ' + plural(dias.size, 'día', 'días') + ' · de ' + hm(Math.min(...todas.map(b => b[1]))) + ' a ' + hm(Math.max(...todas.map(b => b[2]))) + '.</p>';
      } else html += '<p class="ho-estado-t">' + ICONO.visto + '<span>Sin topes</span></p><p class="ho-estado-d">' + (n ? n + ' de ' + NR + ' ramos elegidos' : 'Aún no eliges ninguna sección') + '. Faltan ' + plural(NR - n, 'ramo', 'ramos') + '.</p>';
      const firma = topes.length + '/' + n;
      estadoEl.innerHTML = html;
      if (firma !== ultima && ultima && !quieto()) { estadoEl.classList.remove('pulsa'); void estadoEl.offsetWidth; estadoEl.classList.add('pulsa'); }
      ultima = firma;
    }
    function miniatura(c) {
      const mini = h('div', 'ho-mini'); mini.setAttribute('aria-hidden', 'true');
      const col = [0, 1, 2, 3, 4].map(() => { const d = h('div'); mini.append(d); return d; });
      c.forEach((s, r) => RAMOS[r].secs[s].forEach(b => {
        const i = h('i'); i.dataset.r = r; i.style.top = ((b[1] - ABRE) / (CIERRA - ABRE) * 100) + '%'; i.style.height = ((b[2] - b[1]) / (CIERRA - ABRE) * 100) + '%'; col[b[0]].append(i);
      }));
      return mini;
    }
    function pintaCombos(lista, total) {
      const n = lista.length, hay = est.picks.some(p => p != null);
      est.ver = n ? Math.max(0, Math.min(n - 1, est.ver)) : 0;
      const antes = $('.ho-combos-n', combosEl), nTexto = String(n);
      combosEl.textContent = '';
      const cab = h('div', 'ho-combos-cab', '<h2>Combinaciones sin tope</h2><span class="ho-combos-n">' + n + '</span>');
      combosEl.append(cab);
      const nn = $('.ho-combos-n', combosEl); if (antes && antes.textContent !== nTexto && !quieto()) nn.classList.add('cambia');
      if (!n) {
        const sug = [];
        est.picks.forEach((p, r) => { if (p == null) return; const q = est.picks.slice(); q[r] = null; const k = combinaciones(q).length; if (k) sug.push({ r, k }); });
        sug.sort((a, b) => b.k - a.k || a.r - b.r);
        combosEl.append(h('p', 'ho-combos-d', 'Con esta elección <b>ninguna combinación</b> evita los topes.' + (sug.length ? ' Suelta un ramo y vuelven las opciones:' : ' Prueba soltando dos ramos.')));
        const ul = h('div', 'ho-sueltas');
        sug.slice(0, 3).forEach(x => {
          const b = h('button', 'ho-suelta', '<span></span><b></b>'); b.type = 'button'; $('span', b).textContent = 'Soltar ' + RAMOS[x.r].nombre; $('b', b).textContent = plural(x.k, 'opción', 'opciones');
          b.setAttribute('aria-label', 'Soltar ' + RAMOS[x.r].nombre + ': quedan ' + plural(x.k, 'combinación', 'combinaciones')); b.addEventListener('click', () => suelta(x.r)); ul.append(b);
        });
        combosEl.append(ul);
        return;
      }
      combosEl.append(h('p', 'ho-combos-d', hay ? 'Con tu elección hay <b>' + n + '</b> de las <b>' + total + '</b> que existen.' : 'Estas son <b>todas</b> las que existen.'));
      const c = lista[est.ver];
      combosEl.append(miniatura(c));
      const ul = h('ul', 'ho-lineas');
      c.forEach((s, r) => { const li = h('li', '', '<i></i><b></b><span></span>'); li.dataset.r = r; $('b', li).textContent = RAMOS[r].nombre; $('span', li).textContent = 'Sección ' + (s + 1); ul.append(li); });
      combosEl.append(ul);
      const igual = c.every((s, r) => est.picks[r] === s);
      const nav = h('div', 'ho-nav', '<button type="button" class="ho-nav-b" data-prev aria-label="Combinación anterior">' + ICONO.izq + '</button><span class="ho-nav-t"><b>' + (est.ver + 1) + '</b> de ' + n + '</span><button type="button" class="ho-nav-b" data-sig aria-label="Combinación siguiente">' + ICONO.der + '</button>');
      $('[data-prev]', nav).disabled = est.ver === 0; $('[data-sig]', nav).disabled = est.ver >= n - 1;
      $('[data-prev]', nav).addEventListener('click', () => { est.ver--; pinta(); }); $('[data-sig]', nav).addEventListener('click', () => { est.ver++; pinta(); });
      const usa = h('button', 'ho-usa', igual ? 'Ya es tu horario' : 'Usar esta combinación'); usa.type = 'button'; usa.disabled = igual;
      usa.addEventListener('click', () => usaCombo(est.ver));
      combosEl.append(nav, usa);
    }
    let ultimoTotal = null;
    function pinta() {
      const topes = topesDe(est.picks), lista = combinaciones(est.picks);
      if (ultimoTotal == null) ultimoTotal = combinaciones(new Array(NR).fill(null)).length;
      pintaRamos(); pintaSemana(); pintaEstado(topes); pintaCombos(lista, ultimoTotal);
      return { topes, lista };
    }

    /* ── las acciones ────────────────────────────────────────────────────────────── */
    function elige(r, s) { est.picks[r] = est.picks[r] === s ? null : s; est.ver = 0; muestra(null); const x = pinta(); refoca(r, s); return x; }
    function suelta(r) { est.picks[r] = null; est.ver = 0; pinta(); }
    function quitaTodos() { est.picks = new Array(NR).fill(null); est.ver = 0; muestra(null); pinta(); }
    function usaCombo(i) { const l = combinaciones(est.picks); if (!l[i]) return; est.picks = l[i].slice(); est.ver = 0; muestra(null); pinta(); }
    function reinicia() { est.picks = o.picks.slice(); est.ver = 0; muestra(null); pinta(); }
    function refoca(r, s) { const c = tarjetas[r] && tarjetas[r].chips[s]; if (c && document.activeElement && document.activeElement.classList.contains('ho-chip')) { try { c.focus({ preventScroll: true }); } catch (_) {} } }
    $('[data-quita]', raiz).addEventListener('click', quitaTodos);
    $('[data-reinicio]', raiz).addEventListener('click', reinicia);
    const atajo = e => { if (e.ctrlKey || e.metaKey || e.altKey) return; if (e.key.toLowerCase() === 'r') reinicia(); };
    raiz.addEventListener('keydown', atajo);
    document.addEventListener('keydown', e => { if (document.activeElement === document.body) atajo(e); });
    window.addEventListener('resize', () => { lee(); bloques.forEach(v => { v.el.remove(); }); bloques.clear(); topesEl.forEach(e => e.remove()); topesEl.clear(); montaHoras(); pinta(); });

    /* ── arranque ───────────────────────────────────────────────────────────────────── */
    function montaHoras() { $$('.ho-hora', gridEl).forEach(e => e.remove()); const cuerpo = $('.ho-cuerpo', gridEl); for (let t = ABRE; t <= CIERRA; t += 60) { const e = h('span', 'ho-hora', hm(t)); e.style.top = (cuerpo.offsetTop + (t - ABRE) * px) + 'px'; e.setAttribute('aria-hidden', 'true'); gridEl.append(e); } }
    lee(); montaRamos(); montaSemana(); montaHoras(); pinta();

    const api = {
      elige, suelta, quitaTodos, usa: usaCombo, reinicia,
      estado: () => ({
        picks: est.picks.slice(), topes: topesDe(est.picks), combos: combinaciones(est.picks), total: combinaciones(new Array(NR).fill(null)).length,
        enPantalla: { bloques: bloques.size, topes: topesEl.size },
      }),
    };
    raiz.__horario = api;
    return api;
  }

  Horario.combinaciones = combinaciones; Horario.RAMOS = RAMOS;
  window.Horario = Horario;
  $$('[data-horario]').forEach(el => Horario(el));
})();
