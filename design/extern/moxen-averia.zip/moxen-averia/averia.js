/* =====================================================================
   Avería · Moxen
   El formulario para pedir una visita técnica: el cliente dice qué
   equipo es, responde las preguntas de ESE equipo, cuenta qué pasa, sube
   fotos y elige una franja. Al enviar recibe un folio que dice cuándo va el
   técnico.

   · Las fotos se achican aquí, en el navegador. Cada archivo se abre,
     se dibuja en un lienzo (canvas) con el lado más largo en 1280 px como
     máximo y se vuelve a guardar como JPEG (calidad 0,72). Una foto de
     teléfono de varios megas queda en unos cientos de KB, que es lo que
     sube por la red. Si el primer intento no pesa menos que el original se
     prueba con 1024, 800 y 640 px y calidades más bajas. Como el lienzo
     vuelve a codificar la imagen, también desaparece la información
     oculta (ubicación, modelo del teléfono, fecha): es decir, no viaja
     con la foto. La orientación sí se respeta (se aplica antes de dibujar).
     La tarjeta de cada foto muestra el peso antes, el peso después y cuánto
     se ahorró; el número baja rodando.
   · Se rechaza lo que no es una imagen mirando los primeros bytes del
     archivo (la «firma» de JPG, PNG o WebP), no el nombre ni el tipo que
     declara el navegador: un «foto.jpg» que por dentro es texto, un PDF, un
     GIF, un archivo vacío o uno de más de 25 MB se rechazan con su motivo;
     una imagen dañada también. Máximo 4 fotos y sin repetir.
   · Cada equipo tiene sus preguntas (EQUIPOS): la primera es obligatoria y
     dice qué le pasa; la segunda es una ayuda para el técnico.
   · La franja: cinco días hábiles por dos franjas (mañana y tarde) con cupo
     de 3 visitas. Las que se llenaron no se pueden elegir. Al enviar se
     ocupa un lugar de la franja y el folio lo cuenta.
   · El folio, AV-DDMM-FNN: AV, el día y el mes de la visita, la franja (M o
     T) y el número de orden en esa franja. Es decir, el folio ya dice cuándo
     vas y en qué lugar de la fila.
   · Las fotos de ejemplo se dibujan en un lienzo (una lavadora con una fuga
     y la etiqueta de un equipo) con azar de semilla: ninguna foto se baja
     de ninguna parte. Nada se envía ni se guarda: es una demostración.
   · Teclado: todo es nativo (radios con ← →, botones, Intro). Movimiento
     reducido: las tarjetas y los pesos aparecen de golpe. Sin Date.

   Montaje (se inicia solo sobre [data-averia]; index.html es la plantilla):
     const a = Averia(document.querySelector('[data-averia]'), {
       alEnviar: ({ folio, equipo, respuestas, texto, franja, fotos }) => {},   // aquí van las fotos achicadas (Blob)
       lado: 1280, calidad: 0.72, maxFotos: 4,
     });
     a.agrega(fileList);  a.fotos();  a.estado();  a.reinicia();   // y Averia.folio(dia, mes, franja, orden)

   Qué se personaliza: los equipos y sus preguntas (EQUIPOS), los días y las franjas (DIAS,
   FRANJAS, CUPO, OCUPADAS) y los colores, en las variables --av-* de averia.css. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const p2 = n => String(n).padStart(2, '0');
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';

  /* ── Los equipos y sus preguntas ──────────────────────────────────────── */
  const svg = d => '<svg viewBox="0 0 24 24" aria-hidden="true">' + d + '</svg>';
  const EQUIPOS = [
    { id: 'lavadora', nombre: 'Lavadora', icono: svg('<rect x="5" y="3.5" width="14" height="17" rx="2.6"/><circle cx="12" cy="13.4" r="4"/><path d="M8.2 7h.01M11 7h5"/>'),
      preguntas: [{ id: 'falla', etq: '¿Qué hace?', opciones: ['No enciende', 'No desagua', 'Gotea agua', 'Hace ruido fuerte', 'No centrifuga'] },
                  { id: 'codigo', etq: '¿Muestra un código en la pantalla?', opciones: ['Sí', 'No'], ayuda: true }] },
    { id: 'refrigerador', nombre: 'Refrigerador', icono: svg('<rect x="6.5" y="3" width="11" height="18" rx="2.6"/><path d="M6.5 10.2h11M9.7 6.2v1.7M9.7 13v3"/>'),
      preguntas: [{ id: 'falla', etq: '¿Qué pasa?', opciones: ['No enfría', 'Enfría poco', 'Hace hielo de más', 'Gotea agua', 'Hace ruido'] },
                  { id: 'luz', etq: '¿Se enciende la luz de adentro?', opciones: ['Sí', 'No'], ayuda: true }] },
    { id: 'aire', nombre: 'Aire acondicionado', rotulo: 'Aire acondi\u00ADcionado', icono: svg('<rect x="3.5" y="5" width="17" height="7.5" rx="2.4"/><path d="M7 8.8h10M7.2 15.5c0 1.4-.9 1.7-.9 3.2M12 15.5c0 1.4-.9 1.7-.9 3.2M16.8 15.5c0 1.4-.9 1.7-.9 3.2"/>'),
      preguntas: [{ id: 'falla', etq: '¿Qué pasa?', opciones: ['No enciende', 'No enfría', 'Gotea agua', 'Hace ruido', 'Huele raro'] },
                  { id: 'control', etq: '¿Responde el control remoto?', opciones: ['Sí', 'No'], ayuda: true }] },
    { id: 'horno', nombre: 'Horno', icono: svg('<rect x="4" y="4.5" width="16" height="15" rx="2.6"/><path d="M4 9h16"/><rect x="7.4" y="11.5" width="9.2" height="5.2" rx="1.2"/><path d="M7.6 6.8h.01M10.6 6.8h.01"/>'),
      preguntas: [{ id: 'falla', etq: '¿Qué pasa?', opciones: ['No enciende', 'No calienta', 'Calienta mal parejo', 'La puerta no cierra'] },
                  { id: 'energia', etq: '¿Funciona a gas o eléctrico?', opciones: ['Gas', 'Eléctrico'], ayuda: true }] },
    { id: 'calentador', nombre: 'Calentador de agua', icono: svg('<rect x="7" y="3" width="10" height="15.5" rx="4.4"/><path d="M10.4 18.5v2.6M13.6 18.5v2.6M12 7.4c1.5 1.7 2.1 2.6 2.1 3.6a2.1 2.1 0 0 1-4.2 0c0-1 .6-1.9 2.1-3.6z"/>'),
      preguntas: [{ id: 'falla', etq: '¿Qué pasa?', opciones: ['No calienta', 'Poca presión', 'Gotea agua', 'Se apaga solo'] },
                  { id: 'energia', etq: '¿Es a gas o eléctrico?', opciones: ['Gas', 'Eléctrico'], ayuda: true }] },
  ];

  /* ── Los días, las franjas y el cupo (hoy es el viernes 23 de octubre de 2026) ── */
  const DIAS = [
    { etq: 'Lun', num: 26, mes: 10, largo: 'lunes 26 de octubre', corto: '26 oct' },
    { etq: 'Mar', num: 27, mes: 10, largo: 'martes 27 de octubre', corto: '27 oct' },
    { etq: 'Mié', num: 28, mes: 10, largo: 'miércoles 28 de octubre', corto: '28 oct' },
    { etq: 'Jue', num: 29, mes: 10, largo: 'jueves 29 de octubre', corto: '29 oct' },
    { etq: 'Vie', num: 30, mes: 10, largo: 'viernes 30 de octubre', corto: '30 oct' },
  ];
  const FRANJAS = [{ id: 'M', nombre: 'Mañana', horas: '9:00 – 13:00' }, { id: 'T', nombre: 'Tarde', horas: '14:00 – 18:00' }];
  const CUPO = 3;
  const OCUPADAS = { '26M': 3, '26T': 1, '27M': 2, '27T': 0, '28M': 1, '28T': 2, '29M': 0, '29T': 3, '30M': 1, '30T': 0 };   // lugares ya tomados por franja
  const folio = (dia, mes, franja, orden) => 'AV-' + p2(dia) + p2(mes) + '-' + franja + p2(orden);

  /* ── Pesos ──────────────────────────────────────────────────────────────
     1 KB = 1024 bytes. Hasta 1023 B se escribe en bytes, hasta 1 MB en KB enteros y desde ahí en MB con un decimal y coma. */
  function peso(b) {
    b = Math.max(0, Math.round(b));
    if (b < 1024) return b + ' B';
    if (b < 1048576 - 512) return Math.round(b / 1024) + ' KB';
    return (b / 1048576).toFixed(1).replace('.', ',') + ' MB';
  }
  const ahorro = (antes, despues) => Math.round((1 - despues / antes) * 100);

  /* ── Qué es un archivo, por dentro ──────────────────────────────────────
     Se miran los primeros bytes: así un «foto.jpg» que es un texto no pasa, ni un JPG de verdad con otro nombre se rechaza. */
  async function tipoDe(archivo) {
    const b = new Uint8Array(await archivo.slice(0, 16).arrayBuffer());
    if (!b.length) return 'vacio';
    const ascii = (a, z) => String.fromCharCode(...b.slice(a, z));
    if (b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF) return 'jpeg';
    if (b[0] === 0x89 && ascii(1, 4) === 'PNG') return 'png';
    if (ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP') return 'webp';
    if (ascii(0, 4) === 'GIF8') return 'gif';
    if (ascii(0, 4) === '%PDF') return 'pdf';
    if (ascii(0, 2) === 'PK') return 'zip';
    if ([...b].every(x => x === 9 || x === 10 || x === 13 || (x >= 32 && x < 127) || x >= 0xC2)) return 'texto';
    return 'otro';
  }
  const MOTIVO = {
    vacio: 'está vacío.', pdf: 'es un PDF, no una imagen.', gif: 'es un GIF: usa JPG, PNG o WebP.', zip: 'es un archivo comprimido, no una imagen.',
    texto: 'es un archivo de texto, aunque se llame como una foto.', otro: 'no es una imagen JPG, PNG o WebP.',
  };

  /* ── Achicar una foto ───────────────────────────────────────────────────
     Abrirla (con su orientación), dibujarla más chica sobre fondo blanco y guardarla como JPEG.
     Devuelve { blob, ancho, alto, anchoOrig, altoOrig, calidad, liviana } (liviana: ni así pesó menos que el original). */
  async function abre(archivo) {
    try { return await createImageBitmap(archivo, { imageOrientation: 'from-image' }); }
    catch (e) { /* el navegador no acepta las opciones: se prueba con un <img> */ }
    const url = URL.createObjectURL(archivo);
    try {
      const img = new Image(); img.src = url; await img.decode();
      return img;
    } finally { URL.revokeObjectURL(url); }
  }
  async function achica(archivo, lado, calidad) {
    let img;
    try { img = await abre(archivo); } catch (e) { throw new Error('dañada'); }
    const w0 = img.width || img.naturalWidth, h0 = img.height || img.naturalHeight;
    if (!w0 || !h0) throw new Error('dañada');
    let mejor = null;
    const intentos = [[lado, calidad], [Math.min(lado, 1024), Math.min(calidad, .62)], [Math.min(lado, 800), Math.min(calidad, .52)], [Math.min(lado, 640), Math.min(calidad, .45)]];
    for (const [l, q] of intentos) {
      const k = Math.min(1, l / Math.max(w0, h0));
      const w = Math.max(1, Math.round(w0 * k)), h = Math.max(1, Math.round(h0 * k));
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      const g = c.getContext('2d');
      g.fillStyle = '#fff'; g.fillRect(0, 0, w, h);      // un PNG con transparencia quedaría negro en un JPEG
      g.imageSmoothingQuality = 'high'; g.drawImage(img, 0, 0, w, h);
      const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', q));
      if (!blob) throw new Error('dañada');
      if (!mejor || blob.size < mejor.blob.size) mejor = { blob, ancho: w, alto: h, calidad: q };
      if (blob.size < archivo.size) break;
    }
    if (img.close) img.close();
    return Object.assign(mejor, { anchoOrig: w0, altoOrig: h0, liviana: mejor.blob.size >= archivo.size });
  }

  /* ── Las fotos de ejemplo, dibujadas en un lienzo ───────────────────────
     Dos escenas (una lavadora que gotea y la etiqueta de un equipo) de 2400 × 1800 px con grano de película, para que pesen
     como una foto de teléfono. Azar con semilla: siempre salen iguales. */
  function mulberry32(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function escenaFalla(g, W, H) {
    let f = g.createLinearGradient(0, 0, 0, H * .74); f.addColorStop(0, '#e8d9c2'); f.addColorStop(1, '#d6c2a3'); g.fillStyle = f; g.fillRect(0, 0, W, H);
    f = g.createLinearGradient(0, H * .72, 0, H); f.addColorStop(0, '#c2a987'); f.addColorStop(1, '#a58b6b'); g.fillStyle = f; g.fillRect(0, H * .72, W, H * .28);
    g.fillStyle = 'rgba(70,45,20,.18)'; g.fillRect(0, H * .715, W, 10);
    // sombra y cuerpo de la lavadora
    g.fillStyle = 'rgba(60,38,16,.28)'; g.beginPath(); g.ellipse(W * .5, H * .805, W * .25, H * .03, 0, 0, 7); g.fill();
    f = g.createLinearGradient(W * .27, 0, W * .73, 0); f.addColorStop(0, '#dcd4c6'); f.addColorStop(.5, '#f7f3ec'); f.addColorStop(1, '#d3cbbc');
    g.fillStyle = f; rr(g, W * .27, H * .1, W * .46, H * .7, 64); g.fill();
    g.fillStyle = '#e4ddd0'; rr(g, W * .27, H * .1, W * .46, H * .14, 64); g.fill(); g.fillRect(W * .27, H * .2, W * .46, H * .04);
    g.fillStyle = '#23408e'; g.beginPath(); g.arc(W * .36, H * .17, W * .026, 0, 7); g.fill();
    g.fillStyle = '#2b3550'; rr(g, W * .45, H * .145, W * .13, H * .05, 18); g.fill();
    g.fillStyle = '#d0613a'; g.beginPath(); g.arc(W * .63, H * .17, W * .012, 0, 7); g.fill();
    // la puerta
    g.fillStyle = '#c9c1b2'; g.beginPath(); g.arc(W * .5, H * .5, W * .185, 0, 7); g.fill();
    g.fillStyle = '#2f3d63'; g.beginPath(); g.arc(W * .5, H * .5, W * .158, 0, 7); g.fill();
    f = g.createRadialGradient(W * .46, H * .44, 10, W * .5, H * .5, W * .15); f.addColorStop(0, '#9fb3e6'); f.addColorStop(.55, '#4a62a8'); f.addColorStop(1, '#25356a');
    g.fillStyle = f; g.beginPath(); g.arc(W * .5, H * .5, W * .14, 0, 7); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 16; g.lineCap = 'round'; g.beginPath(); g.arc(W * .5, H * .5, W * .105, 3.5, 4.5); g.stroke();
    // el charco y las gotas
    g.fillStyle = 'rgba(52,86,170,.62)'; g.beginPath(); g.ellipse(W * .5, H * .835, W * .27, H * .05, 0, 0, 7); g.fill();
    g.fillStyle = 'rgba(190,210,250,.55)'; g.beginPath(); g.ellipse(W * .46, H * .828, W * .12, H * .014, 0, 0, 7); g.fill();
    g.fillStyle = 'rgba(52,86,170,.75)';
    [[.43, .81], [.5, .805], [.575, .812]].forEach(([x, y], i) => { g.beginPath(); g.ellipse(W * x, H * y, 16 + i * 3, 30 + i * 4, 0, 0, 7); g.fill(); });
  }
  function escenaEtiqueta(g, W, H) {
    let f = g.createLinearGradient(0, 0, W, H); f.addColorStop(0, '#8e98a7'); f.addColorStop(.5, '#c5cbd5'); f.addColorStop(1, '#8a94a3'); g.fillStyle = f; g.fillRect(0, 0, W, H);
    for (let i = 0; i < 70; i++) { g.fillStyle = 'rgba(255,255,255,' + (0.025 + (i % 5) * .008) + ')'; g.fillRect(0, i * H / 70, W, 5); }
    g.fillStyle = 'rgba(30,24,16,.3)'; rr(g, W * .115, H * .265, W * .78, H * .5, 40); g.fill();
    g.fillStyle = '#ebe8df'; rr(g, W * .1, H * .24, W * .8, H * .5, 40); g.fill();
    g.strokeStyle = '#23408e'; g.lineWidth = 10; rr(g, W * .115, H * .26, W * .77, H * .46, 30); g.stroke();
    g.fillStyle = '#20160f'; g.textBaseline = 'alphabetic';
    const filas = [['MODELO', 'LV-1500'], ['SERIE', '0048213'], ['TENSIÓN', '220 V ~ 50 Hz'], ['POTENCIA', '1800 W'], ['CAPACIDAD', '7 kg']];
    filas.forEach(([a, b], i) => {
      const y = H * .35 + i * H * .068;
      g.font = '600 56px ui-monospace, Menlo, monospace'; g.fillStyle = '#6a5a4a'; g.fillText(a, W * .15, y);
      g.font = '700 76px ui-monospace, Menlo, monospace'; g.fillStyle = '#20160f'; g.fillText(b, W * .43, y);
    });
    g.fillStyle = '#20160f';
    for (let i = 0, x = W * .15; x < W * .85; i++) { const w = 4 + (i * 7 % 13); g.fillRect(x, H * .665, w, H * .045); x += w + 5 + (i * 3 % 9); }
    [[.13, .27], [.87, .27], [.13, .71], [.87, .71]].forEach(([x, y]) => { g.fillStyle = '#9aa0aa'; g.beginPath(); g.arc(W * x, H * y, 22, 0, 7); g.fill(); g.strokeStyle = '#555c68'; g.lineWidth = 5; g.beginPath(); g.moveTo(W * x - 12, H * y - 6); g.lineTo(W * x + 12, H * y + 6); g.stroke(); });
  }
  function grano(g, W, H, rnd, fuerza) {
    const img = g.getImageData(0, 0, W, H), d = img.data;
    for (let i = 0; i < d.length; i += 4) { const n = (rnd() - .5) * fuerza * 2; d[i] += n; d[i + 1] += n * .9; d[i + 2] += n * 1.1; }
    g.putImageData(img, 0, 0);
  }
  async function creaEjemplo(n) {
    const W = 2400, H = 1800, c = document.createElement('canvas'); c.width = W; c.height = H;
    const g = c.getContext('2d');
    (n === 0 ? escenaFalla : escenaEtiqueta)(g, W, H);
    grano(g, W, H, mulberry32(8550 + n), 19);
    const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', .97));
    return new File([blob], n === 0 ? 'foto-falla.jpg' : 'foto-etiqueta.jpg', { type: 'image/jpeg' });
  }

  /* ── El formulario ────────────────────────────────────────────────────── */
  function Averia(raiz, opciones) {
    const o = Object.assign({ lado: 1280, calidad: 0.72, maxFotos: 4, maxOriginal: 25 * 1048576, equipo: 'refrigerador', alEnviar: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const el = { equipos: $('[data-equipos]'), preguntas: $('[data-preguntas]'), texto: $('[data-texto]'), cuentaTexto: $('[data-cuenta-texto]'), zona: $('[data-zona]'), archivo: $('[data-archivo]'),
      elegir: $('[data-elegir]'), ejemplo: $('[data-ejemplo]'), fotos: $('[data-fotos]'), avisos: $('[data-avisos]'), total: $('[data-total]'), cuenta: $('[data-cuenta]'),
      franjas: $('[data-franjas]'), franjaTxt: $('[data-franja-txt]'), enviar: $('[data-enviar]'), enviarT: $('[data-enviar-t]'), form: $('[data-form]'), listo: $('[data-listo]'),
      folio: $('[data-folio]'), folioNota: $('[data-folio-nota]'), copiar: $('[data-copiar]'), copiarT: $('[data-copiar-t]'), nueva: $('[data-nueva]'), vivo: $('[data-vivo]'),
      titulo: $('#av-titulo'), tituloListo: $('#av-t-listo') };
    const voz = t => { el.vivo.textContent = ''; setTimeout(() => { el.vivo.textContent = t; }, 30); };

    let equipo = o.equipo, respuestas = {}, fotos = [], franja = null, ocupadas = Object.assign({}, OCUPADAS), contador = 0, cola = Promise.resolve(), ejemplos = null, enviando = false, ultimo = null;
    const equipoActual = () => EQUIPOS.find(e => e.id === equipo);
    const grupo = n => raiz.querySelector('[data-grupo="' + n + '"]');
    const err = (n, t) => { const e = raiz.querySelector('[data-err="' + n + '"]'); if (e) e.textContent = t || ''; const g = grupo(n); if (g) g.toggleAttribute('data-invalido', !!t); };

    /* — los equipos y sus preguntas — */
    EQUIPOS.forEach(e => {
      const l = document.createElement('label'); l.className = 'av-equipo'; l.dataset.equipo = e.id;
      l.innerHTML = '<input type="radio" name="equipo" value="' + e.id + '"><span class="av-eq-i">' + e.icono + '</span><b>' + (e.rotulo || e.nombre) + '</b>';
      el.equipos.appendChild(l);
    });
    const radiosEquipo = [...el.equipos.querySelectorAll('input')];
    function pintaPreguntas() {
      el.preguntas.innerHTML = '';
      equipoActual().preguntas.forEach(q => {
        const f = document.createElement('fieldset'); f.className = 'av-pregunta'; f.dataset.pregunta = q.id;
        f.innerHTML = '<legend>' + q.etq + (q.ayuda ? ' <em>(ayuda al técnico)</em>' : '') + '</legend><div class="av-chips">' +
          q.opciones.map(op => '<label class="av-chip"><input type="radio" name="q-' + q.id + '" value="' + op + '"><span>' + op + '</span></label>').join('') + '</div><p class="av-err" data-err="q-' + q.id + '" role="alert"></p>';
        el.preguntas.appendChild(f);
        f.querySelectorAll('input').forEach(i => i.addEventListener('change', () => { respuestas[q.id] = i.value; err('q-' + q.id, ''); }));
      });
    }
    function eligeEquipo(id, enfoca) {
      equipo = id; respuestas = {};
      radiosEquipo.forEach(i => { i.checked = i.value === id; });
      pintaPreguntas();
      err('equipo', '');
      if (enfoca) voz('Equipo: ' + equipoActual().nombre + '. Hay ' + equipoActual().preguntas.length + ' preguntas.');
    }
    radiosEquipo.forEach(i => i.addEventListener('change', () => eligeEquipo(i.value, true)));

    el.texto.addEventListener('input', () => { el.cuentaTexto.textContent = el.texto.value.length; if (el.texto.value.trim().length >= 10) err('texto', ''); });

    /* — la franja — */
    function pintaFranjas() {
      const antes = franja;
      el.franjas.innerHTML = '';
      DIAS.forEach(d => {
        const c = document.createElement('div'); c.className = 'av-dia';
        c.innerHTML = '<p class="av-dia-t">' + d.etq + '<b>' + d.num + '</b></p>';
        FRANJAS.forEach(f => {
          const k = d.num + f.id, tomadas = ocupadas[k], llena = tomadas >= CUPO;
          const l = document.createElement('label'); l.className = 'av-slot'; l.dataset.slot = k;
          l.title = d.largo + ', ' + f.nombre.toLowerCase() + ' (' + f.horas + ')' + (llena ? ': completa' : ': quedan ' + (CUPO - tomadas));
          l.innerHTML = '<input type="radio" name="franja" value="' + k + '"' + (llena ? ' disabled' : '') + ' aria-label="' + d.largo + ', ' + f.nombre.toLowerCase() + ', ' + f.horas + (llena ? ', completa' : ', quedan ' + (CUPO - tomadas)) + '">' +
            '<b>' + f.nombre + '</b><span class="av-puntos" aria-hidden="true">' + Array.from({ length: CUPO }, (_, i) => '<i' + (i < tomadas ? ' data-lleno' : '') + '></i>').join('') + '</span>';
          c.appendChild(l);
        });
        el.franjas.appendChild(c);
      });
      if (antes && !(ocupadas[antes] >= CUPO)) { const i = el.franjas.querySelector('input[value="' + antes + '"]'); if (i) i.checked = true; } else franja = null;
      el.franjas.querySelectorAll('input').forEach(i => i.addEventListener('change', () => { franja = i.value; err('franja', ''); textoFranja(); }));
      textoFranja();
    }
    function textoFranja() {
      if (!franja) { el.franjaTxt.textContent = 'Elige una'; return; }
      const d = DIAS.find(x => String(x.num) === franja.slice(0, -1)), f = FRANJAS.find(x => x.id === franja.slice(-1));
      el.franjaTxt.textContent = d.etq + ' ' + d.num + ' · ' + f.nombre.toLowerCase();
    }

    /* — las fotos — */
    const tarjeta = id => el.fotos.querySelector('[data-foto="' + id + '"]');
    function rueda(nodo, desde, hasta) {          // el peso baja rodando, con requestAnimationFrame y performance.now
      if (quieto()) { nodo.textContent = peso(hasta); return; }
      const t0 = performance.now(), ms = 900;
      const paso = () => {
        const k = Math.min(1, (performance.now() - t0) / ms), e = 1 - Math.pow(1 - k, 3);
        nodo.textContent = peso(desde + (hasta - desde) * e);
        if (k < 1) requestAnimationFrame(paso);
      };
      requestAnimationFrame(paso);
    }
    function creaTarjeta(f) {
      const li = document.createElement('li'); li.className = 'av-foto'; li.dataset.foto = f.id;
      li.innerHTML = '<span class="av-f-mini"><i></i></span><span class="av-f-nombre"></span><span class="av-f-pesos">Achicando…</span>' +
        '<span class="av-f-barra"><i></i></span><button class="av-f-quita" type="button" aria-label="Quitar la foto"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/></svg></button>';
      li.querySelector('.av-f-nombre').textContent = f.nombre;
      li.querySelector('.av-f-nombre').title = f.nombre;
      li.querySelector('.av-f-quita').setAttribute('aria-label', 'Quitar ' + f.nombre);
      li.querySelector('.av-f-quita').addEventListener('click', () => quita(f.id));
      el.fotos.insertBefore(li, el.fotos.querySelector('.es-vacia'));
      if (quieto()) li.style.animation = 'none';
    }
    function terminaTarjeta(f) {
      const li = tarjeta(f.id); if (!li) return;
      const mini = li.querySelector('.av-f-mini'); mini.innerHTML = ''; mini.style.backgroundImage = 'url("' + f.url + '")';
      const p = li.querySelector('.av-f-pesos');
      p.innerHTML = '<s></s><span aria-hidden="true">→</span><b></b>' + (f.liviana ? '<span class="av-f-pct">ya era liviana</span>' : '<span class="av-f-pct">−' + ahorro(f.antes, f.despues) + ' %</span>');
      p.querySelector('s').textContent = peso(f.antes);
      const b = p.querySelector('b'); b.textContent = peso(f.antes); rueda(b, f.antes, f.despues);
      const barra = li.querySelector('.av-f-barra i');
      barra.style.setProperty('--r', '1');
      requestAnimationFrame(() => requestAnimationFrame(() => barra.style.setProperty('--r', String(Math.min(1, f.despues / f.antes)))));
      voz(f.nombre + ': de ' + peso(f.antes) + ' a ' + peso(f.despues) + (f.liviana ? ', ya era liviana' : ', ' + ahorro(f.antes, f.despues) + ' % menos') + '.');
    }
    // las ranuras vacías: siempre se ven las cuatro plazas, así que nada se mueve al agregar una foto
    function ranuras() {
      el.fotos.querySelectorAll('.es-vacia').forEach(n => n.remove());
      for (let i = fotos.length; i < o.maxFotos; i++) {
        const li = document.createElement('li'); li.className = 'av-foto es-vacia'; li.setAttribute('aria-hidden', 'true');
        li.innerHTML = '<span class="av-f-mini"><svg viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="14" rx="3"/><circle cx="9" cy="10.2" r="1.6"/><path d="m4.5 17.6 4.6-4.4 3.2 3 2.6-2.4 4.6 4.4"/></svg></span><span class="av-f-nombre">Foto ' + (i + 1) + '</span><span class="av-f-pesos">Libre</span>';
        el.fotos.appendChild(li);
      }
    }
    function pintaCuenta() {
      ranuras();
      el.cuenta.textContent = fotos.length + ' de ' + o.maxFotos;
      const listas = fotos.filter(f => f.estado === 'lista');
      if (!listas.length || fotos.some(f => f.estado === 'achicando')) { el.total.innerHTML = ''; return; }
      const a = listas.reduce((s, f) => s + f.antes, 0), d = listas.reduce((s, f) => s + f.despues, 0);
      el.total.innerHTML = 'Subirás <b></b> en vez de <s></s>' + (d < a ? ': ahorras <em></em>.' : '.');
      el.total.querySelector('b').textContent = peso(d); el.total.querySelector('s').textContent = peso(a);
      if (d < a) el.total.querySelector('em').textContent = ahorro(a, d) + ' %';
    }
    function aviso(t) { const li = document.createElement('li'); li.textContent = t; el.avisos.appendChild(li); voz(t); }
    function quita(id) {
      const f = fotos.find(x => x.id === id); if (!f) return;
      fotos = fotos.filter(x => x !== f);
      if (f.url) URL.revokeObjectURL(f.url);
      const li = tarjeta(id);
      if (li) { if (quieto()) li.remove(); else { li.classList.add('es-sale'); setTimeout(() => li.remove(), 340); } }
      pintaCuenta(); voz('Se quitó ' + f.nombre + '.');
    }

    /* agrega: valida cada archivo por dentro, crea las tarjetas y achica de a una (la memoria de un teléfono lo agradece) */
    function agrega(lista) {
      const archivos = [...lista];
      const trabajo = cola.then(async () => {
        el.avisos.innerHTML = '';
        const validos = [];
        for (const a of archivos) {
          if (fotos.length + validos.length >= o.maxFotos) { aviso('Ya hay ' + o.maxFotos + ' fotos: quita una para agregar otra.'); break; }
          if (fotos.concat(validos).some(f => f.nombre === a.name && f.antes === a.size)) { aviso('«' + a.name + '» ya está en la lista.'); continue; }
          const tipo = await tipoDe(a);
          if (!['jpeg', 'png', 'webp'].includes(tipo)) { aviso('«' + a.name + '» ' + (MOTIVO[tipo] || MOTIVO.otro)); continue; }
          if (a.size > o.maxOriginal) { aviso('«' + a.name + '» pesa ' + peso(a.size) + ': el máximo es ' + peso(o.maxOriginal) + '.'); continue; }
          validos.push({ id: ++contador, nombre: a.name, antes: a.size, estado: 'achicando', archivo: a });
        }
        validos.forEach(f => { fotos.push(f); creaTarjeta(f); });
        pintaCuenta();
        for (const f of validos) {
          if (!fotos.includes(f)) continue;                // la quitaron mientras esperaba
          try {
            const r = await achica(f.archivo, o.lado, o.calidad);
            if (!fotos.includes(f)) continue;
            Object.assign(f, { blob: r.blob, despues: r.blob.size, ancho: r.ancho, alto: r.alto, anchoOrig: r.anchoOrig, altoOrig: r.altoOrig, calidad: r.calidad, liviana: r.liviana, url: URL.createObjectURL(r.blob), estado: 'lista' });
            terminaTarjeta(f);
          } catch (e) {
            fotos = fotos.filter(x => x !== f); const li = tarjeta(f.id); if (li) li.remove();
            aviso('«' + f.nombre + '» no se pudo abrir: la imagen está dañada.');
          }
          pintaCuenta();
        }
      });
      cola = trabajo.catch(() => {});
      return trabajo;
    }
    el.elegir.addEventListener('click', () => el.archivo.click());
    el.archivo.addEventListener('change', () => { const l = [...el.archivo.files]; el.archivo.value = ''; if (l.length) agrega(l); });
    el.ejemplo.addEventListener('click', async () => { ejemplos = ejemplos || Promise.all([creaEjemplo(0), creaEjemplo(1)]); agrega(await ejemplos); });
    setTimeout(() => { ejemplos = ejemplos || Promise.all([creaEjemplo(0), creaEjemplo(1)]); }, 80);    // se dibujan de antemano, con calma

    // arrastrar y soltar: sobre la zona se marca; fuera de ella no se deja que el navegador abra la foto
    ['dragenter', 'dragover'].forEach(n => raiz.addEventListener(n, e => { e.preventDefault(); el.zona.toggleAttribute('data-arrastra', !!e.target.closest('[data-zona]')); }));
    raiz.addEventListener('dragleave', e => { if (!e.relatedTarget || !el.zona.contains(e.relatedTarget)) el.zona.removeAttribute('data-arrastra'); });
    raiz.addEventListener('drop', e => { e.preventDefault(); el.zona.removeAttribute('data-arrastra'); if (e.dataTransfer && e.dataTransfer.files.length) agrega(e.dataTransfer.files); });

    /* — enviar — */
    function valida() {
      const e = {}, eq = equipoActual();
      eq.preguntas.forEach((q, i) => { if (i === 0 && !respuestas[q.id]) e['q-' + q.id] = 'Elige qué le pasa al equipo.'; });
      const n = el.texto.value.trim().length;
      if (n < 10) e.texto = n ? 'Cuéntalo con un poco más de detalle: faltan ' + (10 - n) + ' caracteres.' : 'Cuéntanos qué pasa, con tus palabras.';
      if (!franja) e.franja = 'Elige una franja para la visita.';
      return e;
    }
    el.form.addEventListener('submit', ev => { ev.preventDefault(); envia(); });
    async function envia() {
      if (enviando) return;
      const e = valida();
      ['texto', 'franja'].concat(equipoActual().preguntas.map(q => 'q-' + q.id)).forEach(k => err(k, e[k] || ''));
      err('envio', '');
      const primero = Object.keys(e)[0];
      if (primero) {
        err('envio', 'Falta completar ' + (Object.keys(e).length === 1 ? 'un dato' : Object.keys(e).length + ' datos') + ' para pedir la visita.');
        voz('Faltan datos: ' + Object.values(e).join(' '));
        const f = primero === 'texto' ? el.texto : primero === 'franja' ? el.franjas.querySelector('input:not(:disabled)') : raiz.querySelector('[data-pregunta="' + primero.slice(2) + '"] input');
        if (f) f.focus();
        return;
      }
      enviando = true; el.enviar.classList.add('es-enviando'); el.enviarT.textContent = fotos.some(f => f.estado === 'achicando') ? 'Achicando fotos…' : 'Pidiendo la visita…';
      await cola;                                          // si hay fotos achicándose, se espera a que terminen
      const fin = () => {
        const d = DIAS.find(x => String(x.num) === franja.slice(0, -1)), fr = FRANJAS.find(x => x.id === franja.slice(-1));
        ocupadas[franja] = (ocupadas[franja] || 0) + 1;
        const orden = ocupadas[franja], nro = folio(d.num, d.mes, fr.id, orden), eq = equipoActual();
        const listas = fotos.filter(f => f.estado === 'lista');
        ultimo = { folio: nro, equipo: eq.nombre, respuestas: eq.preguntas.map(q => ({ pregunta: q.etq, respuesta: respuestas[q.id] || null })), texto: el.texto.value.trim(), franja, dia: d.largo, horas: fr.horas, orden,
          fotos: listas.map(f => ({ nombre: f.nombre, antes: f.antes, despues: f.despues, blob: f.blob })) };
        muestraListo(ultimo, d, fr, orden);
        enviando = false; el.enviar.classList.remove('es-enviando'); el.enviarT.textContent = 'Pedir visita';
        if (o.alEnviar) o.alEnviar(ultimo);
      };
      if (quieto()) fin(); else setTimeout(fin, 700);
    }
    function muestraListo(r, d, fr, orden) {
      const partes = r.folio.match(/^(AV)-(\d{4})-([MT])(\d{2})$/);
      el.folio.innerHTML = '<span>' + partes[1] + '</span><span class="f-sep">-</span><span class="f-dia">' + partes[2] + '</span><span class="f-sep">-</span><span class="f-franja">' + partes[3] + partes[4] + '</span>';
      el.folioNota.innerHTML = 'Dice cuándo vas: <b>' + d.corto + '</b>, franja de la <i>' + fr.nombre.toLowerCase() + '</i> y el lugar <b>n.º ' + orden + '</b> de esa franja.';
      const k = n => raiz.querySelector('[data-r="' + n + '"]');
      k('equipo').textContent = r.equipo;
      k('respuestas').textContent = r.respuestas.filter(x => x.respuesta).map((x, i) => i === 0 ? x.respuesta : x.pregunta.replace(/^¿|\?$/g, '').replace(/^./, c => c.toLowerCase()) + ': ' + x.respuesta.toLowerCase()).join(' · ');
      k('texto').textContent = r.texto;
      k('franja').textContent = d.largo.replace(/^./, c => c.toUpperCase()) + ' · ' + fr.nombre.toLowerCase() + ' (' + fr.horas + ')';
      const lista = $('[data-r-fotos]'); lista.innerHTML = '';
      fotos.filter(f => f.estado === 'lista').forEach(f => {
        const li = document.createElement('li');
        li.innerHTML = '<i></i><span></span><b><s></s></b>';
        li.querySelector('i').style.backgroundImage = 'url("' + f.url + '")';
        li.querySelector('span').textContent = f.nombre;
        li.querySelector('s').textContent = peso(f.antes);
        li.querySelector('b').appendChild(document.createTextNode(peso(f.despues)));
        lista.appendChild(li);
      });
      const tot = $('[data-r-total]'), l = fotos.filter(f => f.estado === 'lista');
      if (l.length) { const a = l.reduce((s, f) => s + f.antes, 0), dd = l.reduce((s, f) => s + f.despues, 0); tot.innerHTML = 'Subieron <b></b> en vez de <s></s>' + (dd < a ? ' (' + ahorro(a, dd) + ' % menos).' : '.'); tot.querySelector('b').textContent = peso(dd); tot.querySelector('s').textContent = peso(a); }
      else tot.innerHTML = '';
      raiz.dataset.fase = 'listo'; el.listo.setAttribute('aria-hidden', 'false'); el.form.setAttribute('aria-hidden', 'true');
      voz('Visita pedida. Tu folio es ' + r.folio + ': ' + d.largo + ', franja de la ' + fr.nombre.toLowerCase() + '.');
      setTimeout(() => el.tituloListo.focus({ preventScroll: true }), 60);
    }
    el.copiar.addEventListener('click', async () => {
      const t = ultimo ? ultimo.folio : '';
      let ok = false;
      try { await navigator.clipboard.writeText(t); ok = true; } catch (e) { try { const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;left:-9999px'; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); } catch (e2) { ok = false; } }
      el.copiarT.textContent = ok ? 'Copiado ✓' : 'Copia el folio a mano';
      setTimeout(() => { el.copiarT.textContent = 'Copiar folio'; }, 1800);
    });

    function reinicia() {
      fotos.forEach(f => f.url && URL.revokeObjectURL(f.url)); fotos = []; el.fotos.innerHTML = ''; el.avisos.innerHTML = '';
      el.texto.value = ''; el.cuentaTexto.textContent = '0'; franja = null; ultimo = null;
      eligeEquipo(o.equipo, false);
      pintaFranjas(); pintaCuenta();
      ['texto', 'franja', 'envio', 'equipo'].forEach(k => err(k, ''));
      raiz.dataset.fase = 'form'; el.listo.setAttribute('aria-hidden', 'true'); el.form.removeAttribute('aria-hidden');
    }
    el.nueva.addEventListener('click', () => { reinicia(); voz('Nueva solicitud.'); setTimeout(() => el.titulo.focus({ preventScroll: true }), 60); });

    reinicia();
    return {
      agrega, reinicia,
      fotos: () => fotos.map(f => ({ nombre: f.nombre, antes: f.antes, despues: f.despues, ancho: f.ancho, alto: f.alto, anchoOrig: f.anchoOrig, altoOrig: f.altoOrig, calidad: f.calidad, liviana: f.liviana, estado: f.estado, blob: f.blob })),
      estado: () => ({ equipo, respuestas: Object.assign({}, respuestas), franja, ocupadas: Object.assign({}, ocupadas), fase: raiz.dataset.fase, ultimo }),
      espera: () => cola,
      ejemplos: () => { ejemplos = ejemplos || Promise.all([creaEjemplo(0), creaEjemplo(1)]); return ejemplos; },
    };
  }

  Averia.folio = folio;
  Averia.peso = peso;
  Averia.tipoDe = tipoDe;
  Averia.EQUIPOS = EQUIPOS;
  window.Averia = Averia;

  const raiz = document.querySelector('[data-averia]');
  if (raiz) Averia.actual = Averia(raiz);
})();
