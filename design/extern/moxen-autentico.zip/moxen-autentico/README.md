# Auténtico · Moxen

Cada comprobante lleva un código de verificación que sale de sus datos con la clave del negocio (HMAC-SHA-256, calculado con SubtleCrypto). Cambia cualquier dato —la cuota, el estado, un solo dígito— y el código recalculado deja de coincidir en todos sus grupos y el sello pasa de «VÁLIDO» a «ALTERADO». Copia el texto de un comprobante, o pega el de otra persona, y se verifica en el acto.

## Qué trae

- `index.html` — la demostración
- `autentico.css`
- `autentico.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `autentico.css` y `autentico.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Each receipt carries a verification code derived from its data with the business's key (HMAC-SHA-256, computed with SubtleCrypto). Change any detail — the installment, the status, a single digit — and the recalculated code stops matching in every group, and the stamp flips from «VÁLIDO» to «ALTERADO». Copy a receipt as text, or paste someone else's, and it is checked on the spot.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
