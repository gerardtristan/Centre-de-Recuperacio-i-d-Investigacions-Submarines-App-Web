/* =====================================================================
   Probador · Moxen
   Una galería de plantillas cuya vista previa se abre en marcos de dispositivo,
   para probarlas antes de elegir.

   · La rejilla enseña cada plantilla como una MINIATURA VIVA: la página de verdad,
     dibujada a 1200 px y reducida. Pasar por una la inclina con suavidad (resortes,
     perspectiva y un brillo que sigue al puntero).
   · Al pulsarla, la miniatura se EXPANDE con FLIP hasta un marco de escritorio: el
     marco crece desde el rectángulo de la miniatura (escala y recorte con resorte) y
     el resto de la interfaz entra detrás.
   · Tres botones (escritorio, tableta, móvil) estrechan el marco con un resorte y,
     como la plantilla se mide con el ancho de su propio marco (container queries), el
     contenido se RECOMPONE DE VERDAD mientras se estrecha: cambian las columnas, el
     menú se pliega, la barra lateral se baja.
   · El deslizador de ACENTO cambia el matiz de todas las superficies de color al instante.
   · «Usar esta plantilla» se convierte en una ✓ que se dibuja; las FLECHAS (o ← →) pasan
     a la siguiente plantilla con un cruce y el marco se queda en el dispositivo que
     estabas probando. Esc o «Galería» vuelve y el marco se encoge hasta su miniatura.

   Cómo se monta (ver index.html):
     const p = Probador(document.querySelector('[data-probador]'), {
       plantillas: [{ id, nombre, desc, html }, …],   // opcional: las tuyas (html = página con clases .pg-…)
       acento: 252,                                    // matiz inicial (205–405; sin verdes, pasado 360 cuenta desde 0)
       alElegir: ({ id, nombre, acento }) => { … },
     });
     p.abre(1);  p.cierra();  p.dispositivo('movil');

   Qué se personaliza:
   · Las plantillas están al final de este archivo (PLANTILLAS) y sus estilos, en probador.css (bloques .pg-…);
     usan --ac y sus tintes (que salen del matiz --h), así que cambiar el acento las recolorea.
   · DISPOSITIVOS fija el ancho de cada marco; MUELLE reúne los resortes (marco, inclinación, cruce).
   · Solo se anima transform, opacity y clip-path (y el ancho del marco al cambiar de dispositivo). Sin
     dependencias, sin Date ni azar: la página y el vídeo coinciden.
   ===================================================================== */
(function () {
  'use strict';

  const reduceMQ = matchMedia('(prefers-reduced-motion: reduce)');
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));

  // un resorte: x es el valor, meta a dónde va, k la rigidez y c la amortiguación
  const resorte = (x, par) => ({ x, v: 0, meta: x, k: par[0], c: par[1] });
  function avanza(r, h) { for (let i = 0; i < 2; i++) { r.v += (r.k * (r.meta - r.x) - r.c * r.v) * h / 2; r.x += r.v * h / 2; } }
  const reposo = (r, e) => Math.abs(r.v) < (e || .02) * 2 && Math.abs(r.meta - r.x) < (e || .02);
  const MUELLE = {
    marco: [190, 24],        // el ancho del marco al cambiar de dispositivo
    inclina: [180, 17],      // la inclinación de una miniatura
    expande: [150, 17],      // la miniatura que crece hasta el marco
    cruce: [230, 20]         // el paso a otra plantilla
  };
  // El acento recorre solo los matices sin verde: del ámbar (405° = 45°) al azul (205°), pasando por el rojo, el
  // magenta y el violeta. El deslizador va de 0 a 360 como posición; matizDe y posDe lo traducen a matiz y de vuelta.
  const ARCO = [405, 205];
  const enArco = h => {
    const g = ((h % 360) + 360) % 360;
    return g >= ARCO[1] ? g : g <= ARCO[0] - 360 ? g + 360 : g < (ARCO[0] - 360 + ARCO[1]) / 2 ? ARCO[0] : ARCO[1];
  };
  const matizDe = p => ARCO[0] - p * (ARCO[0] - ARCO[1]) / 360;
  const posDe = h => (ARCO[0] - enArco(h)) * 360 / (ARCO[0] - ARCO[1]);
  // los matices vecinos (avatares e imágenes de las plantillas) se desvían del verde (75°–195°): si h + o cae ahí, van al otro lado
  const esVerde = g => { g = ((g % 360) + 360) % 360; return g >= 75 && g <= 195; };
  const vecino = (h, o) => esVerde(h + o) ? h - 2 * o : h + o;
  function ponMatiz(el, h) {
    el.style.setProperty('--h', h);
    el.style.setProperty('--h-a', vecino(h, 50));
    el.style.setProperty('--h-b', vecino(h, -50));
    el.style.setProperty('--h-c', vecino(h, 46));
    el.style.setProperty('--h-d', vecino(h, -40));
  }
  const DISPOSITIVOS = { escritorio: 1200, tableta: 768, movil: 390 };
  const ALTO = 640;          // alto de pantalla de diseño (todas las plantillas se miden a 1200 × 640 en su miniatura)
  const ESCALA_MAX = .86, INCLINA_MAX = 5.5;

  // un resorte convertido en curva CSS linear(), para animar con la API de animaciones
  function muelleCss(k, c) {
    const ok = window.CSS && CSS.supports && CSS.supports('animation-timing-function', 'linear(0, 1)');
    let x = 0, v = 0, t = 0, fin = 1;
    const pts = [0];
    while (t < 2.5) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240; pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .002 && Math.abs(v) < .02) { fin = t; break; }
    }
    if (!ok) return { easing: 'cubic-bezier(.34, 1.3, .64, 1)', ms: 760 };
    const out = [];
    for (let i = 0; i <= 44; i++) out.push(pts[Math.round(i / 44 * (pts.length - 1))].toFixed(4));
    out[44] = '1';
    return { easing: 'linear(' + out.join(', ') + ')', ms: Math.round(fin * 1000) };
  }

  /* =====================================================================
     La galería
     ===================================================================== */
  function Probador(raiz, opciones) {
    const op = Object.assign({ plantillas: null, acento: 252, alElegir: null }, opciones || {});
    const lista = op.plantillas || PLANTILLAS;
    const q = s => raiz.querySelector(s);
    const rejilla = q('[data-rejilla]'), capa = q('[data-capa]'), escenario = q('[data-escenario]'), vivo = q('[data-vivo]');
    const bVolver = q('[data-volver]'), bAnt = q('[data-ant]'), bSig = q('[data-sig]');
    const vNombre = q('[data-v-nombre]'), vCuenta = q('[data-v-cuenta]');
    const grupoDisp = q('[data-disp]'), pastilla = q('[data-pastilla]'), botonesDisp = Array.from(grupoDisp.querySelectorAll('[data-d]'));
    const rango = q('[data-acento]'), punto = q('[data-punto]'), bUsar = q('[data-usar]'), usarTxt = q('[data-usar-txt]');
    const anuncia = t => { vivo.textContent = ''; setTimeout(() => { vivo.textContent = t; }, 30); };

    op.acento = enArco(op.acento);
    let abierta = -1, disp = 'escritorio', hue = op.acento, marco = null, visor = null, lienzoF = null, cuerpo = null, sombra = null;
    let pantallaActual = null, anim = null, ocupado = false, tUsar = 0, ultimoFoco = null;
    const wR = resorte(DISPOSITIVOS.escritorio, MUELLE.marco);
    let raf = 0, ultimo = 0, S = ESCALA_MAX;

    ponMatiz(raiz, op.acento);

    /* ── la rejilla de miniaturas ───────────────────────────────── */
    const tarjetas = lista.map((p, i) => {
      const art = document.createElement('article');
      art.className = 'pr-tarjeta'; art.setAttribute('role', 'listitem'); art.style.setProperty('--i', i);
      art.innerHTML =
        '<button class="pr-abre" type="button"><span class="pr-inclina">' +
          '<span class="pr-miniatura" aria-hidden="true"><span class="pr-lienzo"><span class="pr-pantalla">' + p.html + '</span></span><i class="pr-brillo"></i><span class="pr-probar"><svg viewBox="0 0 20 20"><path d="M7 5.5 13 10l-6 4.5z"/></svg>Probar</span></span>' +
          '<span class="pr-pie"><b class="pr-nombre"></b><span class="pr-desc"></span></span>' +
        '</span></button>';
      art.querySelector('.pr-nombre').textContent = p.nombre;
      art.querySelector('.pr-desc').textContent = p.desc;
      art.querySelector('.pr-abre').setAttribute('aria-label', 'Probar la plantilla ' + p.nombre);
      rejilla.appendChild(art);
      const t = {
        art, btn: art.querySelector('.pr-abre'), inclina: art.querySelector('.pr-inclina'), mini: art.querySelector('.pr-miniatura'), brillo: art.querySelector('.pr-brillo'),
        rx: resorte(0, MUELLE.inclina), ry: resorte(0, MUELLE.inclina), lev: resorte(0, MUELLE.inclina), bx: 50, by: 50, sobre: false, tr: ''
      };
      t.btn.addEventListener('click', () => abre(i));
      t.btn.addEventListener('pointermove', e => {
        if (e.pointerType !== 'mouse' || reduceMQ.matches) return;
        const r = t.mini.getBoundingClientRect();
        const nx = lim((e.clientX - r.left) / r.width - .5, -.6, .6) * 2, ny = lim((e.clientY - r.top) / r.height - .5, -.6, .6) * 2;
        t.ry.meta = nx * INCLINA_MAX; t.rx.meta = -ny * INCLINA_MAX; t.lev.meta = 1; t.bx = 50 + nx * 38; t.by = 50 + ny * 38; t.sobre = true; arranca();
      });
      const sale = () => { t.rx.meta = 0; t.ry.meta = 0; t.lev.meta = 0; t.sobre = false; arranca(); };
      t.btn.addEventListener('pointerleave', sale);
      t.btn.addEventListener('blur', sale);
      t.btn.addEventListener('focus', () => { if (!reduceMQ.matches && t.btn.matches(':focus-visible')) { t.lev.meta = .6; arranca(); } });
      return t;
    });

    // las miniaturas se miden a 1200 px y se reducen al ancho de su caja
    function mideRejilla() {
      const w = tarjetas[0] ? tarjetas[0].mini.clientWidth : 460;
      rejilla.style.setProperty('--k', (w / 1200).toFixed(5));
    }
    if (window.ResizeObserver) new ResizeObserver(mideRejilla).observe(rejilla); else addEventListener('resize', mideRejilla);
    mideRejilla();

    function tick(ts) {
      raf = 0;
      const dt = lim((ts - (ultimo || ts)) / 1000, 0, .05); ultimo = ts;
      let sigue = false;
      tarjetas.forEach(t => {
        avanza(t.rx, dt); avanza(t.ry, dt); avanza(t.lev, dt);
        if (!reposo(t.rx, .01) || !reposo(t.ry, .01) || !reposo(t.lev, .002)) sigue = true;
        const tr = 'perspective(900px) translate3d(0,' + (-t.lev.x * 6).toFixed(2) + 'px,0) rotateX(' + t.rx.x.toFixed(2) + 'deg) rotateY(' + t.ry.x.toFixed(2) + 'deg) scale(' + (1 + t.lev.x * .012).toFixed(4) + ')';
        if (tr !== t.tr) { t.inclina.style.transform = tr; t.tr = tr; }
        t.brillo.style.setProperty('--bx', t.bx.toFixed(1) + '%'); t.brillo.style.setProperty('--by', t.by.toFixed(1) + '%');
        t.art.style.setProperty('--lev', lim(t.lev.x, 0, 1).toFixed(3));
      });
      // el marco: su ancho es un resorte y la escala se ajusta para que quepa
      if (marco) {
        avanza(wR, dt); if (reduceMQ.matches) { wR.x = wR.meta; wR.v = 0; }
        if (!reposo(wR, .1)) sigue = true;
        ajustaMarco();
      }
      if (sigue) raf = requestAnimationFrame(tick); else { ultimo = 0; if (marco) { wR.x = wR.meta; ajustaMarco(); } }
    }
    const arranca = () => { if (!raf) raf = requestAnimationFrame(tick); };

    /* ── el marco y su escala ────────────────────────────────────── */
    function escalaPara(w) {
      const ew = escenario.clientWidth, eh = escenario.clientHeight;
      const chrome = disp === 'escritorio' ? 40 : 0, bisel = disp === 'escritorio' ? 0 : 26;
      return lim(Math.min(ESCALA_MAX, (ew - 36 - bisel) / w, (eh - 28 - chrome - bisel) / ALTO), .2, ESCALA_MAX);
    }
    function ajustaMarco() {
      const w = wR.x;
      S = escalaPara(w);
      visor.style.width = (w * S).toFixed(2) + 'px'; visor.style.height = (ALTO * S).toFixed(2) + 'px';
      lienzoF.style.width = w.toFixed(2) + 'px'; lienzoF.style.height = ALTO + 'px';
      lienzoF.style.transform = 'scale(' + S.toFixed(5) + ')';
    }

    function creaPantalla(i) {
      const s = document.createElement('div');
      s.className = 'pr-pantalla'; s.setAttribute('role', 'document'); s.setAttribute('aria-label', 'Plantilla ' + lista[i].nombre);
      s.innerHTML = lista[i].html;
      return s;
    }
    function montaMarco(i) {
      marco = document.createElement('div');
      marco.className = 'pr-marco'; marco.dataset.disp = disp;
      ponMatiz(marco, hue);
      marco.innerHTML = '<i class="pr-sombra"></i><div class="pr-cuerpo"><div class="pr-chrome" aria-hidden="true"><i></i><i></i><i></i><span class="pr-url"></span></div><div class="pr-visor"><div class="pr-lienzo-f"></div></div><i class="pr-muesca" aria-hidden="true"></i></div>';
      escenario.replaceChildren(marco);
      visor = marco.querySelector('.pr-visor'); lienzoF = marco.querySelector('.pr-lienzo-f'); cuerpo = marco.querySelector('.pr-cuerpo'); sombra = marco.querySelector('.pr-sombra');
      pantallaActual = creaPantalla(i); lienzoF.appendChild(pantallaActual);
      wR.x = wR.meta = DISPOSITIVOS[disp]; wR.v = 0;
      ajustaMarco();
    }

    /* ── abrir: la miniatura se expande hasta el marco ───────────── */
    function abre(i) {
      if (abierta >= 0 || ocupado) return;
      abierta = i; disp = 'escritorio'; hue = op.acento; ocupado = true;
      ultimoFoco = tarjetas[i].btn;
      ponAcento(hue, true);
      capa.hidden = false;
      pintaDisp(true);                               // con la capa visible, para medir los botones
      capa.classList.remove('is-abierta');
      montaMarco(i);
      titulos();
      void capa.offsetWidth; capa.classList.add('is-abierta');
      // FLIP: el marco, a su sitio final, se lleva a la miniatura y se suelta
      const src = tarjetas[i].mini.getBoundingClientRect(), F = visor.getBoundingClientRect(), M = marco.getBoundingClientRect();
      tarjetas[i].art.classList.add('is-oculta');
      if (reduceMQ.matches) { ocupado = false; bVolver.focus({ preventScroll: true }); return; }
      const k = src.width / F.width, dx = src.left - F.left, dy = src.top - F.top;
      marco.style.transformOrigin = (F.left - M.left).toFixed(1) + 'px ' + (F.top - M.top).toFixed(1) + 'px';
      const cur = muelleCss(MUELLE.expande[0], MUELLE.expande[1]);
      const ch = F.top - M.top, r0 = 16 / k;
      const a1 = marco.animate([{ transform: 'translate(' + dx.toFixed(1) + 'px,' + dy.toFixed(1) + 'px) scale(' + k.toFixed(5) + ')' }, { transform: 'none' }], { duration: cur.ms, easing: cur.easing });
      cuerpo.animate([{ clipPath: 'inset(' + ch.toFixed(1) + 'px 0px 0px 0px round ' + r0.toFixed(1) + 'px)' }, { clipPath: 'inset(0px 0px 0px 0px round 20px)' }], { duration: 640, easing: 'cubic-bezier(.22, 1, .36, 1)' });
      sombra.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 520, delay: 140, easing: 'ease-out', fill: 'backwards' });
      cuerpo.querySelector('.pr-chrome').animate([{ opacity: 0 }, { opacity: 1 }], { duration: 360, delay: 240, easing: 'ease-out', fill: 'backwards' });
      a1.onfinish = () => { ocupado = false; };
      setTimeout(() => { ocupado = false; }, cur.ms + 60);
      bVolver.focus({ preventScroll: true });
      anuncia('Vista previa de ' + lista[i].nombre);
    }

    /* ── cerrar: el marco se encoge hasta su miniatura ───────────── */
    function cierra() {
      if (abierta < 0 || ocupado) return;
      ocupado = true;
      clearTimeout(tUsar); restauraUsar();
      const i = abierta, t = tarjetas[i];
      const fin = () => {
        capa.classList.remove('is-abierta'); capa.hidden = true; escenario.replaceChildren();
        marco = null; visor = null; lienzoF = null; abierta = -1; ocupado = false;
        tarjetas.forEach(x => x.art.classList.remove('is-oculta'));
        if (ultimoFoco) ultimoFoco.focus({ preventScroll: true });
      };
      capa.classList.remove('is-abierta');
      if (reduceMQ.matches || !marco) { fin(); return; }
      const src = t.mini.getBoundingClientRect(), F = visor.getBoundingClientRect(), M = marco.getBoundingClientRect();
      // cualquiera que sea el dispositivo, el marco se mete dentro de la miniatura sin deformarse
      const k = Math.min(src.width / F.width, src.height / F.height);
      const dx = src.left + src.width / 2 - (F.left + F.width / 2), dy = src.top + src.height / 2 - (F.top + F.height / 2);
      marco.style.transformOrigin = (F.left + F.width / 2 - M.left).toFixed(1) + 'px ' + (F.top + F.height / 2 - M.top).toFixed(1) + 'px';
      const cur = muelleCss(230, 26);
      t.art.classList.remove('is-oculta');
      marco.animate([{ transform: 'none', opacity: 1 }, { transform: 'translate(' + dx.toFixed(1) + 'px,' + dy.toFixed(1) + 'px) scale(' + k.toFixed(5) + ')', opacity: 1, offset: .72 }, { transform: 'translate(' + dx.toFixed(1) + 'px,' + dy.toFixed(1) + 'px) scale(' + k.toFixed(5) + ')', opacity: 0 }],
        { duration: Math.max(cur.ms, 560), easing: cur.easing, fill: 'forwards' });
      setTimeout(fin, Math.max(cur.ms, 560) - 40);
    }

    /* ── dispositivos ────────────────────────────────────────────── */
    function pintaDisp(directo) {
      botonesDisp.forEach(b => b.setAttribute('aria-checked', b.dataset.d === disp ? 'true' : 'false'));
      const act = botonesDisp.find(b => b.dataset.d === disp);
      const l = act.offsetLeft, w = act.offsetWidth;
      if (directo) pastilla.style.transition = 'none';
      pastilla.style.transform = 'translateX(' + l + 'px)'; pastilla.style.width = w + 'px';
      if (directo) { void pastilla.offsetWidth; pastilla.style.transition = ''; }
    }
    function ponDisp(d) {
      if (!marco || d === disp || !DISPOSITIVOS[d]) return;
      disp = d; marco.dataset.disp = d;
      wR.meta = DISPOSITIVOS[d];
      pintaDisp(false);
      arranca();
      anuncia('Marco de ' + (d === 'movil' ? 'móvil' : d));
    }
    botonesDisp.forEach(b => b.addEventListener('click', () => ponDisp(b.dataset.d)));

    /* ── acento y botón de uso ───────────────────────────────────── */
    function ponAcento(h, sinMarco) {
      hue = enArco(h); rango.value = posDe(hue);
      punto.style.background = 'hsl(' + hue + ' 100% 62%)';
      ponMatiz(capa, hue);                               // el botón de uso y los controles de la vista previa
      if (marco) ponMatiz(marco, hue);
    }
    rango.addEventListener('input', () => ponAcento(matizDe(+rango.value)));
    bUsar.addEventListener('click', () => {
      if (abierta < 0 || bUsar.classList.contains('is-ok')) return;
      bUsar.classList.add('is-ok'); usarTxt.textContent = 'Plantilla añadida';
      anuncia('Plantilla ' + lista[abierta].nombre + ' añadida');
      if (op.alElegir) op.alElegir({ id: lista[abierta].id, nombre: lista[abierta].nombre, acento: Math.round(hue % 360) });
      clearTimeout(tUsar);
      tUsar = setTimeout(restauraUsar, 2000);
    });
    function restauraUsar() { bUsar.classList.remove('is-ok'); usarTxt.textContent = 'Usar esta plantilla'; }

    /* ── pasar a otra plantilla con un cruce ─────────────────────── */
    function titulos() {
      vNombre.textContent = lista[abierta].nombre;
      vCuenta.textContent = (abierta + 1) + ' / ' + lista.length;
    }
    function ir(d) {
      if (abierta < 0 || ocupado || !marco) return;
      const nuevo = (abierta + d + lista.length) % lista.length;
      if (nuevo === abierta) return;
      abierta = nuevo; titulos(); restauraUsar(); clearTimeout(tUsar);
      hue = op.acento; ponAcento(hue);
      ultimoFoco = tarjetas[nuevo].btn;
      tarjetas.forEach((x, j) => x.art.classList.toggle('is-oculta', j === nuevo));
      const vieja = pantallaActual, nueva = creaPantalla(nuevo);
      lienzoF.appendChild(nueva); pantallaActual = nueva;
      if (reduceMQ.matches) { vieja.remove(); return; }
      ocupado = true;
      const cur = muelleCss(MUELLE.cruce[0], MUELLE.cruce[1]), dist = 70 * d;
      vieja.style.pointerEvents = 'none';
      vieja.animate([{ transform: 'translateX(0)', opacity: 1 }, { transform: 'translateX(' + (-dist) + 'px)', opacity: 0 }], { duration: 380, easing: 'cubic-bezier(.4, 0, .6, 1)', fill: 'forwards' }).onfinish = () => vieja.remove();
      nueva.animate([{ transform: 'translateX(' + dist + 'px) scale(.985)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: cur.ms, easing: cur.easing });
      nueva.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 280, easing: 'ease-out' });
      setTimeout(() => { ocupado = false; if (vieja.isConnected) vieja.remove(); }, 400);
      anuncia('Plantilla ' + lista[nuevo].nombre + ', ' + (nuevo + 1) + ' de ' + lista.length);
    }
    bAnt.addEventListener('click', () => ir(-1));
    bSig.addEventListener('click', () => ir(1));
    bVolver.addEventListener('click', cierra);

    /* ── teclado ─────────────────────────────────────────────────── */
    capa.addEventListener('keydown', e => {
      if (e.key === 'Escape') { e.preventDefault(); cierra(); return; }
      const enRango = e.target === rango;
      if (!enRango && e.key === 'ArrowLeft') { e.preventDefault(); ir(-1); }
      else if (!enRango && e.key === 'ArrowRight') { e.preventDefault(); ir(1); }
      else if (!enRango && e.key === '1') ponDisp('escritorio');
      else if (!enRango && e.key === '2') ponDisp('tableta');
      else if (!enRango && e.key === '3') ponDisp('movil');
      else if (e.key === 'Tab') {
        // el foco se queda dentro de la vista previa
        const fs = Array.from(capa.querySelectorAll('button, input')).filter(x => !x.disabled && x.offsetParent !== null);
        if (!fs.length) return;
        const a = document.activeElement, i = fs.indexOf(a);
        if (e.shiftKey && i <= 0) { e.preventDefault(); fs[fs.length - 1].focus(); }
        else if (!e.shiftKey && i === fs.length - 1) { e.preventDefault(); fs[0].focus(); }
      }
    });
    addEventListener('resize', () => { if (marco) { arranca(); } });

    return {
      abre, cierra,
      dispositivo: ponDisp,
      siguiente: () => ir(1),
      estado: () => ({ abierta, dispositivo: disp, acento: Math.round(hue % 360) })
    };
  }

  /* =====================================================================
     Las plantillas: páginas dibujadas con bloques genéricos (sin textos ni marcas)
     ===================================================================== */
  const rep = (n, f) => Array.from({ length: n }, (_, i) => f(i)).join('');
  const t = (c) => '<i class="t' + (c ? ' ' + c : '') + '"></i>';
  const nav = extra => '<header class="pg-nav"><span class="pg-logo"></span><i class="t pg-marca"></i><nav>' + rep(4, () => '<i class="t"></i>') + '</nav><span class="pg-esp"></span>' + (extra || '<span class="pg-btn pg-btn-s"></span>') + '<span class="pg-burger"><u></u><u></u><u></u></span></header>';

  function portada() {
    return '<div class="pg pg-portada">' + nav() +
      '<section class="pg-hero"><div class="pg-hero-t"><span class="pg-etq"></span><div class="pg-titular">' + t('h') + t('h') + t('h w54') + '</div><div class="pg-parrafo">' + t() + t() + t('w70') + '</div>' +
        '<div class="pg-fila"><span class="pg-btn"></span><span class="pg-btn pg-btn-o"></span></div><div class="pg-sellos"><span class="pg-av"></span><span class="pg-av"></span><span class="pg-av"></span>' + t('w40') + '</div></div>' +
        '<div class="pg-ilu"><span class="pg-c1"></span><span class="pg-c2"></span><span class="pg-c3"></span>' +
          '<div class="pg-flot pg-f1"><i class="pg-dot"></i><div>' + t() + t('w60') + '</div></div>' +
          '<div class="pg-flot pg-f2">' + t('w50') + '<i class="pg-barra-v"><u style="--a:44%"></u><u style="--a:72%"></u><u style="--a:58%"></u><u style="--a:90%"></u></i></div></div></section>' +
      '<section class="pg-bloques">' + rep(3, i => '<article class="pg-card"><span class="pg-ico pg-ico' + (i + 1) + '"></span>' + t('h2') + t() + t('w70') + '</article>') + '</section>' +
      '<section class="pg-banda"><div>' + t('h w60') + t('w40') + '</div><span class="pg-btn pg-btn-c"></span></section>' +
      '<footer class="pg-pie"><span class="pg-logo"></span>' + rep(4, () => t('w' + 30)) + '</footer></div>';
  }
  function tienda() {
    const filtro = () => '<div class="pg-filtro">' + t('h2 w50') + rep(4, () => '<div class="pg-chk"><u></u>' + t() + '</div>') + '</div>';
    return '<div class="pg pg-tienda">' +
      '<header class="pg-nav"><span class="pg-logo"></span><i class="t pg-marca"></i><span class="pg-busca">' + t('w40') + '</span><span class="pg-esp"></span><span class="pg-cesta"><u></u></span><span class="pg-burger"><u></u><u></u><u></u></span></header>' +
      '<div class="pg-cuerpo"><aside class="pg-filtros">' + filtro() + filtro() + '<div class="pg-filtro">' + t('h2 w50') + '<div class="pg-rango"><u></u><u></u></div></div></aside>' +
      '<main class="pg-cat"><div class="pg-barra"><div>' + t('h2 w50') + t('w30') + '</div><span class="pg-orden"></span></div>' +
        '<div class="pg-chips">' + rep(5, i => '<span class="pg-chip' + (i === 0 ? ' on' : '') + '"></span>') + '</div>' +
        '<div class="pg-rej">' + rep(8, i => '<article class="pg-prod"><div class="pg-img i' + (i % 4 + 1) + '"><u class="pg-fav"></u></div>' + t('w86') + t('w56') + '<div class="pg-precio"><span class="pg-pill"></span><span class="pg-mas"></span></div></article>') + '</div></main></div></div>';
  }
  function panel() {
    const filas = rep(5, i => '<div class="pg-fila-t"><span class="pg-av"></span><div class="pg-celda">' + t('w' + (70 - i * 6)) + t('w40') + '</div><span class="pg-estado e' + (i % 3) + '"></span><i class="t pg-monto"></i></div>');
    return '<div class="pg pg-panel"><aside class="pg-lat"><span class="pg-logo"></span>' + rep(5, i => '<span class="pg-ic' + (i === 1 ? ' on' : '') + '"></span>') + '</aside>' +
      '<div class="pg-princ"><header class="pg-top"><div>' + t('h2 w50') + t('w30') + '</div><span class="pg-esp"></span><span class="pg-busca">' + t('w40') + '</span><span class="pg-av"></span><span class="pg-burger"><u></u><u></u><u></u></span></header>' +
      '<section class="pg-kpis">' + rep(4, i => '<article class="pg-kpi">' + t('w50') + '<b class="pg-num"></b><span class="pg-delta ' + (i === 2 ? 'baja' : '') + '"></span></article>') + '</section>' +
      '<section class="pg-graf"><article class="pg-card pg-grafico"><div class="pg-gcab">' + t('h2 w40') + '<span class="pg-pill"></span></div>' +
        '<svg viewBox="0 0 600 220" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="pg-g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" class="s1"/><stop offset="1" class="s2"/></linearGradient></defs>' +
        '<g class="pg-rejilla-g">' + rep(4, i => '<path d="M0 ' + (30 + i * 50) + 'H600"/>') + '</g>' +
        '<path class="pg-area" d="M0 160C60 150 90 100 150 112S250 170 310 120 400 50 450 74 540 40 600 28V220H0Z"/><path class="pg-linea" d="M0 160C60 150 90 100 150 112S250 170 310 120 400 50 450 74 540 40 600 28"/>' +
        '<path class="pg-linea2" d="M0 190C80 176 120 150 190 160S300 190 370 150 470 110 600 100"/><circle class="pg-pt" cx="450" cy="74" r="7"/></svg></article>' +
        '<article class="pg-card pg-dona"><div class="pg-gcab">' + t('h2 w50') + '</div><div class="pg-dona-i"><svg viewBox="0 0 120 120" aria-hidden="true"><circle class="pg-d0" cx="60" cy="60" r="44"/><circle class="pg-d1" cx="60" cy="60" r="44"/><circle class="pg-d2" cx="60" cy="60" r="44"/></svg></div>' +
        rep(3, i => '<div class="pg-leyenda"><u class="l' + i + '"></u>' + t('w' + (70 - i * 12)) + '</div>') + '</article></section>' +
      '<section class="pg-card pg-tabla"><div class="pg-gcab">' + t('h2 w30') + '<span class="pg-pill"></span></div>' + filas + '</section></div></div>';
  }
  function blog() {
    const post = i => '<article class="pg-post"><div class="pg-img i' + (i % 4 + 1) + '"></div><span class="pg-etq s"></span>' + t('h2') + t() + t('w60') + '<div class="pg-autor"><span class="pg-av"></span>' + t('w30') + '</div></article>';
    return '<div class="pg pg-blog">' + nav('<span class="pg-btn pg-btn-s pg-btn-o"></span>') +
      '<section class="pg-dest"><div class="pg-img big i1"><span class="pg-c1"></span><span class="pg-c2"></span></div><div class="pg-dest-t"><span class="pg-etq"></span><div class="pg-titular">' + t('h') + t('h') + t('h w54') + '</div><div class="pg-parrafo">' + t() + t() + t('w60') + '</div>' +
        '<div class="pg-autor"><span class="pg-av"></span>' + t('w30') + '</div></div></section>' +
      '<div class="pg-cuerpo2"><section class="pg-posts">' + rep(6, post) + '</section>' +
      '<aside class="pg-lado"><article class="pg-card"><span class="pg-av g"></span>' + t('h2 w60') + t() + t('w70') + '</article><div class="pg-temas">' + t('h2 w40') + rep(6, i => '<span class="pg-chip' + (i === 1 ? ' on' : '') + '"></span>') + '</div>' +
      '<article class="pg-card pg-suscribe">' + t('h2 w70') + t('w50') + '<span class="pg-campo"></span><span class="pg-btn pg-btn-s"></span></article></aside></div></div>';
  }

  const PLANTILLAS = [
    { id: 'portada', nombre: 'Portada', desc: 'Primera pantalla, beneficios y llamada a la acción', html: portada() },
    { id: 'tienda', nombre: 'Tienda', desc: 'Catálogo con filtros y fichas de producto', html: tienda() },
    { id: 'panel', nombre: 'Panel', desc: 'Indicadores, gráfico y tabla de actividad', html: panel() },
    { id: 'blog', nombre: 'Blog', desc: 'Entrada destacada y archivo de artículos', html: blog() }
  ];

  window.Probador = Probador;
})();
