# Duermevela · Moxen

Claro, oscuro o «Sistema»: la página sigue el tema del equipo en vivo con matchMedia, lo fija en un guion del <head> antes del primer pintado (un medidor lo comprueba cargando la página en un marco) y lo sincroniza entre pestañas con el evento storage. El cambio se revela con una cortina que sale del control, y la barra del teléfono (theme-color), los controles nativos (color-scheme) y la ilustración (<picture>) cambian con él.

## Qué trae

- `index.html` — la demostración
- `duermevela.css`
- `duermevela.js`
- `ilustraciones/`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `duermevela.css` y `duermevela.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Light, dark or «System»: the page follows the device theme live with matchMedia, sets it in a script in the <head> before the first paint (a meter checks it by loading the page in a frame) and syncs it across tabs with the storage event. The change is revealed by a curtain that grows out of the control, and the phone bar (theme-color), the native controls (color-scheme) and the illustration (<picture>) change with it.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
