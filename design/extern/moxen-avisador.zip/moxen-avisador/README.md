# Avisador · Moxen

Decides qué avisos recibes y por dónde, viendo al instante cómo llega cada uno. Tocas una casilla de la matriz y la vista previa muestra el aviso por correo, mensaje o en la app, mientras un resumen en palabras se reescribe con cada cambio; apagar un canal bloquea su columna y dice qué deja de existir (sin correo no hay resumen del día), «Solo lo importante» apaga el resto y «Restaurar» vuelve exactamente al inicio.

## Qué trae

- `index.html` — la demostración
- `avisador.css`
- `avisador.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `avisador.css` y `avisador.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

You decide which alerts you get and where, seeing instantly how each one arrives. Tap a cell in the matrix and the preview shows the alert by email, text message or in the app, while a plain-words summary rewrites itself with every change; turning off a channel locks its column and says what stops existing (no email, no daily summary), “Only what matters” switches off the rest and “Restore” goes back exactly to the start.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
