# Emisor · Moxen

Emite el documento correcto en un solo paso: eliges boleta o factura y, si es factura, el formulario se despliega y pide RUT, razón social, giro y dirección mientras la hoja de al lado se rellena sola. El RUT se da formato al escribir y se comprueba con el módulo 11 (si el dígito no cuadra, te dice cuál debería ser); las empresas se guardan en tu navegador, y la próxima vez basta con escribir su RUT, o elegirla de la lista, para que el resto se complete solo y el sello caiga sobre el documento.

## Qué trae

- `index.html` — la demostración
- `emisor.css`
- `emisor.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `emisor.css` y `emisor.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Issue the right document in one step: pick receipt or invoice and, if it is an invoice, the form unfolds and asks for the RUT (tax ID), legal name, line of business and address while the sheet beside it fills itself in. The RUT is formatted as you type and checked with modulo 11 (if the check digit does not match, it tells you which one it should be); companies are saved in your browser, so next time typing the RUT, or picking the company from the list, is enough for the rest to complete itself and the stamp to land on the document.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
