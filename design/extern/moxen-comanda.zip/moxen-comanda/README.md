# Comanda · Moxen

Una app para meseros dentro de un teléfono, con pantallas reales y navegación: el salón muestra las nueve mesas con su estado (libre, sentados, en cocina, para servir, servida), que sale siempre de lo que pasa con sus platos. Al tomar el pedido cada plato trae sus reglas —«elige 2 acompañamientos», un punto de cocción, «sin cebolla», pares que no van juntos— y el botón «Agregar al pedido» no se enciende hasta que todo vale, así que un plato incompleto nunca llega a cocina. Al enviar nace una comanda con su número, un reloj de cocina simulado pasa cada plato a «listo» según su tiempo de preparación, suena el aviso y el mesero lo marca servido; sin precios, y «Atrás» siempre conserva lo elegido.

## Qué trae

- `index.html` — la demostración
- `comanda.css`
- `comanda.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `comanda.css` y `comanda.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

A waiter app inside a phone, with real screens and navigation: the floor shows the nine tables with their state (free, seated, in the kitchen, ready to serve, served), which always comes from what is happening with their dishes. When taking the order each dish carries its rules —“choose 2 sides”, a doneness, “no onion”, pairs that don’t go together— and the “Add to order” button stays off until everything is valid, so an incomplete dish never reaches the kitchen. Sending creates a ticket with its number, a simulated kitchen clock moves each dish to “ready” according to its preparation time, the alert rings and the waiter marks it served; no prices, and “Back” always keeps what you chose.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
