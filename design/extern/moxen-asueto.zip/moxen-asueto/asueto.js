/* =====================================================================
   Asueto · Moxen
   Cerrar un día, o abrir con otro horario, y ver al instante qué citas
   quedan fuera. Como en la agenda de una consulta, un taller o una
   peluquería: eliges la fecha (feriado, inventario, salida temprano),
   agarras la asa de cierre de la línea del día y la subes; las citas que
   ya no caben se rayan y, al lado, la agenda te dice a qué hora libre
   se puede mover cada una.

   Qué es real (nada está simulado):
   · El horario de siempre es semanal (por día, de apertura a cierre en
     minutos). Una excepción por fecha lo reemplaza: o cierra el día
     entero, o fija otro horario para esa fecha. Quitar la excepción lo
     devuelve a lo de siempre.
   · Una cita «queda fuera» si no cabe ENTERA en el horario de su fecha:
     [inicio, inicio + duración] tiene que estar dentro de [abre, cierra].
     Una que termina justo a la hora de cierre cabe; la que cruza el cierre
     un minuto, no.
   · La primera hora libre: desde la apertura de la fecha de la cita, a
     pasos de `paso` minutos y día tras día (hasta `busca` días), el primer
     inicio que cabe en el horario de ese día (con sus excepciones), no
     pisa ninguna otra cita (las que están fuera siguen ocupando su sitio
     hasta moverse: así mover en cualquier orden nunca choca) y no repite
     la hora que ya se le ofreció a otra cita de la lista.
   · «Mover» pasa la cita a esa hora; si cae otro día, sale de este.
   · El mes cuenta, por día, las citas y las que están fuera de horario.

   Cómo se monta (ver index.html):
     const a = Asueto(document.querySelector('[data-asueto]'), {
       hoy: '2026-11-09', mes: '2026-11', dia: '2026-11-12',   // AAAA-MM-DD: la fecha de hoy la pones tú
       semana: [[540, 1140], …, null],      // lunes a domingo: [abre, cierra] en minutos, o null si no se atiende
       excepciones: [{ fecha, abre, cierra, motivo } | { fecha, cerrado: true, motivo }],
       citas: [{ titulo, fecha, ini, dur }],
       paso: 15, busca: 30,                 // paso de la grilla (min) y cuántos días hacia delante se busca hueco
       alAplicar: ({ fecha, cerrado, abre, cierra, motivo }) => {},   // al guardar o quitar una excepción
       alMover: ({ cita, antes, despues }) => {},
     });
     a.selecciona('2026-11-12');  a.cierra(840);  a.abre(600);  a.modo('cerrado' | 'especial' | 'normal');
     a.aplica();  a.mueve(id);  a.moverTodas();  a.estado();  a.restablece();

   Teclado: Tab llega a las dos asas; ↑ y ↓ las mueven de a 15 minutos,
   Re Pág y Av Pág de a una hora, Inicio y Fin a los extremos. En el mes,
   las flechas cambian de día. Con el puntero (ratón o dedo) se arrastran
   directamente. Qué se personaliza: los colores están al principio del CSS
   (--as-ciruela es lo que está abierto, --as-naranja lo que cambia).
   Todo lo que se mueve es transform u opacity. Sin dependencias, y sin
   Date: las fechas son números de día con aritmética propia.
   ===================================================================== */
(function () {
  'use strict';

  /* ── las fechas, a mano ────────────────────────────────────────────
     Cada día es un número entero (días desde el 1-1-1970): sin husos
     horarios ni cambios de hora que corran una fecha. */
  const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const MES_C = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const DIAS = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
  const DIA_C = ['lun', 'mar', 'mié', 'jue', 'vie', 'sáb', 'dom'];
  const bisiesto = a => (a % 4 === 0 && a % 100 !== 0) || a % 400 === 0;
  const diasDelMes = (a, m) => [31, bisiesto(a) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
  function aNumero(a, m, d) {
    a -= m <= 2 ? 1 : 0;
    const era = Math.floor(a / 400), ae = a - era * 400;
    const dia = Math.floor((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1;
    return era * 146097 + ae * 365 + Math.floor(ae / 4) - Math.floor(ae / 100) + dia - 719468;
  }
  function aFecha(n) {
    n += 719468;
    const era = Math.floor(n / 146097), de = n - era * 146097;
    const ae = Math.floor((de - Math.floor(de / 1460) + Math.floor(de / 36524) - Math.floor(de / 146096)) / 365);
    const da = de - (365 * ae + Math.floor(ae / 4) - Math.floor(ae / 100));
    const mp = Math.floor((5 * da + 2) / 153), m = mp < 10 ? mp + 3 : mp - 9;
    return { a: ae + era * 400 + (m <= 2 ? 1 : 0), m, d: da - Math.floor((153 * mp + 2) / 5) + 1 };
  }
  // el 1-1-1970 fue jueves: con la semana que empieza el lunes, 0 = lunes … 6 = domingo
  const semanaDe = n => (((n + 3) % 7) + 7) % 7;
  const dos = v => (v < 10 ? '0' : '') + v;
  const leeISO = s => { const p = String(s).split('-').map(Number); return aNumero(p[0], p[1], p[2] || 1); };
  const aISO = n => { const f = aFecha(n); return f.a + '-' + dos(f.m) + '-' + dos(f.d); };
  const larga = n => { const f = aFecha(n); return DIAS[semanaDe(n)] + ' ' + f.d + ' de ' + MESES[f.m - 1]; };
  const corta = n => { const f = aFecha(n); return DIA_C[semanaDe(n)] + ' ' + f.d + ' ' + MES_C[f.m - 1]; };
  const hhmm = m => dos(Math.floor(m / 60)) + ':' + dos(m % 60);
  const rango = (i, d) => hhmm(i) + ' – ' + hhmm(i + d);
  const hora = m => Math.floor(m / 60) + ':' + dos(m % 60);
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const plural = (n, uno, varios) => n + ' ' + (n === 1 ? uno : varios);
  const escapa = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';
  const el = (tag, clase, html) => { const e = document.createElement(tag); if (clase) e.className = clase; if (html != null) e.innerHTML = html; return e; };

  function Asueto(raiz, opc) {
    const o = Object.assign({
      hoy: '2026-11-09', mes: null, dia: null, paso: 15, busca: 30, minimo: 60, ventana: [480, 1200],
      semana: [[540, 1140], [540, 1140], [540, 1140], [540, 1140], [540, 1140], [600, 840], null],
      excepciones: [], citas: [], alAplicar() {}, alMover() {},
    }, opc);
    const $ = s => raiz.querySelector(s);
    const W0 = o.ventana[0], W1 = o.ventana[1], WM = W1 - W0;
    const HOY = leeISO(o.hoy);
    raiz.style.setProperty('--as-t0', W0);
    raiz.style.setProperty('--as-min', WM);

    /* ── el estado ───────────────────────────────────────────────────── */
    const S = { sel: 0, mes: null, excep: new Map(), citas: [], modo: 'normal', bor: null, motivo: 'Salida temprano', manual: false, ult: null, props: new Map() };
    const clona = h => (h ? { abre: h.abre, cierra: h.cierra } : null);
    function carga() {
      S.excep = new Map();
      o.excepciones.forEach(e => S.excep.set(leeISO(e.fecha), { cerrado: !!e.cerrado, abre: e.abre, cierra: e.cierra, motivo: e.motivo || 'Otro motivo' }));
      S.citas = o.citas.map((c, i) => ({ id: c.id || 'c' + i, titulo: c.titulo, fecha: leeISO(c.fecha), ini: c.ini, dur: c.dur }));
      const d = leeISO(o.dia || o.hoy), f = aFecha(leeISO(o.mes ? o.mes + '-01' : o.hoy));
      S.mes = { a: f.a, m: f.m };
      elige(d, true);
    }

    /* ── las reglas ──────────────────────────────────────────────────── */
    const semanal = n => { const w = o.semana[semanaDe(n)]; return w ? { abre: w[0], cierra: w[1] } : null; };
    const guardado = n => { const e = S.excep.get(n); if (e) return e.cerrado ? null : { abre: e.abre, cierra: e.cierra }; return semanal(n); };
    const igual = (a, b) => (!a && !b) || !!(a && b && a.abre === b.abre && a.cierra === b.cierra);
    const horaDe = n => (n === S.sel ? S.bor : guardado(n));     // el día que editas se ve con el borrador
    // una cita cabe si [ini, ini + dur] está entero dentro de [abre, cierra]
    const cabe = (c, h) => !!h && c.ini >= h.abre && c.ini + c.dur <= h.cierra;
    const delDia = n => S.citas.filter(c => c.fecha === n).sort((a, b) => a.ini - b.ini || a.dur - b.dur);
    const afectadas = (n, h) => delDia(n).filter(c => !cabe(c, h));
    const pisa = (n, ini, dur, ignora, reservas) =>
      S.citas.some(c => c.id !== ignora && c.fecha === n && ini < c.ini + c.dur && ini + dur > c.ini) ||
      reservas.some(r => r.fecha === n && ini < r.ini + r.dur && ini + dur > r.ini);
    // la primera hora libre para una cita: desde la apertura de su fecha, día tras día
    function primeraLibre(c, reservas) {
      for (let k = 0; k <= o.busca; k++) {
        const n = c.fecha + k, h = horaDe(n);
        if (!h) continue;
        for (let s = Math.ceil(h.abre / o.paso) * o.paso; s + c.dur <= h.cierra; s += o.paso) {
          if (!pisa(n, s, c.dur, c.id, reservas)) return { fecha: n, ini: s };
        }
      }
      return null;
    }
    function calculaPropuestas(lista) {
      const reservas = [], out = new Map();
      lista.forEach(c => {
        const p = primeraLibre(c, reservas);
        if (p) reservas.push({ fecha: p.fecha, ini: p.ini, dur: c.dur });
        out.set(c.id, p);
      });
      return out;
    }

    /* ── elegir fecha y modo ─────────────────────────────────────────── */
    function elige(n, sinAnuncio) {
      S.sel = n;
      const f = aFecha(n);
      if (f.a !== S.mes.a || f.m !== S.mes.m) { S.mes = { a: f.a, m: f.m }; construyeMes(); }
      const e = S.excep.get(n), w = semanal(n);
      S.modo = e ? (e.cerrado ? 'cerrado' : 'especial') : 'normal';
      S.bor = clona(guardado(n));
      S.ult = clona(S.bor) || clona(w) || { abre: 600, cierra: 840 };
      S.motivo = e ? e.motivo : (S.modo === 'cerrado' ? 'Feriado' : 'Salida temprano');
      S.manual = !!e;
      if (!sinAnuncio) anuncia(larga(n) + '. ' + resumenDia());
      render(true);
    }
    function ponModo(m, auto) {
      if (m === S.modo) return;
      if (S.bor) S.ult = clona(S.bor);
      S.modo = m;
      if (m === 'normal') S.bor = clona(semanal(S.sel));
      else if (m === 'cerrado') S.bor = null;
      else S.bor = clona(S.ult) || clona(semanal(S.sel)) || { abre: 600, cierra: 840 };
      if (!S.manual) S.motivo = m === 'cerrado' ? 'Feriado' : 'Salida temprano';
      if (!auto) anuncia({ normal: 'Horario de siempre.', especial: 'Otro horario: ' + (S.bor ? hhmm(S.bor.abre) + ' a ' + hhmm(S.bor.cierra) : ''), cerrado: 'Día cerrado.' }[m]);
      render();
    }
    // al agarrar una asa estando «como siempre», el día pasa solo a «otro horario»
    function haceEspecial() {
      if (S.modo === 'especial') return;
      S.ult = clona(S.bor) || clona(S.ult);
      S.modo = 'especial';
      S.bor = clona(S.ult);
      if (!S.manual) S.motivo = 'Salida temprano';
    }
    function ponHora(cual, m, anunciar) {
      if (!S.bor) return;
      haceEspecial();
      const b = S.bor;
      m = Math.round(m / o.paso) * o.paso;
      if (cual === 'abre') b.abre = lim(m, W0, b.cierra - o.minimo);
      else b.cierra = lim(m, b.abre + o.minimo, W1);
      S.ult = clona(b);
      render();
      if (anunciar) anuncia((cual === 'abre' ? 'Abre ' : 'Cierra ') + hhmm(cual === 'abre' ? b.abre : b.cierra) + '. ' + resumenImpacto());
    }

    /* ── pintar: el mes ──────────────────────────────────────────────── */
    const cal = $('[data-cal]'), celdas = new Map();
    function construyeMes() {
      const { a, m } = S.mes;
      $('[data-mes-titulo]').textContent = MESES[m - 1] + ' ' + a;
      const primero = aNumero(a, m, 1), off = semanaDe(primero), dm = diasDelMes(a, m);
      cal.innerHTML = ''; celdas.clear();
      for (let i = 0; i < off; i++) cal.appendChild(el('span', 'as-d as-d-vacio'));
      for (let d = 1; d <= dm; d++) {
        const n = primero + d - 1;
        const b = el('button', 'as-d', '<span class="as-d-n">' + d + '</span><span class="as-d-pts"></span><em class="as-d-ins"></em>');
        b.type = 'button'; b.dataset.dia = n;
        b.addEventListener('click', () => { elige(n); });
        b.addEventListener('keydown', e => {
          const mov = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[e.key];
          if (mov == null) return;
          e.preventDefault();
          const t = n + mov;
          if (t < HOY) return;
          elige(t);
          const c = celdas.get(t); if (c) c.focus();
        });
        cal.appendChild(b); celdas.set(n, b);
      }
      pintaMes();
    }
    function pintaMes() {
      celdas.forEach((b, n) => {
        const h = horaDe(n), w = semanal(n), e = S.excep.get(n);
        const total = delDia(n).length, fuera = afectadas(n, h).length;
        b.disabled = n < HOY;
        b.classList.toggle('is-sel', n === S.sel);
        b.classList.toggle('is-hoy', n === HOY);
        b.classList.toggle('is-libre', !w && !(n === S.sel ? S.modo !== 'normal' : e));
        const hayCierre = n === S.sel ? S.modo === 'cerrado' : !!(e && e.cerrado);
        const hayEsp = n === S.sel ? S.modo === 'especial' : !!(e && !e.cerrado);
        b.classList.toggle('is-cierre', hayCierre);
        b.classList.toggle('is-especial', hayEsp);
        b.tabIndex = n === S.sel ? 0 : -1;
        b.setAttribute('aria-pressed', n === S.sel ? 'true' : 'false');
        const pts = b.querySelector('.as-d-pts');
        const k = Math.min(total, 4);
        if (pts.dataset.k !== String(k)) { pts.dataset.k = k; pts.innerHTML = '<i></i>'.repeat(k); }
        const ins = b.querySelector('.as-d-ins');
        ins.textContent = fuera || '';
        ins.classList.toggle('is-on', fuera > 0);
        b.setAttribute('aria-label', larga(n) + ': ' + plural(total, 'cita', 'citas') + (fuera ? ', ' + plural(fuera, 'queda fuera de horario', 'quedan fuera de horario') : '') +
          (hayCierre ? ', cerrado' : hayEsp ? ', otro horario' : !w ? ', sin atención' : ''));
      });
    }

    /* ── pintar: el encabezado del día ───────────────────────────────── */
    const modoCaja = $('[data-modo]'), botonesModo = [...modoCaja.querySelectorAll('[data-m]')];
    const selMotivo = $('[data-motivo]'), motivoCaja = $('[data-motivo-caja]');
    function resumenDia() {
      const w = semanal(S.sel), t = delDia(S.sel).length;
      return plural(t, 'cita', 'citas') + (w ? ' · de siempre ' + hora(w.abre) + ' a ' + hora(w.cierra) : ' · sin atención de siempre');
    }
    function pintaCab() {
      const f = aFecha(S.sel);
      $('[data-dia-et]').textContent = DIAS[semanaDe(S.sel)];
      $('[data-dia-titulo]').textContent = f.d + ' de ' + MESES[f.m - 1];
      $('[data-dia-sub]').textContent = resumenDia();
      raiz.dataset.modo = S.modo;
      const i = botonesModo.findIndex(b => b.dataset.m === S.modo);
      modoCaja.style.setProperty('--i', i);
      botonesModo.forEach((b, k) => { b.setAttribute('aria-checked', k === i ? 'true' : 'false'); b.tabIndex = k === i ? 0 : -1; });
      const conMotivo = S.modo !== 'normal';
      motivoCaja.classList.toggle('is-off', !conMotivo);
      selMotivo.disabled = !conMotivo;
      if (selMotivo.value !== S.motivo) selMotivo.value = S.motivo;
    }

    /* ── pintar: la línea del día ────────────────────────────────────── */
    const lienzo = $('[data-lienzo]');
    lienzo.innerHTML =
      '<i class="as-hh as-hh-n" data-h="n1"></i><i class="as-hh as-hh-n" data-h="n2"></i>' +
      '<i class="as-hh as-hh-x" data-h="x1"></i><i class="as-hh as-hh-x" data-h="x2"></i>' +
      '<span class="as-rot" data-rot="x1"></span><span class="as-rot" data-rot="x2"></span>' +
      '<div class="as-citas" data-citas></div>' +
      '<div class="as-asa" data-asa="abre"><button type="button" class="as-pill" role="slider" aria-orientation="vertical" aria-label="Hora de apertura"><i class="as-grip"></i><b data-t></b></button></div>' +
      '<div class="as-asa" data-asa="cierra"><button type="button" class="as-pill" role="slider" aria-orientation="vertical" aria-label="Hora de cierre"><i class="as-grip"></i><b data-t></b></button></div>';
    const capaCitas = $('[data-citas]');
    const asa = { abre: $('[data-asa="abre"]'), cierra: $('[data-asa="cierra"]') };
    const hatch = {}; lienzo.querySelectorAll('[data-h]').forEach(e => { hatch[e.dataset.h] = e; });
    const rot = {}; lienzo.querySelectorAll('[data-rot]').forEach(e => { rot[e.dataset.rot] = e; });
    let h = ''; for (let m = W0; m <= W1; m += 60) h += '<span style="--m:' + m + '">' + hhmm(m) + '</span>';
    $('[data-horas]').innerHTML = h;

    const pct = m => ((m - W0) / WM * 100).toFixed(3) + '%';
    const fijaTramo = (e, a, b) => { e.style.setProperty('--a', a == null ? '100%' : pct(a)); e.style.setProperty('--b', b == null ? '0%' : (100 - (b - W0) / WM * 100).toFixed(3) + '%'); e.classList.toggle('is-vacio', a == null); };
    // las zonas cerradas del borrador, partidas en «de siempre» (neutras) y «por excepción» (naranja)
    function pintaCierres() {
      const w = semanal(S.sel), b = S.bor;
      const pts = [...new Set([W0, W1, b && b.abre, b && b.cierra, w && w.abre, w && w.cierra].filter(v => v != null && v >= W0 && v <= W1))].sort((x, y) => x - y);
      const tramos = { n: [], x: [] };
      for (let i = 0; i < pts.length - 1; i++) {
        const p = pts[i], q = pts[i + 1], mid = (p + q) / 2;
        const cb = !b || mid < b.abre || mid > b.cierra, cw = !w || mid < w.abre || mid > w.cierra;
        const t = cb && cw ? 'n' : cb ? 'x' : null;
        if (!t) continue;
        const u = tramos[t][tramos[t].length - 1];
        if (u && u[1] === p) u[1] = q; else tramos[t].push([p, q]);
      }
      ['n', 'x'].forEach(t => {
        const arriba = tramos[t].find(r => (r[0] + r[1]) / 2 < (W0 + W1) / 2), abajo = tramos[t].find(r => (r[0] + r[1]) / 2 >= (W0 + W1) / 2);
        fijaTramo(hatch[t + '1'], arriba && arriba[0], arriba && arriba[1]);
        fijaTramo(hatch[t + '2'], abajo && abajo[0], abajo && abajo[1]);
        if (t === 'x') [['x1', arriba], ['x2', abajo]].forEach(([k, r]) => {
          const alto = r ? (r[1] - r[0]) / WM * lienzo.clientHeight : 0;
          rot[k].classList.toggle('is-on', alto > 44);
          if (r) { rot[k].style.setProperty('--m', (r[0] + r[1]) / 2); rot[k].textContent = S.modo === 'cerrado' ? 'Cerrado · ' + S.motivo : S.motivo; }
        });
      });
    }

    const citaEls = new Map(), fantasmas = new Map();
    function pintaLienzo(cambioDia) {
      const lista = delDia(S.sel), af = afectadas(S.sel, S.bor);
      const ids = new Set(lista.map(c => c.id));
      citaEls.forEach((e, id) => { if (!ids.has(id) && !e.classList.contains('is-sale')) { e.remove(); citaEls.delete(id); } });
      lista.forEach(c => {
        let e = citaEls.get(c.id);
        if (!e) {
          e = el('div', 'as-cita', '<i class="as-nb"></i><span class="as-cita-t"><b></b><small></small></span>');
          e.dataset.id = c.id;
          e.querySelector('b').textContent = c.titulo;
          capaCitas.appendChild(e); citaEls.set(c.id, e);
          if (!cambioDia && !quieto()) e.classList.add('is-nueva');
        }
        e.style.setProperty('--ini', c.ini); e.style.setProperty('--dur', c.dur);
        e.classList.toggle('is-corta', c.dur < 50);
        e.querySelector('small').textContent = rango(c.ini, c.dur);
        const k = af.indexOf(c);
        e.classList.toggle('is-fuera', k > -1);
        e.querySelector('.as-nb').textContent = k > -1 ? k + 1 : '';
        e.title = c.titulo + ' · ' + rango(c.ini, c.dur) + (k > -1 ? ' · queda fuera de horario' : '');
      });
      // los fantasmas: la hora libre propuesta, cuando cae el mismo día
      fantasmas.forEach((g, id) => { if (!(S.props.get(id) && S.props.get(id).fecha === S.sel && af.some(c => c.id === id))) { g.remove(); fantasmas.delete(id); } });
      af.forEach((c, k) => {
        const p = S.props.get(c.id);
        if (!p || p.fecha !== S.sel) return;
        let g = fantasmas.get(c.id);
        if (!g) { g = el('div', 'as-fant', '<i></i><span></span>'); capaCitas.appendChild(g); fantasmas.set(c.id, g); }
        g.style.setProperty('--ini', p.ini); g.style.setProperty('--dur', c.dur);
        g.firstChild.textContent = k + 1;
        g.lastChild.textContent = hhmm(p.ini);
        g.classList.toggle('is-corta', c.dur < 50);
      });
      // las asas
      const b = S.bor;
      ['abre', 'cierra'].forEach(c => {
        const a = asa[c], p = a.firstChild;
        a.classList.toggle('is-oculta', !b);
        a.classList.toggle('is-cambia', !!b && (!semanal(S.sel) || b[c] !== semanal(S.sel)[c]));
        p.tabIndex = b ? 0 : -1;
        if (!b) return;
        const v = b[c];
        a.style.setProperty('--m', v);
        a.querySelector('[data-t]').textContent = hhmm(v);
        p.setAttribute('aria-valuemin', c === 'abre' ? W0 : b.abre + o.minimo);
        p.setAttribute('aria-valuemax', c === 'abre' ? b.cierra - o.minimo : W1);
        p.setAttribute('aria-valuenow', v);
        p.setAttribute('aria-valuetext', (c === 'abre' ? 'Abre a las ' : 'Cierra a las ') + hhmm(v));
      });
      pintaCierres();
    }

    /* ── pintar: el efecto y la lista ────────────────────────────────── */
    const listaEl = $('[data-lista]'), efecto = $('[data-efecto]'), todas = $('[data-mover-todas]');
    const itemEls = new Map();
    let nPrev = -1;
    function resumenImpacto() {
      const n = afectadas(S.sel, S.bor).length;
      return n ? plural(n, 'cita queda fuera de horario', 'citas quedan fuera de horario') + '.' : 'Todas las citas caben.';
    }
    function pintaPanel() {
      const af = afectadas(S.sel, S.bor), total = delDia(S.sel).length;
      S.props = calculaPropuestas(af);
      efecto.dataset.nivel = af.length ? 'alerta' : 'ok';
      const cifra = $('[data-n]');
      if (nPrev !== af.length) {
        cifra.textContent = af.length;
        if (nPrev !== -1 && !quieto()) { cifra.classList.remove('is-pop'); void cifra.offsetWidth; cifra.classList.add('is-pop'); }
        nPrev = af.length;
      }
      $('[data-efecto-t]').textContent = af.length
        ? (af.length === 1 ? 'cita queda fuera' : 'citas quedan fuera')
        : (S.modo === 'cerrado' ? 'El día está vacío' : 'Todas las citas caben');
      $('[data-efecto-s]').textContent = af.length
        ? 'de ' + plural(total, 'cita', 'citas') + ' ese día'
        : (total ? plural(total, 'cita dentro', 'citas dentro') + ' del horario' : 'Sin citas ese día');

      // FLIP: se mide dónde estaba cada fila para que las demás se deslicen a su sitio nuevo
      const antes = new Map();
      if (!quieto()) itemEls.forEach((li, id) => antes.set(id, li.getBoundingClientRect().top));
      const vivos = new Set(af.map(c => c.id));
      itemEls.forEach((li, id) => {
        if (vivos.has(id)) return;
        itemEls.delete(id);
        if (!quieto()) {
          // una copia se desvanece donde estaba la fila, mientras las demás suben
          const L = listaEl.getBoundingClientRect(), r = li.getBoundingClientRect(), g = li.cloneNode(true);
          g.style.cssText = 'position:absolute;left:0;margin:0;pointer-events:none;animation:none;width:' + r.width + 'px;top:' + (r.top - L.top) + 'px';
          listaEl.appendChild(g);
          g.animate([{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateX(18px) scale(.97)' }], { duration: 300, easing: 'cubic-bezier(.22, 1, .36, 1)' }).onfinish = () => g.remove();
        }
        li.remove();
      });
      af.forEach((c, k) => {
        let li = itemEls.get(c.id);
        if (!li) {
          li = el('li', 'as-fuera', '<i class="as-num"></i><div class="as-fuera-t"><b></b><small></small></div><button type="button" class="as-mini">Mover</button><p class="as-nuevo"></p>');
          li.dataset.id = c.id;
          li.querySelector('b').textContent = c.titulo;
          li.querySelector('.as-mini').addEventListener('click', () => mueve(c.id));
          const g = () => fantasmas.get(c.id);
          li.addEventListener('pointerenter', () => { const f = g(); if (f) f.classList.add('is-resalta'); li.classList.add('is-resalta'); });
          li.addEventListener('pointerleave', () => { const f = g(); if (f) f.classList.remove('is-resalta'); li.classList.remove('is-resalta'); });
          li.addEventListener('animationend', () => li.classList.add('is-visto'));
          listaEl.appendChild(li); itemEls.set(c.id, li);
        }
        li.querySelector('.as-num').textContent = k + 1;
        li.querySelector('small').textContent = rango(c.ini, c.dur);
        const p = S.props.get(c.id), nuevo = li.querySelector('.as-nuevo'), btn = li.querySelector('.as-mini');
        btn.disabled = !p;
        btn.setAttribute('aria-label', p ? 'Mover ' + c.titulo + ' al ' + larga(p.fecha) + ' a las ' + hhmm(p.ini) : c.titulo + ': sin hueco');
        if (p) {
          const dd = p.fecha - c.fecha;
          nuevo.innerHTML = '→ <strong>' + corta(p.fecha) + ' · ' + hhmm(p.ini) + '</strong><span> · ' + (dd === 0 ? 'mismo día' : dd === 1 ? 'día siguiente' : 'en ' + dd + ' días') + '</span>';
        } else nuevo.innerHTML = 'Sin hueco en los próximos ' + o.busca + ' días';
      });
      // el orden del DOM es el de la pantalla (lector de pantalla y Tab lo siguen)
      af.forEach((c, k) => { const li = itemEls.get(c.id); if (listaEl.children[k] !== li) listaEl.insertBefore(li, listaEl.children[k] || null); });
      $('[data-cap]').hidden = !af.length;
      todas.hidden = af.length < 2;
      if (af.length >= 2) todas.textContent = 'Mover las ' + af.length + ' a su primera hora libre';
      antes.forEach((top, id) => {
        const li = itemEls.get(id);
        if (!li) return;
        const d = top - li.getBoundingClientRect().top;
        if (Math.abs(d) > 1) li.animate([{ transform: 'translateY(' + d + 'px)' }, { transform: 'none' }], { duration: 420, easing: CURVA });
      });
    }

    /* ── pintar: lo guardado ─────────────────────────────────────────── */
    const exEl = $('[data-excepciones]');
    function pintaExcepciones() {
      const filas = [...S.excep.keys()].sort((a, b) => a - b);
      exEl.innerHTML = '';
      if (!filas.length) exEl.appendChild(el('li', 'as-vacia', 'Ninguna por ahora: todos los días siguen el horario de siempre.'));
      filas.forEach(n => {
        const e = S.excep.get(n), pend = afectadas(n, horaDe(n)).length;
        const li = el('li', 'as-ex' + (n === S.sel ? ' is-sel' : ''),
          '<button type="button" class="as-ex-ir"><b>' + corta(n) + '</b><span>' + (e.cerrado ? 'Cerrado' : hora(e.abre) + ' a ' + hora(e.cierra)) + ' · ' + escapa(e.motivo) + '</span></button>' +
          (pend ? '<em class="as-ex-p" title="Citas por mover">' + pend + '</em>' : '') +
          '<button type="button" class="as-ex-x" aria-label="Quitar la excepción del ' + larga(n) + '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 7l10 10M17 7 7 17"/></svg></button>');
        li.querySelector('.as-ex-ir').addEventListener('click', () => elige(n));
        li.querySelector('.as-ex-x').addEventListener('click', () => quita(n));
        exEl.appendChild(li);
      });
    }

    /* ── el conjunto ─────────────────────────────────────────────────── */
    const aplicarBtn = $('[data-aplicar]'), aplicarT = $('[data-aplicar-t]');
    function nuevoHorario() { return S.modo === 'normal' ? clona(semanal(S.sel)) : clona(S.bor); }
    function hayCambios() {
      const e = S.excep.get(S.sel), nuevo = nuevoHorario();
      if (!igual(nuevo, guardado(S.sel))) return true;
      return !!(e && S.modo !== 'normal' && e.motivo !== S.motivo);
    }
    function pintaAplicar() {
      const cambia = hayCambios();
      aplicarBtn.disabled = !cambia;
      const n = S.sel, e = S.excep.get(n);
      aplicarT.textContent = !cambia ? (e ? 'Excepción guardada' : 'Sin cambios')
        : S.modo === 'normal' ? 'Volver al horario de siempre'
        : S.modo === 'cerrado' ? 'Cerrar el ' + corta(n)
        : 'Aplicar al ' + corta(n);
    }
    function render(cambioDia) {
      pintaCab(); pintaPanel(); pintaLienzo(cambioDia); pintaMes(); pintaExcepciones(); pintaAplicar();
    }

    /* ── acciones ────────────────────────────────────────────────────── */
    const voz = $('[data-voz]'), guardadoEl = $('[data-guardado]');
    const anuncia = t => { voz.textContent = ''; setTimeout(() => { voz.textContent = t; }, 30); };
    let tGuardado = 0;
    function aplica() {
      if (!hayCambios()) return;
      const n = S.sel, nuevo = nuevoHorario();
      let msg;
      if (igual(nuevo, semanal(n))) {
        S.excep.delete(n);
        msg = corta(n) + ' vuelve al horario de siempre';
        o.alAplicar({ fecha: aISO(n), quitada: true });
      } else {
        const ex = { cerrado: !nuevo, abre: nuevo && nuevo.abre, cierra: nuevo && nuevo.cierra, motivo: S.motivo };
        S.excep.set(n, ex);
        msg = nuevo ? corta(n) + ': abre ' + hora(nuevo.abre) + ', cierra ' + hora(nuevo.cierra) : corta(n) + ': cerrado';
        o.alAplicar({ fecha: aISO(n), cerrado: !nuevo, abre: nuevo ? nuevo.abre : null, cierra: nuevo ? nuevo.cierra : null, motivo: S.motivo });
      }
      S.modo = S.excep.has(n) ? (S.excep.get(n).cerrado ? 'cerrado' : 'especial') : 'normal';
      S.manual = S.excep.has(n);
      render();
      $('[data-guardado-t]').textContent = msg;
      guardadoEl.classList.add('is-on');
      clearTimeout(tGuardado);
      tGuardado = setTimeout(() => guardadoEl.classList.remove('is-on'), 2800);
      const c = celdas.get(n);
      if (c && !quieto()) { c.classList.remove('is-pop'); void c.offsetWidth; c.classList.add('is-pop'); }
      const af = afectadas(n, horaDe(n)).length;
      anuncia('Guardado. ' + msg + '.' + (af ? ' ' + plural(af, 'cita queda', 'citas quedan') + ' por mover.' : ''));
    }
    function quita(n) {
      if (!S.excep.has(n)) return;
      S.excep.delete(n);
      o.alAplicar({ fecha: aISO(n), quitada: true });
      if (n === S.sel) elige(n, true); else render();
      anuncia('Excepción quitada: ' + larga(n) + ' sigue el horario de siempre.');
    }
    function mueve(id, sinRender) {
      const c = S.citas.find(x => x.id === id), p = S.props.get(id);
      if (!c || !p) return false;
      const antes = { fecha: aISO(c.fecha), ini: c.ini };
      const sale = p.fecha !== c.fecha;
      c.fecha = p.fecha; c.ini = p.ini;
      o.alMover({ cita: c.titulo, antes, despues: { fecha: aISO(p.fecha), ini: p.ini } });
      if (sale && !quieto()) {
        const e = citaEls.get(id);
        if (e) { e.classList.add('is-sale'); setTimeout(() => { e.remove(); citaEls.delete(id); }, 480); }
      }
      if (!sinRender) {
        render();
        anuncia(c.titulo + ' pasa al ' + larga(p.fecha) + ' a las ' + hhmm(p.ini) + '. ' + resumenImpacto());
      }
      return true;
    }
    function moverTodas() {
      const af = afectadas(S.sel, S.bor);
      const props = calculaPropuestas(af);
      S.props = props;
      let n = 0;
      af.forEach(c => { if (mueve(c.id, true)) n++; });
      render();
      anuncia(plural(n, 'cita movida', 'citas movidas') + ' a su primera hora libre. ' + resumenImpacto());
    }
    function restablece() {
      citaEls.forEach(e => e.remove()); citaEls.clear();
      fantasmas.forEach(e => e.remove()); fantasmas.clear();
      itemEls.forEach(e => e.remove()); itemEls.clear();
      nPrev = -1;
      guardadoEl.classList.remove('is-on');
      S.mes = null;
      const f = aFecha(leeISO(o.mes ? o.mes + '-01' : o.hoy));
      S.mes = { a: f.a, m: f.m };
      carga(); construyeMes(); render(true);
      anuncia('Agenda restablecida.');
    }

    /* ── arrastrar las asas ──────────────────────────────────────────── */
    let drag = null;
    ['abre', 'cierra'].forEach(c => {
      const a = asa[c], p = a.firstChild;
      p.addEventListener('pointerdown', e => {
        if (e.button > 0 || drag || !S.bor) return;
        e.preventDefault();
        p.setPointerCapture(e.pointerId);
        const L = lienzo.getBoundingClientRect();
        // la distancia entre donde la tomaste y la línea: así la asa no salta al puntero
        const y = L.top + (S.bor[c] - W0) / WM * L.height;
        drag = { id: e.pointerId, c, dy: e.clientY - y };
        p.classList.add('is-arrastra'); raiz.classList.add('is-arrastrando');
      });
      p.addEventListener('pointermove', e => {
        if (!drag || e.pointerId !== drag.id) return;
        const L = lienzo.getBoundingClientRect();
        ponHora(c, W0 + (e.clientY - drag.dy - L.top) / L.height * WM, false);
      });
      const fin = e => {
        if (!drag || e.pointerId !== drag.id) return;
        drag = null;
        p.classList.remove('is-arrastra'); raiz.classList.remove('is-arrastrando');
        try { p.releasePointerCapture(e.pointerId); } catch (er) {}
        anuncia((c === 'abre' ? 'Abre ' : 'Cierra ') + hhmm(S.bor[c]) + '. ' + resumenImpacto());
      };
      p.addEventListener('pointerup', fin);
      p.addEventListener('pointercancel', fin);
      p.addEventListener('keydown', e => {
        if (!S.bor) return;
        const paso = { ArrowUp: -o.paso, ArrowLeft: -o.paso, ArrowDown: o.paso, ArrowRight: o.paso, PageUp: -60, PageDown: 60 }[e.key];
        if (paso != null) { e.preventDefault(); ponHora(c, S.bor[c] + paso, true); return; }
        if (e.key === 'Home') { e.preventDefault(); ponHora(c, c === 'abre' ? W0 : S.bor.abre + o.minimo, true); }
        if (e.key === 'End') { e.preventDefault(); ponHora(c, c === 'abre' ? S.bor.cierra - o.minimo : W1, true); }
      });
    });

    /* ── los controles ───────────────────────────────────────────────── */
    botonesModo.forEach(b => b.addEventListener('click', () => ponModo(b.dataset.m)));
    modoCaja.addEventListener('keydown', e => {
      const k = { ArrowLeft: -1, ArrowUp: -1, ArrowRight: 1, ArrowDown: 1 }[e.key];
      if (!k) return;
      e.preventDefault();
      const i = botonesModo.findIndex(b => b.dataset.m === S.modo), t = lim(i + k, 0, 2);
      ponModo(botonesModo[t].dataset.m);
      botonesModo[t].focus();
    });
    selMotivo.addEventListener('change', () => { S.motivo = selMotivo.value; S.manual = true; render(); });
    $('[data-aplicar]').addEventListener('click', aplica);
    $('[data-restablecer]').addEventListener('click', restablece);
    todas.addEventListener('click', moverTodas);
    raiz.querySelectorAll('[data-mes]').forEach(b => b.addEventListener('click', () => {
      const t = S.mes.a * 12 + S.mes.m - 1 + Number(b.dataset.mes);
      S.mes = { a: Math.floor(t / 12), m: t % 12 + 1 };
      construyeMes();
    }));

    // el horario de siempre, en palabras: los días iguales se juntan
    (function () {
      const grupos = [];
      o.semana.forEach((w, i) => {
        const clave = w ? hora(w[0]) + ' a ' + hora(w[1]) : 'cerrado';
        const u = grupos[grupos.length - 1];
        if (u && u.clave === clave) u.hasta = i; else grupos.push({ clave, desde: i, hasta: i });
      });
      const txt = g => g.desde === g.hasta ? DIA_C[g.desde] : DIA_C[g.desde] + ' a ' + DIA_C[g.hasta];
      $('[data-semana-txt]').textContent = 'De siempre: ' + grupos.map(g => txt(g) + ' ' + (g.clave === 'cerrado' ? 'cerrado' : g.clave.replace(' a ', ' – '))).join(' · ');
    })();

    carga(); construyeMes(); render(true);

    return {
      selecciona: iso => elige(leeISO(iso)),
      modo: m => ponModo(m, true),
      abre: m => ponHora('abre', m),
      cierra: m => ponHora('cierra', m),
      aplica, quita: iso => quita(leeISO(iso)),
      mueve: id => mueve(id), moverTodas, restablece,
      // qué pasaría si ese día tuviera ese horario (o estuviera cerrado, con null), sin tocar nada de lo que se ve
      impacto: (iso, hor) => {
        const sel0 = S.sel, bor0 = S.bor;
        S.sel = leeISO(iso); S.bor = clona(hor);
        const af = afectadas(S.sel, S.bor), pr = calculaPropuestas(af);
        const out = {
          afectadas: af.map(c => ({ id: c.id, titulo: c.titulo, ini: c.ini, dur: c.dur })),
          propuestas: af.map(c => { const p = pr.get(c.id); return { id: c.id, fecha: p ? aISO(p.fecha) : null, ini: p ? p.ini : null }; }),
        };
        S.sel = sel0; S.bor = bor0;
        return out;
      },
      estado: () => ({
        fecha: aISO(S.sel), modo: S.modo, horario: clona(S.bor), motivo: S.motivo,
        afectadas: afectadas(S.sel, S.bor).map(c => ({ id: c.id, titulo: c.titulo, ini: c.ini, dur: c.dur })),
        propuestas: [...S.props.entries()].map(([id, p]) => ({ id, fecha: p && aISO(p.fecha), ini: p && p.ini })),
        citas: S.citas.map(c => ({ id: c.id, titulo: c.titulo, fecha: aISO(c.fecha), ini: c.ini, dur: c.dur })),
        excepciones: [...S.excep.entries()].map(([n, e]) => Object.assign({ fecha: aISO(n) }, e)),
      }),
    };
  }

  window.Asueto = Asueto;
})();
