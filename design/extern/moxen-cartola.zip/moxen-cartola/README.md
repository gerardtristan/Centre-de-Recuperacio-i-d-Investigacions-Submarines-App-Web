# Cartola · Moxen

Cada cliente es una fila y cada documento pendiente, una ficha que cae en su columna según los días desde su emisión: 0–30, 31–60 o más de 60, con el 30 y el 31, y el 60 y el 61, en tramos distintos. Filtra por estado (por vencer, vencido, en disputa) y aísla un cliente tocando su nombre: lo que no cumple se apaga en su lugar y las cifras de cada tramo, cliente y estado se recalculan. El detalle muestra emisión, vencimiento y antigüedad, la disputa se marca y se quita con un botón, y «Exportar CSV» descarga lo que se ve, sin montos.

## Qué trae

- `index.html` — la demostración
- `cartola.css`
- `cartola.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `cartola.css` y `cartola.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Each customer is a row and each pending document is a tile that lands in its column by the days since it was issued: 0–30, 31–60 or over 60, with day 30 and 31, and 60 and 61, in different bands. Filter by status (not yet due, overdue, disputed) and isolate a customer by tapping its name: whatever does not match dims in place and the figures for each band, customer and status are recalculated. The detail shows issue date, due date and age, the dispute is set and removed with one button, and “Export CSV” downloads what you see, with no amounts.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
