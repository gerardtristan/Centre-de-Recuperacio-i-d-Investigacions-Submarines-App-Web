/* =====================================================================
   Errata · Moxen
   Una solicitud de alta en cuatro secciones que se corrige como una prueba de imprenta. Los errores no aparecen mientras
   escribes sino al salir del campo; al enviar con errores, el foco salta a un recuadro «Hay 3 errores» arriba del todo, cada
   enlace lleva a su campo y lo enfoca, y el índice del lado marca cada sección como incompleta, con errores o completa y
   cambia al corregir. Al arreglar el último, el recuadro se vuelve «Todo correcto» con un ✓ de lápiz azul.

   Funciona de verdad (nada está simulado salvo la respuesta del servidor):
   · El formulario lleva `novalidate` y la validación es la del navegador: Constraint Validation API. Cada campo declara lo que
     sabe el navegador (required, type=email, type=date con min y max, pattern) y lo que no (contraseña de 10 caracteres con un
     número, las dos iguales, teléfono de nueve dígitos, un texto de al menos 20 caracteres) se le dice con setCustomValidity.
     Todo se lee luego de `validity` (valueMissing, typeMismatch, patternMismatch, rangeOverflow, rangeUnderflow, badInput,
     customError). El «Inspector» del lado enseña esos siete indicadores del campo en foco, en vivo.
   · Los mensajes son concretos y salen del valor escrito: «Tiene 6 caracteres: necesita al menos 10», «Solo letras, números y
     guion bajo: sobra «ñ»», «La fecha debe ser anterior a hoy». Nunca «Campo inválido».
   · Accesible: cada campo con error lleva aria-invalid y un aria-describedby que apunta a su mensaje (más su ayuda), el grupo
     de radios es un radiogroup, y el resumen es un role="alert" con tabindex="-1" que recibe el foco al enviar.
   · El índice y el resumen cuentan lo mismo porque salen de la misma lista: los campos con un error visible. Los números de
     margen (01 a 12) son los mismos en el campo, en el resumen y en el índice.
   · El «servidor» rechaza los correos ya registrados (hola@estudio.dev y contacto@estudio.dev) después de 0,9 s y su error entra
     en el mismo resumen, ligado al campo con setCustomValidity; se borra solo al cambiar el correo.

   Cómo se monta (ver index.html): se inicia solo sobre [data-errata]; el HTML es la plantilla (un [data-campo] por campo).
     const e = Errata(document.querySelector('[data-errata]'));
     e.caso('vacio');  e.envia();  e.estado();      // estado() → { modo, errores:[{n, campo, mensaje}], indice:[…], foco }
   Teclado: Tab recorre el formulario; Intro envía; B, V y C cargan el borrador, el formulario vacío y el correcto; R vuelve al
   borrador (fuera de los campos de texto).
   Qué se personaliza: los colores, al principio de errata.css (--er-rojo es el corrector, --er-azul el lápiz); las reglas y los
   textos, en REGLAS y TEXTOS de este archivo; los correos «ya registrados», en REGISTRADOS. El tiempo sale de requestAnimationFrame
   y setTimeout (sin Date para animar; solo se lee la fecha para saber qué es «hoy»); lo que se limpia al terminar una animación
   va con un setTimeout, nunca con `onfinish`. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const pad = n => String(n).padStart(2, '0');
  const plural = (n, uno, otros) => n + ' ' + (n === 1 ? uno : otros);
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';
  const ESPERA = 900;                                   // lo que tarda el «servidor» en contestar
  const REGISTRADOS = ['hola@estudio.dev', 'contacto@estudio.dev'];
  const ERROR_SERVIDOR = 'Ese correo ya tiene una cuenta. Entra con él o escribe otro.';
  const FLAGS = ['valueMissing', 'typeMismatch', 'patternMismatch', 'rangeOverflow', 'rangeUnderflow', 'badInput', 'customError'];

  /* los tres juegos de datos para probar: el borrador de siempre (tres errores y un correo que el servidor rechazará), el
     formulario en blanco y uno sin un solo fallo */
  const BASE = { correo: '', usuario: '', clave: '', repite: '', taller: '', apertura: '', telefono: '', cp: '', idioma: '', frecuencia: '', necesidad: '', condiciones: false, novedades: false };
  const CASOS = {
    borrador: { correo: 'hola@estudio.dev', usuario: 'taller_norte', clave: 'Taller-2026!', repite: 'Taller-2025!', taller: 'Taller de cerámica', apertura: '2031-04-12', telefono: '600 123 456', cp: '28014', idioma: 'es', frecuencia: 'semanal', necesidad: 'Necesitamos llevar los pedidos y los cursos de los sábados.', condiciones: false, novedades: true },
    vacio: BASE,
    correcto: { correo: 'taller@estudio.dev', usuario: 'taller_norte', clave: 'Taller-2026!', repite: 'Taller-2026!', taller: 'Taller de cerámica', apertura: '2019-04-12', telefono: '600 123 456', cp: '28014', idioma: 'es', frecuencia: 'semanal', necesidad: 'Necesitamos llevar los pedidos y los cursos de los sábados.', condiciones: true, novedades: true }
  };
  const AVISO_CASO = { borrador: 'Borrador cargado: tiene tres errores', vacio: 'Formulario vacío', correcto: 'Formulario correcto' };

  /* ── las reglas que el navegador no conoce: devuelven el mensaje, o '' si el valor vale ───────────────────────────── */
  const REGLAS = {
    correo: v => (v && /^[^\s@]+@[^\s@.]+$/.test(v) ? 'Al dominio le falta el punto, por ejemplo estudio.dev' : ''),
    clave: v => (!v ? '' : v.length < 10 ? 'Tiene ' + plural(v.length, 'carácter', 'caracteres') + ': necesita al menos 10' : !/\d/.test(v) ? 'Añade al menos un número' : ''),
    repite: (v, de) => (v && v !== de('clave') ? 'Las dos contraseñas no coinciden' : ''),
    taller: v => (v && v.length < 3 ? 'Escribe al menos 3 letras' : ''),
    telefono: v => {
      if (!v) return '';
      const sin = v.replace(/[\s.-]/g, ''), raro = sin.replace(/\d/g, '');
      if (raro) return 'Solo números: sobra «' + raro.charAt(0) + '»';
      return sin.length === 9 ? '' : 'Tiene ' + plural(sin.length, 'dígito', 'dígitos') + ': debe tener 9';
    },
    necesidad: v => (v && v.length < 20 ? 'Escribe al menos 20 caracteres: llevas ' + v.length : '')
  };

  /* lo que se dice cuando falta el valor (`falta`) y cuando el navegador lo da por malo (`mal`, que mira el valor y validity) */
  const rareza = (v, bien) => {
    const raros = Array.from(new Set(v.replace(bien, '').split('')));
    return raros.slice(0, 3).map(q => (q === ' ' ? 'el espacio' : '«' + q + '»')).join(', ');
  };
  const TEXTOS = {
    correo: {
      falta: 'Escribe el correo con el que vas a entrar',
      mal: v => {
        if (/\s/.test(v)) return 'El correo no puede llevar espacios';
        if (v.indexOf('@') < 0) return 'Falta la @: el correo se escribe como nombre@estudio.dev';
        if (v.indexOf('@') === 0) return 'Falta lo que va antes de la @';
        if (/@$/.test(v)) return 'Falta el dominio después de la @, por ejemplo estudio.dev';
        if (v.split('@').length > 2) return 'Sobra una @: solo puede haber una';
        return 'Revisa el correo: algo no cuadra después de la @';
      }
    },
    usuario: {
      falta: 'Elige un nombre de usuario',
      mal: v => {
        const raros = rareza(v, /[A-Za-z0-9_]/g);
        if (raros) return 'Solo letras, números y guion bajo: sobra ' + raros;
        return v.length < 3 ? 'Tiene ' + plural(v.length, 'carácter', 'caracteres') + ': necesita al menos 3' : 'Tiene ' + v.length + ' caracteres: el máximo es 20';
      }
    },
    clave: { falta: 'Elige una contraseña' },
    repite: { falta: 'Repite la contraseña para evitar erratas' },
    taller: { falta: 'Escribe el nombre del taller' },
    apertura: {
      falta: 'Indica la fecha de apertura del taller',
      mal: (v, val) => (val.badInput ? 'La fecha está incompleta: falta el día, el mes o el año'
        : val.rangeOverflow ? 'La fecha debe ser anterior a hoy' : 'La fecha no puede ser anterior a 1900: revisa el año')
    },
    telefono: {},
    cp: {
      falta: 'Escribe el código postal',
      mal: v => {
        const raros = rareza(v, /\d/g);
        return raros ? 'Solo números: sobra ' + raros : 'Son 5 dígitos; tienes ' + v.length;
      }
    },
    idioma: { falta: 'Elige el idioma de los correos' },
    frecuencia: { falta: 'Elige cada cuánto quieres recibir avisos' },
    necesidad: { falta: 'Cuéntanos qué necesitas, en una o dos frases' },
    condiciones: { falta: 'Acepta las condiciones de uso para enviar la solicitud' }
  };

  function Errata(raiz, opciones) {
    const o = opciones || {};
    const form = $('[data-form]', raiz);
    const marco = $('[data-res-marco]', raiz), resumen = $('[data-resumen]', raiz), resTitulo = $('[data-res-titulo]', raiz), resSub = $('[data-res-sub]', raiz), resLista = $('[data-res-lista]', raiz);
    const indiceEl = $('[data-indice]', raiz), totalEl = $('[data-total]', raiz);
    const bEstado = $('[data-b-estado]', raiz), bVer = $('[data-b-ver]', raiz), btnEnviar = $('[data-enviar]', raiz), enviarT = $('[data-enviar-t]', raiz), vivo = $('[data-vivo]', raiz);
    const inspCampo = $('[data-insp-campo]', raiz), inspFlags = $('[data-insp-flags]', raiz), inspMsg = $('[data-insp-msg]', raiz);
    const casosEl = $$('[data-caso]', raiz);
    const novedades = $('#f-novedades', raiz), cuenta = $('[data-cuenta]', raiz);
    const E = { intento: false, enviando: false, enviado: false, enviados: 0, caso: 'borrador', foco: null, timers: [] };

    /* ── los campos: cada [data-campo] con sus controles, su error y su sección ───────────────────────────────────── */
    const secciones = $$('[data-seccion]', raiz).map(el => ({ el, nombre: el.dataset.seccion, titulo: $('h2', el), campos: [], li: null }));
    const campos = [], porNombre = {};
    $$('[data-campo]', raiz).forEach(w => {
      const els = $$('input, select, textarea', w);
      const c = { w, nombre: w.dataset.campo, els, el: els[0], tipo: els[0].type, err: $('.er-error', w), tag: $('.er-n', w), et: $('.er-et', w).textContent.trim(),
        sec: secciones.find(s => s.el.contains(w)), requerido: els.some(e => e.required), msg: '', visible: '', tocado: false, revelado: false, serv: '', servValor: '', tErr: 0 };
      c.ariaEl = c.tipo === 'radio' ? w : c.el;
      if (!c.el.id) c.el.id = 'f-' + c.nombre;
      c.n = campos.length + 1;
      c.tag.textContent = pad(c.n);
      c.sec.campos.push(c);
      campos.push(c); porNombre[c.nombre] = c;
    });
    const valorDe = nombre => valor(porNombre[nombre]);
    const campoDe = t => (t && t.closest && t.tagName !== 'BUTTON' ? campos.find(c => c.w.contains(t)) : null);

    // «anterior a hoy»: el último día válido de la fecha es ayer
    (function () {
      const ayer = new Date(); ayer.setDate(ayer.getDate() - 1);
      porNombre.apertura.el.max = ayer.getFullYear() + '-' + pad(ayer.getMonth() + 1) + '-' + pad(ayer.getDate());
    })();

    const despues = (fn, ms) => { const id = setTimeout(() => { E.timers = E.timers.filter(t => t !== id); fn(); }, ms); E.timers.push(id); return id; };
    const limpiaTimers = () => { E.timers.forEach(clearTimeout); E.timers = []; };
    const anuncia = t => { vivo.textContent = ''; despues(() => { vivo.textContent = t; }, 30); };
    function anima(el, kf, op) { if (quieto() || !el || !el.animate) return null; return el.animate(kf, op); }

    /* ── leer y diagnosticar un campo ───────────────────────────────────────────────────────────────────────────── */
    function valor(c) {
      if (c.tipo === 'radio') { const r = c.els.find(e => e.checked); return r ? r.value : ''; }
      if (c.tipo === 'checkbox') return c.el.checked ? 'si' : '';
      return c.tipo === 'password' ? c.el.value : c.el.value.trim();
    }

    /* El mensaje de un campo, o '' si está bien. Primero se le dicen al navegador las reglas que no conoce (setCustomValidity,
       o el error del servidor mientras el valor sea el que rechazó) y luego se lee `validity`. */
    function diagnostico(c) {
      const v = valor(c), T = TEXTOS[c.nombre] || {};
      const regla = REGLAS[c.nombre] ? REGLAS[c.nombre](v, valorDe) : '';
      const srv = c.serv && c.servValor === v ? c.serv : '';
      c.el.setCustomValidity(regla || srv || '');
      const val = c.el.validity;
      if (val.badInput) return T.mal ? T.mal(v, val) : '';
      if (c.requerido && v === '') return T.falta || 'Este campo es obligatorio';
      if (val.valid) return '';
      if (val.valueMissing) return T.falta || 'Este campo es obligatorio';
      if (val.typeMismatch || val.patternMismatch || val.rangeOverflow || val.rangeUnderflow) return T.mal ? T.mal(v, val) : c.el.validationMessage;
      return c.el.validationMessage;
    }

    /* ── un campo con error visible, o sin él ──────────────────────────────────────────────────────────────────── */
    function aplicaCampo(c) {
      const mostrar = c.revelado ? c.msg : '';
      if (mostrar !== c.visible) {
        c.visible = mostrar;
        const span = c.err.firstElementChild;
        clearTimeout(c.tErr);
        if (mostrar) span.textContent = mostrar;
        else c.tErr = setTimeout(() => { if (!c.visible) span.textContent = ''; }, 400);    // el texto se queda mientras se pliega
        c.w.classList.toggle('er-mal', !!mostrar);
        if (mostrar) c.ariaEl.setAttribute('aria-invalid', 'true'); else c.ariaEl.removeAttribute('aria-invalid');
      } else if (mostrar) {
        c.err.firstElementChild.textContent = mostrar;                                       // el recuento cambia mientras escribes
      }
      c.w.classList.toggle('er-bien', c.tocado && !c.msg && valor(c) !== '');
    }

    /* ── el índice ──────────────────────────────────────────────────────────────────────────────────────────────── */
    const NS = 'http://www.w3.org/2000/svg';
    function construyeIndice() {
      secciones.forEach((s, i) => {
        const li = h('li', 'er-idx'); li.dataset.estado = 'incompleta';
        const a = h('a'); a.href = '#' + s.el.id;
        a.innerHTML = '<svg class="er-anillo" viewBox="0 0 34 34" aria-hidden="true"><circle class="er-pista" cx="17" cy="17" r="14"/><circle class="er-avance" cx="17" cy="17" r="14" pathLength="100" stroke-dasharray="0 100"/>' +
          '<circle class="er-relleno" cx="17" cy="17" r="14"/><path class="er-tilde" d="m10.500 17.500 4.500 4.500 8.500-10"/><path class="er-exclam" d="M17 9.500v9M17 23.500v.01"/></svg>' +
          '<span class="er-idx-t"><b></b><em></em></span>';
        $('b', a).textContent = s.nombre;
        li.appendChild(a); indiceEl.appendChild(li);
        s.li = li; s.avance = $('.er-avance', a); s.estadoEl = $('em', a); s.estado = 'incompleta';
      });
    }

    function pintaIndice() {
      secciones.forEach(s => {
        const req = s.campos.filter(c => c.requerido);
        s.listos = req.filter(c => !c.msg).length; s.total = req.length;
        s.invalidos = s.campos.filter(c => c.msg).length;
        s.errores = s.campos.filter(c => c.visible).length;
        s.estado = s.errores ? 'errores' : s.invalidos ? 'incompleta' : 'completa';
        s.li.dataset.estado = s.estado;
        const pct = s.estado === 'completa' ? 100 : s.total ? Math.round(s.listos / s.total * 100) : 0;
        s.avance.setAttribute('stroke-dasharray', pct + ' 100');
        s.estadoEl.textContent = s.estado === 'errores' ? plural(s.errores, 'error', 'errores') : s.estado === 'completa' ? 'completa' : s.listos + ' de ' + s.total + ' listos';
      });
      const vis = campos.filter(c => c.visible).length, conErr = secciones.filter(s => s.errores).length, hechas = secciones.filter(s => s.estado === 'completa').length;
      totalEl.className = 'er-total' + (vis ? ' er-mal-t' : hechas === secciones.length ? ' er-bien-t' : '');
      totalEl.innerHTML = vis ? '<b>' + plural(vis, 'error', 'errores') + '</b> en ' + plural(conErr, 'sección', 'secciones')
        : hechas === secciones.length ? '<b>Las cuatro secciones</b>, completas' : '<b>' + hechas + ' de ' + secciones.length + '</b> secciones completas';
    }

    /* ── el resumen de errores ──────────────────────────────────────────────────────────────────────────────────── */
    let modoActual = null, tModo = 0;
    const calculaModo = () => {
      if (E.enviado) return 'enviado';
      if (!E.intento) return null;                                                        // el resumen no sube hasta que se intenta enviar
      if (campos.some(c => c.visible)) return 'errores';
      return E.intento && !campos.some(c => c.msg) ? 'ok' : null;
    };

    function itemResumen(c) {
      const li = h('li'); li.dataset.de = c.nombre; li.dataset.n = c.n;
      const a = h('a'); a.href = '#' + c.el.id;
      a.innerHTML = '<i class="er-res-n"></i><span class="er-res-t"><b></b><em></em></span><small></small>';
      $('.er-res-n', a).textContent = pad(c.n);
      $('b', a).textContent = c.et;
      $('small', a).textContent = c.sec.nombre;
      li.appendChild(a);
      return li;
    }

    function retira(li, ms) {
      clearTimeout(li._t);
      li._t = setTimeout(() => {
        const alto = li.offsetHeight;
        anima(li, [{ height: alto + 'px', opacity: 1 }, { height: '0px', opacity: 0 }], { duration: 260, easing: CURVA, fill: 'forwards' });
        li._t = setTimeout(() => li.remove(), quieto() ? 0 : 270);
      }, quieto() ? 0 : ms);
    }

    function aplicaLista(vis) {
      const hay = new Set(vis.map(c => c.nombre));
      $$('li', resLista).forEach(li => {
        if (hay.has(li.dataset.de)) { if (li.classList.contains('er-tachado')) { clearTimeout(li._t); li.getAnimations().forEach(a => a.cancel()); li.classList.remove('er-tachado'); } return; }
        if (li.classList.contains('er-tachado')) return;
        const c = porNombre[li.dataset.de];
        if (!c.msg) { li.classList.add('er-tachado'); retira(li, vis.length ? 440 : 700); } else retira(li, 0);
      });
      vis.forEach(c => {
        let li = $('li[data-de="' + c.nombre + '"]', resLista);
        if (!li) {
          li = itemResumen(c);
          const sig = $$('li', resLista).find(x => +x.dataset.n > c.n);
          resLista.insertBefore(li, sig || null);
          anima(li, [{ height: '0px', opacity: 0 }, { height: li.scrollHeight + 'px', opacity: 1 }], { duration: 340, easing: CURVA });
        }
        $('em', li).textContent = c.visible;
        const peque = $('small', li), srv = !!c.serv && c.visible === c.serv;
        peque.textContent = srv ? 'servidor' : c.sec.nombre; peque.classList.toggle('er-srv', srv);
      });
    }

    function aplicaModo(modo) {
      modoActual = modo;
      if (!modo) { marco.classList.remove('er-abierto'); return; }
      resumen.dataset.modo = modo;
      if (modo === 'errores') {
        const n = campos.filter(c => c.visible).length;
        resTitulo.textContent = 'Hay ' + plural(n, 'error', 'errores');
        resSub.textContent = 'Corrígelos y se irán tachando. Cada enlace lleva a su campo.';
      } else if (modo === 'ok') {
        resTitulo.textContent = 'Todo correcto';
        resSub.textContent = 'Las cuatro secciones están completas: ya puedes enviar la solicitud.';
      } else {
        resTitulo.textContent = 'Solicitud enviada';
        resSub.textContent = 'Hemos recibido ' + plural(E.enviados, 'campo', 'campos') + '. Revisaremos el alta del taller en dos días hábiles.';
      }
      marco.classList.add('er-abierto');
    }

    function pintaResumen() {
      const modo = calculaModo(), vis = campos.filter(c => c.visible);
      aplicaLista(vis);
      if (modo === 'errores' && modoActual === 'errores') {                                  // solo cambia la cuenta
        resTitulo.textContent = 'Hay ' + plural(vis.length, 'error', 'errores');
        return;
      }
      if (modo === modoActual) { clearTimeout(tModo); tModo = 0; return; }
      if (tModo) return;                                                                      // ya hay un cambio en camino: no se reinicia la espera
      if (modoActual === 'errores' && resLista.children.length && !quieto()) {               // primero se tacha lo último, luego cambia la hoja
        tModo = setTimeout(() => { tModo = 0; const m = calculaModo(); if (m !== modoActual) aplicaModo(m); }, 720);
      } else aplicaModo(modo);
    }

    /* ── la barra de envío y el inspector ───────────────────────────────────────────────────────────────────────── */
    function pintaBarra() {
      const vis = campos.filter(c => c.visible).length, faltan = campos.filter(c => c.msg).length;
      let e = 'falta', t;
      if (E.enviando) { e = 'listo'; t = 'Enviando la solicitud…'; }
      else if (E.enviado) { e = 'enviado'; t = '<b>Solicitud enviada.</b><span class="er-b-resto"> Todo en orden</span>'; }
      else if (vis) { e = 'mal'; t = '<b>' + plural(vis, 'error', 'errores') + '</b><span class="er-b-resto"> por corregir</span>'; }
      else if (faltan) t = 'Faltan <b>' + plural(faltan, 'campo', 'campos') + '</b><span class="er-b-resto"> por revisar</span>';
      else { e = 'listo'; t = '<b>Todo listo</b><span class="er-b-resto"> para enviar</span>'; }
      bEstado.dataset.e = e; bEstado.innerHTML = t;
      const est = E.enviando ? 'enviando' : E.enviado ? 'enviado' : '';
      btnEnviar.dataset.e = est; btnEnviar.disabled = E.enviando || E.enviado;
      enviarT.textContent = E.enviando ? 'Enviando…' : E.enviado ? 'Enviada' : 'Enviar solicitud';
      btnEnviar.setAttribute('aria-busy', E.enviando ? 'true' : 'false');
      bVer.hidden = !calculaModo();
    }

    function pintaInsp() {
      const c = E.foco;
      if (!c) return;
      const val = c.el.validity;
      inspCampo.innerHTML = '<b></b> · ' + (c.tipo === 'radio' ? 'radiogroup' : c.tipo === 'textarea' ? 'textarea' : c.tipo === 'select-one' ? 'select' : c.tipo);
      $('b', inspCampo).textContent = '#' + c.el.id;
      inspFlags.textContent = '';
      const li0 = h('li', val.valid ? 'er-v' : '', 'valid ' + val.valid); inspFlags.appendChild(li0);
      FLAGS.forEach(f => inspFlags.appendChild(h('li', val[f] ? 'er-f' : '', f)));
      inspMsg.textContent = c.msg ? '«' + c.msg + '»' : 'Sin errores en este campo.';
    }

    /* ── todo junto: se recalcula cada campo y se pinta lo que cambió ───────────────────────────────────────────── */
    function sincroniza() {
      campos.forEach(c => { c.msg = diagnostico(c); if (!c.msg) c.revelado = false; });
      campos.forEach(aplicaCampo);
      cuenta.textContent = porNombre.necesidad.el.value.trim().length;
      pintaIndice(); pintaResumen(); pintaBarra(); pintaInsp();
    }

    /* ── desplazamiento propio (con requestAnimationFrame, para que el vídeo y la página coincidan) ────────────── */
    let idScroll = 0;
    function desplazaA(y, ms) {
      cancelAnimationFrame(idScroll);
      const max = Math.max(0, document.documentElement.scrollHeight - innerHeight);
      y = Math.max(0, Math.min(max, Math.round(y)));
      const y0 = scrollY;
      if (quieto() || Math.abs(y - y0) < 2) { scrollTo(0, y); return; }
      let t0 = null;
      const paso = t => {
        if (t0 === null) t0 = t;
        const u = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - u, 3);
        scrollTo(0, y0 + (y - y0) * e);
        if (u < 1) idScroll = requestAnimationFrame(paso);
      };
      idScroll = requestAnimationFrame(paso);
    }
    // si la persona toma el control (rueda, dedo o teclas de desplazamiento), el desplazamiento propio se detiene
    ['wheel', 'touchstart'].forEach(ev => addEventListener(ev, () => cancelAnimationFrame(idScroll), { passive: true }));
    addEventListener('keydown', e => { if (/^(Arrow(Up|Down)|Page(Up|Down)|Home|End| )$/.test(e.key) && !/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) cancelAnimationFrame(idScroll); }, { passive: true });

    function iraResumen() {
      desplazaA(scrollY + marco.getBoundingClientRect().top - 24, 560);
      resumen.focus({ preventScroll: true });
    }
    function iraCampo(c) {
      const r = c.w.getBoundingClientRect(), barra = $('[data-barra]', raiz).offsetHeight;
      if (r.top < 90 || r.bottom > innerHeight - barra - 24) desplazaA(scrollY + r.top - innerHeight * .3, 560);   // si ya se ve, no se mueve nada
      c.el.focus({ preventScroll: true });
      if (/^(text|email|tel|password|textarea)$/.test(c.tipo)) c.el.select();
      c.w.classList.remove('er-pulso'); void c.w.offsetWidth; c.w.classList.add('er-pulso');
      despues(() => c.w.classList.remove('er-pulso'), 1150);
    }
    function iraSeccion(s) {
      desplazaA(scrollY + s.el.getBoundingClientRect().top - 20, 560);
      s.titulo.focus({ preventScroll: true });
    }

    /* la sección en la que estás, según el desplazamiento */
    let espiando = false;
    function espia() {
      const ref = innerHeight * .4;
      let actual = secciones[0];
      secciones.forEach(s => { if (s.el.getBoundingClientRect().top <= ref) actual = s; });
      if (innerHeight + scrollY >= document.documentElement.scrollHeight - 4) actual = secciones[secciones.length - 1];
      secciones.forEach(s => {
        const on = s === actual;
        s.li.classList.toggle('er-aqui', on);
        const a = $('a', s.li);
        if (on) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current');
      });
    }
    addEventListener('scroll', () => { if (espiando) return; espiando = true; requestAnimationFrame(() => { espiando = false; espia(); }); }, { passive: true });

    /* ── el envío: validar, y si todo está bien, esperar al «servidor» ─────────────────────────────────────────── */
    function envia() {
      E.enviando = true; pintaBarra();
      despues(() => {
        E.enviando = false;
        const datos = new FormData(form);
        const correo = String(datos.get('correo') || '').trim().toLowerCase();
        if (REGISTRADOS.indexOf(correo) >= 0) {
          const c = porNombre.correo;
          c.serv = ERROR_SERVIDOR; c.servValor = valor(c); c.tocado = true; c.revelado = true;
          sincroniza(); iraResumen();
        } else {
          E.enviados = Array.from(datos.entries()).filter(([k, v]) => String(v).trim() !== '').length;
          E.enviado = true;
          sincroniza(); iraResumen();
        }
      }, ESPERA);
    }

    function intentaEnviar() {
      if (E.enviando) return;
      E.enviado = false;
      sincroniza();
      const malos = campos.filter(c => c.msg);
      E.intento = true;
      if (malos.length) {
        malos.forEach(c => { c.tocado = true; c.revelado = true; });
        sincroniza(); iraResumen();
        return;
      }
      sincroniza(); envia();
    }

    /* ── los juegos de datos ────────────────────────────────────────────────────────────────────────────────────── */
    function cargaCaso(nombre, callado) {
      limpiaTimers(); cancelAnimationFrame(idScroll);
      $$('.er-pulso', raiz).forEach(x => x.classList.remove('er-pulso'));
      E.caso = nombre; E.intento = false; E.enviando = false; E.enviado = false; E.enviados = 0;
      const datos = CASOS[nombre] || BASE;
      campos.forEach(c => {
        c.tocado = false; c.revelado = false; c.serv = ''; c.servValor = '';
        const v = datos[c.nombre];
        if (c.tipo === 'radio') c.els.forEach(e => { e.checked = e.value === v; });
        else if (c.tipo === 'checkbox') c.el.checked = !!v;
        else c.el.value = v || '';
      });
      novedades.checked = !!datos.novedades;
      clearTimeout(tModo); tModo = 0;
      $$('li', resLista).forEach(li => { clearTimeout(li._t); li.remove(); });
      casosEl.forEach(b => b.setAttribute('aria-pressed', b.dataset.caso === nombre ? 'true' : 'false'));
      sincroniza();
      if (modoActual) aplicaModo(null);
      if (!callado) { desplazaA(0, 480); anuncia(AVISO_CASO[nombre] || ''); }
    }

    /* ── los eventos ────────────────────────────────────────────────────────────────────────────────────────────── */
    form.addEventListener('submit', e => { e.preventDefault(); intentaEnviar(); });
    const alEscribir = e => {
      const c = campoDe(e.target);
      if (!c) return;
      if (E.enviado) E.enviado = false;
      if (c.nombre === 'clave') { const r = porNombre.repite; if (r.tocado && valor(r) !== '') r.revelado = true; }   // la otra ya se había escrito: se compara al momento
      sincroniza();
    };
    form.addEventListener('input', alEscribir);
    form.addEventListener('change', alEscribir);
    form.addEventListener('focusin', e => { const c = campoDe(e.target); if (c) { E.foco = c; pintaInsp(); } });
    form.addEventListener('focusout', e => {
      const c = campoDe(e.target);
      if (!c || (e.relatedTarget && c.w.contains(e.relatedTarget))) return;                // sigue dentro del mismo campo (un grupo de radios)
      c.tocado = true; c.revelado = true;
      sincroniza();
    });

    resLista.addEventListener('click', e => {
      const a = e.target.closest('a');
      if (!a) return;
      e.preventDefault();
      const li = a.closest('li'), c = li && porNombre[li.dataset.de];
      if (c) iraCampo(c);
    });
    indiceEl.addEventListener('click', e => {
      const a = e.target.closest('a');
      if (!a) return;
      e.preventDefault();
      const s = secciones.find(x => x.li.contains(a));
      if (s) iraSeccion(s);
    });
    casosEl.forEach(b => b.addEventListener('click', () => cargaCaso(b.dataset.caso)));
    bVer.addEventListener('click', iraResumen);

    // el ojo de la contraseña: muestra u oculta las dos a la vez
    const ver = $('[data-ver]', raiz);
    ver.addEventListener('click', () => {
      const ya = ver.getAttribute('aria-pressed') === 'true', ahora = !ya;
      ver.setAttribute('aria-pressed', String(ahora));
      ver.setAttribute('aria-label', ahora ? 'Ocultar las contraseñas' : 'Mostrar las contraseñas');
      ver.title = ver.getAttribute('aria-label');
      ver.firstElementChild.firstElementChild.setAttribute('href', ahora ? '#er-i-ojo-no' : '#er-i-ojo');
      porNombre.clave.el.type = porNombre.repite.el.type = ahora ? 'text' : 'password';
      porNombre.clave.tipo = porNombre.repite.tipo = ahora ? 'text' : 'password';
    });

    document.addEventListener('keydown', e => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const t = e.target, escribe = t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) && !/^(checkbox|radio|button|submit)$/.test(t.type || '');
      if (escribe) return;
      const k = e.key.toLowerCase();
      if (k === 'r' || k === 'b') cargaCaso('borrador');
      else if (k === 'v') cargaCaso('vacio');
      else if (k === 'c') cargaCaso('correcto');
    });

    /* ── arranque ────────────────────────────────────────────────────────────────────────────────────────────────── */
    construyeIndice();
    cargaCaso(o.caso || 'borrador', true);
    espia();

    return {
      caso: cargaCaso,
      envia: intentaEnviar,
      estado() {
        return {
          modo: modoActual,
          errores: campos.filter(c => c.visible).map(c => ({ n: c.n, campo: c.nombre, mensaje: c.visible })),
          indice: secciones.map(s => ({ seccion: s.nombre, estado: s.estado, errores: s.errores })),
          foco: document.activeElement && document.activeElement.id
        };
      }
    };
  }

  window.Errata = Errata;
  const raiz = document.querySelector('[data-errata]');
  if (raiz) window.errata = Errata(raiz);
})();
