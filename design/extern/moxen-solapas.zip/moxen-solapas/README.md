# Solapas · Moxen

En una app de gestión, cada cliente o pedido que abres queda en su propia pestaña: las arrastras para ordenarlas, las cierras con la ×, y al cerrar la activa pasa a la pestaña de su derecha (o a la de su izquierda si era la última). Cuando ya no caben, las que menos usas pasan a un menú con su contador y vuelven al elegirlas; cada pestaña conserva lo que escribiste y marca con un punto los cambios sin guardar, que además quedan como borrador al cerrarla.

## Qué trae

- `index.html` — la demostración
- `solapas.css`
- `solapas.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `solapas.css` y `solapas.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

In a management app, every client or order you open gets its own tab: drag them to reorder, close them with the ×, and closing the active one moves to the tab on its right (or on its left if it was the last). When they no longer fit, the ones you use least move into a menu with a counter and come back when you pick them; each tab keeps what you typed and marks unsaved changes with a dot, and they are also kept as a draft when you close it.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
