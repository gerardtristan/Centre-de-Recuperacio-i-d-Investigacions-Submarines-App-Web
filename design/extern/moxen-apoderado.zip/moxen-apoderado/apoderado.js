/* =====================================================================
   Apoderado · Moxen
   La app de un colegio para la familia, dentro de un teléfono dibujado con un contenedor (no un marco). Las pantallas son HTML de
   verdad y se navegan con la barra de abajo: Avisos (las comunicaciones, con confirmación de lectura), Evaluaciones (el calendario
   del mes), Asistencia (el porcentaje del mes) y Firmas (las autorizaciones, que se firman con el dedo una sola vez).

   Lo que se calcula de verdad (no hay porcentajes ni estados escritos a mano en la pantalla):
   · cada mensaje se marca como leído al abrirlo. Los que piden confirmación (`requiere`) siguen «Por confirmar» hasta que tocas
     «Confirmar que lo leí»: eso guarda el día y la hora de la lectura y no se puede deshacer. La insignia de Avisos cuenta los
     mensajes pendientes: sin leer, o que piden confirmación y aún no la tienen;
   · el calendario es el mes real (los días caen en su día de la semana, con años bisiestos): cada día lleva un punto del color de
     cada asignatura evaluada, y un día con 2 o más evaluaciones se avisa como «día cargado»;
   · la asistencia es de cada mes: se recorren los días de clases (lunes a viernes menos los días sin clases) hasta hoy y cada uno
     tiene su estado (presente, atraso, ausente o ausente justificada). El porcentaje es (presentes + atrasos) ÷ días de clases,
     con una decimal y redondeo hacia arriba en el medio (85,714… → 85,7), calculado con enteros para que no haya errores de
     coma flotante. Las ausencias justificadas cuentan como ausencia. Se compara con el mínimo (85 % por defecto);
   · una autorización se firma UNA vez: eliges «Sí autorizo» o «No autorizo», firmas en el cuadro con el dedo, el ratón o el teclado
     (flechas dibujan, espacio levanta el lápiz) y «Firmar y enviar» solo se enciende con una firma de verdad (un largo mínimo).
     Al enviar queda respondida con su fecha, hora y la firma, y desde entonces la hoja solo la muestra: no se puede firmar dos
     veces. En un colegio de verdad la firma y su fecha las guarda tu servidor (`alFirmar`).

   Montaje (se inicia solo sobre [data-apoderado]; el HTML es la plantilla y los datos salen de las opciones):
     const a = Apoderado(document.querySelector('[data-apoderado]'), {
       hoy: '2026-11-11',                // la fecha de hoy, AAAA-MM-DD (la pones tú)
       ahora: '10:30',                   // la hora de hoy: es la hora que lleva la confirmación o la firma
       minimo: 85,                       // el porcentaje mínimo de asistencia
       sinClases: ['2026-11-02'],        // días de semana en que no hay clases
       asistencia: { '2026-11': 'PPAPJPP' },   // un carácter por día de clases del mes hasta hoy: P presente, A atraso, F ausente, J ausente justificada
       mensajes: [ { id, de, ico: 'libro' | 'colegio', dia: 0, hora: '08:05', titulo, texto: ['párrafo'], requiere: true, leido: false, confirmado: null } ],
       evaluaciones: [ { fecha: '2026-11-18', asig: 'len', tipo: 'Prueba', tema: 'Comprensión lectora' } ],
       autorizaciones: [ { id, ico, titulo, corto, plazo: 7, texto, firma: null } ],
       alConfirmar: mensaje => {},       // {id, cuando}: aquí va tu servidor
       alFirmar: firma => {},            // {id, respuesta: 'si' | 'no', cuando, trazos}
     });
     a.abre('reunion');   a.confirma('reunion');   a.firma('salida', { respuesta: 'si', trazos });   a.asistencia('2026-11');
     Apoderado.porcentaje(6, 7);   // → '85,7'
     a.estado();   a.reinicia();

   `asig` es una de 'mat', 'len', 'cie', 'his', 'ing' (sus colores están en el CSS). Teclado: Tab e Intro en todo, ← → entre las
   pestañas, Esc para volver o cerrar la hoja; en el cuadro de firma, las flechas dibujan. Todo lo que se mueve es transform u
   opacity. No usa Date (la fecha es aritmética) y el azar no hace falta: los datos son fijos, así que la página y el vídeo
   muestran lo mismo.
   ===================================================================== */
(function () {
  'use strict';

  /* ── las fechas, a mano ───────────────────────────────────────────
     Cada día es un número entero (días desde el 1-1-1970): sin husos horarios que corran un día, y el «hoy» lo decides tú. */
  const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const MESES_C = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const DIAS = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
  const DIAS_C = ['lun', 'mar', 'mié', 'jue', 'vie', 'sáb', 'dom'];
  const aNum = (a, m, d) => {                         // los «días civiles» de H. Hinnant
    a -= m <= 2 ? 1 : 0;
    const era = Math.floor(a / 400), ae = a - era * 400;
    const dia = Math.floor((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1;
    return era * 146097 + ae * 365 + Math.floor(ae / 4) - Math.floor(ae / 100) + dia - 719468;
  };
  const deNum = n => {
    n += 719468;
    const era = Math.floor(n / 146097), de = n - era * 146097;
    const ae = Math.floor((de - Math.floor(de / 1460) + Math.floor(de / 36524) - Math.floor(de / 146096)) / 365);
    const da = de - (365 * ae + Math.floor(ae / 4) - Math.floor(ae / 100));
    const mp = Math.floor((5 * da + 2) / 153), m = mp < 10 ? mp + 3 : mp - 9;
    return [ae + era * 400 + (m <= 2 ? 1 : 0), m, da - Math.floor((153 * mp + 2) / 5) + 1];
  };
  const dsem = n => (((n + 3) % 7) + 7) % 7;          // 0 = lunes (el 1-1-1970 fue jueves)
  const dos = v => (v < 10 ? '0' : '') + v;
  const leeISO = s => { const p = String(s).split('-').map(Number); return aNum(p[0], p[1], p[2]); };
  const iso = n => { const f = deNum(n); return f[0] + '-' + dos(f[1]) + '-' + dos(f[2]); };
  const diasDelMes = (a, m) => aNum(m === 12 ? a + 1 : a, m === 12 ? 1 : m + 1, 1) - aNum(a, m, 1);
  const may = t => t.charAt(0).toUpperCase() + t.slice(1);
  const corto = n => { const f = deNum(n); return may(DIAS_C[dsem(n)]) + ' ' + f[2] + ' ' + MESES_C[f[1] - 1]; };
  const largo = n => { const f = deNum(n); return may(DIAS[dsem(n)]) + ' ' + f[2] + ' de ' + MESES[f[1] - 1]; };
  const relativo = n => n === 0 ? 'hoy' : n === 1 ? 'mañana' : n === -1 ? 'ayer' : n > 1 ? 'en ' + n + ' días' : 'hace ' + (-n) + ' días';

  /* El porcentaje de asistencia, exacto: mil veces la fracción redondeada hacia arriba en el medio, solo con enteros
     (floor((2000·a + t) / 2t) = redondeo de 1000·a/t). Devuelve el texto con coma decimal: 85,7. */
  function porcentaje(asis, total) {
    if (!total) return '0,0';
    const d = Math.floor((2000 * asis + total) / (2 * total));
    return Math.floor(d / 10) + ',' + (d % 10);
  }

  /* ── los datos de ejemplo ─────────────────────────────────────────
     Todo es genérico: roles en vez de nombres, «Estudiante», «Curso 4.º B». */
  const MENSAJES = [
    { id: 'reunion', de: 'Profesor jefe', ico: 'libro', dia: 0, hora: '08:05', titulo: 'Reunión de apoderados', requiere: true, leido: false, confirmado: null,
      texto: ['La reunión de apoderados de 4.º B será el jueves 19 de noviembre, a las 19:00, en la sala del curso.',
        'Veremos el cierre del año y el calendario de las evaluaciones finales. Dura una hora.',
        'Confirma que leíste este aviso para que sepamos que llegó a tu casa.'] },
    { id: 'horario', de: 'Inspectoría', ico: 'colegio', dia: 0, hora: '07:40', titulo: 'Cambio de horario del viernes', requiere: false, leido: false, confirmado: null,
      texto: ['El viernes 13 las clases terminan a las 12:30 por una jornada de planificación del equipo docente.',
        'Ese día no habrá almuerzo en el colegio. Los buses de acercamiento salen a las 12:40.'] },
    { id: 'salida', de: 'Dirección', ico: 'colegio', dia: -2, hora: '12:05', titulo: 'Salida pedagógica: falta tu firma', requiere: true, leido: true, confirmado: null,
      texto: ['El viernes 20 de noviembre el curso visita un museo de ciencias, de 09:00 a 13:00.',
        'Necesitamos tu autorización firmada antes del miércoles 18. La firmas en la pestaña Firmas de esta app, con el dedo.'] },
    { id: 'materiales', de: 'Coordinación', ico: 'colegio', dia: -4, hora: '16:10', titulo: 'Materiales para Artes', requiere: false, leido: true, confirmado: null,
      texto: ['Para la próxima clase de Artes el curso necesita témperas, un pincel plano y una hoja de block grande.',
        'Si algo no se consigue, avisa al profesor y se presta en la sala.'] },
    { id: 'lenguaje', de: 'Docente de Lenguaje', ico: 'libro', dia: -6, hora: '18:42', titulo: 'Resultados de la prueba de Lenguaje', requiere: true, leido: true, confirmado: { dia: -6, hora: '18:42' },
      texto: ['Ya están publicadas las notas de la prueba de comprensión lectora. Puedes revisarlas con tu hijo o hija esta semana.',
        'La retroalimentación de cada pregunta se entrega en clase.'] },
  ];
  const ASIGNATURAS = { mat: 'Matemática', len: 'Lenguaje', cie: 'Ciencias', his: 'Historia', ing: 'Inglés' };
  const EVALUACIONES = [
    { fecha: '2026-11-05', asig: 'cie', tipo: 'Control', tema: 'Materia y sus cambios' },
    { fecha: '2026-11-09', asig: 'len', tipo: 'Prueba', tema: 'Comprensión lectora' },
    { fecha: '2026-11-12', asig: 'ing', tipo: 'Control', tema: 'Vocabulario de la unidad 8' },
    { fecha: '2026-11-16', asig: 'mat', tipo: 'Prueba', tema: 'Fracciones y proporciones' },
    { fecha: '2026-11-18', asig: 'len', tipo: 'Prueba', tema: 'Texto narrativo: personajes y ambiente' },
    { fecha: '2026-11-18', asig: 'cie', tipo: 'Control', tema: 'Circuitos eléctricos' },
    { fecha: '2026-11-24', asig: 'his', tipo: 'Entrega', tema: 'Trabajo de investigación en grupo' },
    { fecha: '2026-11-26', asig: 'mat', tipo: 'Prueba', tema: 'Geometría: ángulos y triángulos' },
    { fecha: '2026-11-26', asig: 'ing', tipo: 'Prueba', tema: 'Present perfect' },
    { fecha: '2026-11-30', asig: 'cie', tipo: 'Prueba', tema: 'Energía y movimiento' },
    { fecha: '2026-12-02', asig: 'len', tipo: 'Prueba final', tema: 'Lectura de cierre del año' },
    { fecha: '2026-12-04', asig: 'mat', tipo: 'Prueba final', tema: 'Todo el año' },
    { fecha: '2026-12-09', asig: 'his', tipo: 'Prueba final', tema: 'Unidades 1 a 4' },
  ];
  // los días sin clases y, de cada mes, un carácter por día de clases hasta hoy: P presente · A atraso · F ausente · J ausente justificada
  const SIN_CLASES = ['2026-10-12', '2026-11-02'];
  const ASISTENCIA = { '2026-10': 'PP' + 'PPAPP' + 'PFPP' + 'PPPJP' + 'PPPPP', '2026-11': 'PPAPJPP' };
  const AUTORIZACIONES = [
    { id: 'salida', ico: 'museo', titulo: 'Salida pedagógica', corto: 'Museo de ciencias · viernes 20 de noviembre', plazo: 7, firma: null,
      texto: 'El viernes 20 de noviembre, de 09:00 a 13:00, el curso visita un museo de ciencias. Viaja en un bus contratado por el colegio y vuelve a la hora de salida. Lleva colación y ropa cómoda. Autorizo que mi hijo o hija participe en la salida.' },
    { id: 'imagen', ico: 'camara', titulo: 'Uso de imágenes', corto: 'Fotos y videos de actividades del curso', plazo: 14, firma: null,
      texto: 'Autorizo que se tomen fotografías y videos de mi hijo o hija en las actividades del colegio, solo para uso interno (el muro del curso y el libro de la generación). No se publican en redes sociales.' },
    { id: 'salud', ico: 'salud', titulo: 'Ficha de salud', corto: 'Datos y contactos de emergencia', plazo: -8, firma: { respuesta: 'si', dia: -8, hora: '09:12', trazos: [[[22, 92], [34, 60], [46, 30], [56, 70], [66, 104], [78, 58], [92, 24], [104, 70], [112, 100]], [[128, 78], [160, 74], [196, 72], [236, 66], [268, 58]]] },
      texto: 'Confirmo que los datos de salud y los contactos de emergencia de la ficha del estudiante están al día.' },
  ];

  const ICONO = (id, c) => '<svg class="ap-i' + (c ? ' ' + c : '') + '" aria-hidden="true"><use href="#ap-i-' + id + '"/></svg>';
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const PAD_W = 300, PAD_H = 140, LARGO_MIN = 90;      // el cuadro de firma mide 300 × 140 y una firma necesita al menos 90 de largo

  function Apoderado(raiz, opciones) {
    const o = Object.assign({ hoy: '2026-01-05', ahora: '10:00', minimo: 85, sinClases: SIN_CLASES, asistencia: ASISTENCIA, mensajes: MENSAJES, evaluaciones: EVALUACIONES, autorizaciones: AUTORIZACIONES, alConfirmar: null, alFirmar: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const $$ = s => Array.from(raiz.querySelectorAll(s));
    const HOY = leeISO(o.hoy), HORA = o.ahora;
    const vistas = {};
    $$('[data-vista]').forEach(v => { vistas[v.dataset.vista] = v; });
    const titulo = $('[data-titulo]'), ojo = $('[data-ojo]'), reloj = $('[data-reloj]'), tabs = $('[data-tabs]'), toast = $('[data-toast]'), atras = $('[data-atras]');
    const hoja = $('[data-hoja]'), velo = $('[data-velo]'), cuerpoHoja = $('[data-hoja-cuerpo]');
    const sinClases = new Set(o.sinClases.map(leeISO));
    const TITULOS = { avisos: 'Avisos', mensaje: 'Mensaje', evaluaciones: 'Evaluaciones', asistencia: 'Asistencia', firmas: 'Autorizaciones' };
    const ORDEN = { avisos: 0, mensaje: 1, evaluaciones: 2, asistencia: 3, firmas: 4 }, TABIDX = { avisos: 0, mensaje: 0, evaluaciones: 1, asistencia: 2, firmas: 3 };
    const TABS = ['avisos', 'evaluaciones', 'asistencia', 'firmas'];

    /* ── el estado de la app ───────────────────────────────────────── */
    let actual = 'avisos', avisoT = 0, mensajes = [], firmas = [], vistoPendientes = null;
    const evals = o.evaluaciones.map(e => Object.assign({}, e, { n: leeISO(e.fecha) }));
    const meses = Object.keys(o.asistencia).sort();
    const st = { msg: null, mes: null, dia: null, asisMes: null, asisDia: null, hoja: null, resp: 'si', trazos: [], cursor: null, lapiz: true };
    const hmTxt = () => HORA;
    const sello = () => corto(HOY).toLowerCase() + ' · ' + hmTxt();
    const selloDe = (dia, hora) => corto(HOY + dia).toLowerCase() + ' · ' + hora;

    function arranca() {
      mensajes = o.mensajes.map(m => Object.assign({}, m, { confirmado: m.confirmado ? { dia: m.confirmado.dia, hora: m.confirmado.hora } : null }));
      firmas = o.autorizaciones.map(a => Object.assign({}, a, { firma: a.firma ? Object.assign({}, a.firma) : null }));
    }
    arranca();
    const fHoy = deNum(HOY);
    st.mes = [fHoy[0], fHoy[1]];
    st.asisMes = meses.indexOf(fHoy[0] + '-' + dos(fHoy[1])) >= 0 ? fHoy[0] + '-' + dos(fHoy[1]) : meses[meses.length - 1];

    /* ── navegación ────────────────────────────────────────────────── */
    function ir(v) {
      cierraHoja(true);
      if (v === actual) return;
      const nueva = vistas[v], vieja = vistas[actual], dir = ORDEN[v] > ORDEN[actual] ? 1 : -1;
      const enfoca = vieja.contains(document.activeElement) && document.activeElement.matches && document.activeElement.matches(':focus-visible');
      nueva.style.transition = 'none';
      nueva.dataset.pos = dir > 0 ? 'der' : 'izq';
      void nueva.offsetWidth;
      nueva.style.transition = '';
      nueva.dataset.pos = 'activa'; nueva.inert = false;
      vieja.dataset.pos = dir > 0 ? 'izq' : 'der'; vieja.inert = true;
      nueva.classList.remove('is-entra'); void nueva.offsetWidth; nueva.classList.add('is-entra');
      nueva.scrollTop = 0;
      actual = v;
      toast.dataset.ver = '0';
      if (v === 'asistencia') pintaAsistencia(true);
      marco();
      if (enfoca) nueva.focus({ preventScroll: true });
    }
    // la cabecera, la barra de abajo y las insignias
    function marco() {
      const t = TITULOS[actual];
      if (titulo.textContent !== t) {
        titulo.textContent = t;
        titulo.classList.remove('is-cambia'); void titulo.offsetWidth; titulo.classList.add('is-cambia');
      }
      raiz.dataset.pantalla = actual;
      const det = actual === 'mensaje';
      atras.tabIndex = det ? 0 : -1;
      const abierto = det ? mensajes.find(m => m.id === st.msg) : null;
      ojo.textContent = abierto ? 'Mensaje · ' + abierto.de : 'Estudiante · Curso 4.º B';
      tabs.style.setProperty('--ti', TABIDX[actual]);
      $$('[data-tab]').forEach(b => { if (b.dataset.tab === TABS[TABIDX[actual]]) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
      reloj.textContent = HORA;
      const pa = mensajes.filter(pendiente).length, pf = firmas.filter(f => !f.firma).length;
      const ia = $('[data-ins-avisos]'), iff = $('[data-ins-firmas]');
      ia.hidden = pa === 0; ia.textContent = pa; iff.hidden = pf === 0; iff.textContent = pf;
      $('[data-tab="avisos"]').setAttribute('aria-label', 'Avisos' + (pa ? ', ' + pa + (pa === 1 ? ' pendiente' : ' pendientes') : ''));
      $('[data-tab="firmas"]').setAttribute('aria-label', 'Firmas' + (pf ? ', ' + pf + (pf === 1 ? ' por firmar' : ' por firmar') : ''));
    }

    /* ── 1 · avisos ────────────────────────────────────────────────── */
    const pendiente = m => !m.leido || (m.requiere && !m.confirmado);
    const estadoMsg = m => (!m.leido ? 'sin' : m.requiere && !m.confirmado ? 'falta' : m.requiere ? 'confirmado' : 'leido');
    const ETIQ = { sin: 'Sin leer', falta: 'Por confirmar', confirmado: 'Confirmado', leido: 'Leído' };
    const cuando = m => m.dia === 0 ? 'Hoy · ' + m.hora : m.dia === -1 ? 'Ayer · ' + m.hora : corto(HOY + m.dia);
    const ordenados = () => mensajes.slice().sort((a, b) => b.dia - a.dia || (a.hora < b.hora ? 1 : -1));
    function htmlMsg(m, i) {
      const e = estadoMsg(m);
      const prev = m.texto[0];
      return '<li class="ap-msg" data-id="' + m.id + '" data-estado="' + e + '" style="--i:' + i + '"><button type="button" class="ap-msg-b" data-msg="' + m.id + '" aria-label="' + m.titulo + ', ' + ETIQ[e].toLowerCase() + '">' +
        '<span class="ap-msg-ico">' + ICONO(m.ico) + '</span>' +
        '<span class="ap-msg-txt"><small>' + m.de + ' · ' + cuando(m) + '</small><b>' + m.titulo + '</b><span class="ap-msg-prev">' + prev + '</span></span>' +
        '<span class="ap-eti ap-eti-' + e + '">' + (e === 'confirmado' ? ICONO('tilde') : e === 'sin' ? '<i></i>' : '') + ETIQ[e] + '</span></button></li>';
    }
    function pintaMensajes() {
      vistas.avisos.classList.remove('is-entra');          // rehacer la lista no repite la entrada en cascada (la repite `ir`)
      $('[data-mensajes]').innerHTML = ordenados().map(htmlMsg).join('');
      pintaResumen();
    }
    // al abrir o confirmar solo cambia esa fila y el resumen
    function actualizaMsg(m) {
      const li = $('[data-mensajes] [data-id="' + m.id + '"]');
      if (li) { const i = li.style.getPropertyValue('--i') || 0, nuevo = document.createElement('div'); nuevo.innerHTML = htmlMsg(m, i); li.replaceWith(nuevo.firstChild); }
      pintaResumen();
    }
    function pintaResumen() {
      const pend = mensajes.filter(pendiente).length, sin = mensajes.filter(m => !m.leido).length, falta = mensajes.filter(m => m.requiere && !m.confirmado).length;
      const el = $('[data-resumen]'), antes = el.querySelector('.ap-resumen-n b');
      const cifra = antes && antes.textContent !== String(pend) && !reduce
        ? '<b class="sale">' + antes.textContent + '</b><b class="entra">' + pend + '</b>' : '<b>' + pend + '</b>';
      el.dataset.cero = String(pend === 0);
      el.innerHTML = '<span class="ap-resumen-n">' + (pend === 0 ? ICONO('tilde') : cifra) + '</span>' +
        '<span class="ap-resumen-txt"><b>' + (pend === 0 ? 'Todo al día' : pend === 1 ? '1 mensaje pendiente' : pend + ' mensajes pendientes') + '</b>' +
        '<small>' + (pend === 0 ? 'Leíste y confirmaste todo lo que el colegio te envió.' : sin + (sin === 1 ? ' sin leer' : ' sin leer') + ' · ' + falta + (falta === 1 ? ' por confirmar' : ' por confirmar')) + '</small></span>';
    }
    function abreMensaje(id) {
      const m = mensajes.find(x => x.id === id);
      if (!m) return false;
      const era = m.leido;
      m.leido = true;
      st.msg = id;
      pintaDetalle(m);
      if (!era) actualizaMsg(m);
      ir('mensaje');
      marco();                                             // `ir` no repinta si ya estabas en un mensaje (el título y la insignia sí cambian)
      return true;
    }
    function pintaDetalle(m) {
      const conf = m.confirmado;
      const caja = !m.requiere
        ? '<p class="ap-msg-nota">' + ICONO('tilde') + 'Se marcó como leído al abrirlo.</p>'
        : conf
          ? '<div class="ap-sello is-confirmado" data-sello>' + sellar(conf) + '</div>'
          : '<div class="ap-pide"><p><b>Este aviso pide confirmación.</b> Así el colegio sabe que llegó a tu casa.</p>' +
            '<button class="ap-boton ap-boton-azul" type="button" data-confirmar>' + ICONO('tilde') + 'Confirmar que lo leí</button></div>';
      $('[data-detalle]').innerHTML = '<div class="ap-msg-de"><span class="ap-msg-ico">' + ICONO(m.ico) + '</span><span><b>' + m.de + '</b><small>' + cuando(m) + '</small></span></div>' +
        '<h2 class="ap-msg-tit">' + m.titulo + '</h2>' + m.texto.map(t => '<p class="ap-msg-p">' + t + '</p>').join('') + caja;
    }
    const sellar = c => '<span class="ap-sello-ico">' + ICONO('tilde') + '</span><span class="ap-sello-txt"><b>Lectura confirmada</b><small>' + selloDe(c.dia, c.hora) + ' · el colegio ya lo sabe</small></span>';
    function confirma(id) {
      const m = mensajes.find(x => x.id === id);
      if (!m || !m.requiere || m.confirmado || !m.leido) return false;       // solo se confirma lo que se abrió, y una vez
      m.confirmado = { dia: 0, hora: HORA };
      actualizaMsg(m); marco();
      if (actual === 'mensaje' && st.msg === id) {
        const caja = $('[data-detalle] .ap-pide');
        if (caja) { const s = document.createElement('div'); s.className = 'ap-sello is-confirmado is-nuevo'; s.dataset.sello = ''; s.innerHTML = sellar(m.confirmado); caja.replaceWith(s); }
      }
      avisa('Lectura confirmada · ' + selloDe(0, HORA));
      if (o.alConfirmar) o.alConfirmar({ id: m.id, cuando: iso(HOY) + ' ' + HORA });
      return true;
    }

    /* ── 2 · evaluaciones ──────────────────────────────────────────── */
    const evalsDe = n => evals.filter(e => e.n === n);
    function proximaEval() { const f = evals.filter(e => e.n >= HOY).sort((a, b) => a.n - b.n)[0]; return f ? f.n : null; }
    function pintaCal(nuevo) {
      const a = st.mes[0], m = st.mes[1], total = diasDelMes(a, m), primero = dsem(aNum(a, m, 1));
      $('[data-cal-titulo]').textContent = may(MESES[m - 1]) + ' ' + a;
      let h = '';
      for (let k = 0; k < primero; k++) h += '<span class="ap-cel ap-cel-vacia"></span>';
      for (let d = 1; d <= total; d++) {
        const n = aNum(a, m, d), es = evalsDe(n), fin = dsem(n) >= 5, hoy = n === HOY, sel = n === st.dia;
        const puntos = es.slice(0, 3).map(e => '<i data-asig="' + e.asig + '"></i>').join('');
        const clase = 'ap-cel' + (fin ? ' is-fin' : '') + (n < HOY ? ' is-paso' : '') + (hoy ? ' is-hoy' : '') + (sel ? ' is-sel' : '') + (es.length > 1 ? ' is-carga' : '');
        const lab = largo(n) + ': ' + (es.length ? es.length + (es.length === 1 ? ' evaluación' : ' evaluaciones') : 'sin evaluaciones');
        h += fin ? '<span class="' + clase + '" style="--k:' + d + '"><b>' + d + '</b></span>'
          : '<button type="button" class="' + clase + '" style="--k:' + d + '" data-d="' + n + '" aria-label="' + lab + '" aria-pressed="' + sel + '"><b>' + d + '</b><span class="ap-puntos">' + puntos + '</span></button>';
      }
      const cont = $('[data-cal]');
      cont.innerHTML = h;
      if (nuevo) { cont.classList.remove('is-entra'); void cont.offsetWidth; cont.classList.add('is-entra'); } else cont.classList.remove('is-entra');
      const usadas = Object.keys(ASIGNATURAS).filter(k => evals.some(e => e.asig === k));
      $('[data-leyenda]').innerHTML = usadas.map(k => '<span data-asig="' + k + '"><i></i>' + ASIGNATURAS[k] + '</span>').join('');
    }
    function pintaDia(anima) {
      const n = st.dia, el = $('[data-dia]');
      if (n === null) { el.innerHTML = ''; return; }
      const es = evalsDe(n);
      el.innerHTML = '<div class="ap-dia-cab"><h3>' + largo(n) + '</h3><span class="ap-rel">' + relativo(n - HOY) + '</span></div>' +
        (es.length > 1 ? '<p class="ap-carga">' + ICONO('reloj') + 'Día cargado: ' + es.length + ' evaluaciones. Conviene repasar desde antes.</p>' : '') +
        (es.length ? '<ul class="ap-evals">' + es.map((e, i) => '<li class="ap-eval" data-asig="' + e.asig + '" style="--i:' + i + '"><i class="ap-eval-barra"></i><span class="ap-eval-txt"><b>' + ASIGNATURAS[e.asig] + '</b><small>' + e.tema + '</small></span><span class="ap-tipo">' + e.tipo + '</span></li>').join('') + '</ul>'
          : '<p class="ap-sin">Sin evaluaciones este día.</p>');
      el.classList.remove('is-entra'); if (anima) { void el.offsetWidth; el.classList.add('is-entra'); }
    }
    function eligeDia(n) {
      st.dia = n;
      $$('[data-cal] button').forEach(b => { const s = +b.dataset.d === n; b.classList.toggle('is-sel', s); b.setAttribute('aria-pressed', String(s)); });
      pintaDia(true);
    }
    function cambiaMes(d) {
      let a = st.mes[0], m = st.mes[1] + d;
      if (m < 1) { m = 12; a--; } else if (m > 12) { m = 1; a++; }
      st.mes = [a, m];
      // el día elegido pasa al primer día con evaluaciones del mes nuevo, si lo hay
      const prim = evals.filter(e => deNum(e.n)[0] === a && deNum(e.n)[1] === m).sort((x, y) => x.n - y.n)[0];
      st.dia = prim ? prim.n : null;
      pintaCal(true); pintaDia(true);
    }

    /* ── 3 · asistencia ────────────────────────────────────────────── */
    // los días de clases de un mes: lunes a viernes menos los días sin clases; cada uno hasta hoy lleva su estado
    function diasDeClases(clave) {
      const p = clave.split('-').map(Number), a = p[0], m = p[1], total = diasDelMes(a, m), patron = o.asistencia[clave].replace(/\s/g, '');
      const out = []; let k = 0;
      for (let d = 1; d <= total; d++) {
        const n = aNum(a, m, d);
        if (dsem(n) >= 5) continue;
        if (sinClases.has(n)) { out.push({ n, e: 'S' }); continue; }
        out.push({ n, e: n <= HOY ? (patron[k++] || 'P') : 'F0' });        // F0: todavía no hay clases ese día
      }
      return out;
    }
    function cuentaMes(clave) {
      const c = { P: 0, A: 0, F: 0, J: 0 };
      diasDeClases(clave).forEach(x => { if (c[x.e] !== undefined) c[x.e]++; });
      const total = c.P + c.A + c.F + c.J, asis = c.P + c.A;
      return { P: c.P, A: c.A, F: c.F, J: c.J, total, asis, pct: porcentaje(asis, total), sobre: asis * 100 >= o.minimo * total };
    }
    const C = 2 * Math.PI * 56;
    const ESTADO_TXT = { P: 'Presente', A: 'Atraso', F: 'Ausente', J: 'Ausente justificada', S: 'Sin clases', F0: 'Aún no hay clases registradas' };
    function pintaAsistencia(anima) {
      const clave = st.asisMes, p = clave.split('-').map(Number), r = cuentaMes(clave), i = meses.indexOf(clave);
      $('[data-asis-titulo]').textContent = may(MESES[p[1] - 1]);
      $$('[data-asis-mes]').forEach(b => { const nuevo = i + +b.dataset.asisMes; b.disabled = nuevo < 0 || nuevo >= meses.length; });
      const arco = $('[data-anillo]'), frac = r.total ? r.asis / r.total : 0;
      arco.style.strokeDasharray = C.toFixed(2);
      const poner = () => { arco.style.strokeDashoffset = (C * (1 - frac)).toFixed(2); };
      if (anima && !reduce) { arco.style.transition = 'none'; arco.style.strokeDashoffset = C.toFixed(2); void arco.getBoundingClientRect(); arco.style.transition = ''; setTimeout(poner, 60); } else poner();
      $('[data-anillo-min]').setAttribute('transform', 'rotate(' + (o.minimo * 3.6) + ' 68 68)');
      $('[data-pct]').innerHTML = r.pct + '<span> %</span>';
      $('[data-asis-calculo]').innerHTML = '<b>' + r.asis + '</b> de <b>' + r.total + '</b> días de clases · ' + r.P + ' presentes + ' + r.A + (r.A === 1 ? ' atraso' : ' atrasos');
      $('[data-asis-cifras]').innerHTML =
        '<span class="ap-cifra" data-e="P"><i>' + ICONO('tilde') + '</i><b>' + r.P + '</b><small>Presentes</small></span>' +
        '<span class="ap-cifra" data-e="A"><i>' + ICONO('reloj') + '</i><b>' + r.A + '</b><small>Atrasos</small></span>' +
        '<span class="ap-cifra" data-e="F"><i>' + ICONO('x') + '</i><b>' + (r.F + r.J) + '</b><small>Ausencias' + (r.J ? ' · ' + r.J + ' justificada' : '') + '</small></span>';
      const msg = $('[data-asis-msg]');
      msg.dataset.sobre = String(r.sobre);
      msg.innerHTML = ICONO(r.sobre ? 'tilde' : 'reloj') + (r.sobre ? 'Sobre el mínimo exigido (' + o.minimo + ' %)' : 'Bajo el mínimo exigido (' + o.minimo + ' %)');
      // los días de clases, por semana
      const dias = diasDeClases(clave), filas = [];
      dias.forEach(x => { const ini = x.n - dsem(x.n); let f = filas.find(z => z.ini === ini); if (!f) { f = { ini, c: [null, null, null, null, null] }; filas.push(f); } f.c[dsem(x.n)] = x; });
      $('[data-asis-dias]').innerHTML = '<div class="ap-asis-sem" aria-hidden="true"><span>L</span><span>M</span><span>M</span><span>J</span><span>V</span></div>' +
        filas.map(f => '<div class="ap-asis-fila">' + f.c.map(x => !x ? '<span class="ap-adia ap-adia-vacia"></span>' :
          '<button type="button" class="ap-adia" data-e="' + x.e + '" data-n="' + x.n + '" aria-label="' + largo(x.n) + ': ' + ESTADO_TXT[x.e].toLowerCase() + '" aria-pressed="' + (st.asisDia === x.n) + '"><small>' + deNum(x.n)[2] + '</small><i>' +
          (x.e === 'P' ? ICONO('tilde') : x.e === 'A' ? ICONO('reloj') : x.e === 'F' ? ICONO('x') : x.e === 'J' ? '<em>J</em>' : '') + '</i></button>').join('') + '</div>').join('');
      $('[data-asis-det]').innerHTML = st.asisDia !== null && dias.some(x => x.n === st.asisDia) ? detalleDia(dias.find(x => x.n === st.asisDia)) : '';
    }
    const detalleDia = x => '<b>' + largo(x.n) + '</b> · ' + ESTADO_TXT[x.e];
    function cambiaMesAsis(d) {
      const i = meses.indexOf(st.asisMes) + d;
      if (i < 0 || i >= meses.length) return;
      st.asisMes = meses[i]; st.asisDia = null;
      pintaAsistencia(true);
    }

    /* ── 4 · firmas ────────────────────────────────────────────────── */
    const trazoD = trazos => trazos.map(t => {
      if (!t.length) return '';
      if (t.length === 1) return 'M' + t[0][0].toFixed(1) + ' ' + t[0][1].toFixed(1) + 'l.1 .1';
      let d = 'M' + t[0][0].toFixed(1) + ' ' + t[0][1].toFixed(1);
      for (let k = 1; k < t.length - 1; k++) d += ' Q' + t[k][0].toFixed(1) + ' ' + t[k][1].toFixed(1) + ' ' + ((t[k][0] + t[k + 1][0]) / 2).toFixed(1) + ' ' + ((t[k][1] + t[k + 1][1]) / 2).toFixed(1);
      return d + ' L' + t[t.length - 1][0].toFixed(1) + ' ' + t[t.length - 1][1].toFixed(1);
    }).join(' ');
    const largoDe = trazos => trazos.reduce((s, t) => s + t.reduce((u, p, k) => u + (k ? Math.hypot(p[0] - t[k - 1][0], p[1] - t[k - 1][1]) : 0), 0), 0);
    const miniatura = f => '<svg class="ap-firma-mini" viewBox="0 0 ' + PAD_W + ' ' + PAD_H + '" aria-hidden="true"><path d="' + trazoD(f.trazos) + '"/></svg>';
    const respTxt = f => (f.respuesta === 'si' ? 'Autorizado' : 'No autorizado');
    function pintaFirmas() {
      const pend = firmas.filter(f => !f.firma).length;
      $('[data-firmas-sub]').textContent = pend ? (pend === 1 ? 'Tienes 1 autorización por firmar.' : 'Tienes ' + pend + ' autorizaciones por firmar.') + ' Se firman una sola vez.' : 'Todo firmado. Ya respondiste las autorizaciones del colegio.';
      vistas.firmas.classList.remove('is-entra');
      const orden = firmas.slice().sort((a, b) => (a.firma ? 1 : 0) - (b.firma ? 1 : 0) || a.plazo - b.plazo);
      $('[data-firmas]').innerHTML = orden.map((f, i) => {
        const hecha = !!f.firma;
        return '<li class="ap-firma" data-id="' + f.id + '" data-estado="' + (hecha ? 'firmada' : 'pendiente') + '" style="--i:' + i + '"><button type="button" class="ap-firma-b" data-firma="' + f.id + '" aria-label="' + f.titulo + ', ' + (hecha ? respTxt(f.firma).toLowerCase() : 'por firmar') + '">' +
          '<span class="ap-firma-ico">' + ICONO(f.ico) + '</span>' +
          '<span class="ap-firma-txt"><b>' + f.titulo + '</b><small>' + f.corto + '</small>' +
          (hecha ? '<span class="ap-firma-fecha">' + ICONO('tilde') + respTxt(f.firma) + ' · ' + selloDe(f.firma.dia, f.firma.hora) + '</span>'
            : '<span class="ap-firma-plazo">' + ICONO('reloj') + 'Responde antes del ' + corto(HOY + f.plazo).toLowerCase() + ' · ' + relativo(f.plazo) + '</span>') + '</span>' +
          (hecha ? miniatura(f.firma) : '<span class="ap-eti ap-eti-falta">Por firmar</span>') + '</button></li>';
      }).join('');
    }
    function abreHoja(id) {
      const f = firmas.find(x => x.id === id);
      if (!f) return false;
      st.hoja = id; st.resp = 'si'; st.trazos = []; st.cursor = null; st.lapiz = true;
      pintaHoja(f);
      hoja.hidden = false; velo.hidden = false;
      void hoja.offsetWidth;
      hoja.classList.add('is-ver'); velo.classList.add('is-ver');
      vistas.firmas.inert = true; tabs.inert = true;
      focoAntes = document.activeElement;
      hoja.querySelector('[data-hoja-cierra]').focus({ preventScroll: true });
      return true;
    }
    let focoAntes = null;
    function cierraHoja(rapido) {
      if (hoja.hidden) return;
      hoja.classList.remove('is-ver'); velo.classList.remove('is-ver');
      vistas[actual].inert = false; tabs.inert = false;
      const fin = () => { hoja.hidden = true; velo.hidden = true; };
      if (rapido || reduce) fin(); else setTimeout(fin, 420);
      st.hoja = null;
      if (focoAntes && document.contains(focoAntes) && !rapido) { try { focoAntes.focus({ preventScroll: true }); } catch (e) { /* el foco ya no existe */ } }
    }
    function pintaHoja(f, gracias) {
      let h = '<p class="ap-hoja-ojo">' + (f.firma ? 'Autorización respondida' : 'Autorización') + '</p><h2 id="ap-hoja-t" class="ap-hoja-t">' + f.titulo + '</h2><p class="ap-hoja-texto">' + f.texto + '</p>';
      if (gracias) {
        h = '<div class="ap-gracias"><svg class="ap-check" viewBox="0 0 96 96" aria-hidden="true"><circle class="ap-check-onda" cx="48" cy="48" r="38"/><circle class="ap-check-aro" cx="48" cy="48" r="44" pathLength="1"/><circle class="ap-check-disco" cx="48" cy="48" r="35"/><path class="ap-check-marca" d="M31 49.500 43 61.500 66 36" pathLength="1"/></svg>' +
          '<h2 id="ap-hoja-t" class="ap-hoja-t">Autorización enviada</h2><p class="ap-hoja-texto">' + f.titulo + '</p>' +
          '<div class="ap-recibo"><div><span>Respuesta</span><b>' + respTxt(f.firma) + '</b></div><div><span>Firmada</span><b>' + selloDe(f.firma.dia, f.firma.hora) + '</b></div><div class="ap-recibo-firma"><span>Firma</span>' + miniatura(f.firma) + '</div></div>' +
          '<button class="ap-boton ap-boton-azul ap-hoja-ok" type="button" data-hoja-cierra>Listo</button></div>';
        cuerpoHoja.innerHTML = h; hoja.classList.remove('is-gracias'); void hoja.offsetWidth; hoja.classList.add('is-gracias');
        return;
      }
      if (f.firma) {
        h += '<div class="ap-recibo"><div><span>Tu respuesta</span><b>' + respTxt(f.firma) + '</b></div><div><span>Firmada</span><b>' + selloDe(f.firma.dia, f.firma.hora) + '</b></div><div class="ap-recibo-firma"><span>Firma</span>' + miniatura(f.firma) + '</div></div>' +
          '<p class="ap-hoja-ya">' + ICONO('candado') + 'Ya está firmada. Una autorización no se firma dos veces.</p>';
      } else {
        h += '<div class="ap-resp" role="radiogroup" aria-label="Tu respuesta"><i class="ap-resp-pulgar" aria-hidden="true"></i>' +
          '<button type="button" role="radio" data-resp="si" aria-checked="true">Sí autorizo</button><button type="button" role="radio" data-resp="no" aria-checked="false">No autorizo</button></div>' +
          '<div class="ap-firmar"><div class="ap-firmar-cab"><b>Firma con el dedo</b><button class="ap-link" type="button" data-borra disabled>Borrar</button></div>' +
          '<svg class="ap-pad" data-pad viewBox="0 0 ' + PAD_W + ' ' + PAD_H + '" tabindex="0" role="application" aria-label="Cuadro de firma. Con el teclado, las flechas dibujan y la barra espaciadora levanta el lápiz." aria-describedby="ap-pad-ayuda">' +
          '<line class="ap-pad-linea" x1="20" y1="104" x2="280" y2="104"/><text class="ap-pad-x" x="20" y="96">×</text><path class="ap-pad-trazo" data-trazo d=""/><circle class="ap-pad-cursor" data-cursor r="4" cx="0" cy="0" hidden/></svg>' +
          '<p class="ap-pad-ayuda" id="ap-pad-ayuda" data-ayuda>Dibuja tu firma en el cuadro.</p></div>' +
          '<button class="ap-boton ap-boton-azul" type="button" data-firmar disabled>Firmar y enviar</button>';
      }
      cuerpoHoja.innerHTML = h;
    }
    // el cuadro de firma: Pointer Events (ratón y dedo) y, con el teclado, las flechas
    const puntoDe = (pad, e) => { const r = pad.getBoundingClientRect(); return [Math.max(0, Math.min(PAD_W, (e.clientX - r.left) / r.width * PAD_W)), Math.max(0, Math.min(PAD_H, (e.clientY - r.top) / r.height * PAD_H))]; };
    let dibujando = false;
    function pintaPad() {
      const t = $('[data-trazo]');
      if (!t) return;
      t.setAttribute('d', trazoD(st.trazos));
      const largo_ = largoDe(st.trazos), ok = largo_ >= LARGO_MIN;
      const b = $('[data-firmar]'), borra = $('[data-borra]');
      if (b) b.disabled = !ok;
      if (borra) borra.disabled = st.trazos.length === 0;
      const ay = $('[data-ayuda]');
      if (ay) ay.textContent = ok ? 'Listo para firmar.' : st.trazos.length ? 'Sigue dibujando: la firma es muy corta.' : 'Dibuja tu firma en el cuadro.';
      const pad = $('[data-pad]');
      if (pad) pad.classList.toggle('is-firmado', st.trazos.length > 0);
    }
    function pintaCursor() {
      const c = $('[data-cursor]');
      if (!c) return;
      c.hidden = !st.cursor;
      if (st.cursor) { c.setAttribute('cx', st.cursor[0]); c.setAttribute('cy', st.cursor[1]); c.classList.toggle('is-baja', st.lapiz); }
    }
    function firma(id, opc) {
      const f = firmas.find(x => x.id === id);
      if (!f || f.firma) { if (f) avisa('Esa autorización ya está firmada'); return false; }                // no se firma dos veces
      const trazos = opc && opc.trazos ? opc.trazos : (st.hoja === id ? st.trazos : []);
      const resp = opc && opc.respuesta ? opc.respuesta : (st.hoja === id ? st.resp : 'si');
      if (largoDe(trazos) < LARGO_MIN) return false;                                                       // sin firma de verdad no se envía
      f.firma = { respuesta: resp === 'no' ? 'no' : 'si', dia: 0, hora: HORA, trazos: trazos.map(t => t.map(p => [+p[0].toFixed(1), +p[1].toFixed(1)])) };
      pintaFirmas(); marco();
      if (st.hoja === id) { pintaHoja(f, true); focoNuevo(); }
      if (o.alFirmar) o.alFirmar({ id: f.id, respuesta: f.firma.respuesta, cuando: iso(HOY) + ' ' + HORA, trazos: f.firma.trazos });
      return true;
    }
    const focoNuevo = () => { const b = hoja.querySelector('.ap-hoja-ok'); if (b) b.focus({ preventScroll: true }); };

    function avisa(texto) {
      toast.textContent = texto;
      toast.dataset.ver = '1';
      clearTimeout(avisoT);
      avisoT = setTimeout(() => { toast.dataset.ver = '0'; }, 2600);
    }
    function pintaTodo() { pintaMensajes(); pintaCal(false); pintaDia(false); pintaAsistencia(false); pintaFirmas(); marco(); }
    function reinicia() {
      arranca();
      const f = deNum(HOY); st.mes = [f[0], f[1]]; st.msg = null; st.asisDia = null;
      st.dia = proximaEval();
      st.asisMes = meses.indexOf(f[0] + '-' + dos(f[1])) >= 0 ? f[0] + '-' + dos(f[1]) : meses[meses.length - 1];
      st.hoja = null; st.trazos = [];
      cierraHoja(true);
      pintaTodo();
      ir('avisos');
    }

    /* ── ratón, dedo y teclado ─────────────────────────────────────── */
    raiz.addEventListener('click', e => {
      const t = e.target.closest('button');
      if (!t || t.disabled) return;
      const d = t.dataset;
      if (d.tab) return ir(d.tab);
      if ('atras' in d) return ir('avisos');
      if (d.msg) return abreMensaje(d.msg);
      if ('confirmar' in d) return confirma(st.msg);
      if (d.d) return eligeDia(+d.d);
      if (d.mes) return cambiaMes(+d.mes);
      if (d.asisMes) return cambiaMesAsis(+d.asisMes);
      if (d.n) { st.asisDia = +d.n; $$('[data-asis-dias] button').forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.n === st.asisDia))); $('[data-asis-det]').innerHTML = detalleDia(diasDeClases(st.asisMes).find(x => x.n === st.asisDia)); return; }
      if (d.firma) return abreHoja(d.firma);
      if ('hojaCierra' in d) { cierraHoja(); return; }
      if (d.resp) { st.resp = d.resp; $$('[data-resp]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.resp === st.resp))); $('.ap-resp').style.setProperty('--ri', st.resp === 'no' ? 1 : 0); return; }
      if ('borra' in d) { st.trazos = []; st.cursor = null; pintaPad(); pintaCursor(); return; }
      if ('firmar' in d) return firma(st.hoja);
    });
    velo.addEventListener('click', () => cierraHoja());
    raiz.addEventListener('pointerdown', e => {
      const pad = e.target.closest && e.target.closest('[data-pad]');
      if (!pad || (e.button !== undefined && e.button > 0)) return;
      e.preventDefault();
      try { pad.setPointerCapture(e.pointerId); } catch (x) { /* sin captura el trazo igual se dibuja */ }
      st.trazos.push([puntoDe(pad, e)]); dibujando = true; st.cursor = null; pintaCursor(); pintaPad();
      pad.focus({ preventScroll: true });
    });
    raiz.addEventListener('pointermove', e => {
      if (!dibujando) return;
      const pad = $('[data-pad]');
      if (!pad) return;
      const p = puntoDe(pad, e), t = st.trazos[st.trazos.length - 1], u = t[t.length - 1];
      if (Math.hypot(p[0] - u[0], p[1] - u[1]) < 1.2) return;
      t.push(p); pintaPad();
    });
    const sueltaPad = () => { if (dibujando) { dibujando = false; pintaPad(); } };
    raiz.addEventListener('pointerup', sueltaPad);
    raiz.addEventListener('pointercancel', sueltaPad);
    raiz.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (!hoja.hidden) { e.preventDefault(); cierraHoja(); return; }
        if (actual === 'mensaje') { e.preventDefault(); ir('avisos'); return; }
      }
      // la hoja de firma: Tab no sale de ella
      if (!hoja.hidden && e.key === 'Tab') {
        const f = Array.from(hoja.querySelectorAll('button:not([disabled]), [tabindex="0"]'));
        if (f.length) { const i = f.indexOf(document.activeElement); if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); } }
      }
      const enPad = e.target.closest && e.target.closest('[data-pad]');
      if (enPad) {
        const paso = 6, k = e.key;
        if (k === ' ' || k === 'Enter') {                       // levantar o bajar el lápiz
          e.preventDefault();
          st.lapiz = !st.lapiz;
          if (!st.cursor) st.cursor = [PAD_W / 2, PAD_H / 2];
          if (st.lapiz) st.trazos.push([st.cursor.slice()]);
          pintaCursor(); pintaPad(); return;
        }
        const dx = k === 'ArrowRight' ? paso : k === 'ArrowLeft' ? -paso : 0, dy = k === 'ArrowDown' ? paso : k === 'ArrowUp' ? -paso : 0;
        if (dx || dy) {
          e.preventDefault();
          if (!st.cursor) { st.cursor = [PAD_W / 2, PAD_H / 2]; if (st.lapiz) st.trazos.push([st.cursor.slice()]); }
          st.cursor = [Math.max(0, Math.min(PAD_W, st.cursor[0] + dx)), Math.max(0, Math.min(PAD_H, st.cursor[1] + dy))];
          if (st.lapiz) { if (!st.trazos.length) st.trazos.push([st.cursor.slice()]); st.trazos[st.trazos.length - 1].push(st.cursor.slice()); }
          pintaCursor(); pintaPad();
        }
        return;
      }
      const enTab = e.target.closest && e.target.closest('[data-tabs]');
      if (enTab && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) {
        e.preventDefault();
        const i = TABIDX[actual] + (e.key === 'ArrowRight' ? 1 : -1);
        if (i >= 0 && i < TABS.length) { ir(TABS[i]); tabs.querySelector('[data-tab="' + TABS[i] + '"]').focus(); }
      }
    });
    raiz.addEventListener('focusout', e => { if (e.target.matches && e.target.matches('[data-pad]')) { st.cursor = null; pintaCursor(); } });

    /* ── arranque ─────────────────────────────────────────────────── */
    Object.keys(vistas).forEach(k => { vistas[k].dataset.pos = k === 'avisos' ? 'activa' : 'der'; vistas[k].inert = k !== 'avisos'; vistas[k].tabIndex = -1; });
    st.dia = proximaEval();
    pintaTodo();
    vistas.avisos.classList.add('is-entra');

    return {
      abre: abreMensaje, confirma, firma, reinicia,
      asistencia: clave => { const c = cuentaMes(clave || st.asisMes); return { P: c.P, A: c.A, F: c.F, J: c.J, total: c.total, asis: c.asis, pct: c.pct, sobre: c.sobre }; },
      dias: clave => diasDeClases(clave).map(x => ({ fecha: iso(x.n), e: x.e })),
      evaluaciones: () => evals.map(e => ({ fecha: e.fecha, asig: e.asig, tipo: e.tipo })),
      mensajes: () => mensajes.map(m => ({ id: m.id, leido: m.leido, requiere: m.requiere, confirmado: !!m.confirmado, estado: estadoMsg(m) })),
      firmas: () => firmas.map(f => ({ id: f.id, firmada: !!f.firma, respuesta: f.firma ? f.firma.respuesta : null, largo: f.firma ? largoDe(f.firma.trazos) : 0 })),
      estado: () => ({ pestana: actual, msg: st.msg, mes: st.mes.join('-'), dia: st.dia === null ? null : iso(st.dia), asisMes: st.asisMes, hoja: st.hoja, pendientes: mensajes.filter(pendiente).length, porFirmar: firmas.filter(f => !f.firma).length }),
    };
  }

  Apoderado.porcentaje = porcentaje;
  window.Apoderado = Apoderado;
})();
