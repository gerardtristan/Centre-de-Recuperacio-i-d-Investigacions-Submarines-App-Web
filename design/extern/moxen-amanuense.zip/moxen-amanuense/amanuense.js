/* =====================================================================
   Amanuense · Moxen
   Un campo de mensaje que se dicta: se mantiene el micrófono y lo que se dice entra en el campo en vivo —lo provisional en gris
   claro, que el reconocedor corrige solo, y lo definitivo en tinta—, las órdenes («coma», «punto», «nuevo párrafo») se vuelven
   signos y, al soltar, el texto queda editable con las palabras dudosas subrayadas a puntos.

   · Funciona de verdad. Reconocimiento de voz del navegador (SpeechRecognition / webkitSpeechRecognition) con
     interimResults y maxAlternatives = 3, en español, inglés o francés; y getUserMedia + AnalyserNode para la onda del
     micrófono (el espectro del propio audio, no una animación). El permiso se pide al primer dictado; la voz la reconoce el
     servicio del navegador (Chrome y Edge mandan el audio a su servidor) y la demo no guarda nada.
   · Lo provisional y lo definitivo. Cada evento `result` trae una lista acumulada: los resultados con isFinal se escriben en
     tinta (con un pequeño asentado de gris a tinta, palabra a palabra) y el resto se pinta en gris en un tramo que no se puede
     editar y que se reescribe en cada evento; solo cambian las palabras que cambian.
   · Las órdenes se aplican al texto, no al audio: compone(texto, idioma, antes) lo parte en palabras, busca las frases de
     orden más largas primero («punto y coma» antes que «punto»), pone la mayúscula después de un punto o un salto y cuida los
     espacios. Cada signo salta un poco y su ficha del lado se enciende. Con Amanuense.compone() se usa solo, sin pantalla.
   · Las palabras dudosas salen de las alternativas del propio reconocedor: se alinean (LCS) la mejor y las otras palabra a
     palabra y, donde una palabra de la mejor no coincide con las demás, se subraya a puntos. Un toque abre «¿Quisiste decir…?»
     con esas alternativas; «Revisar» las recorre con el teclado. Chrome da la confianza por frase, no por palabra, por eso se
     usan las alternativas.
   · Mantener el micrófono (o Alt + Espacio) escucha mientras dura; un toque corto lo deja abierto. «Deshacer dictado» borra
     solo lo último dictado. Intro envía y Mayús + Intro hace un salto. Esc para.
   · Sin permiso, sin micrófono o sin reconocimiento de voz, la demo lo dice y explica cómo activarlo, y suena una VOZ DE
     EJEMPLO: una voz sintética que entra por el mismo camino (los mismos eventos, el mismo procesador de órdenes, las mismas
     alternativas), con su propio nivel para la onda. Así se ve cómo funciona sin hablar. El panel del lado lo dice
     («Voz de ejemplo»). Escribir sigue funcionando siempre.

   Montaje (se inicia solo sobre [data-amanuense]):
     const a = Amanuense(document.querySelector('[data-amanuense]'), { lang: 'es' });
     a.empieza();  a.suelta();  a.deshaz();  a.enviar();  a.reinicia();  a.idioma('en');  a.estado();
     Amanuense.compone('hola coma qué tal punto', 'es', '')   // el procesador de órdenes solo: [{ k: 'w'|'p'|'b', s, ti }]

   Qué cambia qué: los colores (--am-indigo, --am-coral) al principio de amanuense.css; las órdenes de cada idioma y la voz de
   ejemplo están en IDIOMAS y GUIONES de este archivo. Sin azar (la voz de ejemplo es una tabla fija); lo que se limpia al
   terminar una animación va con un setTimeout, nunca con `onfinish`. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const anima = (el, kf, op) => (quieto() || !el || !el.animate) ? null : el.animate(kf, op);
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

  /* Un resorte convertido en curva `linear()` de CSS: devuelve la curva y lo que dura. */
  const APOYA = !!(window.CSS && CSS.supports && CSS.supports('transition-timing-function', 'linear(0, 1)'));
  function muelle(k, c) {
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const n = 40, out = [];
    for (let i = 0; i < n + 1; i++) out.push(pts[Math.round(i / n * (pts.length - 1))].toFixed(4));
    out[n] = '1';
    return { curva: APOYA ? 'linear(' + out.join(', ') + ')' : 'cubic-bezier(.34, 1.4, .64, 1)', ms: Math.round(t * 1000) };
  }
  const R1 = muelle(240, 20);      // el micrófono que se abre, la ventana de dudas
  const R2 = muelle(330, 15);      // el salto de los signos

  /* =====================================================================
     Idiomas y órdenes de voz
     ===================================================================== */
  const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9' ]/g, '');
  const IDIOMAS = {
    es: {
      nombre: 'Español', bcp: 'es-ES',
      cmds: [
        { f: 'punto y coma', s: ';', t: 'p', id: 'puntoycoma' }, { f: 'dos puntos', s: ':', t: 'p', id: 'dos' },
        { f: 'puntos suspensivos', s: '…', t: 'p', id: 'susp' },
        { f: 'signo de interrogacion', s: '?', t: 'p', id: 'pregunta' }, { f: 'interrogacion', s: '?', t: 'p', id: 'pregunta' },
        { f: 'signo de exclamacion', s: '!', t: 'p', id: 'exclama' }, { f: 'exclamacion', s: '!', t: 'p', id: 'exclama' },
        { f: 'nuevo parrafo', s: '\n\n', t: 'b', id: 'parrafo' }, { f: 'nueva linea', s: '\n', t: 'b', id: 'linea' },
        { f: 'coma', s: ',', t: 'p', id: 'coma' }, { f: 'punto', s: '.', t: 'p', id: 'punto' }
      ],
      chips: [['coma', ',', 'coma'], ['punto', '.', 'punto'], ['dos puntos', ':', 'dos'], ['interrogación', '?', 'pregunta'], ['nueva línea', '↵', 'linea'], ['nuevo párrafo', '¶', 'parrafo']]
    },
    en: {
      nombre: 'English', bcp: 'en-US',
      cmds: [
        { f: 'new paragraph', s: '\n\n', t: 'b', id: 'parrafo' }, { f: 'new line', s: '\n', t: 'b', id: 'linea' },
        { f: 'question mark', s: '?', t: 'p', id: 'pregunta' }, { f: 'exclamation mark', s: '!', t: 'p', id: 'exclama' },
        { f: 'semicolon', s: ';', t: 'p', id: 'puntoycoma' }, { f: 'colon', s: ':', t: 'p', id: 'dos' },
        { f: 'full stop', s: '.', t: 'p', id: 'punto' }, { f: 'period', s: '.', t: 'p', id: 'punto' }, { f: 'comma', s: ',', t: 'p', id: 'coma' }
      ],
      chips: [['comma', ',', 'coma'], ['period', '.', 'punto'], ['colon', ':', 'dos'], ['question mark', '?', 'pregunta'], ['new line', '↵', 'linea'], ['new paragraph', '¶', 'parrafo']]
    },
    fr: {
      nombre: 'Français', bcp: 'fr-FR',
      cmds: [
        { f: 'nouveau paragraphe', s: '\n\n', t: 'b', id: 'parrafo' }, { f: 'nouvelle ligne', s: '\n', t: 'b', id: 'linea' }, { f: 'a la ligne', s: '\n', t: 'b', id: 'linea' },
        { f: "point d'interrogation", s: '?', t: 'p', id: 'pregunta' }, { f: "point d'exclamation", s: '!', t: 'p', id: 'exclama' },
        { f: 'point virgule', s: ';', t: 'p', id: 'puntoycoma' }, { f: 'deux points', s: ':', t: 'p', id: 'dos' },
        { f: 'virgule', s: ',', t: 'p', id: 'coma' }, { f: 'point', s: '.', t: 'p', id: 'punto' }
      ],
      chips: [['virgule', ',', 'coma'], ['point', '.', 'punto'], ['deux-points', ':', 'dos'], ["point d'interr.", '?', 'pregunta'], ['à la ligne', '↵', 'linea'], ['nouveau paragraphe', '¶', 'parrafo']]
    }
  };
  Object.keys(IDIOMAS).forEach(k => {
    IDIOMAS[k].cmds.forEach(c => { c.n = c.f.split(' '); });
    IDIOMAS[k].cmds.sort((a, b) => b.n.length - a.n.length);   // la frase más larga gana
    IDIOMAS[k].palabras = new Set(IDIOMAS[k].cmds.reduce((r, c) => r.concat(c.n), []));
  });

  /* =====================================================================
     El procesador de órdenes: de lo que oyó el reconocedor a palabras, signos y saltos
     ===================================================================== */
  const mayus = w => w ? w.charAt(0).toUpperCase() + w.slice(1) : w;
  function compone(texto, lang, antes) {
    const L = IDIOMAS[lang] || IDIOMAS.es;
    const toks = String(texto || '').trim().split(/\s+/).filter(Boolean);
    const nt = toks.map(norm);
    antes = antes || '';
    // ¿hay que abrir con mayúscula?, ¿hace falta un espacio antes de la palabra?
    let capital = !antes.trim() || /[.!?…]\s*$/.test(antes) || /\n\s*$/.test(antes);
    let espacio = !!antes && !/\s$/.test(antes);
    const items = [];
    for (let i = 0; i < toks.length;) {
      const orden = L.cmds.find(c => c.n.every((p, j) => nt[i + j] === p));
      if (orden) {
        if (orden.t === 'p') { items.push({ k: 'p', s: orden.s, id: orden.id, ti: i }); espacio = true; capital = /[.!?…]/.test(orden.s); }
        else { items.push({ k: 'b', s: orden.s, id: orden.id, ti: i }); espacio = false; capital = true; }
        i += orden.n.length;
      } else {
        items.push({ k: 'w', s: capital ? mayus(toks[i]) : toks[i], sp: espacio, ti: i });
        espacio = true; capital = false; i++;
      }
    }
    return items;
  }

  /* Palabras dudosas: se alinea la mejor alternativa con las otras (LCS) y, donde la mejor tiene una sola palabra que
     las demás cambian por una o dos, esa palabra es dudosa y lo que dicen las otras son sus alternativas. */
  function calculaDudas(alts, lang) {
    const out = {};
    if (!alts || alts.length < 2) return out;
    const L = IDIOMAS[lang] || IDIOMAS.es;
    const base = alts[0].t.split(/\s+/).filter(Boolean), B = base.map(w => w.toLowerCase());
    for (let k = 1; k < alts.length; k++) {
      const A = alts[k].t.split(/\s+/).filter(Boolean), N = A.map(w => w.toLowerCase());
      const n = B.length, m = N.length;
      const T = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
      for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) T[i][j] = B[i] === N[j] ? T[i + 1][j + 1] + 1 : Math.max(T[i + 1][j], T[i][j + 1]);
      let i = 0, j = 0, gi = [], gj = [];
      const cierra = () => {
        if (gi.length === 1 && gj.length >= 1 && gj.length <= 2 && !L.palabras.has(norm(B[gi[0]]))) {
          const t = gj.map(x => A[x]).join(' ');
          const l = out[gi[0]] || (out[gi[0]] = []);
          if (t.toLowerCase() !== B[gi[0]] && l.indexOf(t) < 0) l.push(t);
        }
        gi = []; gj = [];
      };
      while (i < n && j < m) {
        if (B[i] === N[j]) { cierra(); i++; j++; }
        else if (T[i + 1][j] >= T[i][j + 1]) gi.push(i++);
        else gj.push(j++);
      }
      while (i < n) gi.push(i++);
      while (j < m) gj.push(j++);
      cierra();
    }
    return out;
  }

  /* El texto plano de un nodo o fragmento, sin lo provisional. */
  function plano(n) {
    let s = '';
    const rec = x => {
      if (x.nodeType === 3) s += x.data;
      else if (x.nodeType === 1) { if (x.classList.contains('am-prov')) return; if (x.tagName === 'BR') s += '\n'; x.childNodes.forEach(rec); }
      else if (x.nodeType === 11) x.childNodes.forEach(rec);
    };
    rec(n);
    return s;
  }

  /* =====================================================================
     La voz de ejemplo: la misma lista de resultados que da el navegador, sacada de una tabla
     ===================================================================== */
  const GUIONES = {
    es: {
      tokens: 'sí coma te la mando hoy punto nuevo párrafo falta revisar el contraste del botón punto'.split(' '),
      cortes: [7, 16],
      borrador: { mando: 'mandó', revisar: 'rebi', contraste: 'con trans', botón: 'bot' },
      variantes: { 4: ['mandó', 'mandé'], 12: ['con traste'] }
    },
    en: {
      tokens: 'yes comma I will send it today period new paragraph the button contrast still needs checking period'.split(' '),
      cortes: [8, 17],
      borrador: { send: 'sen', contrast: 'con', checking: 'check' },
      variantes: { 4: ['sent'], 12: ['contract'] }
    },
    fr: {
      tokens: "oui virgule je te l'envoie aujourd'hui point nouveau paragraphe il reste à vérifier le contraste du bouton point".split(' '),
      cortes: [7, 18],
      borrador: { "l'envoie": "l'en", contraste: 'con', vérifier: 'vérif' },
      variantes: { 4: ["l'envoi"], 14: ['contrat'] }
    }
  };

  function creaEjemplo(lang, alEvento) {
    const G = GUIONES[lang] || GUIONES.es, T = G.tokens;
    const dur = T.map(t => .08 + .024 * t.length);
    const ini = [], fin = [];
    let c = .1;
    T.forEach((t, i) => { ini[i] = c; c += dur[i]; fin[i] = c; c += G.cortes.indexOf(i + 1) >= 0 ? .18 : .02; });
    // las alternativas de un tramo: la mejor y una por cada variante que cae dentro
    const alternativas = (a, b) => {
      const mejor = T.slice(a, b).join(' ');
      const alts = [{ transcript: mejor, confidence: .94 }];
      let k = 0;
      while (true) {
        const t = T.slice(a, b);
        let hay = false;
        Object.keys(G.variantes).forEach(g => {
          const i = +g - a, v = G.variantes[g][k];
          if (i >= 0 && i < t.length && v) { t[i] = v; hay = true; }
        });
        if (!hay) break;
        alts.push({ transcript: t.join(' '), confidence: +(.74 - .17 * k).toFixed(2) });
        k++;
      }
      return alts;
    };
    // la línea de tiempo de eventos
    const eventos = [];
    G.cortes.forEach((hasta, s) => {
      const a = s ? G.cortes[s - 1] : 0;
      for (let i = a; i < hasta; i++) {
        const previo = T.slice(a, i).join(' ');
        eventos.push({ t: ini[i] + dur[i] * .5, parcial: (previo ? previo + ' ' : '') + (G.borrador[T[i]] || T[i]) });
        eventos.push({ t: fin[i], parcial: T.slice(a, i + 1).join(' ') });
      }
      eventos.push({ t: fin[hasta - 1] + .2, final: s });
    });
    eventos.sort((x, y) => x.t - y.t);
    const finales = [];
    let t = 0, k = 0, parcialActual = '', muerta = false;
    const emite = (indice, parcial) => {
      const res = finales.slice();
      if (parcial) res.push(Object.assign([{ transcript: parcial, confidence: 0 }], { isFinal: false }));
      alEvento({ resultIndex: indice, results: res });
    };
    return {
      tipo: 'ejemplo',
      tick(dt) {
        if (muerta) return;
        t += dt;
        while (k < eventos.length && eventos[k].t <= t) {
          const e = eventos[k++];
          if (e.final != null) {
            const a = e.final ? G.cortes[e.final - 1] : 0, b = G.cortes[e.final];
            finales.push(Object.assign(alternativas(a, b), { isFinal: true }));
            parcialActual = '';
            emite(finales.length - 1, '');
          } else { parcialActual = e.parcial; emite(finales.length, e.parcial); }
        }
      },
      // el nivel de cada barra: una loma por palabra y un poco de variedad entre barras
      nivel(out) {
        let e = .03;
        for (let i = 0; i < T.length; i++) {
          if (t >= ini[i] && t <= fin[i]) { const u = (t - ini[i]) / dur[i]; e = Math.pow(Math.sin(Math.PI * u), .6) * (.55 + .4 * Math.abs(Math.sin(i * 2.7 + 1))); break; }
        }
        for (let j = 0; j < out.length; j++) out[j] = lim(e * (.5 + .5 * Math.abs(Math.sin(t * 11 + j * 1.9 + e * 3))) * (1 - Math.abs(j - (out.length - 1) / 2) / out.length * .7) + .02, 0, 1);
      },
      // al soltar, lo que quedaba provisional se da por definitivo, como hace el navegador
      para() {
        muerta = true;
        if (parcialActual) {
          finales.push(Object.assign([{ transcript: parcialActual, confidence: .9 }], { isFinal: true }));
          parcialActual = '';
          emite(finales.length - 1, '');
        }
      }
    };
  }

  /* =====================================================================
     El componente
     ===================================================================== */
  const AVISOS = {
    negado: '<b>El navegador no dio permiso al micrófono.</b> Pulsa el candado junto a la dirección, elige Micrófono y Permitir, y vuelve a intentarlo. Suena una voz de ejemplo y puedes escribir.',
    soporte: '<b>Este navegador no trae reconocimiento de voz</b> (Chrome y Edge sí). Suena una voz de ejemplo para ver cómo funciona; escribir sigue disponible.',
    mic: '<b>No se encontró ningún micrófono.</b> Conecta uno y vuelve a intentarlo. Suena una voz de ejemplo y puedes escribir.',
    red: '<b>El reconocimiento necesita conexión:</b> el navegador manda el audio a su servicio de voz. Revisa la red y vuelve a intentarlo.',
    servicio: '<b>El servicio de voz del navegador no respondió.</b> Puedes volver a intentarlo o escribir; la voz de ejemplo sigue disponible.'
  };
  const NB = 11;

  function Amanuense(raiz, opciones) {
    const o = Object.assign({ lang: 'es', alEnviar: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const campo = $('[data-campo]'), caja = $('[data-caja]'), mic = $('[data-mic]'), tiempoEl = $('[data-tiempo]');
    const barrasEl = $('[data-barras]'), hilo = $('[data-hilo]'), enviarBtn = $('[data-enviar]');
    const btnIdioma = $('[data-idioma]'), idiomaT = $('[data-idioma-t]'), menu = $('[data-menu]');
    const btnRevisar = $('[data-revisar]'), revisarT = $('[data-revisar-t]'), btnDeshacer = $('[data-deshacer]');
    const aviso = $('[data-aviso]'), avisoT = $('[data-aviso-t]'), pista = $('[data-pista]');
    const ordenesEl = $('[data-ordenes]'), registro = $('[data-registro]');
    const fuenteT = $('[data-fuente]'), fuentePto = $('[data-fuente-pto]'), fuenteBox = fuentePto.parentNode;
    const pop = $('[data-pop]'), popO = $('[data-pop-o]'), popOk = $('[data-pop-ok]'), app = pop.parentNode;
    const anuncio = $('[data-anuncio]');
    raiz.style.setProperty('--am-r1', R1.curva);
    raiz.style.setProperty('--am-r2', R2.curva);

    let lang = IDIOMAS[o.lang] ? o.lang : 'es';
    let estado = 'quieto';                  // quieto · escucha · fijo · cierra
    let fuente = null, generacion = 0;
    let ses = null, prov = null, provPrev = [];
    let sesiones = [];
    let apretado = false, vinoDeTecla = false, t0 = 0;
    let rafId = 0, ultTs = 0, tiempo = 0, segPintado = -1;
    let ultimaSel = null, regParcial = null, popPalabra = null, popTeclado = false, interinoRaw = '';
    let avisoMostrado = {}, hiloVacio = hilo.innerHTML, cierraT = 0, permiso = 'prompt';
    // el estado del permiso se sabe antes de pedirlo: así no se espera a que el navegador lo rechace
    if (navigator.permissions && navigator.permissions.query) {
      navigator.permissions.query({ name: 'microphone' }).then(p => { permiso = p.state; p.onchange = () => { permiso = p.state; }; }).catch(() => {});
    }
    const barras = [], niveles = new Array(NB).fill(0), alturas = new Array(NB).fill(0), encendidas = {};
    for (let i = 0; i < NB; i++) { const b = document.createElement('i'); barrasEl.appendChild(b); barras.push(b); }

    const anuncia = t => { anuncio.textContent = ''; setTimeout(() => { anuncio.textContent = t; }, 40); };

    /* ── las fichas de órdenes, según el idioma ─────────────────────── */
    function pintaOrdenes() {
      ordenesEl.replaceChildren();
      IDIOMAS[lang].chips.forEach(([txt, sim, id]) => {
        const li = h('li', 'am-ord'); li.dataset.id = id;
        li.append(h('span', null, txt), h('b', null, sim));
        li.title = '«' + txt + '» escribe ' + (sim === '↵' ? 'un salto de línea' : sim === '¶' ? 'un párrafo nuevo' : sim);
        ordenesEl.appendChild(li);
      });
      idiomaT.textContent = IDIOMAS[lang].nombre;
      btnIdioma.setAttribute('aria-label', 'Idioma del dictado: ' + IDIOMAS[lang].nombre);
      menu.querySelectorAll('[data-lang]').forEach(b => b.setAttribute('aria-checked', b.dataset.lang === lang ? 'true' : 'false'));
    }
    function enciende(id) {
      const li = ordenesEl.querySelector('[data-id="' + id + '"]');
      if (!li) return;
      li.dataset.on = '1';
      anima(li, [{ transform: 'scale(.94)' }, { transform: 'scale(1.06)', offset: .4 }, { transform: 'none' }], { duration: 520, easing: R2.curva });
      clearTimeout(encendidas[id]);
      encendidas[id] = setTimeout(() => { li.dataset.on = '0'; }, 1700);
    }

    /* ── el registro de lo que oye el reconocedor ───────────────────── */
    const fmtC = c => c.toFixed(2).replace('.', ',');
    function lineaReg(tipo, texto, conf, nAlt) {
      const li = h('li', 'am-reg'); li.dataset.t = tipo;
      li.append(h('small', null, tipo), h('p', null, texto), h('em', null, conf == null ? '' : fmtC(conf)));
      if (conf != null) {
        if (conf < .8) li.dataset.baja = '1';
        const c = h('div', 'am-conf'), pista = h('i'), b = h('b');
        b.style.width = Math.round(conf * 100) + '%';
        pista.appendChild(b);
        c.append(pista, h('small', null, (nAlt || 1) + (nAlt === 1 || !nAlt ? ' alternativa' : ' alternativas')));
        li.appendChild(c);
      }
      return li;
    }
    function recorta() { while (registro.children.length > 4) registro.lastElementChild.remove(); }
    function logParcial(texto) {
      if (!texto) { if (regParcial) { regParcial.remove(); regParcial = null; } return; }
      if (!regParcial) { regParcial = lineaReg('parcial', texto, null); registro.prepend(regParcial); recorta(); }
      else regParcial.querySelector('p').textContent = texto;
    }
    function logFinal(texto, conf, nAlt) {
      const li = lineaReg('final', texto, conf, nAlt);
      if (regParcial) { regParcial.replaceWith(li); regParcial = null; } else { registro.prepend(li); recorta(); }
    }
    function pintaFuente(tipo) {
      fuenteBox.dataset.e = tipo || '';
      fuenteT.textContent = tipo === 'real' ? 'Micrófono · ' + IDIOMAS[lang].bcp : tipo === 'ejemplo' ? 'Voz de ejemplo · ' + IDIOMAS[lang].bcp : 'Esperando la voz';
    }

    /* ── el campo ───────────────────────────────────────────────────── */
    const colocaCaret = () => {
      if (!ses || !ses.isConnected) return;
      const r = document.createRange(), s = getSelection();
      r.setStartAfter(ses); r.collapse(true);
      s.removeAllRanges(); s.addRange(r);
    };
    document.addEventListener('selectionchange', () => {
      const s = getSelection();
      if (s.rangeCount && campo.contains(s.anchorNode)) ultimaSel = s.getRangeAt(0).cloneRange();
    });
    function limpia() { if (!plano(campo).length && !campo.querySelector('.am-ses') && campo.childNodes.length) campo.replaceChildren(); }
    function actualiza() {
      limpia();
      enviarBtn.disabled = !plano(campo).trim() || estado === 'cierra';
      const dudas = campo.querySelectorAll('[data-alt]').length;
      const ocupado = estado === 'escucha' || estado === 'fijo';
      btnRevisar.hidden = !dudas || ocupado;
      revisarT.textContent = 'Revisar ' + dudas + (dudas === 1 ? ' duda' : ' dudas');
      while (sesiones.length && !sesiones[sesiones.length - 1].isConnected) sesiones.pop();
      btnDeshacer.hidden = !sesiones.length || ocupado;
    }
    campo.addEventListener('input', () => { actualiza(); });
    const antesDe = nodo => {
      const r = document.createRange();
      r.setStart(campo, 0); r.setEndBefore(nodo);
      return plano(r.cloneContents());
    };

    /* El punto donde entra el dictado: donde estaba el cursor, o al final; nunca dentro de una palabra ya dictada. */
    function preparaSesion(conCaret) {
      let r;
      if (ultimaSel && campo.contains(ultimaSel.startContainer)) r = ultimaSel.cloneRange();
      else { r = document.createRange(); r.selectNodeContents(campo); r.collapse(false); }
      const n = r.startContainer, el = n.nodeType === 1 ? n : n.parentElement;
      const pal = el && el.closest && el.closest('.am-w, .am-sg');
      if (pal && campo.contains(pal)) { r.setStartAfter(pal); r.collapse(true); }
      ses = h('span', 'am-ses');
      prov = h('span', 'am-prov'); prov.contentEditable = 'false';
      ses.appendChild(prov);
      r.insertNode(ses);
      provPrev = [];
      if (conCaret) { campo.focus({ preventScroll: true }); colocaCaret(); }
    }

    /* Palabras y signos como nodos. */
    function nodos(items, dudas) {
      const f = document.createDocumentFragment();
      items.forEach(it => {
        if (it.k === 'w') {
          if (it.sp) f.appendChild(document.createTextNode(' '));
          const s = h('span', 'am-w', it.s);
          if (dudas && dudas[it.ti]) s.dataset.alt = dudas[it.ti].join('|');
          f.appendChild(s);
        } else if (it.k === 'p') f.appendChild(h('span', 'am-sg', it.s));
        else f.appendChild(document.createTextNode(it.s));
      });
      return f;
    }

    /* Lo provisional: gris, reescrito en cada evento; solo se anima lo que cambió. */
    function actualizaProv(texto) {
      const txt = (texto || '').trim();
      interinoRaw = txt;
      logParcial(txt);
      if (!ses || !prov.isConnected) return;
      if (!txt) { prov.replaceChildren(); provPrev = []; return; }
      const items = compone(txt, lang, antesDe(prov));
      const f = nodos(items, null);
      const cambiadas = [];
      items.forEach((it, j) => { if (provPrev[j] !== it.s) cambiadas.push(j); });
      prov.replaceChildren(f);
      const spans = prov.querySelectorAll('.am-w, .am-sg');
      let n = 0;
      items.forEach((it, j) => {
        if (it.k === 'b') return;
        const el = spans[n++];
        if (el && cambiadas.indexOf(j) >= 0) anima(el, [{ opacity: .25, transform: 'translateY(3px)' }, { opacity: 1, transform: 'none' }], { duration: 220, easing: 'cubic-bezier(.22,1,.36,1)' });
      });
      provPrev = items.map(it => it.s);
      if (document.activeElement === campo) colocaCaret();
      campo.scrollTop = campo.scrollHeight;
    }

    /* Lo definitivo: tinta, con un asentado de gris a tinta palabra a palabra y un salto en cada signo. */
    function asienta(seg) {
      if (quieto()) return;
      let i = 0;
      seg.querySelectorAll('.am-w, .am-sg').forEach(el => {
        const delay = Math.min(i, 16) * 52;
        if (el.classList.contains('am-sg')) {
          anima(el, [
            { transform: 'translateY(0) scale(1)', color: 'var(--am-prov)', backgroundColor: 'transparent' },
            { transform: 'translateY(-13px) scale(1.9)', color: 'var(--am-coral-tx)', backgroundColor: 'var(--am-coral-suave)', offset: .36 },
            { transform: 'translateY(1px) scale(1)', color: 'var(--am-coral-tx)', backgroundColor: 'var(--am-coral-suave)', offset: .62 },
            { transform: 'translateY(0) scale(1)', color: 'var(--am-tinta)', backgroundColor: 'transparent' }],
            { duration: 760, delay, easing: R2.curva, fill: 'backwards' });
        } else {
          // la palabra se «entinta»: un resalte índigo la recorre y el gris pasa a tinta
          anima(el, [
            { color: 'var(--am-prov)', backgroundColor: 'transparent' },
            { color: 'var(--am-prov)', backgroundColor: 'var(--am-indigo-suave)', offset: .3 },
            { color: 'var(--am-tinta)', backgroundColor: 'var(--am-indigo-suave)', offset: .55 },
            { color: 'var(--am-tinta)', backgroundColor: 'transparent' }],
            { duration: 760, delay, easing: 'ease-out', fill: 'backwards' });
        }
        i++;
      });
    }
    function confirma(r) {
      const alts = Array.from(r, a => ({ t: a.transcript.trim(), c: a.confidence }));
      const texto = alts[0] ? alts[0].t : '';
      if (!texto || !ses) return;
      const items = compone(texto, lang, antesDe(prov));
      const dudas = calculaDudas(alts, lang);
      const seg = h('span', 'am-seg');
      seg.appendChild(nodos(items, dudas));
      ses.insertBefore(seg, prov);
      asienta(seg);
      prov.replaceChildren(); provPrev = []; interinoRaw = '';
      logFinal(texto, alts[0].c, alts.length);
      items.forEach(it => { if (it.id) enciende(it.id); });
      if (document.activeElement === campo) colocaCaret();
      campo.scrollTop = campo.scrollHeight;
      actualiza();
    }

    /* El evento del reconocedor, tal cual lo da el navegador (o la voz de ejemplo). */
    function alResultado(ev) {
      if (!ses) return;
      let interino = '';
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const r = ev.results[i];
        if (r.isFinal) { confirma(r); interino = ''; }
        else interino += (interino ? ' ' : '') + r[0].transcript.trim();
      }
      actualizaProv(interino);
    }

    /* ── el aviso ───────────────────────────────────────────────────── */
    function avisa(clave) {
      if (avisoMostrado[clave]) return;
      avisoMostrado[clave] = true;
      avisoT.innerHTML = AVISOS[clave];
      aviso.hidden = false; pista.hidden = true;
      anima(aviso, [{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 420, easing: 'cubic-bezier(.22,1,.36,1)' });
    }
    const cierraAviso = () => { aviso.hidden = true; pista.hidden = false; };
    $('[data-aviso-x]').addEventListener('click', cierraAviso);

    /* ── la fuente de voz ───────────────────────────────────────────── */
    async function creaReal() {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      const AC = window.AudioContext || window.webkitAudioContext;
      const ctx = new AC();
      if (ctx.state === 'suspended') ctx.resume();
      const an = ctx.createAnalyser();
      an.fftSize = 512; an.smoothingTimeConstant = .5;
      ctx.createMediaStreamSource(stream).connect(an);
      const buf = new Uint8Array(an.frequencyBinCount);
      const rec = new SR();
      rec.lang = IDIOMAS[lang].bcp; rec.continuous = true; rec.interimResults = true; rec.maxAlternatives = 3;
      let vivo = true;
      rec.onresult = ev => alResultado(ev);
      rec.onerror = ev => {
        if (ev.error === 'no-speech' || ev.error === 'aborted') return;
        if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') avisa('negado');
        else if (ev.error === 'network') avisa('red');
        else if (ev.error === 'audio-capture') avisa('mic');
        else avisa('servicio');
      };
      rec.onend = () => {
        if (vivo && (estado === 'escucha' || estado === 'fijo')) { try { rec.start(); } catch (e) { /* ya está en marcha */ } }
        else if (estado === 'cierra') cierra();
      };
      rec.start();
      return {
        tipo: 'real',
        tick() {},
        nivel(out) {
          an.getByteFrequencyData(buf);
          const lo = 2, hi = 60;
          for (let j = 0; j < out.length; j++) {
            const a = Math.floor(lo + (hi - lo) * Math.pow(j / out.length, 1.4));
            const b = Math.max(a + 1, Math.floor(lo + (hi - lo) * Math.pow((j + 1) / out.length, 1.4)));
            let s = 0;
            for (let k = a; k < b; k++) s += buf[k];
            out[j] = lim(Math.pow(s / (b - a) / 175, 1.15), 0, 1);
          }
        },
        para() {
          vivo = false;
          try { rec.stop(); } catch (e) { /* ya parado */ }
          stream.getTracks().forEach(t => t.stop());
          setTimeout(() => { if (ctx.close) ctx.close(); }, 800);
        }
      };
    }
    async function creaFuente() {
      if (!SR) { avisa('soporte'); return creaEjemplo(lang, alResultado); }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { avisa('mic'); return creaEjemplo(lang, alResultado); }
      if (permiso === 'denied') { avisa('negado'); return creaEjemplo(lang, alResultado); }
      try { return await creaReal(); }
      catch (e) {
        const n = e && e.name;
        if (n === 'NotAllowedError' || n === 'SecurityError') avisa('negado');
        else if (n === 'NotFoundError' || n === 'OverconstrainedError') avisa('mic');
        else avisa('servicio');
        return creaEjemplo(lang, alResultado);
      }
    }

    /* ── escuchar ───────────────────────────────────────────────────── */
    function fijaEstado(e) {
      estado = e;
      mic.dataset.e = e;
      mic.setAttribute('aria-pressed', e === 'escucha' || e === 'fijo' ? 'true' : 'false');
      caja.dataset.escucha = e === 'escucha' || e === 'fijo' ? '1' : '0';
      raiz.dataset.estado = e;
    }
    function bucle(ts) {
      rafId = requestAnimationFrame(bucle);
      const dt = Math.min(.05, (ts - (ultTs || ts)) / 1000);
      ultTs = ts;
      if (estado === 'escucha' || estado === 'fijo') {
        tiempo += dt;
        const s = Math.floor(tiempo);
        if (s !== segPintado) { segPintado = s; tiempoEl.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
      }
      if (fuente && estado !== 'quieto') { fuente.tick(dt); if (estado !== 'cierra') fuente.nivel(niveles); else niveles.fill(0); }
      else niveles.fill(0);
      let max = 0;
      for (let j = 0; j < NB; j++) {
        alturas[j] += (niveles[j] - alturas[j]) * (niveles[j] > alturas[j] ? .6 : .2);
        max = Math.max(max, alturas[j]);
        barras[j].style.transform = 'scaleY(' + (.1 + .9 * alturas[j]).toFixed(3) + ')';
      }
      if (estado === 'quieto' && max < .015) { cancelAnimationFrame(rafId); rafId = 0; }
    }
    async function empieza(via) {
      if (estado !== 'quieto') return;
      if (popPalabra) cierraPop();
      clearTimeout(cierraT);
      fijaEstado('escucha');
      tiempo = 0; ultTs = 0; segPintado = -1; tiempoEl.textContent = '0:00';
      actualizaBotones();
      preparaSesion(via !== 'toque');
      pintaFuente('');
      if (!rafId) rafId = requestAnimationFrame(bucle);
      anuncia('Escuchando');
      const mia = ++generacion;
      const f = await creaFuente();
      if (mia !== generacion || (estado !== 'escucha' && estado !== 'fijo')) { f.para(); if (mia === generacion) cierra(); return; }
      fuente = f;
      if (f.tipo === 'ejemplo') f.tick(Math.min(tiempo, 1.2));      // lo que tardó en saberse que no hay micrófono no se pierde
      pintaFuente(f.tipo);
    }
    function actualizaBotones() { actualiza(); }
    function suelta() {
      if (estado !== 'escucha' && estado !== 'fijo') return;
      fijaEstado('cierra');
      if (fuente) fuente.para();
      actualiza();
      // el navegador entrega lo último poco después de parar; si no avisa, se cierra solo
      cierraT = setTimeout(cierra, fuente && fuente.tipo === 'real' ? 1500 : 420);
    }
    function cierra() {
      if (estado !== 'cierra' && estado !== 'quieto') return;
      clearTimeout(cierraT);
      if (!ses) { fijaEstado('quieto'); fuente = null; return; }
      if (interinoRaw) confirma(Object.assign([{ transcript: interinoRaw, confidence: .9 }], { isFinal: true }));
      prov.remove(); logParcial('');
      const palabras = ses.querySelectorAll('.am-w').length;
      if (!ses.textContent.trim()) ses.remove(); else sesiones.push(ses);
      const hizo = ses && ses.isConnected;
      if (document.activeElement === campo && hizo) colocaCaret();
      ses = null; prov = null; fuente = null; provPrev = [];
      fijaEstado('quieto');
      actualiza();
      const dudas = campo.querySelectorAll('[data-alt]').length;
      anuncia(palabras ? 'Dictado terminado: ' + palabras + (palabras === 1 ? ' palabra' : ' palabras') + (dudas ? ', ' + dudas + (dudas === 1 ? ' duda' : ' dudas') + ' para revisar' : '') : 'No se oyó nada');
    }
    function cierraYa() { if (estado === 'escucha' || estado === 'fijo') suelta(); if (estado === 'cierra') cierra(); }

    /* Mantener = escuchar mientras dura; un toque corto lo deja abierto. */
    function presiona(via) {
      if (estado === 'fijo') { suelta(); return; }
      if (estado !== 'quieto') return;
      apretado = true; t0 = performance.now();
      empieza(via);
    }
    function alza() {
      if (!apretado) return;
      apretado = false;
      if (estado === 'escucha' && performance.now() - t0 < 320) { fijaEstado('fijo'); anuncia('Escuchando; toca otra vez para parar'); }
      else suelta();
    }
    mic.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      e.preventDefault();
      try { mic.setPointerCapture(e.pointerId); } catch (x) { /* sin captura */ }
      presiona(e.pointerType === 'touch' ? 'toque' : 'puntero');
    });
    mic.addEventListener('mousedown', e => e.preventDefault());       // el foco se queda en el campo
    mic.addEventListener('pointerup', alza);
    mic.addEventListener('pointercancel', alza);
    mic.addEventListener('click', e => {
      if (e.detail !== 0) return;                                      // el ratón y el dedo ya se atendieron arriba
      if (estado === 'quieto') { empieza('teclado'); fijaEstado('fijo'); } else suelta();
    });
    mic.addEventListener('contextmenu', e => e.preventDefault());

    /* ── idioma ─────────────────────────────────────────────────────── */
    function idioma(l) {
      if (!IDIOMAS[l] || l === lang) return;
      cierraYa();
      lang = l;
      pintaOrdenes();
      pintaFuente('');
      anuncia('Idioma del dictado: ' + IDIOMAS[l].nombre);
    }
    function abreMenu(abre, enfoca) {
      menu.hidden = !abre;
      btnIdioma.setAttribute('aria-expanded', abre ? 'true' : 'false');
      if (abre && enfoca) (menu.querySelector('[aria-checked="true"]') || menu.querySelector('button')).focus();
    }
    btnIdioma.addEventListener('click', e => abreMenu(menu.hidden, e.detail === 0));
    menu.addEventListener('click', e => {
      const b = e.target.closest('[data-lang]');
      if (!b) return;
      idioma(b.dataset.lang); abreMenu(false); btnIdioma.focus();
    });
    menu.addEventListener('keydown', e => {
      const bs = Array.from(menu.querySelectorAll('button')), i = bs.indexOf(document.activeElement);
      if (e.key === 'ArrowDown') { e.preventDefault(); bs[(i + 1) % bs.length].focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); bs[(i + bs.length - 1) % bs.length].focus(); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); abreMenu(false); btnIdioma.focus(); }
    });
    document.addEventListener('pointerdown', e => {
      if (!menu.hidden && !e.target.closest('.am-idioma')) abreMenu(false);
      if (popPalabra && !e.target.closest('.am-pop') && !e.target.closest('[data-alt]') && !e.target.closest('[data-revisar]')) cierraPop();
    });

    /* ── las palabras dudosas ───────────────────────────────────────── */
    function cierraPop(devuelve) {
      if (popPalabra) delete popPalabra.dataset.abierta;
      popPalabra = null;
      pop.hidden = true;
      if (devuelve) campo.focus({ preventScroll: true });
    }
    function abrePop(span, conTeclado) {
      if (!span || !span.isConnected) return;
      if (popPalabra) delete popPalabra.dataset.abierta;
      popPalabra = span; popTeclado = !!conTeclado;
      span.dataset.abierta = '1';
      const oyo = span.textContent, alts = (span.dataset.alt || '').split('|').filter(Boolean);
      popO.replaceChildren();
      const pon = (txt, nota, esOyo) => {
        const b = h('button'); b.type = 'button'; b.dataset.v = txt;
        b.append(document.createTextNode(txt));
        if (nota) b.append(h('small', null, nota));
        b.addEventListener('click', () => resuelve(span, esOyo ? null : txt));
        popO.appendChild(b);
      };
      pon(oyo, 'se oyó', true);
      alts.forEach(a => pon(/^[A-ZÁÉÍÓÚÑ]/.test(oyo) ? mayus(a) : a, '', false));
      pop.hidden = false;
      // junto a la palabra, arriba si cabe y abajo si no
      const a = app.getBoundingClientRect(), r = span.getBoundingClientRect();
      const w = pop.offsetWidth, hh = pop.offsetHeight;
      let x = lim(r.left + r.width / 2 - a.left - w / 2, 12, a.width - w - 12);
      const arriba = r.top - a.top - hh - 12 > 8;
      pop.style.left = x + 'px';
      pop.style.top = (arriba ? r.top - a.top - hh - 11 : r.bottom - a.top + 11) + 'px';
      pop.style.setProperty('--am-ox', lim(r.left + r.width / 2 - a.left - x, 18, w - 18) + 'px');
      pop.dataset.abajo = arriba ? '0' : '1';
      popOk.onclick = () => resuelve(span, null);
      if (conTeclado) popO.querySelector('button').focus();
    }
    function resuelve(span, nuevo) {
      const sigue = popTeclado;
      if (nuevo != null) span.textContent = nuevo;
      span.removeAttribute('data-alt');
      delete span.dataset.abierta;
      span.classList.add('am-ok');
      setTimeout(() => span.classList.remove('am-ok'), 1000);
      cierraPop(false);
      actualiza();
      const otra = campo.querySelector('[data-alt]');
      if (sigue && otra) abrePop(otra, true);
      else if (sigue) campo.focus({ preventScroll: true });
      anuncia(nuevo != null ? 'Cambiada por ' + nuevo : 'Palabra confirmada');
    }
    campo.addEventListener('click', e => {
      const s = e.target.closest && e.target.closest('[data-alt]');
      if (s && campo.contains(s)) abrePop(s, false);
    });
    btnRevisar.addEventListener('click', () => { const s = campo.querySelector('[data-alt]'); if (s) abrePop(s, true); });
    pop.addEventListener('keydown', e => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); cierraPop(true); }
      else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        const bs = Array.from(popO.querySelectorAll('button')), i = bs.indexOf(document.activeElement);
        if (i >= 0) { e.preventDefault(); bs[(i + (e.key === 'ArrowRight' ? 1 : bs.length - 1)) % bs.length].focus(); }
      }
    });

    /* ── deshacer lo último dictado ─────────────────────────────────── */
    function deshaz() {
      while (sesiones.length && !sesiones[sesiones.length - 1].isConnected) sesiones.pop();
      const s = sesiones.pop();
      if (!s) return;
      cierraPop();
      const els = Array.from(s.querySelectorAll('.am-w, .am-sg')).reverse();
      btnDeshacer.hidden = true;
      if (quieto() || !els.length) { s.remove(); actualiza(); }
      else {
        els.forEach((el, i) => anima(el, [{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateY(9px) scale(.9)' }], { duration: 240, delay: i * 24, easing: 'ease-in', fill: 'both' }));
        setTimeout(() => { s.remove(); actualiza(); }, 240 + els.length * 24 + 40);
      }
      anuncia('Dictado deshecho');
    }
    btnDeshacer.addEventListener('click', deshaz);

    /* ── enviar ─────────────────────────────────────────────────────── */
    function enviar() {
      cierraYa();
      const texto = plano(campo).replace(/ /g, ' ').replace(/[ \t]+\n/g, '\n').trim();
      if (!texto) return;
      cierraPop();
      const de = campo.getBoundingClientRect();
      const antes = Array.from(hilo.children).map(el => [el, el.getBoundingClientRect().top]);
      const art = h('article', 'am-msg am-msg--yo am-msg--nuevo');
      const bur = h('div', 'am-burbuja', texto);
      const tm = h('time');
      tm.innerHTML = 'Enviado <i class="am-vi" aria-hidden="true"><svg viewBox="0 0 16 16"><path d="m3.500 8.500 3 3 6-7"/></svg></i>';
      art.append(bur, tm);
      hilo.appendChild(art);
      campo.replaceChildren();
      sesiones = [];
      ultimaSel = null;
      hilo.scrollTop = hilo.scrollHeight;
      actualiza();
      // el mensaje sube desde el campo y lo de arriba se corre con un resorte
      const d = bur.getBoundingClientRect();
      anima(bur, [
        { transform: 'translate(' + (de.left + 20 - d.left) + 'px, ' + (de.top + 24 - d.top) + 'px) scale(.92)', opacity: .15, backgroundColor: 'var(--am-panel)', color: 'var(--am-tinta)' },
        { opacity: 1, offset: .35 },
        { transform: 'none', opacity: 1, backgroundColor: 'var(--am-indigo)', color: 'var(--am-sobre-indigo)' }
      ], { duration: R1.ms + 200, easing: R1.curva });
      antes.forEach(([el, y]) => {
        const dy = y - el.getBoundingClientRect().top;
        if (dy) anima(el, [{ transform: 'translateY(' + dy + 'px)' }, { transform: 'none' }], { duration: R1.ms, easing: R1.curva });
      });
      anuncia('Mensaje enviado');
      if (o.alEnviar) o.alEnviar(texto);
      return texto;
    }
    enviarBtn.addEventListener('click', () => { enviar(); });
    campo.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.isComposing) {
        e.preventDefault();
        if (e.shiftKey) {
          const s = getSelection();
          if (!s.rangeCount) return;
          const r = s.getRangeAt(0);
          r.deleteContents();
          const n = document.createTextNode('\n');
          r.insertNode(n);
          r.setStartAfter(n); r.collapse(true);
          s.removeAllRanges(); s.addRange(r);
          if (!n.nextSibling) campo.appendChild(document.createTextNode('\n'));   // un salto al final no se ve sin otro detrás
          actualiza();
        } else enviar();
      }
    });
    campo.addEventListener('paste', e => {
      e.preventDefault();
      const t = (e.clipboardData || window.clipboardData).getData('text/plain');
      const s = getSelection();
      if (!t || !s.rangeCount) return;
      const r = s.getRangeAt(0);
      r.deleteContents();
      const n = document.createTextNode(t);
      r.insertNode(n);
      r.setStartAfter(n); r.collapse(true);
      s.removeAllRanges(); s.addRange(r);
      actualiza();
    });

    /* ── reinicio y teclado general ─────────────────────────────────── */
    function reinicia() {
      generacion++;
      clearTimeout(cierraT);
      if (fuente) fuente.para();
      fuente = null; ses = null; prov = null; provPrev = [];
      fijaEstado('quieto');
      cierraPop(); abreMenu(false);
      cierraAviso(); avisoMostrado = {};
      hilo.innerHTML = hiloVacio;
      hilo.scrollTop = hilo.scrollHeight;
      campo.replaceChildren();
      sesiones = []; ultimaSel = null;
      registro.replaceChildren(); regParcial = null;
      ordenesEl.querySelectorAll('.am-ord').forEach(li => { li.dataset.on = '0'; });
      lang = IDIOMAS[o.lang] ? o.lang : 'es';
      pintaOrdenes(); pintaFuente('');
      actualiza();
    }
    document.addEventListener('keydown', e => {
      if (!raiz.isConnected) return;
      if (e.altKey && e.code === 'Space') {
        e.preventDefault();
        if (e.repeat) return;
        vinoDeTecla = true;
        presiona('teclado-alt');
      } else if (e.key === 'Escape' && estado !== 'quieto') { e.preventDefault(); suelta(); }
    });
    document.addEventListener('keyup', e => {
      if (vinoDeTecla && (e.code === 'Space' || e.key === 'Alt')) { vinoDeTecla = false; alza(); }
    });
    document.addEventListener('keydown', e => {
      if (e.metaKey || e.ctrlKey || e.altKey || e.key.toLowerCase() !== 'r') return;
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      reinicia();
    });
    window.addEventListener('blur', () => { if (estado === 'escucha' && apretado) { apretado = false; suelta(); } });

    pintaOrdenes();
    pintaFuente('');
    actualiza();
    hilo.scrollTop = hilo.scrollHeight;

    return {
      empieza: () => empieza('api'), suelta, alterna: () => (estado === 'quieto' ? (empieza('api'), fijaEstado('fijo')) : suelta()),
      deshaz, enviar, reinicia, idioma,
      estado: () => ({ estado, lang, texto: plano(campo), dudas: campo.querySelectorAll('[data-alt]').length })
    };
  }
  Amanuense.compone = compone;
  Amanuense.dudas = calculaDudas;
  window.Amanuense = Amanuense;

  document.querySelectorAll('[data-amanuense]').forEach(el => { el.amanuense = Amanuense(el, {}); });
})();
