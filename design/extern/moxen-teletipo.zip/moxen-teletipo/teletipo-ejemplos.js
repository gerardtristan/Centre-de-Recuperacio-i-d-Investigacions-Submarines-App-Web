/* =====================================================================
   Teletipo · Moxen — los feeds de ejemplo, escritos a mano: un diario técnico (RSS 2.0), un blog de diseño (Atom) y los
   cambios de un producto (JSON Feed). Los textos son de la demo; el formato lo escribe TeletipoNucleo.ESCRIBE, el mismo que se
   usa en la prueba. Las fechas se cuentan hacia atrás desde «ahora» (en minutos), así que la demo siempre se ve reciente.
   Algunos artículos llevan a propósito lo que Teletipo quita al leer: un script, un onclick, un píxel de seguimiento y
   enlaces con utm_*. Cambia aquí el contenido y sigue funcionando igual.
   ===================================================================== */
(function (raiz) {
  'use strict';
  const N = raiz.TeletipoNucleo;

  const DIARIO = {
    canal: { titulo: 'Diario técnico', web: 'https://diario.example/', url: 'https://diario.example/feed.xml', descripcion: 'Ingeniería de software contada con calma.', autor: 'Redacción' },
    formato: 'rss', nombre: 'diario-tecnico.xml',
    items: [
      { m: 35, slug: 'indices', t: 'Tu consulta lenta no necesita más memoria: necesita un índice', c: ['bases de datos', 'rendimiento'], r: 'Antes de ampliar el servidor, mira el plan de ejecución: casi siempre falta un índice.',
        h: '<p>Antes de ampliar el servidor, mira el plan de ejecución. Si la base de datos recorre toda la tabla para devolver cuarenta filas, ningún aumento de memoria lo arregla: lo arregla un <strong>índice</strong> sobre la columna por la que filtras.</p><p>Un índice compuesto sirve en el orden en que se declara: uno sobre <code>(cliente_id, creado_en)</code> acelera «los pedidos de este cliente por fecha», pero no «todos los pedidos de hoy».</p><ul><li>Pide el plan con <code>EXPLAIN</code> antes y después.</li><li>Cuenta las filas leídas, no los milisegundos.</li><li>Borra los índices que nadie usa: cada uno encarece las escrituras.</li></ul><p>Hay más en la <a href="https://diario.example/guias/explain?utm_source=boletin&amp;utm_medium=correo&amp;utm_campaign=octubre">guía del plan de ejecución</a>.</p><img src="https://metricas.example/p.gif?id=8841" width="1" height="1" alt="">' },
      { m: 190, slug: 'cache', t: 'El caché HTTP en tres cabeceras', c: ['web', 'rendimiento'], soloDescripcion: true,
        h: '<p>Con tres cabeceras bien puestas, la mayoría de tus recursos estáticos dejan de pedirse dos veces.</p><pre><code>Cache-Control: public, max-age=31536000, immutable\nETag: "v42"\nVary: Accept-Encoding</code></pre><p><code>max-age</code> dice cuánto tiempo se puede reutilizar sin preguntar; <code>ETag</code> permite preguntar «¿ha cambiado?» y recibir un <code>304</code> sin cuerpo; <code>Vary</code> evita que una copia comprimida se sirva a quien no la entiende.</p><blockquote><p>Si el nombre del archivo lleva el hash de su contenido, <code>immutable</code> es seguro: el archivo nuevo tendrá otro nombre.</p></blockquote>' },
      { m: 430, slug: 'escritura', t: 'Qué ocurre cuando dos procesos escriben el mismo archivo', c: ['sistemas'], r: 'Nada bueno, salvo que lo hayas previsto: las escrituras se pisan.',
        h: '<p>Nada bueno, salvo que lo hayas previsto. Dos escrituras sin coordinar se pisan y el resultado depende del orden en que el sistema operativo las atienda.</p><p>Hay tres salidas honestas:</p><ol><li><strong>Un solo escritor</strong>: los demás le piden el cambio.</li><li><strong>Un bloqueo</strong> del archivo, con un tiempo máximo de espera.</li><li><strong>Escribir en un archivo temporal</strong> y renombrarlo al terminar: el cambio es atómico.</li></ol><p>La tercera es la más barata y la que menos se usa.</p>' },
      { m: 1560, slug: 'migraciones', t: 'Migraciones sin parar el servicio: el patrón de las dos fases', c: ['bases de datos', 'despliegue'], r: 'Renombrar una columna sin romper la versión anterior se hace en dos despliegues.',
        h: '<p>Renombrar una columna parece inocente hasta que dos versiones de la aplicación conviven durante el despliegue.</p><p>La solución es dividir el cambio en dos despliegues:</p><ol><li>Añade la columna nueva, escribe en las dos y lee de la antigua.</li><li>Cuando todo el mundo escribe en las dos, copia lo que falte, lee de la nueva y, un despliegue después, borra la antigua.</li></ol><p>Es más lento, pero ninguna versión se encuentra con una columna que no conoce.</p>' },
      { m: 3000, slug: 'trazas', t: 'Cómo leer una traza de pila sin perder la calma', c: ['depuración'], r: 'Importa la primera línea que pertenece a tu código, no la primera de la lista.',
        h: '<p>Una traza se lee de abajo arriba para saber <em>qué empezó</em> y de arriba abajo para saber <em>dónde falló</em>. Casi siempre importa la primera línea que pertenece a tu código, no la primera de la lista.</p><p>Fíjate en tres cosas: el tipo de error, el mensaje y el archivo con su línea. Lo demás son los pasos intermedios.</p><p>Y guarda siempre la traza completa en el informe del error: <code>app.min.js:1:48213</code> sin mapa de fuentes no le sirve a nadie.</p>' },
      { m: 4400, slug: 'hash', t: 'Contraseñas: por qué el hash lento es una virtud', c: ['seguridad'], r: 'Para guardar contraseñas, que la función sea rápida es un defecto.',
        h: '<p>Para una función de hash normal, ser rápida es un mérito. Para guardar contraseñas es un defecto: quien robe la base de datos podrá probar millones de combinaciones por segundo.</p><p>Por eso se usan funciones diseñadas para ser lentas y caras en memoria, con una <strong>sal</strong> distinta por usuario. Ajusta el coste para que verificar un acceso cueste unas décimas de segundo en tu servidor: imperceptible para quien entra, ruinoso para quien ataca.</p>' },
      { m: 7400, slug: 'colas', t: 'Colas de trabajo: reintentar con paciencia', c: ['sistemas', 'colas'], r: 'Reintentar enseguida casi nunca ayuda: espera más cada vez.',
        h: '<p>Un trabajo que falla casi nunca debe reintentarse enseguida: si el servicio de destino está caído, cien reintentos inmediatos solo empeoran las cosas.</p><p>Usa una espera que crece (1 s, 2 s, 4 s, 8 s…) con algo de azar para que los trabajos no vuelvan todos a la vez, y un tope de intentos tras el cual el trabajo pasa a una cola de «muertos» para que alguien lo revise.</p><script>document.title = "x"</script><p onclick="enviar()" style="color:red">Recuerda que cada trabajo debe poder ejecutarse dos veces sin dañar nada: eso se llama idempotencia.</p>' },
      { m: 13000, slug: 'lista', t: 'Una lista de comprobación antes de publicar', c: ['despliegue'], r: 'Cuatro preguntas que conviene hacerse siempre antes de publicar.',
        h: '<p>Antes de publicar, repasa siempre lo mismo:</p><ul><li>¿Las migraciones son compatibles con la versión anterior?</li><li>¿Hay forma de volver atrás en menos de cinco minutos?</li><li>¿Las alertas apuntan a alguien que está despierto?</li><li>¿Se probó con datos de verdad, no solo con los de ejemplo?</li></ul><p>Si una respuesta es «no sé», es un «no».</p>' },
    ],
  };

  const DISENO = {
    canal: { titulo: 'Blog de diseño', web: 'https://diseno.example/', url: 'https://diseno.example/atom.xml', descripcion: 'Notas sobre interfaces, tipografía y color.', autor: 'Equipo de diseño' },
    formato: 'atom', nombre: 'blog-de-diseno.atom',
    items: [
      { m: 50, slug: 'reticula', t: 'La retícula no es una jaula', c: ['composición'], r: 'Una retícula bien usada se nota cuando se rompe a propósito.',
        h: '<p>Una retícula bien usada se nota cuando se rompe a propósito. Las doce columnas sirven para que casi todo se alinee, y para que lo que no se alinee destaque.</p><p>Empieza por la columna del texto: entre 60 y 75 caracteres por línea es el punto donde la lectura cansa menos. El resto se reparte alrededor de ella.</p><p>Después decide <em>una</em> excepción por pantalla: una imagen que sangra, un titular que invade el margen. Con más de una, ya no es una excepción.</p>' },
      { m: 300, slug: 'contraste', t: 'Contraste: del 4,5 al 7 sin perder el carácter', c: ['accesibilidad', 'color'], tipo: 'xhtml', r: 'Cumplir el contraste no obliga a que todo sea negro sobre blanco.',
        h: '<p>El mínimo para texto normal es 4,5 a 1; para texto grande, 3 a 1. Cumplirlo no obliga a que todo sea negro sobre blanco.</p><p>Un truco: baja la <strong>luminosidad</strong> del color de texto sin cambiar su tono. Un azul oscuro con 7 a 1 de contraste sigue siendo azul, solo que más sereno.</p><blockquote><p>Un color que solo se distingue por el tono, y no por la luminosidad, desaparece para una de cada doce personas.</p></blockquote>' },
      { m: 1320, slug: 'variable', t: 'Tipografía variable: un archivo, mil pesos', c: ['tipografía'], r: 'Una fuente variable guarda todos los pesos y anchos en un solo archivo.',
        h: '<p>Una fuente variable guarda en un solo archivo todos los pesos y anchos intermedios. En CSS se piden con <code>font-variation-settings</code> o, mejor, con <code>font-weight</code> y <code>font-stretch</code>.</p><p>Las ventajas: un archivo en lugar de seis y la posibilidad de animar el peso sin saltos. Cuidado: no todas las variantes están diseñadas con el mismo mimo, así que prueba los extremos antes de fiarte.</p><p>Lee más en <a href="https://diseno.example/notas/variable?utm_source=feed&amp;utm_medium=rss">las notas del equipo</a>.</p>' },
      { m: 3000, slug: 'espaciado', t: 'Espaciado: una escala que se repite', c: ['sistemas de diseño'], tipo: 'text', r: 'Todo se mide con la misma regla.',
        texto: 'Elige una unidad base (4 px) y construye todo con sus múltiplos: 4, 8, 12, 16, 24, 32, 48.\n\nCuando todo se mide con la misma regla, las pantallas se parecen sin esfuerzo y los ajustes dejan de ser una discusión. Si una medida no está en la escala, casi siempre es que sobra.', h: '' },
      { m: 5800, slug: 'iconos', t: 'Iconos de 24 píxeles: lo que se decide en el primer trazo', c: ['iconos'], r: 'El grosor del trazo, las esquinas y el margen interior se eligen una vez.',
        h: '<p>Un conjunto de iconos coherente se decide en el primer trazo: el grosor (1,5 o 2 píxeles), si las esquinas son redondas y cuánto margen se deja dentro del cuadro de 24.</p><p>Con esas tres reglas anotadas, dibujar el icono número cincuenta cuesta lo mismo que el primero. Sin ellas, cada icono nuevo se parece menos a los anteriores.</p><img src="https://diseno.example/img/trazo.png" width="640" height="360" alt="Un trazo de 2 píxeles con esquinas redondas">' },
      { m: 8600, slug: 'vacios', t: 'Estados vacíos que enseñan', c: ['interfaz'], r: 'Una pantalla vacía es la mejor ocasión para explicar qué se hace aquí.',
        h: '<p>Una pantalla vacía es la primera que ve quien estrena una cuenta: la mejor ocasión para explicar qué se hace aquí.</p><p>Una frase que diga <em>qué aparecerá</em>, un botón con la primera acción y, si ayuda, un ejemplo cargado que se pueda borrar. Nada de «No hay nada que mostrar».</p>' },
      { m: 16000, slug: 'curvas', t: 'Animar con intención: tres curvas', c: ['movimiento'], r: 'Entrada, salida y resorte cubren casi todo lo que se mueve en una interfaz.',
        h: '<p>Con tres curvas se cubre casi todo: una de <strong>salida suave</strong> para lo que entra, una de <strong>entrada suave</strong> para lo que se va y un <strong>resorte</strong> para lo que se agarra con el dedo.</p><p>Lo que entra tarda un poco más que lo que sale (250 ms frente a 180 ms): quien mira necesita tiempo para ver qué ha llegado, no para ver qué se fue.</p>' },
      { m: 23000, slug: 'acento', t: 'Color: paletas con un solo acento', c: ['color'], r: 'Un acento bien dosificado vale más que cinco colores competidores.',
        h: '<p>Una paleta con un solo acento obliga a decidir qué es importante. Fondo, tinta y un color para lo que se puede tocar: lo demás son grises.</p><p>Si necesitas un segundo color, que sea para el estado de peligro y que casi nunca aparezca. Así, cuando aparezca, se verá.</p>' },
    ],
  };

  const CAMBIOS = {
    canal: { titulo: 'Cambios del producto', web: 'https://cambios.example/', url: 'https://cambios.example/feed.json', descripcion: 'Lo nuevo, lo mejorado y lo corregido.', autor: 'Equipo de producto' },
    formato: 'json', nombre: 'cambios.json',
    items: [
      { m: 120, slug: 'v42', t: 'Versión 4.2: exportación a CSV con filtros', c: ['nuevo'], r: 'Exporta cualquier tabla respetando los filtros activos.',
        h: '<p>Ya puedes exportar cualquier tabla a CSV respetando los filtros activos. El archivo usa UTF-8 con BOM y «;» como separador, tal como lo abre una hoja de cálculo en español.</p><ul><li>Se exportan solo las columnas visibles.</li><li>Las fechas salen en ISO 8601.</li></ul><p>Encuentra el botón en el menú de cada tabla.</p>' },
      { m: 540, slug: 'fechas', t: 'Corrección: las fechas se mostraban un día antes', c: ['corrección'], r: 'Las fechas sin hora se interpretaban como medianoche en UTC.',
        h: '<p>Las fechas sin hora («2026-10-17») se interpretaban como medianoche en UTC y, en husos al oeste, se mostraban un día antes. Ahora se leen como fechas de calendario y no se mueven.</p><p>Si ya habías corregido a mano alguna fecha, revisa que siga bien.</p>' },
      { m: 2900, slug: 'v41', t: 'Versión 4.1: atajos de teclado en toda la aplicación', c: ['nuevo', 'accesibilidad'], r: 'Pulsa ? en cualquier pantalla para ver los atajos disponibles.',
        h: '<p>Pulsa <kbd>?</kbd> en cualquier pantalla para ver los atajos disponibles. Los más usados: <kbd>g</kbd> y <kbd>i</kbd> para ir al inicio, <kbd>/</kbd> para buscar y <kbd>j</kbd> / <kbd>k</kbd> para moverte por las listas.</p><p>Todos se pueden desactivar en Ajustes → Accesibilidad.</p>' },
      { m: 4300, slug: 'tildes', t: 'Mejora: el buscador entiende las tildes', c: ['mejora'], r: 'Buscar «facturacion» ya encuentra «facturación».',
        h: '<p>Buscar «facturacion» ya encuentra «facturación», y «ESTADISTICAS» encuentra «Estadísticas». La búsqueda ignora tildes y mayúsculas, pero muestra el resultado con su ortografía correcta.</p>' },
      { m: 8600, slug: 'limite', t: 'Aviso: cambia el límite de peticiones', c: ['aviso'], r: 'El 1 de noviembre baja el límite por minuto de las claves de prueba.',
        h: '<p>El 1 de noviembre baja el límite por minuto de las claves de prueba, de 600 a 120 peticiones. Las claves de producción no cambian.</p><p>Si tu integración se acerca a ese tope, agrupa las consultas o añade una espera entre reintentos.</p><iframe src="https://anuncios.example/banner"></iframe><p>Consulta la <a href="https://cambios.example/limites?utm_source=feed&amp;utm_content=aviso&amp;ref_src=twsrc">tabla de límites</a>.</p>' },
      { m: 17000, slug: 'v40', t: 'Versión 4.0: nueva barra lateral', c: ['nuevo'], r: 'Más corta, con secciones plegables y un buscador propio.',
        h: '<p>La barra lateral es más corta, con secciones que se pliegan y un buscador propio. Lo que más usas queda arriba y lo demás, a un clic.</p><p>Si prefieres la anterior, puedes volver a ella desde Ajustes → Apariencia hasta la versión 4.3.</p>' },
      { m: 21000, slug: 'sesiones', t: 'Corrección: sesiones que no se cerraban', c: ['corrección', 'seguridad'], r: 'Cerrar sesión en un dispositivo no la cerraba en los demás.',
        h: '<p>Cerrar sesión en un dispositivo no cerraba la sesión en los demás cuando se había iniciado con un enlace de acceso. Ya se cierran todas las sesiones de la cuenta al pulsar «Cerrar en todos los dispositivos».</p>' },
      { m: 30000, slug: 'v39', t: 'Versión 3.9: modo oscuro', c: ['nuevo'], r: 'La aplicación sigue el ajuste de tu sistema o se cambia a mano.',
        h: '<p>La aplicación sigue el ajuste de tu sistema o se cambia a mano desde el menú de tu cuenta. Los gráficos y las tablas también se adaptan.</p><p>Si ves algún color que desentona, cuéntanoslo desde «Enviar comentarios».</p>' },
    ],
  };

  const FEEDS = [DIARIO, DISENO, CAMBIOS];
  /* Los archivos de ejemplo, con las fechas contadas desde `ahora` (milisegundos). */
  function crea(ahora) {
    return FEEDS.map(f => {
      const items = f.items.map(i => ({
        guid: f.canal.web + 'p/' + i.slug, titulo: i.t, url: f.canal.web + 'p/' + i.slug, fecha: ahora - i.m * 60000, autor: f.canal.autor, etiquetas: i.c, resumen: i.r || '',
        html: i.h || '', tipo: i.tipo, texto: i.texto, soloDescripcion: i.soloDescripcion,
      }));
      return { nombre: f.nombre, formato: f.formato, texto: N.ESCRIBE[f.formato](f.canal, items) };
    });
  }
  raiz.TeletipoEjemplos = { crea, FEEDS };
})(typeof window !== 'undefined' ? window : globalThis);
