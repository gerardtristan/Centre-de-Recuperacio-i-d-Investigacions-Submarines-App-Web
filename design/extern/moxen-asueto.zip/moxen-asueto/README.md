# Asueto · Moxen

Eliges una fecha y arrastras la asa de cierre (o la de apertura) de la línea del día, o la marcas como cerrada: las citas que ya no caben se rayan en naranja al instante y, al lado, la agenda te dice la primera hora libre de cada una, ese mismo día o al siguiente. «Mover» las pasa a esa hora sin pisar a nadie y «Aplicar» guarda la excepción sobre el horario de siempre, con el mes marcando los días afectados.

## Qué trae

- `index.html` — la demostración
- `asueto.css`
- `asueto.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `asueto.css` y `asueto.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Pick a date and drag the closing handle (or the opening one) on the day's timeline, or mark the day as closed: the appointments that no longer fit turn orange-striped at once and, next to them, the calendar gives the first free slot for each one, the same day or the next. “Move” puts them there without overlapping anyone and “Apply” saves the exception on top of the usual hours, with the month marking the affected days.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
