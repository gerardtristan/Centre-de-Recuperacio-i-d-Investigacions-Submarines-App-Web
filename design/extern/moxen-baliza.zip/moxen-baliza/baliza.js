/* =====================================================================
   Baliza · Moxen
   Un recorrido sin bloqueo para las novedades de una interfaz: en vez de oscurecer la pantalla y llevarte de la mano,
   pequeñas balizas laten junto a lo nuevo y tú las descubres cuando quieras, en el orden que quieras.

   · Una baliza es un núcleo naranja con dos anillos que laten fuera de fase. Al pasar el cursor por encima, al enfocarla
     con el teclado o al tocarla se abre una nota anclada con su flecha, del lado donde cabe (prueba el que prefiere el
     objeto y luego bottom, top, right y left). «Entendido» apaga la baliza con un último anillo grande y un destello.
   · Una píldora en la esquina cuenta lo descubierto («3 de 6 descubiertas», con un aro de progreso). Al abrirla sube una
     lista con una fila por novedad: pulsar una fila lleva hasta su baliza (la zona de la página se desplaza con un
     resorte hasta centrar el objeto), lo enmarca un instante con un marco naranja y abre su nota.
   · Al descubrir la última, el aro se llena, se dibuja un ✓ naranja, salta un puñado de chispas y la píldora se cierra
     en un círculo. Pulsarlo vuelve a empezar (con las que declares descubiertas desde el principio).
   · «Ocultar consejos» apaga todo: las balizas que se ven vuelan a la píldora en cascada y esta queda como un
     recordatorio, «Mostrar consejos». La elección se recuerda (localStorage) y, al recargar, las balizas no salen.
   · Teclado: cada baliza es un botón (Tab llega y abre su nota; Intro pasa el foco a «Entendido»; Esc cierra y devuelve
     el foco). La píldora abre la lista, que se recorre con Tab; Esc la cierra. Todo se anuncia en una región aria-live.
     Con movimiento reducido las balizas no laten (quedan fijas), las notas aparecen sin animar y el marco se queda.

   Montaje (se inicia con la llamada de index.html; el HTML de esta demo es la plantilla):
     <div class="ba-obj" data-baliza-id="compartir" data-baliza-titulo="Compartir"
          data-baliza-nota="Invita con un enlace…" data-baliza-lado="bottom" data-baliza-pos="der"
          data-baliza-orden="2" data-baliza-resumen="Invita y decide quién edita"> …lo que quieres señalar… </div>
     const b = Baliza(document.querySelector('[data-baliza]'), {
       clave: 'baliza-consejos',          // en qué clave de localStorage se recuerda «Ocultar consejos» (null: no se guarda)
       descubiertas: ['buscar'],          // ids ya vistos al empezar (y a los que vuelve «volver a empezar»)
       alCambiar: ({ descubiertas, total, estado }) => {},   // al descubrir, ocultar o reiniciar: guárdalo donde quieras
     });
     b.descubre('compartir');  b.abreLista();  b.cierraLista();  b.vaA('exportar');  b.oculta();  b.muestra();  b.reinicia();

   Qué cambia qué: los atributos data-baliza-* de cada objeto (título, nota, lado preferido, esquina de la baliza: der,
   izq o dentro, y orden en la lista) y los colores, al principio de baliza.css (--ba-naranja es todo lo que señala,
   --ba-panel-2 las notas y la lista). Sin dependencias; el tiempo viene de requestAnimationFrame, timers, Web
   Animations y transiciones CSS (nada de Date): la página y el vídeo coinciden.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* Un resorte convertido en curva `linear()`: sirve para CSS y para Web Animations. */
  function muelle(k, c) {
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const out = [];
    for (let i = 0; i <= 40; i++) out.push(pts[Math.round(i / 40 * (pts.length - 1))].toFixed(4));
    out[40] = '1';
    return 'linear(' + out.join(', ') + ')';
  }

  const IC = {
    tilde: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.6 12.6l3.8 3.8 7.2-8.2" pathLength="1"/></svg>',
    ir: '<svg class="ba-fila-go" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  };
  const SCROLL = [150, 24];   // el resorte que lleva la zona de la página hasta una baliza (rigidez, amortiguación)

  function Baliza(raiz, opciones) {
    const op = Object.assign({ clave: 'baliza-consejos', descubiertas: [], alCambiar: null }, opciones);
    const $ = (s, r) => (r || raiz).querySelector(s);
    const el = {
      app: $('[data-app]'), scroll: $('[data-scroll]'), capa: $('[data-capa]'), pildora: $('[data-pildora]'), pil: $('[data-pil]'),
      n: $('[data-n]'), total: $('[data-total]'), lista: $('[data-lista]'), listaSub: $('[data-lista-sub]'), filas: $('[data-filas]'),
      ocultar: $('[data-ocultar]'), vivo: $('[data-vivo]'), chispas: $('.ba-chispas'),
    };
    raiz.style.setProperty('--ba-muelle', muelle(420, 20));
    raiz.style.setProperty('--ba-blando', muelle(260, 22));
    const VUELO = 'cubic-bezier(.5, 0, .2, 1)';

    /* ── las novedades, leídas del HTML ───────────────────────────── */
    const items = Array.from(raiz.querySelectorAll('[data-baliza-id]')).map((o, i) => ({
      id: o.dataset.balizaId, el: o, titulo: o.dataset.balizaTitulo || o.dataset.balizaId, texto: o.dataset.balizaNota || '',
      resumen: o.dataset.balizaResumen || '', lado: o.dataset.balizaLado || 'bottom', orden: +o.dataset.balizaOrden || i + 1, visto: false, fijo: false,
    })).sort((a, b) => a.orden - b.orden);
    const porId = {};
    items.forEach(it => { porId[it.id] = it; });
    const inicial = op.descubiertas.filter(id => porId[id]);

    let estado = 'activa', abierta = null, listaAbierta = false, timers = [], marcoId = 0;
    const tarda = (f, ms) => { const id = setTimeout(f, ms); timers.push(id); return id; };
    const anuncia = t => { el.vivo.textContent = ''; setTimeout(() => { el.vivo.textContent = t; }, 30); };
    const vistas = () => items.filter(it => it.visto).length;
    const memoria = {
      lee() { try { return localStorage.getItem(op.clave); } catch (_) { return null; } },
      pon(v) { if (!op.clave) return; try { if (v) localStorage.setItem(op.clave, v); else localStorage.removeItem(op.clave); } catch (_) { /* sin almacenamiento también funciona */ } },
    };
    const cambio = () => { if (typeof op.alCambiar === 'function') op.alCambiar({ descubiertas: items.filter(it => it.visto).map(it => it.id), total: items.length, estado }); };

    /* ── la construcción: una baliza, una nota y una fila por novedad ─ */
    function construye() {
      items.forEach((it, i) => {
        if (getComputedStyle(it.el).position === 'static') it.el.style.position = 'relative';
        const b = h('button', 'ba-b'); b.type = 'button';
        b.style.setProperty('--ba-d', (-(i * .83 % 2.6)).toFixed(2) + 's');
        b.setAttribute('aria-label', 'Novedad: ' + it.titulo); b.setAttribute('aria-expanded', 'false'); b.setAttribute('aria-controls', 'ba-n-' + it.id);
        b.innerHTML = '<i class="ba-b-n"></i>';
        it.el.appendChild(b); it.baliza = b;

        const n = h('div', 'ba-nota'); n.id = 'ba-n-' + it.id; n.setAttribute('role', 'dialog'); n.setAttribute('aria-modal', 'false'); n.setAttribute('aria-labelledby', 'ba-t-' + it.id);
        n.innerHTML = '<span class="ba-flecha"></span><span class="ba-nota-et"><i></i>Novedad</span><h3 id="ba-t-' + it.id + '">' + esc(it.titulo) + '</h3><p>' + esc(it.texto) + '</p>' +
          '<div class="ba-nota-pie"><small><kbd>Esc</kbd> cierra</small><button class="ba-entendido" type="button">Entendido' + IC.tilde + '</button></div>';
        n.hidden = true;
        el.capa.appendChild(n); it.nota = n; it.boton = n.querySelector('.ba-entendido');

        const li = h('li');
        li.innerHTML = '<button class="ba-fila" type="button" data-id="' + it.id + '"><span class="ba-fila-ic"><span>' + (i + 1) + '</span>' + IC.tilde + '</span><span class="ba-fila-tx"><b>' + esc(it.titulo) + '</b><i></i></span>' + IC.ir + '</button>';
        li.firstChild.style.setProperty('--ba-d', (-(i * .83 % 2.6)).toFixed(2) + 's');
        li.querySelector('i').textContent = it.resumen || it.texto.split(/[.:]/)[0];
        el.filas.appendChild(li); it.fila = li.firstChild;
      });
      el.marco = h('div', 'ba-marco'); el.marco.setAttribute('aria-hidden', 'true'); el.capa.appendChild(el.marco);
      el.total.textContent = items.length;
    }

    /* ── pinta la píldora, la lista y las balizas según lo visto ───── */
    let ultN = -1;
    function pinta() {
      const n = vistas(), t = items.length;
      if (n !== ultN) {
        el.n.textContent = n;
        if (ultN >= 0 && !quieto()) { el.n.classList.remove('is-sube'); void el.n.offsetWidth; el.n.classList.add('is-sube'); }
        ultN = n;
      }
      el.pildora.style.setProperty('--p', (n / t * 100).toFixed(1));
      el.pildora.dataset.estado = estado;
      el.listaSub.textContent = n === t ? 'Lo has visto todo.' : (t - n) + (t - n === 1 ? ' por descubrir' : ' por descubrir') + ' · a tu ritmo, sin orden';
      items.forEach(it => {
        if (it.visto) it.fila.setAttribute('data-visto', ''); else it.fila.removeAttribute('data-visto');
        it.fila.setAttribute('aria-label', it.titulo + (it.visto ? ', ya descubierta. Pulsa para verla otra vez' : ', por descubrir. Pulsa para llegar a su baliza'));
        it.baliza.hidden = it.visto && !it.baliza.classList.contains('is-apaga');
      });
      // la píldora es un botón con tres oficios, según el estado
      if (estado === 'activa') { el.pil.setAttribute('aria-label', n + ' de ' + t + ' descubiertas. ' + (listaAbierta ? 'Cerrar' : 'Abrir') + ' la lista'); el.pil.setAttribute('aria-expanded', listaAbierta ? 'true' : 'false'); el.pil.setAttribute('aria-controls', 'ba-lista'); }
      else {
        el.pil.removeAttribute('aria-expanded'); el.pil.removeAttribute('aria-controls');
        el.pil.setAttribute('aria-label', estado === 'completa' ? 'Todo descubierto. Volver a ver los consejos' : 'Mostrar consejos');
      }
      el.ocultar.disabled = estado !== 'activa';
      raiz.toggleAttribute('data-ocultos', estado === 'oculta');
    }

    /* ── colocar una nota junto a su baliza ───────────────────────── */
    function coloca(it) {
      const capa = el.capa.getBoundingClientRect();
      const br = it.baliza.getBoundingClientRect();
      const cx = br.left + br.width / 2 - capa.left, cy = br.top + br.height / 2 - capa.top;
      const n = it.nota, nw = n.offsetWidth, nh = n.offsetHeight;
      const hueco = 18, m = 12;
      // la nota no tapa el objeto que señala: se aparta de su borde, no solo de la baliza
      const tr = it.el.getBoundingClientRect(), ob = { l: tr.left - capa.left, r: tr.right - capa.left, t: tr.top - capa.top, b: tr.bottom - capa.top };
      const pos = l => {
        if (l === 'bottom') return { x: cx - 44, y: Math.max(cy + hueco, ob.b + 12) };
        if (l === 'top') return { x: cx - 44, y: Math.min(cy - nh - hueco, ob.t - nh - 12) };
        if (l === 'right') return { x: Math.max(cx + hueco, ob.r + 12), y: cy - 44 };
        return { x: Math.min(cx - nw - hueco, ob.l - nw - 12), y: cy - 44 };
      };
      // solo cuenta el eje principal: a lo largo del borde la nota puede deslizarse para entrar
      const cabe = (o, p) => (o === 'bottom' || o === 'top') ? p.y >= m - 1 && p.y + nh <= capa.height - m + 1 : p.x >= m - 1 && p.x + nw <= capa.width - m + 1;
      const orden = [it.lado, 'bottom', 'top', 'right', 'left'].filter((v, i, a) => a.indexOf(v) === i);
      let l = orden.find(o => cabe(o, pos(o)));
      if (!l) l = orden[0];
      const p = pos(l);
      const x = lim(p.x, m, Math.max(m, capa.width - nw - m)), y = lim(p.y, m, Math.max(m, capa.height - nh - m));
      const vert = l === 'bottom' || l === 'top';
      const flecha = lim(vert ? cx - x : cy - y, 24, (vert ? nw : nh) - 24);
      n.style.translate = x.toFixed(1) + 'px ' + y.toFixed(1) + 'px';
      n.dataset.lado = l;
      n.style.setProperty('--flecha', flecha.toFixed(1) + 'px');
      n.style.transformOrigin = l === 'bottom' ? flecha + 'px 0' : l === 'top' ? flecha + 'px 100%' : l === 'right' ? '0 ' + flecha + 'px' : '100% ' + flecha + 'px';
    }
    /* ¿se ve la baliza? Las de la zona que se desplaza pueden quedar fuera de su ventana */
    function visible(it) {
      const r = it.baliza.getBoundingClientRect();
      if (!r.width) return false;
      if (el.scroll.contains(it.el)) {
        const s = el.scroll.getBoundingClientRect();
        return r.top + r.height / 2 > s.top + 4 && r.top + r.height / 2 < s.bottom - 4;
      }
      return true;
    }

    /* ── abrir y cerrar notas ─────────────────────────────────────── */
    function abre(it, foco) {
      if (it.visto || estado === 'oculta' || !visible(it)) return;
      clearTimeout(it.tAbre); clearTimeout(it.tCierra);
      if (abierta && abierta !== it) cierra(abierta);
      abierta = it;
      if (listaAbierta && !foco) cierraLista();
      it.nota.hidden = false;
      coloca(it);
      void it.nota.offsetWidth;
      it.nota.setAttribute('data-abierta', '');
      it.baliza.setAttribute('aria-expanded', 'true');
      if (foco) it.boton.focus({ preventScroll: true });
    }
    function cierra(it, devuelve) {
      if (!it) return;
      clearTimeout(it.tAbre); clearTimeout(it.tCierra);
      it.fijo = false;
      it.nota.removeAttribute('data-abierta');
      it.baliza.setAttribute('aria-expanded', 'false');
      if (abierta === it) abierta = null;
      const ocultaId = setTimeout(() => { if (!it.nota.hasAttribute('data-abierta')) it.nota.hidden = true; }, quieto() ? 0 : 520);
      timers.push(ocultaId);
      if (devuelve && !it.visto) { it.sinAbrir = true; it.baliza.focus({ preventScroll: true }); }
    }
    const programaAbre = (it, ms) => { clearTimeout(it.tCierra); clearTimeout(it.tAbre); it.tAbre = setTimeout(() => abre(it), ms); };
    const programaCierra = (it, ms) => { clearTimeout(it.tAbre); clearTimeout(it.tCierra); if (!it.fijo) it.tCierra = setTimeout(() => cierra(it), ms); };

    function enlaza() {
      items.forEach(it => {
        const b = it.baliza, n = it.nota;
        b.addEventListener('pointerenter', e => { if (e.pointerType !== 'touch') programaAbre(it, 60); });
        b.addEventListener('pointerleave', e => { if (e.pointerType !== 'touch') programaCierra(it, 300); });
        n.addEventListener('pointerenter', () => { clearTimeout(it.tCierra); });
        n.addEventListener('pointerleave', e => { if (e.pointerType !== 'touch') programaCierra(it, 300); });
        b.addEventListener('click', e => {
          if (e.detail === 0) { abre(it, true); return; }                   // Intro o Espacio: el foco pasa a «Entendido»
          if (abierta === it) { it.fijo = !it.fijo; if (!it.fijo && e.pointerType === 'touch') cierra(it); } else { abre(it); it.fijo = true; }
        });
        b.addEventListener('focus', () => { if (it.sinAbrir) { it.sinAbrir = false; return; } if (!b.matches(':hover')) abre(it); });
        b.addEventListener('blur', () => { setTimeout(() => { if (!n.contains(document.activeElement) && document.activeElement !== b) programaCierra(it, 120); }, 0); });
        n.addEventListener('focusout', () => { setTimeout(() => { if (!n.contains(document.activeElement) && document.activeElement !== b) programaCierra(it, 120); }, 0); });
        it.boton.addEventListener('click', e => descubre(it.id, e.detail === 0));
      });
    }

    /* ── descubrir: el último anillo, la cuenta y, si era la última, el ✓ ─ */
    function descubre(id, desdeNota) {
      const it = porId[id];
      if (!it || it.visto) return;
      const habiaFoco = desdeNota && it.nota.contains(document.activeElement);
      it.visto = true;
      cierra(it);
      it.baliza.classList.add('is-apaga');
      tarda(() => { it.baliza.classList.remove('is-apaga'); pinta(); }, quieto() ? 0 : 950);
      pinta();
      const n = vistas(), t = items.length;
      anuncia(it.titulo + ' descubierta. ' + n + ' de ' + t + '.');
      if (habiaFoco) {
        const sig = items.find(o => !o.visto && !o.baliza.hidden);
        if (sig) sig.sinAbrir = true;
        (sig ? sig.baliza : el.pil).focus({ preventScroll: true });
      }
      cambio();
      if (n === t) tarda(completa, quieto() ? 0 : 750);
    }
    function completa() {
      cierraLista();
      estado = 'completa';
      el.pildora.removeAttribute('data-cerrada');
      pinta();
      if (!quieto()) { el.chispas.classList.remove('is-on'); void el.chispas.offsetWidth; el.chispas.classList.add('is-on'); }
      anuncia('Has descubierto todas las novedades.');
      tarda(() => { if (estado === 'completa') el.pildora.setAttribute('data-cerrada', ''); }, quieto() ? 0 : 1250);
      cambio();
    }

    /* ── la lista de novedades ─────────────────────────────────────── */
    function abreLista(foco) {
      if (estado !== 'activa' || listaAbierta) return;
      if (abierta) cierra(abierta);
      listaAbierta = true;
      el.lista.hidden = false;
      void el.lista.offsetWidth;
      el.lista.setAttribute('data-abierta', '');
      pinta();
      if (foco) { const f = items.find(o => !o.visto) || items[0]; f.fila.focus({ preventScroll: true }); }
    }
    function cierraLista(devuelve) {
      if (!listaAbierta) return;
      listaAbierta = false;
      el.lista.removeAttribute('data-abierta');
      tarda(() => { if (!listaAbierta) el.lista.hidden = true; }, quieto() ? 0 : 600);
      pinta();
      if (devuelve) el.pil.focus({ preventScroll: true });
    }
    items.forEach(() => {});

    /* ── desplazar la página hasta un objeto y enmarcarlo ─────────── */
    const sc = { y: 0, v: 0, tgt: 0, activo: false, alFin: null };
    let raf = 0, tPrev = 0;
    function despierta() { if (!raf) { tPrev = 0; raf = requestAnimationFrame(bucle); } }
    function bucle(t) {
      raf = 0;
      const dt = tPrev ? lim((t - tPrev) / 1000, .001, .034) : 1 / 60;
      tPrev = t;
      if (sc.activo) {
        if (quieto()) { sc.y = sc.tgt; sc.v = 0; }
        else {
          const n = Math.ceil(dt * 240), hh = dt / n;
          for (let i = 0; i < n; i++) { sc.v += (SCROLL[0] * (sc.tgt - sc.y) - SCROLL[1] * sc.v) * hh; sc.y += sc.v * hh; }
        }
        el.scroll.scrollTop = sc.y;
        if (abierta) { if (visible(abierta)) coloca(abierta); else cierra(abierta); }
        if (Math.abs(sc.tgt - sc.y) < .6 && Math.abs(sc.v) < 6) {
          sc.y = sc.tgt; el.scroll.scrollTop = sc.y; sc.activo = false; sc.v = 0;
          const f = sc.alFin; sc.alFin = null; if (f) f();
        }
      }
      if (sc.activo) raf = requestAnimationFrame(bucle); else tPrev = 0;
    }
    function llevaA(y, alFin) {
      const max = el.scroll.scrollHeight - el.scroll.clientHeight;
      sc.y = el.scroll.scrollTop; sc.v = 0; sc.tgt = lim(y, 0, Math.max(0, max)); sc.activo = true; sc.alFin = alFin || null;
      if (Math.abs(sc.tgt - sc.y) < 1) { sc.activo = false; if (alFin) alFin(); return; }
      despierta();
    }
    ['wheel', 'touchstart', 'pointerdown'].forEach(ev => el.scroll.addEventListener(ev, () => { sc.activo = false; sc.alFin = null; }, { passive: true }));
    el.scroll.addEventListener('scroll', () => { if (abierta && !sc.activo) { if (visible(abierta)) coloca(abierta); else cierra(abierta); } }, { passive: true });

    function enmarca(it) {
      const capa = el.capa.getBoundingClientRect(), r = it.el.getBoundingClientRect(), pad = 7;
      const m = el.marco;
      m.style.width = (r.width + pad * 2) + 'px'; m.style.height = (r.height + pad * 2) + 'px';
      m.style.setProperty('--mx', (r.left - capa.left - pad).toFixed(1) + 'px'); m.style.setProperty('--my', (r.top - capa.top - pad).toFixed(1) + 'px');
      m.style.left = '0'; m.style.top = '0';
      m.classList.remove('is-on'); void m.offsetWidth; m.classList.add('is-on');
      clearTimeout(marcoId);
      marcoId = setTimeout(() => m.classList.remove('is-on'), quieto() ? 1800 : 2200);
    }
    function vaA(id) {
      const it = porId[id];
      if (!it) return;
      cierraLista();
      if (estado === 'oculta') muestra();
      const llega = () => { enmarca(it); if (!it.visto) tarda(() => abre(it), quieto() ? 0 : 260); };
      if (el.scroll.contains(it.el)) {
        const s = el.scroll.getBoundingClientRect(), r = it.el.getBoundingClientRect();
        llevaA(el.scroll.scrollTop + (r.top - s.top) - (s.height / 2 - r.height / 2), llega);
      } else llega();
      anuncia('Llevada a: ' + it.titulo);
    }

    /* ── ocultar, mostrar y volver a empezar ──────────────────────── */
    function oculta() {
      if (estado !== 'activa') return;
      cierraLista();
      if (abierta) cierra(abierta);
      const capa = el.capa.getBoundingClientRect();
      const aro = el.pil.querySelector('.ba-pil-aro').getBoundingClientRect();
      const dx = aro.left + aro.width / 2 - capa.left, dy = aro.top + aro.height / 2 - capa.top;
      let k = 0;
      items.filter(it => !it.visto && !it.baliza.hidden).forEach(it => {
        const r = it.baliza.getBoundingClientRect();
        if (!quieto() && visible(it)) {
          const x = r.left + r.width / 2 - capa.left, y = r.top + r.height / 2 - capa.top;
          const c = h('div', 'ba-vuelo'); c.innerHTML = '<i></i>'; c.style.translate = x + 'px ' + y + 'px';
          el.capa.appendChild(c);
          const a = c.animate([
            { translate: x + 'px ' + y + 'px', scale: 1, opacity: 1 },
            { translate: (x + (dx - x) * .35) + 'px ' + (y + (dy - y) * .35 - 46) + 'px', scale: 1.15, opacity: 1, offset: .45 },
            { translate: dx + 'px ' + dy + 'px', scale: .3, opacity: .1 },
          ], { duration: 780, delay: k * 85, easing: VUELO, fill: 'both' });
          a.onfinish = () => { c.remove(); };
          k++;
        }
      });
      estado = 'oculta';
      memoria.pon('ocultos');
      pinta();
      anuncia('Consejos ocultos. Puedes volver a verlos desde la esquina.');
      cambio();
    }
    function muestra() {
      if (estado !== 'oculta') return;
      estado = vistas() === items.length ? 'completa' : 'activa';
      memoria.pon(null);
      pinta();
      items.filter(it => !it.visto).forEach((it, i) => {
        it.baliza.classList.remove('is-nace'); void it.baliza.offsetWidth;
        it.baliza.style.setProperty('--ba-n', (i * .07) + 's'); it.baliza.classList.add('is-nace');
        tarda(() => it.baliza.classList.remove('is-nace'), 900 + i * 70);
      });
      anuncia('Consejos visibles otra vez.');
      cambio();
    }
    function reinicia() {
      cierraLista();
      if (abierta) cierra(abierta);
      items.forEach((it, i) => {
        it.visto = inicial.includes(it.id);
        if (!it.visto) { it.baliza.classList.remove('is-apaga'); it.baliza.hidden = false; }
      });
      estado = 'activa'; ultN = -1;
      el.pildora.removeAttribute('data-cerrada');
      memoria.pon(null);
      pinta();
      items.filter(it => !it.visto).forEach((it, i) => {
        it.baliza.classList.remove('is-nace'); void it.baliza.offsetWidth;
        it.baliza.style.setProperty('--ba-n', (.25 + i * .09) + 's'); it.baliza.classList.add('is-nace');
        tarda(() => it.baliza.classList.remove('is-nace'), 1200 + i * 90);
      });
      llevaA(0);
      anuncia('Recorrido reiniciado: ' + (items.length - vistas()) + ' novedades por descubrir.');
      cambio();
    }

    /* ── la píldora y el resto de eventos ─────────────────────────── */
    el.pil.addEventListener('click', e => {
      if (estado === 'oculta') muestra();
      else if (estado === 'completa') reinicia();
      else if (listaAbierta) cierraLista(); else abreLista(e.detail === 0);
    });
    el.filas.addEventListener('click', e => { const f = e.target.closest('.ba-fila'); if (f) vaA(f.dataset.id); });
    el.ocultar.addEventListener('click', oculta);
    document.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      if (abierta) { const it = abierta; cierra(it, true); }
      else if (listaAbierta) cierraLista(true);
    });
    document.addEventListener('pointerdown', e => {
      if (listaAbierta && !e.target.closest('.ba-pildora')) cierraLista();
      if (abierta && !e.target.closest('.ba-nota') && !e.target.closest('.ba-b')) cierra(abierta);
    });
    addEventListener('resize', () => { if (abierta) { if (visible(abierta)) coloca(abierta); else cierra(abierta); } });

    /* ── la puesta en marcha ──────────────────────────────────────── */
    construye();
    inicial.forEach(id => { porId[id].visto = true; });
    if (items.length && vistas() === items.length) { estado = 'completa'; el.pildora.setAttribute('data-cerrada', ''); }
    else if (memoria.lee() === 'ocultos') estado = 'oculta';
    pinta();
    enlaza();

    return {
      descubre: id => descubre(id), abreLista: () => abreLista(false), cierraLista: () => cierraLista(), vaA, oculta, muestra, reinicia,
      estado: () => ({ descubiertas: items.filter(it => it.visto).map(it => it.id), total: items.length, estado }),
    };
  }

  window.Baliza = Baliza;
})();
