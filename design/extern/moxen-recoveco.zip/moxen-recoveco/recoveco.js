/* =====================================================================
   Recoveco · Moxen
   Unas preguntas frecuentes cuyas respuestas, aunque estén cerradas, las encuentra la búsqueda del propio navegador (⌘F o
   Ctrl F): el panel se abre solo, el texto encontrado se resalta y el índice de la izquierda marca el tema donde estaba.
   Cada respuesta se puede enlazar con su frase exacta: «Copiar enlace a esta respuesta» deja una dirección que, al abrirse,
   despliega la pregunta y subraya la frase en amarillo.

   · Funciona de verdad (todo con funciones del navegador, sin simular ninguna).
     - Cada pregunta es un <details name="tema">: el navegador cierra solo la anterior del mismo tema. Si no entiende `name`, un
       pequeño respaldo lo hace por él.
     - Cada respuesta lleva hidden="until-found". Cerrada, la búsqueda del navegador la encuentra, abre la pregunta y dispara el
       evento `beforematch`: de ahí sale el aviso y la marca del índice. Abierta, un CSS le devuelve el contenido (content-visibility).
       Si el navegador no sabe hacerlo (se mide con 'onbeforematch' in document.body), la nota de arriba lo dice y el buscador
       propio, que ya está en la página, hace lo mismo.
     - El buscador propio recorre el texto de todas las preguntas y respuestas, también las plegadas, sin tildes ni mayúsculas;
       dibuja los resultados con la CSS Custom Highlight API (CSS.highlights, sin tocar el HTML), abre el panel del resultado actual
       y cuenta cuántos hay en cada tema. Intro o ↓ saltan al siguiente, Mayús Intro o ↑ al anterior, Esc limpia.
     - «Copiar enlace a esta respuesta» arma la dirección con un fragmento de texto: página#id-de-la-pregunta:~:text=frase. La frase
       es la que hayas seleccionado dentro de la respuesta o, si no, la frase clave de la respuesta (data-frase). Al abrir el enlace
       el navegador despliega la pregunta y resalta la frase (::target-text); la página abre además la pregunta del id, por si el
       navegador no entiende los fragmentos de texto.
   · Se comprueba: buscar «etiqueta de devolución» abre su respuesta cerrada (con la búsqueda propia, y con la del navegador
     por beforematch), y el enlace copiado, pegado en una pestaña nueva, abre esa respuesta con la frase resaltada.
   · Teclado: ↑ ↓ pasan de una pregunta a otra, Inicio y Fin saltan a la primera y a la última, Intro o Espacio abren; / enfoca el
     buscador; R vuelve al principio.

   Montaje (se inicia solo sobre [data-recoveco]; el HTML es la plantilla: una <section class="rc-grupo"> por tema y un
   <details class="rc-p" name="tema" id="…"> por pregunta, con su <div class="rc-resp" hidden="until-found" data-frase="…">):
     const r = Recoveco(document.querySelector('[data-recoveco]'), { abierta: 'envios-plazo' });
     r.busca('devolución');  r.siguiente();  r.abre('cuenta-clave');  r.enlace('cambios-devolver');  r.reinicia();  r.estado();

   Qué cambia qué: el azul tinta y el amarillo subrayador, al principio de recoveco.css (--rc-azul y --rc-amarillo). El tiempo
   sale de requestAnimationFrame, setTimeout y animaciones (sin Date, sin azar); lo que se limpia al terminar una animación va
   con un setTimeout, nunca con `onfinish`. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = typeof matchMedia === 'function' ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  const quieto = () => mq.matches;
  const anima = (el, kf, op) => (quieto() || !el || !el.animate) ? null : el.animate(kf, op);
  const escribiendo = t => !!t && (t.tagName === 'TEXTAREA' || (t.tagName === 'INPUT' && /^(text|search|)$/.test(t.type)) || t.isContentEditable);

  /* Una letra sin su tilde y en minúscula; las posiciones del texto normalizado se pueden devolver al original. */
  const base = c => c.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  function mapa(texto) {
    let n = '';
    const idx = [];
    for (let i = 0; i < texto.length; i++) {
      const d = base(texto[i]);
      for (let k = 0; k < d.length; k++) { n += d[k]; idx.push(i); }
    }
    return { n, idx };
  }
  const norm = s => mapa(s).n;
  /* Lo que el fragmento de texto pide escapar además de lo normal: el guion, la coma y el ampersand. */
  const codifica = t => encodeURIComponent(t).replace(/-/g, '%2D');
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));

  /* Un resorte convertido en curva `linear()` de CSS. */
  const APOYA = !!(window.CSS && CSS.supports && CSS.supports('transition-timing-function', 'linear(0, 1)'));
  function muelle(k, c) {
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const n = 40, out = [];
    for (let i = 0; i < n + 1; i++) out.push(pts[Math.round(i / n * (pts.length - 1))].toFixed(4));
    out[n] = '1';
    return { curva: APOYA ? 'linear(' + out.join(', ') + ')' : 'cubic-bezier(.34, 1.4, .64, 1)', ms: Math.round(t * 1000) };
  }
  const R1 = muelle(260, 19);   // las fichas que entran y la marca del índice

  function Recoveco(raiz, opciones) {
    const o = Object.assign({ abierta: 'envios-plazo' }, opciones);
    const $ = s => raiz.querySelector(s);
    const $$ = s => Array.from(raiz.querySelectorAll(s));
    const paneles = $$('.rc-p');
    const temas = {};
    $$('[data-tema]').forEach(a => { temas[a.dataset.tema] = a; });
    const campo = $('[data-buscar]'), cuentaEl = $('[data-cuenta]'), btnAnt = $('[data-ant]'), btnSig = $('[data-sig]');
    const estadoEl = $('[data-estado]'), notaEl = $('[data-nota]'), atajoEl = $('[data-atajo]'), grupos = $('[data-grupos]');

    /* qué sabe hacer este navegador: se dice en la nota, no se finge */
    const SOPORTA_FIND = typeof document !== 'undefined' && 'onbeforematch' in document.body;
    const SOPORTA_NAME = 'name' in HTMLDetailsElement.prototype;
    const SOPORTA_HL = !!(window.CSS && CSS.highlights && typeof Highlight === 'function');
    const MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent || '');
    atajoEl.textContent = MAC ? '⌘ F' : 'Ctrl F';
    notaEl.textContent = SOPORTA_FIND
      ? (MAC ? '⌘F' : 'Ctrl F') + ' también encuentra el texto de las respuestas cerradas y las abre. Este buscador hace lo mismo y cuenta por tema.'
      : 'Tu navegador no busca dentro de lo que está plegado: este buscador lo hace por ti.';
    notaEl.dataset.k = SOPORTA_FIND ? 'si' : 'no';

    let porEnlace = null;
    let resultados = [], actual = -1, consulta = '', timerBusca = 0, timerEstado = 0, timerMarca = 0, timerCopia = 0, bloques = null, rangoFrase = null;
    const timers = [];
    const prog = (f, ms) => { const id = setTimeout(f, ms); timers.push(id); return id; };

    /* ── el texto que se puede buscar: las preguntas y las respuestas, con su mapa a las posiciones originales ── */
    function indexa() {
      bloques = [];
      paneles.forEach(p => {
        const fuentes = [p.querySelector('.rc-q')].concat(Array.from(p.querySelectorAll('.rc-resp p')));
        fuentes.forEach(el => {
          const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
          let n;
          while ((n = w.nextNode())) if (n.nodeValue.trim()) bloques.push(Object.assign({ p, nodo: n }, mapa(n.nodeValue)));
        });
      });
    }

    function estado(txt, tipo) {
      clearTimeout(timerEstado);
      estadoEl.textContent = txt || '';
      estadoEl.dataset.t = tipo || '';
      if (txt && tipo !== 'fijo') timerEstado = setTimeout(() => { estadoEl.textContent = ''; estadoEl.dataset.t = ''; }, 7000);
    }
    const tituloDe = p => p.querySelector('.rc-q').textContent;
    const temaDe = p => p.getAttribute('name');
    const nombreTema = k => temas[k] ? temas[k].querySelector('.rc-tema').textContent : k;

    /* ── marcar el tema en el índice, con un barrido de subrayador ── */
    function marcaTema(k, motivo) {
      Object.values(temas).forEach(a => a.removeAttribute('data-marca'));
      clearTimeout(timerMarca);
      const a = temas[k];
      if (!a) return;
      a.dataset.marca = motivo || '1';
      anima(a.querySelector('.rc-tema'), [{ transform: 'translateX(0)' }, { transform: 'translateX(5px)' }, { transform: 'translateX(0)' }], { duration: R1.ms, easing: R1.curva });
      timerMarca = setTimeout(() => a.removeAttribute('data-marca'), 6500);
    }
    function pulsa(p) {
      p.dataset.pulso = '1';
      prog(() => p.removeAttribute('data-pulso'), 1300);
    }

    /* La altura se anima solo cuando abre o cierra la persona (o el buscador propio): data-anima va en todas las preguntas del tema
       un instante, porque al abrir una se cierra la otra. */
    const timersAnima = {};
    function anim(tema) {
      const grupo = paneles.filter(p => temaDe(p) === tema);
      grupo.forEach(p => p.setAttribute('data-anima', ''));
      clearTimeout(timersAnima[tema]);
      timersAnima[tema] = setTimeout(() => grupo.forEach(p => p.removeAttribute('data-anima')), 700);
    }
    paneles.forEach(p => {
      const s = p.querySelector('summary');
      s.addEventListener('pointerdown', () => anim(temaDe(p)));
      s.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') anim(temaDe(p)); });
    });

    /* ── abrir una pregunta (y cerrar la anterior del tema, si el navegador no lo hace solo) ── */
    function abre(p, sinMover, animada) {
      if (typeof p === 'string') p = document.getElementById(p);
      if (!p) return;
      if (animada) anim(temaDe(p));
      if (!SOPORTA_NAME) paneles.forEach(x => { if (x !== p && x.getAttribute('name') === p.getAttribute('name')) x.open = false; });
      p.open = true;
      if (!sinMover) prog(() => { const el = p; const g = grupos; const r = el.getBoundingClientRect(), gr = g.getBoundingClientRect(); if (r.bottom > gr.bottom - 8 || r.top < gr.top + 8) el.scrollIntoView({ block: 'nearest' }); }, 120);
    }
    paneles.forEach(p => {
      const resp = p.querySelector('.rc-resp');
      p.addEventListener('toggle', () => {
        if (p.open) {
          if (!SOPORTA_NAME) paneles.forEach(x => { if (x !== p && x.getAttribute('name') === p.getAttribute('name')) x.open = false; });
        } else if (!resp.hasAttribute('hidden')) resp.setAttribute('hidden', 'until-found');   // cerrada otra vez: la búsqueda del navegador la vuelve a encontrar
      });
      // la búsqueda del navegador encontró texto dentro de la respuesta cerrada: abre sola y avisa
      resp.addEventListener('beforematch', () => {
        marcaTema(temaDe(p), 'navegador');
        pulsa(p);
        if (porEnlace === p) { porEnlace = null; return; }   // era el enlace que se acaba de abrir: el aviso ya lo dice
        estado('La búsqueda del navegador abrió «' + tituloDe(p) + '» en ' + nombreTema(temaDe(p)) + '.', 'navegador');
      });
    });

    /* ── el buscador propio ─────────────────────────────────────────────── */
    function pintaResaltado() {
      if (!SOPORTA_HL) return;
      CSS.highlights.delete('rc-hallazgo'); CSS.highlights.delete('rc-actual');
      if (resultados.length) {
        CSS.highlights.set('rc-hallazgo', new Highlight(...resultados.map(x => x.r)));
        if (actual >= 0) CSS.highlights.set('rc-actual', new Highlight(resultados[actual].r));
      }
    }
    function pintaCuentas() {
      const porTema = {};
      const conHallazgo = new Set();
      resultados.forEach(x => { const k = temaDe(x.p); porTema[k] = (porTema[k] || 0) + 1; conHallazgo.add(x.p); });
      Object.keys(temas).forEach(k => {
        const n = porTema[k] || 0, a = temas[k];
        a.querySelector('.rc-n').textContent = n || '';
        if (n) a.dataset.hay = '1'; else a.removeAttribute('data-hay');
      });
      paneles.forEach(p => { if (conHallazgo.has(p)) p.dataset.hit = '1'; else p.removeAttribute('data-hit'); });
      const n = resultados.length;
      cuentaEl.textContent = consulta.trim().length < 2 ? '' : (n ? (actual + 1) + ' de ' + n : 'Sin resultados');
      cuentaEl.dataset.v = n ? '1' : '0';
      btnAnt.disabled = btnSig.disabled = n < 2;
      campo.setAttribute('aria-invalid', consulta.trim().length >= 2 && !n ? 'true' : 'false');
    }
    function busca(q) {
      if (typeof q === 'string' && campo.value !== q) campo.value = q;
      consulta = campo.value;
      const qn = norm(consulta.trim());
      if (!bloques) indexa();
      resultados = [];
      actual = -1;
      if (qn.length >= 2) {
        bloques.forEach(b => {
          let i = b.n.indexOf(qn);
          while (i >= 0) {
            const r = new Range();
            r.setStart(b.nodo, b.idx[i]);
            r.setEnd(b.nodo, b.idx[i + qn.length - 1] + 1);
            resultados.push({ r, p: b.p });
            i = b.n.indexOf(qn, i + qn.length);
          }
        });
      }
      if (resultados.length) { actual = 0; va(0, true); } else { pintaResaltado(); pintaCuentas(); }
      if (qn.length >= 2 && !resultados.length) anima(campo.parentNode, [{ transform: 'translateX(0)' }, { transform: 'translateX(-5px)' }, { transform: 'translateX(4px)' }, { transform: 'translateX(-2px)' }, { transform: 'translateX(0)' }], { duration: 320, easing: 'ease-out' });
      return resultados.length;
    }
    function va(i, primera) {
      if (!resultados.length) return;
      actual = (i + resultados.length) % resultados.length;
      const { r, p } = resultados[actual];
      const yaAbierta = p.open;
      abre(p, true, true);
      pintaResaltado();
      pintaCuentas();
      marcaTema(temaDe(p), 'busca');
      if (!yaAbierta) pulsa(p);
      // espera a que la respuesta termine de desplegarse para llevarla a la vista
      prog(() => { const el = r.startContainer.parentElement; if (el) { const e = el.getBoundingClientRect(), g = grupos.getBoundingClientRect(); if (e.bottom > g.bottom - 10 || e.top < g.top + 10) el.scrollIntoView({ block: 'nearest' }); } }, quieto() ? 0 : 480);
      estado('«' + tituloDe(p) + '» · ' + nombreTema(temaDe(p)), 'busca');
    }
    const siguiente = () => va(actual + 1);
    const anterior = () => va(actual - 1);
    function limpia() {
      campo.value = '';
      consulta = '';
      resultados = []; actual = -1;
      pintaResaltado(); pintaCuentas();
      Object.values(temas).forEach(a => a.removeAttribute('data-marca'));
      estado('', '');
    }
    campo.addEventListener('input', () => { clearTimeout(timerBusca); timerBusca = setTimeout(() => busca(), 140); });
    campo.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); clearTimeout(timerBusca); if (consulta !== campo.value) busca(); else if (e.shiftKey) anterior(); else siguiente(); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); siguiente(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); anterior(); }
      else if (e.key === 'Escape') { e.preventDefault(); if (campo.value) limpia(); else campo.blur(); }
    });
    $('[data-form]').addEventListener('submit', e => e.preventDefault());
    btnSig.addEventListener('click', siguiente);
    btnAnt.addEventListener('click', anterior);

    /* ── el índice: lleva al tema y lo señala ── */
    Object.keys(temas).forEach(k => temas[k].addEventListener('click', e => {
      e.preventDefault();
      const g = document.getElementById('tema-' + k);
      g.scrollIntoView({ block: 'start' });
      anima(g, [{ transform: 'scale(.985)' }, { transform: 'scale(1)' }], { duration: R1.ms, easing: R1.curva });
      const s = g.querySelector('summary'); if (s) s.focus({ preventScroll: true });
    }));

    /* ── el enlace a una respuesta, con su frase exacta ── */
    function seleccionEn(resp) {
      const s = window.getSelection && getSelection();
      if (!s || s.isCollapsed || !s.rangeCount) return '';
      const t = s.toString().replace(/\s+/g, ' ').trim();
      return t && resp.contains(s.anchorNode) && resp.contains(s.focusNode) ? t : '';
    }
    function directiva(frase) {
      const pal = frase.split(' ');
      if (frase.length > 70 && pal.length > 8) return codifica(pal.slice(0, 4).join(' ')) + ',' + codifica(pal.slice(-4).join(' '));   // frase larga: de dónde a dónde
      return codifica(frase);
    }
    function enlace(p, seleccion) {
      if (typeof p === 'string') p = document.getElementById(p);
      const resp = p.querySelector('.rc-resp');
      const frase = seleccion || resp.dataset.frase;
      const trozo = '#' + p.id + ':~:text=' + directiva(frase);
      return { url: location.href.split('#')[0] + trozo, trozo, frase };
    }
    function copiaTexto(t) {
      const ta = document.createElement('textarea');
      ta.value = t; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
      document.body.appendChild(ta); ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      return ok;
    }
    let seleccionPrevia = '';
    raiz.addEventListener('pointerdown', e => { const b = e.target.closest('[data-enlace]'); if (b) seleccionPrevia = seleccionEn(b.closest('.rc-resp')); }, true);
    raiz.addEventListener('click', async e => {
      const b = e.target.closest('[data-enlace]');
      if (!b) return;
      const p = b.closest('.rc-p');
      const e2 = enlace(p, seleccionPrevia || seleccionEn(b.closest('.rc-resp')));
      seleccionPrevia = '';
      let ok = false;
      try { await navigator.clipboard.writeText(e2.url); ok = true; } catch (x) { ok = copiaTexto(e2.url); }
      $$('[data-enlace][data-ok]').forEach(x => { x.removeAttribute('data-ok'); x.querySelector('span').textContent = 'Copiar enlace a esta respuesta'; x.parentNode.querySelector('[data-url]').textContent = ''; });
      clearTimeout(timerCopia);
      b.dataset.ok = ok ? '1' : '0';
      b.querySelector('span').textContent = ok ? 'Enlace copiado' : 'No se pudo copiar';
      const u = b.parentNode.querySelector('[data-url]');
      u.textContent = e2.trozo;
      u.title = e2.url;
      anima(u, [{ opacity: 0, transform: 'translateX(-6px)' }, { opacity: 1, transform: 'none' }], { duration: 380, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'backwards' });
      if (ok) {
        anima(b.querySelector('.rc-ok path'), [{ strokeDashoffset: 1 }, { strokeDashoffset: 0 }], { duration: 360, delay: 60, easing: 'ease-out', fill: 'backwards' });
        anima(b, [{ transform: 'scale(.94)' }, { transform: 'scale(1)' }], { duration: R1.ms, easing: R1.curva });
        estado('Enlace listo: al abrirlo se despliega «' + tituloDe(p) + '» y se resalta «' + e2.frase + '».', 'enlace');
      }
      timerCopia = setTimeout(() => { b.removeAttribute('data-ok'); b.querySelector('span').textContent = 'Copiar enlace a esta respuesta'; u.textContent = ''; }, 5200);
    });

    /* ── abrir desde un enlace: el id del fragmento (y, si el navegador deja verla, la frase) ── */
    function destinoEnlace() {
      let h = '';
      try { h = decodeURIComponent(location.hash.slice(1) || ''); } catch (e) { h = location.hash.slice(1) || ''; }
      if (!h) return null;
      const [id, dir] = h.split(':~:');
      const p = id && document.getElementById(id);
      return p && p.classList.contains('rc-p') ? { p, dir } : null;
    }
    function desdeEnlace(d) {
      if (!d) return false;
      const { p, dir } = d;
      porEnlace = p;
      abre(p, false);
      pulsa(p);
      marcaTema(temaDe(p), 'enlace');
      estado('Abierta desde un enlace: «' + tituloDe(p) + '».', 'enlace');
      // los navegadores que dejan la directiva a la vista: se resalta aquí; Chrome la gasta él mismo con ::target-text
      const m = dir && /(?:^|&)text=([^&]*)/.exec(dir);
      if (m && SOPORTA_HL) {
        if (!bloques) indexa();
        const qn = norm(decodeURIComponent(m[1].split(',')[0]));
        const b = bloques.find(x => x.p === p && x.n.indexOf(qn) >= 0);
        if (b) {
          const i = b.n.indexOf(qn), r = new Range();
          r.setStart(b.nodo, b.idx[i]); r.setEnd(b.nodo, b.idx[i + qn.length - 1] + 1);
          rangoFrase = r;
          CSS.highlights.set('rc-actual', new Highlight(r));
        }
      }
      return true;
    }

    /* ── teclado: ↑ ↓ entre preguntas ── */
    grupos.addEventListener('keydown', e => {
      const s = e.target.closest('summary');
      if (!s) return;
      const lista = $$('.rc-p > summary');
      const i = lista.indexOf(s);
      let j = -1;
      if (e.key === 'ArrowDown') j = Math.min(lista.length - 1, i + 1);
      else if (e.key === 'ArrowUp') j = Math.max(0, i - 1);
      else if (e.key === 'Home') j = 0;
      else if (e.key === 'End') j = lista.length - 1;
      if (j < 0) return;
      e.preventDefault();
      lista[j].focus();
      lista[j].scrollIntoView({ block: 'nearest' });
    });
    document.addEventListener('keydown', e => {
      if (e.target !== document.body && !raiz.contains(e.target)) return;
      if (escribiendo(e.target) || e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === '/') { e.preventDefault(); campo.focus(); campo.select(); }
      else if (e.key.toLowerCase() === 'r') { e.preventDefault(); reinicia(); }
    });

    /* ── la entrada: las fichas se acomodan una tras otra ── */
    function entrada() {
      if (quieto()) return;
      $$('.rc-grupo').forEach((g, i) => anima(g, [{ opacity: 0, transform: 'translateY(16px)' }, { opacity: 1, transform: 'none' }], { duration: 620, delay: 80 + i * 90, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'backwards' }));
      Object.keys(temas).forEach((k, i) => anima(temas[k], [{ opacity: 0, transform: 'translateX(-14px)' }, { opacity: 1, transform: 'none' }], { duration: 520, delay: 40 + i * 70, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'backwards' }));
      anima($('.rc-busca'), [{ opacity: 0, transform: 'translateY(-8px)' }, { opacity: 1, transform: 'none' }], { duration: 520, delay: 60, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'backwards' });
    }

    function reinicia(conEntrada, sinAbierta) {
      timers.forEach(clearTimeout); timers.length = 0;
      clearTimeout(timerCopia);
      $$('[data-enlace]').forEach(x => { x.removeAttribute('data-ok'); x.querySelector('span').textContent = 'Copiar enlace a esta respuesta'; x.parentNode.querySelector('[data-url]').textContent = ''; });
      paneles.forEach(p => { p.open = false; p.removeAttribute('data-pulso'); });
      limpia();
      if (SOPORTA_HL) CSS.highlights.clear();
      const ae = document.activeElement;
      if (ae && ae !== document.body && raiz.contains(ae)) ae.blur();
      if (o.abierta && !sinAbierta) abre(o.abierta, true);
      grupos.scrollTop = 0;
      if (conEntrada !== false) entrada();
    }

    const api = {
      busca, siguiente, anterior, abre, enlace, reinicia, limpia,
      estado: () => ({
        abiertas: paneles.filter(p => p.open).map(p => p.id),
        resultados: resultados.length, actual,
        porTema: Object.fromEntries(Object.keys(temas).map(k => [k, +(temas[k].querySelector('.rc-n').textContent || 0)])),
        soporta: { buscarPlegado: SOPORTA_FIND, nameExclusivo: SOPORTA_NAME, resaltado: SOPORTA_HL },
      }),
    };
    indexa();
    const destino = destinoEnlace();
    reinicia(false, !!destino);
    if (!desdeEnlace(destino)) entrada();
    return api;
  }

  window.Recoveco = Recoveco;
  const monta = () => document.querySelectorAll('[data-recoveco]').forEach(el => { if (!el.__recoveco) el.__recoveco = Recoveco(el); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', monta); else monta();
})();
