/* =====================================================================
   Vistazo · Moxen
   Un índice de series en el que cada fila asoma su foto: al pasar el
   cursor aparece una ventana que lo sigue con un poco de retraso, se
   inclina hacia donde vas según la velocidad y crece con un rebote. Al
   cambiar de fila la foto nueva entra con una cortina desde el lado por
   el que llegas (de abajo si bajas, de arriba si subes). En el teléfono,
   el primer toque muestra la foto y el segundo abre el enlace.
   Sin dependencias.

     Vistazo(document.querySelector('[data-vistazo]'), {
       seguimiento: 9,     // cuánto tarda la ventana en alcanzar al cursor (más = más pegada)
       giro: .016,         // grados de inclinación por px/s de velocidad
       fotos: ['img/montana-niebla.jpg', 'img/mar-aereo.jpg', …],   // una por fila, en orden
     });

   Las fotos: cada .vz-fila lleva su foto en un <img class="vz-foto"> del
   HTML (oculto: la ventana la muestra recortada a su proporción con
   background-size: cover). Si se pasa `fotos`, una lista de URLs en el
   orden de las filas, el efecto las pone él mismo.
   ===================================================================== */
(function () {
  'use strict';

  function Vistazo(indice, opciones) {
    const o = Object.assign({ seguimiento: 9, giro: .016, corrida: .55, fotos: null }, opciones);
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const filas = Array.from(indice.querySelectorAll('.vz-fila'));
    const vista = indice.querySelector('.vz-vista');
    const capas = Array.from(vista.querySelectorAll('.vz-capa'));
    /* Las fotos como parámetro: una URL por fila, en orden; sin la opción
       valen las <img> que ya traiga el HTML. */
    if (o.fotos) filas.forEach((f, i) => {
      if (o.fotos[i] == null) return;
      let img = f.querySelector('.vz-foto');
      if (!img) { img = document.createElement('img'); img.className = 'vz-foto'; img.alt = ''; f.appendChild(img); }
      img.src = o.fotos[i];
    });
    // la ventana pinta la foto de la fila como fondo (cover); ya está cargada y decodificada
    const imagenes = filas.map(f => f.querySelector('.vz-foto'));
    const foto = i => 'url("' + (imagenes[i].currentSrc || imagenes[i].src) + '")';
    imagenes.forEach(img => { if (img.decode) img.decode().catch(() => {}); });
    const CORTINA = 'cubic-bezier(.65, 0, .35, 1)', LLEGA = 'cubic-bezier(.22, 1, .36, 1)';

    let w = vista.offsetWidth, h = vista.offsetHeight, W = indice.clientWidth, Hh = indice.clientHeight;
    let x = 0, y = 0, tx = 0, ty = 0, giro = 0, s = 0, vs = 0, activo = false, elegida = -1, arriba = 0;
    let raf = 0, previo = 0;

    // dónde va la ventana: algo a la derecha del cursor y sin salirse del índice
    function apunta(px, py) {
      tx = Math.max(w / 2, Math.min(W - w / 2, px + W * .12));
      ty = Math.max(h / 2 - 40, Math.min(Hh - h / 2 + 40, py));
    }

    function pinta() {
      vista.style.transform = 'translate3d(' + (x - w / 2).toFixed(2) + 'px, ' + (y - h / 2).toFixed(2) + 'px, 0) rotate(' + giro.toFixed(3) + 'deg) scale(' + Math.max(0, s).toFixed(4) + ')';
    }

    /* Cada cuadro: la posición persigue al cursor (amortiguado
       exponencial), el giro sigue a la velocidad horizontal y la escala es
       un resorte con poco roce, para que asome con un rebote. */
    function paso(t) {
      const dt = previo ? Math.min(.05, (t - previo) / 1000) : 0;
      previo = t;
      if (!dt) { raf = requestAnimationFrame(paso); return; }
      const k = 1 - Math.exp(-dt * o.seguimiento), x0 = x;
      x += (tx - x) * k; y += (ty - y) * k;
      const meta = Math.max(-12, Math.min(12, (x - x0) / dt * o.giro));
      giro += (meta - giro) * (1 - Math.exp(-dt * 7));
      const w0 = 15, z = .52, fin = activo ? 1 : 0;
      for (let hh = dt, st; hh > 0; hh -= st) {
        st = Math.min(hh, 1 / 240);
        vs += (-w0 * w0 * (s - fin) - 2 * z * w0 * vs) * st;
        s += vs * st;
      }
      if (!activo && s < .01 && vs < 0) { s = 0; vs = 0; }
      pinta();
      const quieto = Math.abs(tx - x) < .2 && Math.abs(ty - y) < .2 && Math.abs(giro) < .02 && Math.abs(s - fin) < .001 && Math.abs(vs) < .01;
      if (quieto) { s = fin; giro = 0; pinta(); raf = 0; previo = 0; return; }
      raf = requestAnimationFrame(paso);
    }
    const despierta = () => { if (!raf) raf = requestAnimationFrame(paso); };

    /* Cambio de foto: la nueva sube encima de la otra, abriéndose desde el
       borde por el que llegas y asentándose un poco ampliada. */
    function muestra(i) {
      const antes = elegida;
      elegida = i;
      filas.forEach((f, k) => f.classList.toggle('is-elegida', k === i));
      indice.classList.toggle('is-activo', i >= 0);
      if (i < 0) return;
      const nueva = capas[1 - arriba], vieja = capas[arriba];
      /* Si se cruzan varias filas seguidas, la de arriba puede estar todavía
         a medio abrir: se la deja entera para que debajo no quede un hueco. */
      capas.forEach(c => c.getAnimations().forEach(a => a.cancel()));
      nueva.style.backgroundImage = foto(i);
      if (antes < 0 || s < .05 || reduce) {
        // sin ventana a la vista: la foto aparece directamente
        nueva.style.zIndex = 2; vieja.style.zIndex = 1;
      } else {
        const d = i > antes ? 1 : -1;
        nueva.style.zIndex = 2; vieja.style.zIndex = 1;
        nueva.animate([
          { clipPath: d > 0 ? 'inset(100% 0 0 0)' : 'inset(0 0 100% 0)', transform: 'scale(1.3) translateY(' + 12 * d + '%)' },
          { clipPath: 'inset(0 0 0 0)', transform: 'none' },
        ], { duration: 720, easing: CORTINA });
        vieja.animate([{ transform: 'none' }, { transform: 'translateY(' + -10 * d + '%) scale(1.06)' }], { duration: 720, easing: CORTINA });
      }
      arriba = 1 - arriba;
    }

    function entra(i, px, py) {
      if (!activo) {
        activo = true;
        // aparece donde está el cursor, no viaja desde donde se fue
        apunta(px, py);
        if (s < .05) { x = tx; y = ty; giro = 0; }
      }
      if (i !== elegida) muestra(i);
      despierta();
    }
    function sale() {
      activo = false;
      muestra(-1);
      despierta();
    }

    const local = e => { const r = indice.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    filas.forEach((f, i) => {
      f.addEventListener('pointerenter', e => { if (e.pointerType !== 'touch') entra(i, ...local(e)); });
      // en el teléfono, el primer toque solo muestra la foto
      f.addEventListener('click', e => {
        if (matchMedia('(hover: hover)').matches || elegida === i) return;
        e.preventDefault();
        const r = f.getBoundingClientRect(), c = indice.getBoundingClientRect();
        // la ventana se planta a la derecha de la fila tocada
        entra(i, r.right - c.left, r.top - c.top + r.height / 2);
      });
      f.addEventListener('focus', () => {
        const r = f.getBoundingClientRect(), c = indice.getBoundingClientRect();
        entra(i, r.left - c.left + W * .3, r.top - c.top + r.height / 2);
      });
      f.addEventListener('blur', () => { if (!indice.contains(document.activeElement)) sale(); });
    });
    indice.addEventListener('pointermove', e => { if (activo && e.pointerType !== 'touch') { apunta(...local(e)); despierta(); } });
    indice.querySelector('.vz-lista').addEventListener('pointerleave', e => { if (e.pointerType !== 'touch') sale(); });
    addEventListener('resize', () => { w = vista.offsetWidth; h = vista.offsetHeight; W = indice.clientWidth; Hh = indice.clientHeight; });

    pinta();
    return { muestra: i => (i >= 0 ? entra(i, W / 2, filas[i].offsetTop) : sale()) };
  }

  window.Vistazo = Vistazo;
})();
