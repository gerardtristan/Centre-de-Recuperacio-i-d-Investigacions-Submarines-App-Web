# Apoderado · Moxen

Confirma que leíste los avisos del colegio, mira las pruebas del mes, revisa la asistencia y firma autorizaciones con el dedo, todo en una app de apoderado dentro de un teléfono, con pantallas reales y una barra de pestañas. En Avisos cada mensaje pasa a leído al abrirlo y los que lo piden se confirman con un toque, con su día y su hora. En Evaluaciones ves el mes con un punto de color por asignatura y los días cargados. En Asistencia el porcentaje sale exacto de los días de clases (presentes más atrasos, con una decimal) y se compara con el mínimo. En Firmas eliges «Sí autorizo» o «No autorizo», firmas con el dedo una sola vez y la autorización queda respondida con su fecha, sin poder firmarse dos veces.

## Qué trae

- `index.html` — la demostración
- `apoderado.css`
- `apoderado.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `apoderado.css` y `apoderado.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Confirm you read the school’s notices, see the month’s tests, check attendance and sign permission slips with your finger, all in a parent app inside a phone, with real screens and a tab bar. In Notices each message turns read when opened and the ones that ask for it are confirmed with a tap, with their day and time. In Assessments you see the month with a colored dot per subject and the busy days. In Attendance the percentage is exact from the school days (present plus late, one decimal) and is compared with the minimum. In Signatures you choose “I authorize” or “I do not authorize”, sign with your finger once, and the slip is answered with its date and can’t be signed twice.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
