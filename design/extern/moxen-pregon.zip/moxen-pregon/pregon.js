/* =====================================================================
   Pregón · Moxen
   Un editor de la VISTA PREVIA AL COMPARTIR un enlace: escribes el título y
   la descripción, eliges qué parte de la imagen importa y ves a la vez cómo
   quedará en un chat, en una red social y en un correo.

   · Los textos se reescriben a la vez en las tres tarjetas, LETRA A LETRA
     (cada letra nueva entra con un pequeño salto), y cada lugar los corta
     a su manera: el título se trunca con «…» (en coral) en el límite de cada
     sitio (38, 60 y 72 caracteres; la descripción, 70, 110 y 140) y la cabecera
     de cada tarjeta dice cuánto se pierde.
   · Un ANILLO de caracteres en cada campo pasa de azul a ámbar al acercarse
     al límite ideal y a coral al pasarlo.
   · PUNTO FOCAL: arrastra el punto sobre la imagen (o usa las flechas) y las
     tres miniaturas se recomponen con resorte a su proporción (1,91 : 1, 1 : 1
     y 3 : 1); los tres recortes se dibujan sobre la imagen con trazos
     discontinuos y se deslizan con él.
   · Una lista de comprobación se marca con ✓ una a una (título presente, de
     hasta 60, descripción de 70 a 150, imagen suficiente) y avisa en ámbar de lo
     que no cumple.
   · «Copiar etiquetas» entrega el bloque meta (og:title, og:description,
     og:image, og:url y twitter:card) con un ✓; el bloque se actualiza mientras escribes.

   Montaje (se inicia con la llamada de index.html; el HTML de esta demo es la plantilla):
     const p = Pregon(document.querySelector('[data-pregon]'), {
       titulo: '…', descripcion: '…',
       foco: [0.72, 0.4],                              // punto focal, de 0 a 1
       imagen: 'https://estudio.dev/portada.png',      // la URL que irá en og:image
       alCambiar: ({ titulo, descripcion, foco }) => {},
     });
     p.valores();  p.pon({ titulo: 'Otro título' });  p.restablece();

   Qué cambia qué: los límites por lugar están en LIMITES; el ideal de cada campo y los
   mínimos de la lista, en IDEAL; las proporciones, en PROPORCION; la ilustración es el
   <symbol id="pr-arte"> de index.html (cámbialo por tu imagen con el mismo viewBox,
   1200 × 800). Los colores están al principio de pregon.css (--pr-coral es el único acento).
   Sin dependencias; el tiempo viene de requestAnimationFrame y timers (nada de Date),
   así que la página y el vídeo coinciden. Con movimiento reducido no hay resortes ni
   letras que saltan: todo cambia de golpe.
   ===================================================================== */
(function () {
  'use strict';

  /* ── utilidades y resortes (el solver de la familia Moxen) ─────────── */
  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const resorte = (x, p) => ({ x, v: 0, meta: x, k: p.k, c: p.c });
  function avanza(r, dt) {
    for (let t = dt; t > 0;) {
      const h = Math.min(t, 1 / 240);
      r.v += (r.k * (r.meta - r.x) - r.c * r.v) * h;
      r.x += r.v * h;
      t -= h;
    }
  }
  const enReposo = r => Math.abs(r.v) < .0008 && Math.abs(r.meta - r.x) < .0003;
  const MUELLES = {
    arrastre: { k: 640, c: 40 },       // el punto sigue al dedo con un poco de peso
    suelta: { k: 300, c: 21 },         // al usar teclado o restablecer: llega con un pequeño rebote
  };
  function muelle(k, c) {
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const out = [];
    for (let i = 0; i <= 40; i++) out.push(pts[Math.round(i / 40 * (pts.length - 1))].toFixed(4));
    out[40] = '1';
    return 'linear(' + out.join(', ') + ')';
  }

  /* ── lo que cambia de un sitio a otro ─────────────────────────────── */
  const ARTE = { w: 1200, h: 800 };                                 // la imagen: 3 : 2
  const PROPORCION = { social: 1.91, chat: 1, correo: 3 };          // ancho / alto de cada miniatura
  const LIMITES = { social: { t: 60, d: 110 }, chat: { t: 38, d: 70 }, correo: { t: 72, d: 140 } };
  const IDEAL = { t: 60, dmin: 70, dmax: 150 };
  const C_ANILLO = 2 * Math.PI * 9;
  const INICIAL = {
    titulo: 'Así diseñamos una casa junto al río',
    descripcion: 'Un recorrido por las decisiones de proyecto, los materiales y las pruebas de luz de nuestra última casa.',
    foco: [.71, .38],
    imagen: 'https://estudio.dev/portada.png',
    url: 'https://estudio.dev/cuaderno-de-obra',
  };

  /* un texto que se escribe letra a letra y se corta con «…» donde le toca */
  function Texto(el) {
    const chars = [];
    let pp = null;
    return function (texto, limite, animar) {
      const corta = texto.length > limite;
      const mostrado = corta ? texto.slice(0, limite - 1).replace(/\s+$/, '') : texto;
      let p = 0;
      while (p < chars.length && p < mostrado.length && chars[p].textContent === mostrado[p]) p++;
      while (chars.length > p) chars.pop().remove();
      if (pp) { pp.remove(); pp = null; }
      for (let i = p; i < mostrado.length; i++) {
        const s = document.createElement('span');
        s.className = 'pr-l' + (animar && !quieto() ? ' es-nueva' : '');
        s.textContent = mostrado[i];
        el.appendChild(s); chars.push(s);
      }
      if (corta) {
        pp = document.createElement('span');
        pp.className = 'pr-pp' + (animar && !quieto() ? ' pr-l es-nueva' : '');
        pp.textContent = '…';
        el.appendChild(pp);
      }
      return { corta, ocultos: texto.length - mostrado.length };
    };
  }

  function Pregon(raiz, opciones) {
    const op = Object.assign({ titulo: INICIAL.titulo, descripcion: INICIAL.descripcion, foco: INICIAL.foco, imagen: INICIAL.imagen, url: INICIAL.url, alCambiar: null }, opciones);
    const $ = (s, r) => (r || raiz).querySelector(s);
    const $$ = (s, r) => Array.from((r || raiz).querySelectorAll(s));
    raiz.style.setProperty('--pr-muelle', muelle(300, 21));

    const el = {
      titulo: $('[data-titulo]'), desc: $('[data-desc]'), img: $('[data-img]'), punto: $('[data-punto]'), lista: $('[data-lista]'),
      reset: $('[data-restablece]'), copia: $('[data-copia]'), copiaT: $('[data-copia-t]'), codigo: $('[data-codigo]'), vivo: $('[data-vivo]'),
    };
    const cuentas = {};
    ['titulo', 'desc'].forEach(k => { const e = $('[data-cuenta="' + k + '"]'); cuentas[k] = { el: e, n: $('[data-n]', e), anillo: $('[data-anillo]', e), estado: '' }; });
    const cartas = ['social', 'chat', 'correo'].map(clave => {
      const e = $('[data-carta="' + clave + '"]');
      return { clave, el: e, thumb: $('[data-thumb]', e), svg: $('[data-svg]', e), tt: Texto($('[data-tt]', e)), dd: Texto($('[data-dd]', e)), estado: $('[data-estado]', e), frame: $('[data-recorte="' + clave + '"]'), w: 0, h: 0, txt: '' };
    });

    const est = { titulo: op.titulo, desc: op.descripcion, fx: op.foco[0], fy: op.foco[1] };
    const spr = { fx: resorte(est.fx, MUELLES.suelta), fy: resorte(est.fy, MUELLES.suelta) };
    let raf = 0, ultimo = null, imgW = 0, imgH = 0, textoVis = null;
    function anuncia(t) { el.vivo.textContent = t; }

    /* ── los textos y las vistas ─────────────────────────────────── */
    function pintaTextos(titulo, desc, animar) {
      cartas.forEach(c => {
        const a = c.tt(titulo, LIMITES[c.clave].t, animar), b = c.dd(desc, LIMITES[c.clave].d, animar);
        const perdidos = a.ocultos + b.ocultos, txt = perdidos ? 'Se corta · −' + perdidos : 'Completo';
        if (txt !== c.txt) {
          c.txt = txt; c.estado.textContent = txt;
          c.estado.classList.toggle('es-corta', perdidos > 0);
          if (animar && !quieto()) { c.estado.classList.remove('es-pop'); void c.estado.offsetWidth; c.estado.classList.add('es-pop'); }
        }
      });
    }

    /* los anillos de caracteres */
    function pintaCuenta(k, n) {
      const c = cuentas[k];
      let p, estado;
      if (k === 'titulo') { p = n / IDEAL.t; estado = n === 0 || n < 8 ? 'aviso' : n > IDEAL.t ? 'pasa' : n >= IDEAL.t * .85 ? 'aviso' : 'ok'; }
      else { p = n / IDEAL.dmax; estado = n > IDEAL.dmax ? 'pasa' : n < IDEAL.dmin ? 'aviso' : n >= IDEAL.dmax * .85 ? 'aviso' : 'ok'; }
      c.n.textContent = n;
      c.anillo.style.strokeDashoffset = (C_ANILLO * (1 - lim(p, 0, 1))).toFixed(2);
      if (estado !== c.estado) {
        c.estado = estado;
        c.el.classList.toggle('es-aviso', estado === 'aviso');
        c.el.classList.toggle('es-pasa', estado === 'pasa');
        if (!quieto()) { c.el.classList.remove('es-pulso'); void c.el.offsetWidth; c.el.classList.add('es-pulso'); }
      }
    }

    /* la lista de comprobación */
    const comprobaciones = {
      titulo: () => est.titulo.trim().length >= 8 ? 'ok' : est.titulo.trim().length ? 'aviso' : 'no',
      largo: () => !est.titulo.trim().length ? 'no' : est.titulo.length <= IDEAL.t ? 'ok' : 'aviso',
      desc: () => !est.desc.trim().length ? 'no' : est.desc.length >= IDEAL.dmin && est.desc.length <= IDEAL.dmax ? 'ok' : 'aviso',
      imagen: () => 'ok',
    };
    const filas = $$('li', el.lista);
    function pintaLista(escalonado) {
      filas.forEach((li, i) => {
        const e = comprobaciones[li.dataset.chk]();
        if (li.dataset.e === e) return;
        li.style.setProperty('--d', escalonado ? (i * .16 + .25) + 's' : '0s');
        li.dataset.e = e;
      });
    }

    /* las etiquetas meta */
    const lineas = [0, 1, 2, 3, 4].map(() => { const d = document.createElement('div'); el.codigo.appendChild(d); return d; });
    function lineaMeta(d, attr, nombre, valor) {
      d.textContent = '';
      const mk = (cls, t) => { const s = document.createElement('span'); s.className = cls; s.textContent = t; d.appendChild(s); };
      mk('c-tag', '<meta'); mk('c-at', ' ' + attr + '='); mk('c-val', '"' + nombre + '"'); mk('c-at', ' content='); mk('c-val', '"' + valor + '"'); mk('c-tag', '>');
    }
    const esc = s => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
    function pintaCodigo() {
      lineaMeta(lineas[0], 'property', 'og:title', esc(est.titulo));
      lineaMeta(lineas[1], 'property', 'og:description', esc(est.desc));
      lineaMeta(lineas[2], 'property', 'og:image', op.imagen);
      lineaMeta(lineas[3], 'property', 'og:url', op.url);
      lineaMeta(lineas[4], 'name', 'twitter:card', 'summary_large_image');
    }
    const textoMeta = () => [
      '<meta property="og:title" content="' + esc(est.titulo) + '">',
      '<meta property="og:description" content="' + esc(est.desc) + '">',
      '<meta property="og:image" content="' + op.imagen + '">',
      '<meta property="og:url" content="' + op.url + '">',
      '<meta name="twitter:card" content="summary_large_image">',
    ].join('\n');

    function notifica() { if (op.alCambiar) op.alCambiar({ titulo: est.titulo, descripcion: est.desc, foco: [est.fx, est.fy] }); }
    function actualiza(animar) {
      pintaTextos(est.titulo, est.desc, animar);
      pintaCuenta('titulo', est.titulo.length); pintaCuenta('desc', est.desc.length);
      pintaLista(false); pintaCodigo();
    }

    el.titulo.addEventListener('input', () => { cancelaRetipeo(); est.titulo = el.titulo.value; actualiza(true); notifica(); });
    el.desc.addEventListener('input', () => { cancelaRetipeo(); est.desc = el.desc.value; actualiza(true); notifica(); });
    // al entrar en el título se selecciona todo, como en una barra de dirección
    let selTodo = false;
    el.titulo.addEventListener('focus', () => { selTodo = true; setTimeout(() => el.titulo.select(), 0); });
    el.titulo.addEventListener('mouseup', e => { if (selTodo) { e.preventDefault(); selTodo = false; } });
    el.titulo.addEventListener('blur', () => { selTodo = false; });

    /* ── el punto focal y los recortes ──────────────────────────── */
    let arr = null;
    const focoDe = e => { const r = el.img.getBoundingClientRect(); return [lim((e.clientX - r.left) / r.width, 0, 1), lim((e.clientY - r.top) / r.height, 0, 1)]; };
    function ponFoco(x, y, modo) {
      est.fx = lim(x, 0, 1); est.fy = lim(y, 0, 1);
      Object.assign(spr.fx, MUELLES[modo || 'arrastre'], { meta: est.fx });
      Object.assign(spr.fy, MUELLES[modo || 'arrastre'], { meta: est.fy });
      el.img.setAttribute('aria-valuenow', Math.round(est.fx * 100));
      el.img.setAttribute('aria-valuetext', 'Horizontal ' + Math.round(est.fx * 100) + ' %, vertical ' + Math.round(est.fy * 100) + ' %');
      arranca();
    }
    el.img.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      e.preventDefault();
      el.img.focus({ preventScroll: true });
      try { el.img.setPointerCapture(e.pointerId); } catch (x) {}
      arr = { id: e.pointerId };
      el.img.classList.add('es-arrastra');
      const f = focoDe(e); ponFoco(f[0], f[1]);
    });
    el.img.addEventListener('pointermove', e => { if (arr && e.pointerId === arr.id) { const f = focoDe(e); ponFoco(f[0], f[1]); } });
    const suelta = e => {
      if (!arr || (e && e.pointerId !== arr.id)) return;
      arr = null; el.img.classList.remove('es-arrastra');
      Object.assign(spr.fx, MUELLES.suelta); Object.assign(spr.fy, MUELLES.suelta);
      anuncia('Punto focal en ' + Math.round(est.fx * 100) + ' por ciento horizontal y ' + Math.round(est.fy * 100) + ' vertical');
      notifica();
    };
    el.img.addEventListener('pointerup', suelta);
    el.img.addEventListener('pointercancel', suelta);
    el.img.addEventListener('keydown', e => {
      const p = e.shiftKey ? .1 : .04;
      const d = { ArrowLeft: [-p, 0], ArrowRight: [p, 0], ArrowUp: [0, -p], ArrowDown: [0, p] }[e.key];
      if (!d) return;
      e.preventDefault();
      ponFoco(est.fx + d[0], est.fy + d[1], 'suelta'); notifica();
    });

    /* una miniatura es la imagen escalada para cubrir su caja y desplazada para que el punto focal quede lo más cerca posible del centro */
    function pintaRecortes() {
      const fx = spr.fx.x, fy = spr.fy.x, k = imgW / ARTE.w;
      cartas.forEach(c => {
        if (c.w) {
          const s = Math.max(c.w / ARTE.w, c.h / ARTE.h), iw = ARTE.w * s, ih = ARTE.h * s;
          const ox = lim(fx * iw - c.w / 2, 0, iw - c.w), oy = lim(fy * ih - c.h / 2, 0, ih - c.h);
          c.svg.style.width = iw.toFixed(2) + 'px'; c.svg.style.height = ih.toFixed(2) + 'px';
          c.svg.style.transform = 'translate(' + (-ox).toFixed(2) + 'px,' + (-oy).toFixed(2) + 'px)';
        }
        if (imgW) {
          const r = PROPORCION[c.clave], cw = r >= ARTE.w / ARTE.h ? ARTE.w : ARTE.h * r, ch = cw / r;
          const cx = lim(fx * ARTE.w - cw / 2, 0, ARTE.w - cw), cy = lim(fy * ARTE.h - ch / 2, 0, ARTE.h - ch);
          c.frame.style.width = (cw * k).toFixed(2) + 'px'; c.frame.style.height = (ch * k).toFixed(2) + 'px';
          c.frame.style.transform = 'translate(' + (cx * k).toFixed(2) + 'px,' + (cy * k).toFixed(2) + 'px)';
        }
      });
      if (imgW) el.punto.style.transform = 'translate(' + (fx * imgW).toFixed(2) + 'px,' + (fy * imgH).toFixed(2) + 'px)';
    }
    function mide() {
      const r = el.img.getBoundingClientRect(); imgW = r.width; imgH = r.height;
      cartas.forEach(c => { const t = c.thumb.getBoundingClientRect(); c.w = t.width; c.h = t.height; });
      pintaRecortes();
    }
    if (window.ResizeObserver) { const ro = new ResizeObserver(mide); ro.observe(el.img); cartas.forEach(c => ro.observe(c.thumb)); } else window.addEventListener('resize', mide);

    /* ── el bucle de los resortes ──────────────────────────────── */
    function arranca() { if (!raf) raf = requestAnimationFrame(cuadro); }
    function cuadro(ahora) {
      raf = 0;
      const dt = ultimo == null ? 1 / 60 : lim((ahora - ultimo) / 1000, .001, .05);
      ultimo = ahora;
      let mueve = false;
      ['fx', 'fy'].forEach(k => {
        const r = spr[k];
        if (quieto()) { r.x = r.meta; r.v = 0; } else { avanza(r, dt); if (enReposo(r)) { r.x = r.meta; r.v = 0; } else mueve = true; }
      });
      pintaRecortes();
      if (mueve) arranca(); else ultimo = null;
    }

    /* ── reescribir de golpe, pero letra a letra en las tarjetas ─── */
    let tRetipeo = 0;
    function cancelaRetipeo() { clearTimeout(tRetipeo); tRetipeo = 0; }
    function reescribe(titulo, desc) {
      cancelaRetipeo();
      est.titulo = titulo; est.desc = desc;
      el.titulo.value = titulo; el.desc.value = desc;
      pintaCuenta('titulo', titulo.length); pintaCuenta('desc', desc.length);
      pintaLista(false); pintaCodigo();
      if (quieto()) { pintaTextos(titulo, desc, false); return; }
      let a = 0, b = 0;
      const paso = () => {
        a = Math.min(titulo.length, a + 3); b = Math.min(desc.length, b + 5);
        pintaTextos(titulo.slice(0, a), desc.slice(0, b), true);
        if (a < titulo.length || b < desc.length) tRetipeo = setTimeout(paso, 18); else { tRetipeo = 0; pintaTextos(titulo, desc, false); }
      };
      paso();
    }
    function restablece() {
      reescribe(INICIAL.titulo, INICIAL.descripcion);
      ponFoco(INICIAL.foco[0], INICIAL.foco[1], 'suelta');
      clearTimeout(el.copia.t); el.copia.classList.remove('es-ok'); el.copiaT.textContent = 'Copiar etiquetas';
      anuncia('Vista restablecida');
      notifica();
    }
    el.reset.addEventListener('click', restablece);

    /* ── copiar las etiquetas ──────────────────────────────────── */
    el.copia.addEventListener('click', () => {
      const t = textoMeta();
      const listo = () => {
        el.copia.classList.add('es-ok'); el.copiaT.textContent = 'Copiado';
        lineas.forEach((d, i) => { d.style.setProperty('--i', i); d.classList.remove('es-copia'); void d.offsetWidth; d.classList.add('es-copia'); });
        clearTimeout(el.copia.t);
        el.copia.t = setTimeout(() => { el.copia.classList.remove('es-ok'); el.copiaT.textContent = 'Copiar etiquetas'; }, 1500);
        anuncia('Etiquetas meta copiadas');
      };
      try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).then(listo, listo); return; } } catch (e) {}
      try { const a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); } catch (e) {}
      listo();
    });

    /* ── arranque: los textos ya están y la lista se marca una a una ─ */
    el.titulo.value = est.titulo; el.desc.value = est.desc;
    pintaTextos(est.titulo, est.desc, false);
    pintaCuenta('titulo', est.titulo.length); pintaCuenta('desc', est.desc.length);
    pintaCodigo();
    setTimeout(() => pintaLista(true), 350);
    el.img.setAttribute('aria-valuenow', Math.round(est.fx * 100));
    el.img.setAttribute('aria-valuetext', 'Horizontal ' + Math.round(est.fx * 100) + ' %, vertical ' + Math.round(est.fy * 100) + ' %');
    mide();
    (document.fonts && document.fonts.ready || Promise.resolve()).then(mide);

    return {
      valores: () => ({ titulo: est.titulo, descripcion: est.desc, foco: [est.fx, est.fy] }),
      pon(v) {
        if (v.titulo != null || v.descripcion != null) reescribe(v.titulo != null ? v.titulo : est.titulo, v.descripcion != null ? v.descripcion : est.desc);
        if (v.foco) ponFoco(v.foco[0], v.foco[1], 'suelta');
      },
      restablece,
    };
  }

  window.Pregon = Pregon;
})();
