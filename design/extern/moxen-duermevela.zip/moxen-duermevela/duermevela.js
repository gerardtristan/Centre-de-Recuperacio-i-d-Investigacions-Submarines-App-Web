/* =====================================================================
   Duermevela · Moxen
   El selector de tema que pocas webs hacen bien: tres posiciones (claro, oscuro y «como el sistema»), un cambio que se
   revela con una cortina que sale del propio control, ningún destello al cargar y la misma elección en todas las pestañas
   abiertas. Al lado de la página de ejemplo hay un banco de pruebas que enseña lo que la página lee de verdad.

   Funciona de verdad (lo único simulado es el botón «Simular», que finge un cambio del equipo para quien no quiere tocar
   el suyo; el oyente real sigue puesto):
   · `matchMedia('(prefers-color-scheme: dark)')` y su evento `change`: con «Sistema», si cambia el tema del equipo la página
     lo sigue sin recargar y la etiqueta «El equipo pide» se actualiza.
   · El guion en línea del <head> (index.html) lee la elección guardada y el sistema y deja `data-tema` en <html> antes del
     primer pintado; el medidor lo comprueba: carga la página en un marco y mira el color de fondo de cada cuadro hasta que es
     el del tema («Destello» = cuánto se vio otro color). Con la casilla «Aplicar el tema tarde» el marco lo hace como una web
     que lo pone al terminar de cargar, y el medidor da un destello de verdad (un cuadro o más).
   · `color-scheme`: lo fija el CSS según `data-tema`, y es lo que pinta los controles del navegador (fecha, lista, casilla,
     deslizador, barras de desplazamiento) sin una regla de color.
   · `<meta name="theme-color">` con `media`: una etiqueta por tema. Al elegir a mano, esta página reescribe el `media` de las
     dos (`all` a la que toca, `not all` a la otra); el teléfono del banco lee la que coincide, igual que lo haría el navegador.
   · `<picture>` con `<source media="(prefers-color-scheme: dark)">`: esa condición sigue al sistema y no a tu elección, así que
     al elegir a mano se reescribe también el `media` del <source>.
   · Evento `storage`: guardar la elección en localStorage avisa a las demás pestañas del mismo sitio (y al marco, que es otra
     página); ellas la aplican sin recargar. «Abrir en una pestaña nueva» lo prueba con una pestaña de verdad.
   · La cortina es `document.startViewTransition()` con un recorte circular animado en `::view-transition-new(root)`. Sin la API
     o con movimiento reducido, el cambio es un fundido corto o instantáneo.

   Cómo se monta (ver index.html): el guion del <head> es obligatorio y va ANTES de los estilos; después, este archivo.
     Duermevela.estado()    → { eleccion, tema, pide, guardado, barra, probados, medida }
     Duermevela.elige('oscuro')   cambia como si se pulsara el control (también 'claro' y 'sistema')
   ?tema=claro|oscuro|sistema fuerza la elección inicial sin guardarla; ?marco=1 es la página en pequeño que usa el marco;
   ?tarde=1 aplica el tema tras el primer pintado. R reinicia las fichas de «prueba los tres» y el simulador.
   Qué se personaliza: los colores, al principio de duermevela.css (cada uno con su `light-dark(día, noche)`); si cambias --dv-fondo,
   cambia también COLORES en el guion del <head>, que es con lo que mide el medidor. El tiempo sale de requestAnimationFrame y
   setTimeout (sin Date); lo que se limpia al terminar una animación va con un setTimeout, nunca con `onfinish`. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const T = window.DuermevelaTema;
  if (!T) { console.warn('Duermevela: falta el guion del <head> (ver index.html).'); return; }
  const raiz = document.documentElement;
  const MARCO = !!raiz.dataset.marco;
  const mq = matchMedia('(prefers-color-scheme: dark)');
  const reducido = matchMedia('(prefers-reduced-motion: reduce)');
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const NOMBRE = { claro: 'Claro', oscuro: 'Oscuro', sistema: 'Sistema' };
  const PIDE = { true: 'oscuro', false: 'claro' };
  const ESPERA_SELLO = 3200;                              // cuánto se queda el ✓ antes de volver a las fichas

  let eleccion = T.eleccion;                              // lo que eligió quien usa la página: claro, oscuro o sistema
  let simulado = null;                                    // null, o el tema que finge pedir el equipo (true = oscuro)
  const probados = new Set();
  let medida = null;                                      // la última lectura del medidor: la del marco, que es quien carga la página

  /* ── lo guardado ───────────────────────────────────────────────────────────────────────────────────────────── */
  function lee() {
    try { const v = localStorage.getItem(T.CLAVE); return v === 'claro' || v === 'oscuro' ? v : 'sistema'; } catch (e) { return 'sistema'; }
  }
  function guarda(e) { try { localStorage.setItem(T.CLAVE, e); } catch (err) { /* modo privado: la elección vale solo mientras la página está abierta */ } }
  const sistemaOscuro = () => (simulado !== null ? simulado : mq.matches);

  /* El color que pediría la barra del teléfono: la primera <meta theme-color> cuyo `media` coincide, como hace el navegador. */
  function colorBarra() {
    for (const m of $$('meta[name="theme-color"]')) if (!m.media || matchMedia(m.media).matches) return m.content;
    return '';
  }

  /* ── la cortina: el tema nuevo crece como un círculo desde `origen` ────────────────────────────────────────── */
  function cortina(origen, cambia) {
    if (reducido.matches) { cambia(); return; }
    if (!document.startViewTransition || document.hidden) {        // sin la API: un fundido corto de los colores
      raiz.classList.add('dv-suave'); cambia();
      setTimeout(() => raiz.classList.remove('dv-suave'), 700);
      return;
    }
    const r = (origen || document.body).getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    const radio = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y)) + 4;
    const vt = document.startViewTransition(cambia);
    vt.ready.then(() => {
      raiz.animate({ clipPath: ['circle(0px at ' + x + 'px ' + y + 'px)', 'circle(' + radio + 'px at ' + x + 'px ' + y + 'px)'] },
        { duration: 820, easing: 'cubic-bezier(.6, .02, .2, 1)', pseudoElement: '::view-transition-new(root)' });
    }).catch(() => {});
    vt.finished.catch(() => {});
  }

  /* ── aplicar: resolver, poner y, si el tema cambia, con cortina ────────────────────────────────────────────── */
  function aplica(nueva, origen) {
    const antes = raiz.dataset.tema;
    eleccion = nueva;
    const tema = T.resuelve(nueva, sistemaOscuro());
    const pon = () => { T.aplica(nueva, tema, simulado !== null); pinta(); };
    if (tema === antes) { pon(); return; }
    cortina(origen, pon);
  }

  /* ── los elementos ─────────────────────────────────────────────────────────────────────────────────────────── */
  const ctl = $('#dv-control'), radios = $$('input[name="dv-tema"]'), estado = $('#dv-estado');
  const lPide = $('#dv-l-pide'), lGuardado = $('#dv-l-guardado'), lAplicado = $('#dv-l-aplicado'), lBarra = $('#dv-l-barra'), lMuestra = $('#dv-l-muestra');
  const telBarra = $('#dv-tel-barra'), sim = $('#dv-sim');
  const probadosCaja = $('#dv-probados'), probadosTxt = $('#dv-probados-txt');
  const medViejo = $('#dv-med-viejo'), tira = $('#dv-tira'), marcoEl = $('#dv-marco'), medidor = $('.dv-medidor'), flash = $('#dv-flash'), medTxt = $('#dv-med-txt'), recargaBtn = $('#dv-recarga'), tardeChk = $('#dv-tarde');
  const mTema = $('#dv-m-tema'), mAviso = $('#dv-m-aviso'), mChip = $('.dv-mini-chip');

  /* ── pintar lo que la página sabe de sí misma ──────────────────────────────────────────────────────────────── */
  function pinta() {
    const tema = raiz.dataset.tema;
    if (!tema) return;                                            // con ?tarde=1, hasta el primer pintado no hay tema
    raiz.dataset.listo = '1';
    if (MARCO) { mTema.textContent = NOMBRE[eleccion] + (eleccion === 'sistema' ? ' · ' + tema : ''); return; }
    const pide = PIDE[sistemaOscuro()];
    ctl.dataset.eleccion = eleccion;
    radios.forEach(r => { r.checked = r.value === eleccion; });
    const nota = simulado !== null ? ' <small>(simulado)</small>' : '';
    estado.innerHTML = '<span>' + (eleccion === 'sistema'
      ? 'Siguiendo a tu equipo: ahora pide <b>' + pide + '</b>' + nota
      : 'Fijado en <b>' + NOMBRE[eleccion] + '</b>. Tu equipo pide ' + pide + '.' + nota) + '</span>';
    lPide.textContent = pide + (simulado !== null ? ' · simulado' : '');
    lGuardado.textContent = lee();
    lAplicado.textContent = tema;
    const barra = colorBarra();
    lBarra.textContent = barra; lMuestra.style.background = barra; telBarra.style.background = barra;
    sim.setAttribute('aria-pressed', simulado !== null ? 'true' : 'false');
    notaMedida();
  }

  /* La medida es de la última carga del marco: si luego cambias de tema, deja de describir a la página y lo dice. La línea
     tiene su sitio reservado: que aparezca no mueve nada. */
  function notaMedida() {
    const vieja = !!medida && (medida.eleccion !== eleccion || medida.tema !== raiz.dataset.tema);
    if (vieja) medViejo.textContent = 'Medida con el tema ' + medida.tema + ': recarga el marco.';
    medViejo.dataset.vis = vieja ? '1' : '';
  }

  /* ── «prueba los tres»: cada estado elegido enciende su ficha; con los tres, un ✓ ciruela ─────────────────── */
  let temporizadorSello = 0;
  function marca(e) {
    if (probados.has(e)) return;
    probados.add(e);
    const ficha = $('.dv-fichas i[data-e="' + e + '"]');
    if (ficha) ficha.dataset.ok = '1';
    if (probados.size === 3) {
      probadosCaja.dataset.completo = '1';
      probadosTxt.textContent = 'Los tres estados, probados';
      clearTimeout(temporizadorSello);
      temporizadorSello = setTimeout(reinicia, ESPERA_SELLO);
    }
  }
  function reinicia() {
    probados.clear();
    clearTimeout(temporizadorSello);
    $$('.dv-fichas i').forEach(f => { delete f.dataset.ok; });
    delete probadosCaja.dataset.completo;
    probadosTxt.textContent = 'Prueba los tres estados';
  }

  /* ── el control ────────────────────────────────────────────────────────────────────────────────────────────── */
  function elige(valor, origen) {
    if (valor !== 'claro' && valor !== 'oscuro' && valor !== 'sistema') return;
    guarda(valor);
    marca(valor);
    if (valor === eleccion && raiz.dataset.eleccion === valor) { pinta(); return; }
    aplica(valor, origen || $('.dv-pulgar'));
  }
  if (!MARCO) {
    radios.forEach(r => {
      const label = r.closest('label');
      r.addEventListener('change', () => elige(r.value, label));
      r.addEventListener('click', () => marca(r.value));
    });
  }

  /* ── el sistema: el evento `change` de matchMedia ──────────────────────────────────────────────────────────── */
  mq.addEventListener('change', () => {
    if (simulado !== null) return;                                // el simulador manda mientras está puesto
    if (eleccion === 'sistema') aplica('sistema', MARCO ? mChip : lPide); else pinta();
  });
  if (sim) sim.addEventListener('click', () => {
    simulado = simulado === null ? !mq.matches : null;
    avisaAlMarco();
    if (eleccion === 'sistema') aplica('sistema', sim); else pinta();
  });

  /* ── otra pestaña: el evento `storage` ─────────────────────────────────────────────────────────────────────── */
  let temporizadorAviso = 0;
  addEventListener('storage', ev => {
    if (ev.key !== null && ev.key !== T.CLAVE) return;
    const nueva = lee();
    if (nueva === eleccion && raiz.dataset.eleccion === nueva) return;
    aplica(nueva, MARCO ? mChip : $('.dv-pulgar'));
    if (MARCO) {
      mAviso.dataset.visible = '1';
      clearTimeout(temporizadorAviso);
      temporizadorAviso = setTimeout(() => { delete mAviso.dataset.visible; }, 1700);
    }
  });

  /* ── el marco: se recarga, mide y recibe el simulador ──────────────────────────────────────────────────────── */
  let rodando = 0;
  function rueda(hasta) {
    cancelAnimationFrame(rodando);
    const desde = parseInt(flash.textContent, 10) || 0, t0 = performance.now(), dur = 520;
    if (reducido.matches || desde === hasta) { flash.textContent = hasta; return; }
    const paso = ahora => {
      const u = Math.min(1, (ahora - t0) / dur), e = 1 - Math.pow(1 - u, 3);
      flash.textContent = Math.round(desde + (hasta - desde) * e);
      if (u < 1) rodando = requestAnimationFrame(paso);
    };
    rodando = requestAnimationFrame(paso);
  }
  function muestraMedida(d) {
    medida = d;
    rueda(d.flash);
    if (d.flash > 0) medidor.dataset.destello = '1'; else delete medidor.dataset.destello;
    notaMedida();
    $$('i', tira).forEach((c, k) => { const col = d.serie[k]; c.style.background = col || ''; c.dataset.mal = col && col !== d.esperado ? '1' : ''; c.title = 'Cuadro ' + (k + 1) + ': ' + (col || ''); });
    const mal = d.primero !== d.esperado;
    medTxt.innerHTML = '<span>' + (mal
      ? 'El primer cuadro fue <code>' + d.primero + '</code>, no el de ' + NOMBRE[d.tema] + ' (<code>' + d.esperado + '</code>): ' + d.flash + ' ms con el color equivocado.'
      : 'El primer cuadro ya fue <code>' + d.primero + '</code>, el de ' + NOMBRE[d.tema] + ': el guion del &lt;head&gt; lo fijó antes del primer pintado.') + '</span>';
  }
  function avisaAlMarco() {
    if (!marcoEl || !marcoEl.contentWindow) return;
    marcoEl.contentWindow.postMessage({ duermevela: 'simula', oscuro: simulado }, '*');
  }
  function recarga() {
    recargaBtn.dataset.girando = '1';
    setTimeout(() => { delete recargaBtn.dataset.girando; }, 700);
    medTxt.textContent = 'Midiendo el primer color pintado…';
    medida = null; notaMedida();
    $$('i', tira).forEach(c => { c.style.background = ''; c.dataset.mal = ''; });
    marcoEl.src = urlMarco();
  }
  // el marco carga la misma página en pequeño; si esta lleva ?tema=, el marco también (cada uno guarda lo suyo si no)
  const reenvio = (/[?&](tema=(?:claro|oscuro|sistema))/.exec(location.search) || [])[1];
  const urlMarco = () => marcoEl.dataset.src + (reenvio ? '&' + reenvio : '') + (tardeChk.checked ? '&tarde=1' : '');
  if (!MARCO) {
    if (reenvio) marcoEl.src = urlMarco();                       // el HTML ya trae el marco; solo se cambia si hay que pasarle ?tema=
    recargaBtn.addEventListener('click', recarga);
    tardeChk.addEventListener('change', recarga);
  }
  addEventListener('message', ev => {
    const d = ev.data;
    if (!d || typeof d !== 'object') return;
    if (!MARCO && marcoEl && ev.source === marcoEl.contentWindow && d.duermevela === 'medida') {
      muestraMedida(d);
      if (simulado !== null) avisaAlMarco();                      // el marco recién cargado se entera de la simulación
    }
    if (MARCO && ev.source === parent && d.duermevela === 'simula') {
      simulado = d.oscuro;
      if (eleccion === 'sistema') aplica('sistema', mChip); else pinta();
    }
  });

  /* ── teclado: R vuelve al principio ───────────────────────────────────────────────────────────────────────── */
  addEventListener('keydown', ev => {
    if ((ev.key !== 'r' && ev.key !== 'R') || ev.metaKey || ev.ctrlKey || ev.altKey) return;
    if (/^(input|select|textarea)$/i.test(ev.target.tagName) && ev.target.type !== 'radio') return;
    reinicia();
    if (simulado !== null) { simulado = null; avisaAlMarco(); if (eleccion === 'sistema') { aplica('sistema', lPide); return; } }
    pinta();
  });

  /* ── arranque ──────────────────────────────────────────────────────────────────────────────────────────────── */
  // `data-tema` también lo pone, más tarde, el guion de ?tarde=1: se pinta cada vez que cambia
  new MutationObserver(pinta).observe(raiz, { attributes: true, attributeFilter: ['data-tema'] });
  if (raiz.dataset.tema) T.aplica(eleccion, raiz.dataset.tema);   // las <picture> se crearon después del guion del <head>
  pinta();

  window.Duermevela = {
    elige: valor => elige(valor, $('.dv-pulgar')),
    estado: () => ({
      eleccion, tema: raiz.dataset.tema, pide: PIDE[sistemaOscuro()], guardado: lee(), barra: colorBarra(),
      probados: Array.from(probados), medida
    })
  };
})();
