# Trámite · Moxen

El cliente sigue su pago paso a paso (procesando, autorizado, abonado) con una línea que se llena durante el tiempo real de cada paso y su duración anotada en cada etapa. Si el emisor rechaza el intento, la etapa se vuelve amarilla y solo quedan activos «Reintentar» y «Cancelar»; al abonarse, un comprobante sale por una ranura con su número, fecha y estado, y «Imprimir o guardar PDF» lo deja solo en blanco y negro para el papel.

## Qué trae

- `index.html` — la demostración
- `tramite.css`
- `tramite.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `tramite.css` y `tramite.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

The customer follows the payment step by step (processing, authorized, settled) with a line that fills during the real time of each step and its duration noted on every stage. If the issuer rejects the attempt, the stage turns yellow and only “Retry” and “Cancel” stay active; once settled, a receipt comes out of a slot with its number, date and status, and “Print or save as PDF” leaves just that receipt in black and white for paper.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
