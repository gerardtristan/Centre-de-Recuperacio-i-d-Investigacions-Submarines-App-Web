/* =====================================================================
   Teletipo · Moxen — el núcleo: leer feeds de verdad. Corre en el navegador (window.TeletipoNucleo) porque usa DOMParser; no
   sube ni descarga nada: lee el texto que se le da.

   · Detectar: por el contenido, no por la extensión. Un texto que empieza por «{» es JSON Feed; si no, se lee como XML y la raíz
     manda: <rss> (RSS 2.0), <RDF> (RSS 1.0), <feed> (Atom) o <opml>. Un XML mal formado dice cuál es el error en vez de fallar.
   · Leer: cada formato llega a la misma forma de artículo { guid, titulo, url, fecha, autor, etiquetas, html }. RSS usa
     <content:encoded> si existe y <description> si no; Atom entiende title/content de tipo text, html y xhtml; JSON Feed usa
     content_html o content_text. Las fechas (RFC 822 o ISO 8601) pasan a milisegundos.
   · Sanear: el HTML de cada artículo se reescribe desde cero con una lista blanca. Se parsea con DOMParser (un documento
     inerte: no ejecuta scripts ni carga imágenes) y se COPIAN solo las etiquetas permitidas con los atributos permitidos; todo
     lo demás se quita o se desenvuelve. Se cuenta lo que se quitó: scripts (etiquetas, onclick y enlaces javascript:), estilos,
     marcos, imágenes (con las de seguimiento aparte, por su tamaño o su dirección) y parámetros de seguimiento de los enlaces
     (utm_*, fbclid, gclid…).
   · OPML: las suscripciones se leen con sus carpetas (outline anidados) y se exportan en OPML 2.0 con los atributos escapados;
     lo exportado vuelve a importar las mismas fuentes.
   · La fecha relativa: «ahora», «hace 35 min», «hace 3 h», «ayer», «hace 4 d» y, pasada una semana, «12 oct».
   ===================================================================== */
(function (raiz) {
  'use strict';

  const NS_CONTENT = 'http://purl.org/rss/1.0/modules/content/';

  /* ------------------------------------------------------------------
     Utilidades
     ------------------------------------------------------------------ */
  const sinTildes = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '');
  const plano = s => sinTildes(s).toLowerCase();
  const escHtml = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const escXml = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  const colapsa = s => String(s || '').replace(/\s+/g, ' ').trim();
  const fecha = s => { const t = Date.parse(String(s || '').trim()); return isNaN(t) ? 0 : t; };
  const hijos = (el, nombre) => el ? Array.from(el.children).filter(c => c.localName === nombre) : [];
  const primero = (el, nombre) => hijos(el, nombre)[0] || null;
  const texto = el => el ? el.textContent.trim() : '';
  /* La dirección sin lo que cambia de una descarga a otra: solo para formar identificadores estables. */
  const slug = s => plano(s).replace(/^[a-z]+:\/\//, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'fuente';

  /* ------------------------------------------------------------------
     Detectar y leer
     ------------------------------------------------------------------ */
  /* El navegador cuenta el error de XML a su manera (y cada uno distinto): de ahí se saca la línea, la columna y, si se puede,
     una frase en español. */
  function explicaErrorXml(msg) {
    msg = colapsa(msg);
    let lin = (msg.match(/(?:line(?: number)?|línea)\s+(\d+)/i) || [])[1], col = (msg.match(/column\s+(\d+)/i) || [])[1];
    let que = '';
    const par = msg.match(/tag mismatch:\s*(\S+)\s+line\s+\d+\s+and\s+(\S+)/i);
    if (par) que = '<' + par[1] + '> se cierra con </' + par[2] + '>';
    else if (/mismatched tag/i.test(msg)) que = 'una etiqueta se cierra mal';
    else if (/not well-formed|xmlParseEntityRef|Entity '.*' not defined|undefined entity/i.test(msg)) que = 'hay un carácter o una entidad no válidos (¿un &nbsp; o un & suelto?)';
    else if (/premature end|unexpected end|end of file/i.test(msg)) que = 'el archivo termina antes de cerrar todas las etiquetas';
    else if (/Start tag expected/i.test(msg)) que = 'no empieza con una etiqueta XML';
    const donde = lin ? ' (línea ' + lin + (col ? ', columna ' + col : '') + ')' : '';
    return 'El XML no está bien formado' + (que ? ': ' + que : '') + donde;
  }
  function analizaXml(txt) {
    const doc = new DOMParser().parseFromString(txt, 'application/xml');
    const err = doc.getElementsByTagName('parsererror')[0];
    if (err) throw new Error(explicaErrorXml(err.textContent));
    return doc;
  }
  function detecta(txt) {
    const t = String(txt || '').replace(/^﻿/, '').trim();
    if (!t) return 'vacio';
    if (t[0] === '{') {
      try { const j = JSON.parse(t); return j && /jsonfeed\.org/.test(String(j.version || '')) || (j && Array.isArray(j.items) && 'title' in j) ? 'json' : 'desconocido'; } catch (e) { return 'desconocido'; }
    }
    if (t[0] !== '<') return 'desconocido';
    let doc;
    try { doc = analizaXml(t); } catch (e) { return 'desconocido'; }
    const r = doc.documentElement.localName.toLowerCase();
    return r === 'rss' ? 'rss' : r === 'rdf' ? 'rss' : r === 'feed' ? 'atom' : r === 'opml' ? 'opml' : 'desconocido';
  }

  const articulo = o => ({
    guid: o.guid || o.url || (o.titulo + '|' + o.fecha), titulo: colapsa(o.titulo) || 'Sin título', url: o.url || '', fecha: o.fecha || 0,
    autor: colapsa(o.autor), etiquetas: (o.etiquetas || []).map(colapsa).filter(Boolean), html: o.html || '', resumen: o.resumen || '',
  });
  const aParrafos = t => String(t || '').split(/\n{2,}/).map(p => p.trim()).filter(Boolean).map(p => '<p>' + escHtml(p).replace(/\n/g, '<br>') + '</p>').join('');

  function leeRss(doc) {
    const raizEl = doc.documentElement;
    const canal = primero(raizEl, 'channel') || raizEl;
    const items = raizEl.localName.toLowerCase() === 'rdf' ? hijos(raizEl, 'item') : hijos(canal, 'item');
    const autorCanal = texto(primero(canal, 'managingEditor')) || texto(primero(canal, 'creator'));
    return {
      formato: 'rss', titulo: colapsa(texto(primero(canal, 'title'))) || 'Fuente sin título', web: texto(hijos(canal, 'link').find(l => !l.getAttribute('rel')) || null),
      url: ((hijos(canal, 'link').find(l => l.getAttribute('rel') === 'self') || { getAttribute: () => '' }).getAttribute('href')) || '', descripcion: colapsa(texto(primero(canal, 'description'))),
      articulos: items.map(it => {
        const guid = primero(it, 'guid');
        let url = texto(primero(it, 'link'));
        if (!url && guid && guid.getAttribute('isPermaLink') !== 'false') url = texto(guid);
        const enc = it.getElementsByTagNameNS(NS_CONTENT, 'encoded')[0] || hijos(it, 'encoded')[0];
        const html = enc ? enc.textContent : texto(primero(it, 'description'));
        return articulo({
          guid: texto(guid) || url, titulo: texto(primero(it, 'title')), url, fecha: fecha(texto(primero(it, 'pubDate')) || texto(primero(it, 'date'))),
          autor: texto(primero(it, 'creator')) || texto(primero(it, 'author')) || autorCanal, etiquetas: hijos(it, 'category').map(texto), html,
          resumen: enc ? texto(primero(it, 'description')) : '',
        });
      }),
    };
  }
  function leeAtom(doc) {
    const f = doc.documentElement;
    const enlace = (el, rel) => {
      const ls = hijos(el, 'link');
      const l = ls.find(x => (x.getAttribute('rel') || 'alternate') === rel) || (rel === 'alternate' ? ls[0] : null);
      return l ? (l.getAttribute('href') || '') : '';
    };
    const contenido = el => {
      if (!el) return '';
      const tipo = (el.getAttribute('type') || 'text').toLowerCase();
      if (tipo === 'xhtml') {
        const s = new XMLSerializer(), div = el.firstElementChild;                  // el estándar pide un único <div> dentro
        return Array.from((div && div.localName === 'div' ? div : el).childNodes).map(n => s.serializeToString(n)).join('').replace(/ xmlns="[^"]*"/g, '');
      }
      if (tipo === 'html' || tipo === 'text/html') return el.textContent;
      return aParrafos(el.textContent);
    };
    const autorFeed = texto(primero(primero(f, 'author'), 'name'));
    return {
      formato: 'atom', titulo: colapsa(texto(primero(f, 'title'))) || 'Fuente sin título', web: enlace(f, 'alternate'), url: enlace(f, 'self'), descripcion: colapsa(texto(primero(f, 'subtitle'))),
      articulos: hijos(f, 'entry').map(e => articulo({
        guid: texto(primero(e, 'id')) || enlace(e, 'alternate'), titulo: texto(primero(e, 'title')), url: enlace(e, 'alternate'),
        fecha: fecha(texto(primero(e, 'published')) || texto(primero(e, 'updated'))), autor: texto(primero(primero(e, 'author'), 'name')) || autorFeed,
        etiquetas: hijos(e, 'category').map(c => c.getAttribute('term') || ''), html: contenido(primero(e, 'content')) || contenido(primero(e, 'summary')),
        resumen: texto(primero(e, 'summary')),
      })),
    };
  }
  function leeJson(txt) {
    const j = JSON.parse(txt);
    const autorFeed = (j.authors && j.authors[0] && j.authors[0].name) || (j.author && j.author.name) || '';
    return {
      formato: 'json', titulo: colapsa(j.title) || 'Fuente sin título', web: j.home_page_url || '', url: j.feed_url || '', descripcion: colapsa(j.description),
      articulos: (j.items || []).map(it => articulo({
        guid: it.id != null ? String(it.id) : (it.url || ''), titulo: it.title || colapsa((it.content_text || '').slice(0, 60)), url: it.url || it.external_url || '',
        fecha: fecha(it.date_published || it.date_modified), autor: (it.authors && it.authors[0] && it.authors[0].name) || (it.author && it.author.name) || autorFeed,
        etiquetas: it.tags || [], html: it.content_html || aParrafos(it.content_text || it.summary || ''), resumen: it.summary || '',
      })),
    };
  }
  /* Lee un feed (RSS, Atom o JSON Feed) y lo deja en la forma común. Lanza un Error con un mensaje que se puede mostrar. */
  function leeFeed(txt) {
    txt = String(txt || '').replace(/^﻿/, '').trim();
    const tipo = detecta(txt);
    if (tipo === 'vacio') throw new Error('El archivo está vacío');
    if (tipo === 'opml') throw new Error('Es un OPML: trae suscripciones, no artículos');
    if (tipo === 'desconocido') {
      if (txt[0] === '<') analizaXml(txt);                                            // si es XML roto, el error dice dónde
      throw new Error('No parece un feed: se esperaba RSS, Atom o JSON Feed');
    }
    const feed = tipo === 'json' ? leeJson(txt) : tipo === 'atom' ? leeAtom(analizaXml(txt)) : leeRss(analizaXml(txt));
    feed.id = slug(feed.url || feed.web || feed.titulo);
    return feed;
  }

  /* ------------------------------------------------------------------
     OPML: leer y exportar
     ------------------------------------------------------------------ */
  function leeOpml(txt) {
    txt = String(txt || '').replace(/^﻿/, '').trim();
    const doc = analizaXml(txt);
    if (doc.documentElement.localName.toLowerCase() !== 'opml') throw new Error('No es un OPML');
    const fuentes = [];
    const recorre = (el, carpeta) => {
      hijos(el, 'outline').forEach(o => {
        const url = o.getAttribute('xmlUrl') || o.getAttribute('xmlurl') || '';
        const nombre = o.getAttribute('title') || o.getAttribute('text') || '';
        if (url) fuentes.push({ titulo: colapsa(nombre) || url, url, web: o.getAttribute('htmlUrl') || o.getAttribute('htmlurl') || '', carpeta: carpeta || '' });
        else if (hijos(o, 'outline').length) recorre(o, colapsa(nombre));
      });
    };
    recorre(primero(doc.documentElement, 'body') || doc.documentElement, '');
    const cab = primero(doc.documentElement, 'head');
    return { titulo: colapsa(texto(primero(cab, 'title'))), fuentes };
  }
  function exportaOpml(fuentes, titulo) {
    const por = new Map();
    fuentes.forEach(f => { const c = f.carpeta || ''; if (!por.has(c)) por.set(c, []); por.get(c).push(f); });
    const linea = (f, sangria) => sangria + '<outline type="rss" text="' + escXml(f.titulo) + '" title="' + escXml(f.titulo) + '" xmlUrl="' + escXml(f.url) + '"' + (f.web ? ' htmlUrl="' + escXml(f.web) + '"' : '') + '/>';
    const cuerpo = [];
    (por.get('') || []).forEach(f => cuerpo.push(linea(f, '    ')));
    Array.from(por.keys()).filter(Boolean).forEach(c => {
      cuerpo.push('    <outline text="' + escXml(c) + '" title="' + escXml(c) + '">');
      por.get(c).forEach(f => cuerpo.push(linea(f, '      ')));
      cuerpo.push('    </outline>');
    });
    return '<?xml version="1.0" encoding="UTF-8"?>\n<opml version="2.0">\n  <head>\n    <title>' + escXml(titulo || 'Suscripciones') + '</title>\n  </head>\n  <body>\n' + cuerpo.join('\n') + '\n  </body>\n</opml>\n';
  }

  /* ------------------------------------------------------------------
     Sanear: lista blanca, reescrito desde cero
     ------------------------------------------------------------------ */
  const PERMITIDAS = new Set(['p', 'br', 'a', 'strong', 'b', 'em', 'i', 'ul', 'ol', 'li', 'blockquote', 'h2', 'h3', 'h4', 'code', 'pre', 'hr', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'sup', 'sub', 'figure', 'figcaption', 'del', 'ins', 'mark', 'kbd']);
  const ALIAS = { h1: 'h2', h5: 'h4', h6: 'h4', s: 'del', strike: 'del', tt: 'code', u: 'em', cite: 'em', dfn: 'em', big: 'strong' };
  const SE_QUITAN = new Set(['script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed', 'applet', 'form', 'noscript', 'template', 'svg', 'math', 'audio', 'video', 'canvas', 'link', 'meta', 'head', 'title', 'base', 'button', 'select', 'textarea', 'input', 'dialog', 'portal']);
  const MARCOS = new Set(['iframe', 'frame', 'frameset', 'object', 'embed', 'applet', 'portal']);
  const PARAMS_SEGUIMIENTO = /^(utm_[a-z0-9_]+|fbclid|gclid|dclid|msclkid|yclid|igshid|mc_cid|mc_eid|_hsenc|_hsmi|__hstc|__hssc|__hsfp|ref_src|ref_url|vero_id|oly_enc_id|oly_anon_id|s_cid|wickedid)$/i;
  const IMG_SEGUIMIENTO = /(pixel|beacon|track|analytics|metricas|stat[s]?\.|\/p\.gif|\/t\.gif|\/o\.gif|open\.gif|1x1|spacer)/i;

  /* Una dirección apta: solo http, https y mailto; los parámetros de seguimiento se quitan. Devuelve { href, quitados } o null. */
  function limpiaEnlace(href, base) {
    href = String(href || '').trim().replace(/[\u0000-\u001f\u007f\s]+/g, '');
    if (!href) return null;
    let u;
    try { u = new URL(href, base || 'https://invalido.example/'); } catch (e) { return null; }
    if (!/^(https?|mailto):$/.test(u.protocol)) return null;
    let quitados = 0;
    if (u.protocol !== 'mailto:') {
      Array.from(u.searchParams.keys()).forEach(k => { if (PARAMS_SEGUIMIENTO.test(k)) { u.searchParams.delete(k); quitados++; } });
    }
    if (!base && !/^[a-z][a-z0-9+.-]*:/i.test(href)) return null;              // un enlace relativo necesita saber de dónde parte
    return { href: u.toString(), quitados };
  }

  function sanea(html, base) {
    const inf = { scripts: 0, estilos: 0, marcos: 0, imagenes: 0, rastreadores: 0, enlaces: 0, parametros: 0, otros: 0 };
    const doc = new DOMParser().parseFromString('<!doctype html><body>' + String(html || ''), 'text/html');
    const salida = document.createElement('div');

    const copia = (nodo, destino) => {
      nodo.childNodes.forEach(n => {
        if (n.nodeType === 3) { destino.appendChild(document.createTextNode(n.nodeValue)); return; }
        if (n.nodeType !== 1) return;                                   // comentarios, instrucciones…
        const nombre = n.localName;
        // los atributos peligrosos se cuentan aunque la etiqueta se salve
        Array.from(n.attributes).forEach(a => {
          if (/^on/i.test(a.name)) inf.scripts++;
          else if (a.name === 'style') inf.estilos++;
        });
        if (nombre === 'img' || nombre === 'picture' || nombre === 'source') {
          if (nombre === 'img') {
            inf.imagenes++;
            const w = parseInt(n.getAttribute('width'), 10), h = parseInt(n.getAttribute('height'), 10);
            const chica = (w >= 0 && w <= 2) || (h >= 0 && h <= 2);
            const rastro = chica || IMG_SEGUIMIENTO.test(n.getAttribute('src') || '');
            if (rastro) inf.rastreadores++;
            else {
              const alt = colapsa(n.getAttribute('alt'));
              const m = document.createElement('span'); m.className = 'tt-sin-imagen';
              m.textContent = alt ? 'Imagen no cargada: ' + alt : 'Imagen no cargada';
              destino.appendChild(m);
            }
          }
          return;
        }
        if (SE_QUITAN.has(nombre)) {
          if (nombre === 'script') inf.scripts++; else if (nombre === 'style') inf.estilos++; else if (MARCOS.has(nombre)) inf.marcos++; else inf.otros++;
          return;
        }
        const etiqueta = ALIAS[nombre] || nombre;
        if (!PERMITIDAS.has(etiqueta)) { copia(n, destino); return; }       // se desenvuelve: queda su contenido
        const nuevo = document.createElement(etiqueta);
        if (etiqueta === 'a') {
          const h = n.getAttribute('href');
          if (h && /^\s*(javascript|vbscript|data):/i.test(h.replace(/[\u0000-\u001f\s]+/g, ''))) inf.scripts++;
          const l = limpiaEnlace(h, base);
          if (l) {
            nuevo.setAttribute('href', l.href);
            nuevo.setAttribute('rel', 'noopener noreferrer nofollow');
            nuevo.setAttribute('target', '_blank');
            if (l.quitados) { inf.enlaces++; inf.parametros += l.quitados; }
          }
        } else if ((etiqueta === 'td' || etiqueta === 'th') && /^\d+$/.test(n.getAttribute('colspan') || '')) {
          nuevo.setAttribute('colspan', String(Math.min(12, +n.getAttribute('colspan'))));
        }
        copia(n, nuevo);
        destino.appendChild(nuevo);
      });
    };
    copia(doc.body, salida);
    // un <a> sin enlace válido se queda como texto
    Array.from(salida.querySelectorAll('a:not([href])')).forEach(a => a.replaceWith.apply(a, Array.from(a.childNodes)));
    // párrafos vacíos que dejó la limpieza
    Array.from(salida.querySelectorAll('p')).forEach(p => { if (!p.textContent.trim() && !p.querySelector('br,code,span')) p.remove(); });
    return { html: salida.innerHTML, texto: colapsa(salida.textContent), informe: inf };
  }
  /* El resumen de lo quitado, en una frase (o nada si no se quitó nada). */
  function frase(inf) {
    const p = [];
    const n = (k, uno, varios) => k === 1 ? '1 ' + uno : k + ' ' + varios;
    if (inf.scripts) p.push(n(inf.scripts, 'script', 'scripts'));
    if (inf.marcos) p.push(n(inf.marcos, 'marco incrustado', 'marcos incrustados'));
    if (inf.estilos) p.push(n(inf.estilos, 'estilo', 'estilos'));
    if (inf.rastreadores) p.push(n(inf.rastreadores, 'rastreador', 'rastreadores'));
    const otras = inf.imagenes - inf.rastreadores;
    if (otras > 0) p.push(n(otras, 'imagen sin cargar', 'imágenes sin cargar'));
    if (inf.parametros) p.push(n(inf.parametros, 'parámetro de seguimiento', 'parámetros de seguimiento') + ' en enlaces');
    if (inf.otros) p.push(n(inf.otros, 'elemento ajeno', 'elementos ajenos'));
    return p.length ? p.join(' · ') : '';
  }

  /* ------------------------------------------------------------------
     La fecha relativa
     ------------------------------------------------------------------ */
  const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  function fechaRelativa(ms, ahora) {
    if (!ms) return 'sin fecha';
    const d = ahora - ms;
    if (d < 0) return 'en el futuro';
    const min = Math.floor(d / 60000);
    if (min < 1) return 'ahora';
    if (min < 60) return 'hace ' + min + ' min';
    const h = Math.floor(min / 60);
    if (h < 24) return 'hace ' + h + ' h';
    const dias = Math.floor(h / 24);
    if (dias < 2) return 'ayer';
    if (dias < 7) return 'hace ' + dias + ' d';
    const f = new Date(ms);
    return f.getUTCDate() + ' ' + MESES[f.getUTCMonth()] + (new Date(ahora).getUTCFullYear() !== f.getUTCFullYear() ? ' ' + f.getUTCFullYear() : '');
  }
  function fechaLarga(ms) {
    if (!ms) return '';
    const f = new Date(ms), p = n => String(n).padStart(2, '0');
    return f.getUTCDate() + ' ' + MESES[f.getUTCMonth()] + ' ' + f.getUTCFullYear() + ' · ' + p(f.getUTCHours()) + ':' + p(f.getUTCMinutes()) + ' UTC';
  }

  /* ------------------------------------------------------------------
     Escribir un feed: sirve para fabricar los ejemplos y la prueba (el mismo artículo en los tres formatos)
     ------------------------------------------------------------------ */
  const rfc822 = ms => new Date(ms).toUTCString();
  const iso = ms => new Date(ms).toISOString().replace('.000Z', 'Z');
  function aRss(canal, items) {
    return '<?xml version="1.0" encoding="UTF-8"?>\n<rss version="2.0" xmlns:content="' + NS_CONTENT + '" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:atom="http://www.w3.org/2005/Atom">\n<channel>\n  <title>' + escXml(canal.titulo) + '</title>\n  <link>' + escXml(canal.web) + '</link>\n  <atom:link href="' + escXml(canal.url) + '" rel="self" type="application/rss+xml"/>\n  <description>' + escXml(canal.descripcion || '') + '</description>\n  <language>es</language>\n' +
      items.map(a => '  <item>\n    <title>' + escXml(a.titulo) + '</title>\n    <link>' + escXml(a.url) + '</link>\n    <guid isPermaLink="false">' + escXml(a.guid) + '</guid>\n    <pubDate>' + rfc822(a.fecha) + '</pubDate>\n    <dc:creator>' + escXml(a.autor) + '</dc:creator>\n' +
        a.etiquetas.map(c => '    <category>' + escXml(c) + '</category>\n').join('') +
        (a.soloDescripcion ? '    <description><![CDATA[' + a.html + ']]></description>\n' : '    <description>' + escXml(a.resumen || '') + '</description>\n    <content:encoded><![CDATA[' + a.html + ']]></content:encoded>\n') + '  </item>\n').join('') + '</channel>\n</rss>\n';
  }
  function aAtom(canal, items) {
    return '<?xml version="1.0" encoding="utf-8"?>\n<feed xmlns="http://www.w3.org/2005/Atom">\n  <title>' + escXml(canal.titulo) + '</title>\n  <subtitle>' + escXml(canal.descripcion || '') + '</subtitle>\n  <link href="' + escXml(canal.web) + '"/>\n  <link rel="self" href="' + escXml(canal.url) + '"/>\n  <id>' + escXml(canal.web) + '</id>\n  <updated>' + iso(items.reduce((m, a) => Math.max(m, a.fecha), 0)) + '</updated>\n  <author><name>' + escXml(canal.autor || '') + '</name></author>\n' +
      items.map(a => {
        const cuerpo = a.tipo === 'xhtml' ? '<content type="xhtml"><div xmlns="http://www.w3.org/1999/xhtml">' + a.html + '</div></content>'
          : a.tipo === 'text' ? '<content type="text">' + escXml(a.texto || '') + '</content>' : '<content type="html">' + escXml(a.html) + '</content>';
        return '  <entry>\n    <title>' + escXml(a.titulo) + '</title>\n    <link rel="alternate" href="' + escXml(a.url) + '"/>\n    <id>' + escXml(a.guid) + '</id>\n    <published>' + iso(a.fecha) + '</published>\n    <updated>' + iso(a.fecha) + '</updated>\n' +
          (a.autor && a.autor !== canal.autor ? '    <author><name>' + escXml(a.autor) + '</name></author>\n' : '') + a.etiquetas.map(c => '    <category term="' + escXml(c) + '"/>\n').join('') +
          '    <summary type="text">' + escXml(a.resumen || '') + '</summary>\n    ' + cuerpo + '\n  </entry>\n';
      }).join('') + '</feed>\n';
  }
  function aJson(canal, items) {
    return JSON.stringify({
      version: 'https://jsonfeed.org/version/1.1', title: canal.titulo, home_page_url: canal.web, feed_url: canal.url, description: canal.descripcion || '', language: 'es',
      authors: canal.autor ? [{ name: canal.autor }] : undefined,
      items: items.map(a => ({ id: a.guid, url: a.url, title: a.titulo, summary: a.resumen || undefined, content_html: a.tipo === 'text' ? undefined : a.html, content_text: a.tipo === 'text' ? a.texto : undefined, date_published: iso(a.fecha), authors: a.autor && a.autor !== canal.autor ? [{ name: a.autor }] : undefined, tags: a.etiquetas })),
    }, null, 2);
  }
  const ESCRIBE = { rss: aRss, atom: aAtom, json: aJson };

  /* El artículo de prueba: lleva de todo lo que hay que quitar, para comprobar que los tres formatos lo muestran igual. */
  const ARTICULO_PRUEBA = {
    guid: 'https://prueba.example/p/42', titulo: 'Artículo de prueba: «tildes» & <símbolos>', url: 'https://prueba.example/p/42?utm_source=boletin&utm_medium=correo&id=7',
    fecha: Date.parse('2026-10-01T09:30:00Z'), autor: 'Redacción', etiquetas: ['uno', 'dos'], resumen: 'Resumen de prueba.',
    html: '<h1>Título interno</h1><p>Hola <strong>mundo</strong> con <em>énfasis</em>.<script>alert(1)</script></p><p onclick="robar()" style="color:red">Un párrafo con <a href="https://prueba.example/x?utm_source=a&amp;fbclid=zz&amp;id=7" onmouseover="x()">enlace</a>, otro <a href="javascript:alert(2)">peligroso</a> y <img src="https://metricas.example/p.gif" width="1" height="1" alt="">un píxel.</p><iframe src="https://otro.example/"></iframe><ul><li>uno</li><li>dos</li></ul>',
  };
  const CANAL_PRUEBA = { titulo: 'Fuente de prueba', web: 'https://prueba.example/', url: 'https://prueba.example/feed', descripcion: 'Una fuente para probar.', autor: 'Redacción' };

  /* ------------------------------------------------------------------
     La prueba. Devuelve [descripción, ok].
     ------------------------------------------------------------------ */
  function comprueba() {
    const r = [];
    const t = (d, ok) => r.push([d, !!ok]);
    const AHORA = Date.parse('2026-10-17T12:00:00Z');
    // 1. el mismo artículo en los tres formatos
    const forma = f => ESCRIBE[f](CANAL_PRUEBA, [ARTICULO_PRUEBA]);
    const lec = ['rss', 'atom', 'json'].map(f => leeFeed(forma(f)));
    const a = lec.map(x => x.articulos[0]);
    t('los tres formatos se detectan por el contenido', ['rss', 'atom', 'json'].every((f, i) => detecta(forma(f)) === f && lec[i].formato === f));
    t('el mismo artículo sale igual en RSS, Atom y JSON Feed (título, dirección, fecha, autor y etiquetas)',
      a.every(x => x.titulo === a[0].titulo && x.url === a[0].url && x.fecha === a[0].fecha && x.autor === a[0].autor && x.etiquetas.join() === a[0].etiquetas.join() && x.guid === a[0].guid) && a[0].titulo === 'Artículo de prueba: «tildes» & <símbolos>' && a[0].fecha === Date.parse('2026-10-01T09:30:00Z'));
    const s = a.map(x => sanea(x.html, 'https://prueba.example/'));
    t('y el cuerpo saneado es idéntico en los tres, con el mismo informe', s.every(x => x.html === s[0].html && JSON.stringify(x.informe) === JSON.stringify(s[0].informe)));
    t('el saneado quita scripts, eventos, estilos, marcos, el píxel y los parámetros de seguimiento', !/<script|onclick|onmouseover|style=|<iframe|<img|javascript:|utm_|fbclid|alert\(/i.test(s[0].html) && s[0].informe.scripts === 4 && s[0].informe.marcos === 1 && s[0].informe.rastreadores === 1 && s[0].informe.parametros === 2);
    t('el saneado conserva el texto, los énfasis y los enlaces legítimos con rel y sin seguimiento', /<strong>mundo<\/strong>/.test(s[0].html) && /<a href="https:\/\/prueba\.example\/x\?id=7" rel="noopener noreferrer nofollow" target="_blank">enlace<\/a>/.test(s[0].html) && /<li>dos<\/li>/.test(s[0].html) && /<h2>Título interno<\/h2>/.test(s[0].html));
    // 2. el saneado con trampas
    const trampas = ['<img src=x onerror=alert(1)>', '<svg><script>alert(1)</script></svg>', '<a href="  JaVaScRiPt:alert(1)">x</a>', '<a href="data:text/html,<script>alert(1)</script>">x</a>', '<p style="background:url(javascript:alert(1))">x</p>', '<div><b onclick="x()">negrita</b></div><form action="/x"><input name="a"></form>', '<math><mi xlink:href="javascript:alert(1)">x</mi></math>', '<noscript><img src=x onerror=alert(1)></noscript>', '<a href="https://ok.example/">&lt;script&gt;alert(1)&lt;/script&gt;</a>'];
    t('trampas conocidas: ninguna deja un script, un evento ni un enlace peligroso', trampas.every(h => { const x = sanea(h, 'https://e.example/').html; return !/<script|onerror|onclick|javascript:|data:text|<svg|<math|<form|<input|<style| style=/i.test(x); }));
    t('un texto con «&lt;script&gt;» no se convierte en una etiqueta', sanea('<p>&lt;script&gt;alert(1)&lt;/script&gt;</p>', '').html === '<p>&lt;script&gt;alert(1)&lt;/script&gt;</p>');
    t('lo desconocido se desenvuelve y no se pierde su texto', sanea('<section><div><span>texto <b>seguido</b></span></div></section>', '').html === 'texto <b>seguido</b>');
    // 3. otros formatos y errores
    const atomX = '<?xml version="1.0"?><feed xmlns="http://www.w3.org/2005/Atom"><title>X</title><entry><title>Uno</title><id>1</id><link href="https://x.example/1"/><updated>2026-10-01T00:00:00Z</updated><content type="xhtml"><div xmlns="http://www.w3.org/1999/xhtml"><p>Hola <b>xhtml</b></p></div></content></entry></feed>';
    t('Atom con contenido xhtml se lee entero', leeFeed(atomX).articulos[0].html === '<p>Hola <b>xhtml</b></p>');
    const rss1 = '<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns="http://purl.org/rss/1.0/" xmlns:dc="http://purl.org/dc/elements/1.1/"><channel><title>Viejo</title><link>https://v.example/</link></channel><item><title>Uno</title><link>https://v.example/1</link><dc:date>2026-10-01T00:00:00Z</dc:date></item></rdf:RDF>';
    t('RSS 1.0 (RDF) se lee: los items cuelgan de la raíz y la fecha viene de dc:date', (() => { const f = leeFeed(rss1); return f.articulos.length === 1 && f.articulos[0].fecha === Date.parse('2026-10-01T00:00:00Z'); })());
    const falla = txt => { try { leeFeed(txt); return null; } catch (e) { return e.message; } };
    t('un XML roto dice que no está bien formado, un texto cualquiera que no es un feed y un OPML que trae suscripciones', /bien formado/.test(falla('<rss><channel></rss>')) && /No parece un feed/.test(falla('hola')) && /OPML/.test(falla('<opml version="2.0"><body/></opml>')));
    t('el error de un XML roto dice qué etiqueta y dónde (línea y columna)', (() => { const m = falla('<rss>\n<channel><title>x</title></rss>'); return /<channel> se cierra con <\/rss>/.test(m) && /línea 2/.test(m); })());
    t('con BOM al principio también se lee', leeFeed('﻿' + forma('json')).articulos.length === 1);
    // 4. OPML
    const fuentes = [{ titulo: 'Diario & «técnico»', url: 'https://a.example/feed.xml?x=1&y=2', web: 'https://a.example/', carpeta: '' }, { titulo: 'Blog "de" diseño', url: 'https://b.example/atom', web: 'https://b.example/', carpeta: 'Diseño y <más>' }, { titulo: 'Cambios', url: 'https://c.example/feed.json', web: '', carpeta: 'Diseño y <más>' }];
    const op = exportaOpml(fuentes, 'Mis suscripciones');
    const vuelta = leeOpml(op);
    t('el OPML exportado vuelve a importar las mismas fuentes (título, feed, web y carpeta, con &, comillas y <>)', JSON.stringify(vuelta.fuentes) === JSON.stringify(fuentes) && vuelta.titulo === 'Mis suscripciones' && detecta(op) === 'opml');
    const anidado = '<opml version="2.0"><body><outline text="Noticias"><outline text="Interior"><outline type="rss" text="Uno" xmlUrl="https://u.example/f"/></outline></outline><outline type="rss" title="Dos" xmlUrl="https://d.example/f" htmlUrl="https://d.example/"/></body></opml>';
    t('un OPML con carpetas anidadas aplana las fuentes sin perder ninguna', (() => { const o = leeOpml(anidado); return o.fuentes.length === 2 && o.fuentes[0].url === 'https://u.example/f' && o.fuentes[1].titulo === 'Dos'; })());
    // 5. fechas y enlaces
    t('la fecha relativa: ahora, minutos, horas, ayer, días, fecha y año', [[0, 'ahora'], [35 * 60000, 'hace 35 min'], [3 * 3600000, 'hace 3 h'], [30 * 3600000, 'ayer'], [4 * 86400000, 'hace 4 d'], [20 * 86400000, '27 sep'], [400 * 86400000, '12 sep 2025']].every(([d, e]) => fechaRelativa(AHORA - d, AHORA) === e));
    t('limpiaEnlace: quita utm_* y fbclid, deja los demás y rechaza protocolos raros', (() => { const l = limpiaEnlace('https://x.example/a?utm_source=q&id=3&fbclid=z#h', ''); return l.href === 'https://x.example/a?id=3#h' && l.quitados === 2 && !limpiaEnlace('javascript:alert(1)', 'https://x.example/') && !limpiaEnlace('ftp://x.example/', 'https://x.example/') && limpiaEnlace('mailto:a@b.example', '').href === 'mailto:a@b.example'; })());
    return r;
  }

  const N = { detecta, leeFeed, leeOpml, exportaOpml, sanea, frase, limpiaEnlace, fechaRelativa, fechaLarga, ESCRIBE, ARTICULO_PRUEBA, CANAL_PRUEBA, plano, escHtml, slug, comprueba };
  raiz.TeletipoNucleo = N;
})(typeof window !== 'undefined' ? window : globalThis);
