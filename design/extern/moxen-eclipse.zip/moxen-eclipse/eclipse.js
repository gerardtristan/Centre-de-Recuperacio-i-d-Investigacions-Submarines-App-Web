/* =====================================================================
   Eclipse · Moxen
   Un interruptor de día y noche con un eclipse dentro. Al pasar a la
   noche el sol cruza el riel con un resorte mientras la luna lo va
   tapando; justo antes de cerrarse brilla el anillo de diamante, queda
   la corona, las nubes se hunden y salen las estrellas. Al llegar al
   tope el astro se aplasta contra él. Al volver, la luna se aparta y
   las nubes suben con un rebote. Con { tema: true } la página cambia de
   tema con una onda que nace del astro. Sin dependencias.

     Eclipse(document.querySelector('[data-eclipse]'), {
       tema: true,                 // además cambia el tema de la página
       cambia: noche => …,
     });
   ===================================================================== */
(function () {
  'use strict';

  const HZ = 240, PASO = 1 / HZ;     // los resortes, a pasos fijos: igual a cualquier fps
  const acota = (v, a, b) => Math.max(a, Math.min(b, v));
  const suave = t => t * t * (3 - 2 * t);

  function Eclipse(boton, opciones) {
    const o = Object.assign({ tema: false, cambia: null }, opciones);
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const raiz = document.documentElement;
    const astro = boton.querySelector('.ec-astro'), forma = boton.querySelector('.ec-forma');
    const luna = boton.querySelector('.ec-luna'), corona = boton.querySelector('.ec-corona');
    const diamante = boton.querySelector('.ec-diamante');
    const noche = boton.querySelector('.ec-cielo-noche'), halos = boton.querySelector('.ec-halos');

    // con `tema`, el interruptor arranca como esté la página
    let esNoche = o.tema ? raiz.dataset.tema !== 'claro' : boton.getAttribute('aria-checked') === 'true';

    /* Dos resortes: p lleva al astro de un lado al otro (algo flojo, se
       pasa un 7 % y vuelve) y q a la luna, un poco más lenta, para que el
       eclipse se cierre cuando el sol ya casi llegó. */
    let p = esNoche ? 1 : 0, vp = 0, q = p, vq = 0;
    let raf = 0, previo = null, resto = 0, qAntes = q;

    function pinta() {
      const recorrido = 2.6;                         // em, lo que cruza el astro
      const x = acota(p, 0, 1);
      /* Lo que se pasa del tope no lo recorre: se aplasta contra el borde,
         y en pleno viaje se estira un poco en la dirección en que va. */
      const golpe = p > 1 ? p - 1 : p < 0 ? -p : 0;
      const estira = Math.min(.07, Math.abs(vp) * .014);
      const sx = (1 + estira) * (1 - 1.5 * golpe), sy = (1 - estira * .6) * (1 + .9 * golpe);
      astro.style.transform = halos.style.transform = 'translateX(' + (x * recorrido).toFixed(4) + 'em)';
      // se aplasta contra el lado al que llega
      forma.style.transformOrigin = p > .5 ? '100% 50%' : '0 50%';
      forma.style.transform = 'scale(' + sx.toFixed(4) + ',' + sy.toFixed(4) + ')';
      // la luna: de un 110 % a la derecha (fuera del sol) a taparlo entero
      const l = acota(q, 0, 1);
      luna.style.transform = 'translateX(' + ((1 - l) * 110).toFixed(2) + '%)';
      // el cielo se oscurece con el astro; la corona solo al cerrarse el eclipse
      noche.style.opacity = suave(x).toFixed(3);
      corona.style.opacity = suave(acota((l - .82) / .18, 0, 1)).toFixed(3);
    }

    /* El anillo de diamante: un destello en el último trozo de sol que se
       ve, al cerrarse y al abrirse el eclipse. */
    function destello() {
      if (reduce || !diamante.animate) return;
      diamante.animate([
        { opacity: 0, transform: 'scale(.3) rotate(-20deg)' },
        { opacity: 1, transform: 'scale(1.25) rotate(0deg)', offset: .3 },
        { opacity: 0, transform: 'scale(.7) rotate(15deg)' },
      ], { duration: 750, easing: 'cubic-bezier(.22, 1, .36, 1)' });
    }

    function paso() {
      const meta = esNoche ? 1 : 0;
      vp += (220 * (meta - p) - 19 * vp) * PASO; p += vp * PASO;
      vq += (130 * (meta - q) - 19 * vq) * PASO; q += vq * PASO;
      // el diamante sale cuando la luna cruza el 93 % del sol, en los dos sentidos
      if ((qAntes - .93) * (q - .93) < 0) destello();
      qAntes = q;
    }

    function cuadro(t) {
      if (previo !== null) resto += Math.min(100, t - previo);
      previo = t;
      const n = Math.floor(resto / (1000 / HZ));
      for (let k = 0; k < n; k++) paso();
      resto -= n * (1000 / HZ);
      pinta();
      const meta = esNoche ? 1 : 0;
      if (Math.abs(p - meta) + Math.abs(vp) + Math.abs(q - meta) + Math.abs(vq) < 1e-4) {
        p = q = meta; vp = vq = 0; pinta(); raf = 0; previo = null; return;
      }
      raf = requestAnimationFrame(cuadro);
    }

    /* La onda del tema: un círculo del color nuevo que crece desde el
       astro hasta cubrir la pantalla. Mientras crece, el fondo de la
       página se queda con el color viejo; al terminar se cambia de verdad. */
    let onda = null;
    function cambiaTema() {
      if (onda) { onda.remove(); onda = null; }
      const viejo = getComputedStyle(document.body).backgroundColor;
      if (esNoche) delete raiz.dataset.tema; else raiz.dataset.tema = 'claro';
      if (reduce) return;
      const nuevo = getComputedStyle(raiz).getPropertyValue('--ec-fondo').trim();
      // el centro del astro donde va a quedar, no donde está
      const r = boton.getBoundingClientRect(), u = r.height / 2;
      const cx = r.left + u + (esNoche ? r.width - 2 * u : 0), cy = r.top + u;
      const R = Math.hypot(Math.max(cx, innerWidth - cx), Math.max(cy, innerHeight - cy)) + 4;
      const c = onda = document.createElement('div');
      c.className = 'ec-onda';
      Object.assign(c.style, { left: (cx - R) + 'px', top: (cy - R) + 'px', width: 2 * R + 'px', height: 2 * R + 'px', background: nuevo });
      document.body.style.backgroundColor = viejo;
      document.body.appendChild(c);
      const a = c.animate([{ transform: 'scale(0)' }, { transform: 'scale(1)' }],
        { duration: 1000, easing: 'cubic-bezier(.45, 0, .2, 1)', fill: 'forwards' });
      a.onfinish = () => { if (onda !== c) return; document.body.style.backgroundColor = ''; c.remove(); onda = null; };
    }

    function marca() {
      boton.classList.toggle('is-noche', esNoche);
      boton.setAttribute('aria-checked', esNoche ? 'true' : 'false');
    }

    boton.addEventListener('click', () => {
      esNoche = !esNoche;
      marca();
      if (o.tema) cambiaTema();
      if (o.cambia) o.cambia(esNoche);
      if (reduce) { p = q = esNoche ? 1 : 0; pinta(); return; }
      if (!raf) raf = requestAnimationFrame(cuadro);
    });

    /* El estado inicial se pinta sin transiciones: si no, al cargar de
       noche se vería un eclipse entero sin haber tocado nada. */
    boton.classList.add('ec-quieto');
    marca();
    pinta();
    requestAnimationFrame(() => requestAnimationFrame(() => boton.classList.remove('ec-quieto')));
    return { noche: () => esNoche, alterna: () => boton.click() };
  }

  window.Eclipse = Eclipse;
})();
