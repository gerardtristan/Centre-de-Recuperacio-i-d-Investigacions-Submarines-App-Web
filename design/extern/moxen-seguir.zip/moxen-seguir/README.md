# Seguir · Moxen

Al pulsarlo, el botón se estira como una goma, «Seguir» da paso a «Siguiendo» con su palomita y el contador de seguidores sube rodando cifra a cifra; el avatar late, su anillo se dibuja girando y suelta unas partículas. Otro clic lo deshace con su propio gesto.

## Qué trae

- `index.html` — la demostración
- `seguir.css`
- `seguir.js`
- `img/` — las fotos de la demostración (Unsplash; reemplázalas por las tuyas)
- `CREDITOS.md` — autor y enlace de cada foto
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `seguir.css` y `seguir.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Press it and the button stretches like rubber, «Follow» gives way to «Following» with its check mark and the follower count rolls up digit by digit; the avatar pulses, its ring draws itself while spinning and releases a few particles. Another click undoes it with its own gesture.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
