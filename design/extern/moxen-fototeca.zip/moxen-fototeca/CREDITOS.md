# Créditos de las fotos · Fototeca

Las fotos de `img/` son de [Unsplash](https://unsplash.com) (licencia
Unsplash: uso gratuito, sin atribución obligatoria) y se incluyen solo como
material de demostración: reemplázalas por las tuyas. Sin rostros ni marcas.

| Archivo | Autor | Foto |
|---|---|---|
| `img/faro-v.jpg` | Clay Banks | https://unsplash.com/es/fotos/faro-bajo-el-cielo-azul-XdiNTvxhDVI |
| `img/vasijas.jpg` | Tamara Harhai | https://unsplash.com/es/fotos/un-par-de-jarrones-sentados-encima-de-una-mesa-tSkPbVkiCqY |
| `img/jarron.jpg` | Anton Sukhinov | https://unsplash.com/es/fotos/jarron-de-ceramica-marron-sobre-mantel-blanco-y-negro-4GvsTa3Y-5I |
| `img/fachada.jpg` | Naveed Janmohamed | https://unsplash.com/es/fotos/edificio-de-hormigon-gris-cFOeh09-7Cc |
| `img/mar-aereo.jpg` | Andrzej Kryszpiniuk | https://unsplash.com/es/fotos/vista-aerea-de-las-olas-del-mar-4wFqHZ1ONnM |
| `img/arq-blanco-v.jpg` | Joel Filipe | https://unsplash.com/es/fotos/edificio-de-cemento-moderno-blanco-bajo-cielo-azul-RFDP7_80v5A |
| `img/silla-amarilla.jpg` | YU Carla | https://unsplash.com/es/fotos/una-silla-de-madera-sobre-fondo-amarillo-Or3zn5zbgzE |
| `img/torre.jpg` | Ricardo Gomez Angel | https://unsplash.com/es/fotos/fotografia-de-arquitectura-de-gray-building-KRVXMkiTc7U |
| `img/montana-niebla.jpg` | Brice Cooper | https://unsplash.com/es/fotos/una-montana-cubierta-de-niebla-con-arboles-en-primer-plano-yj4Jjl2sCL0 |
| `img/arq-hormigon.jpg` | Simone Hutsch | https://unsplash.com/es/fotos/fotografia-de-paisaje-de-un-edificio-de-hormigon-gris-XK0faa4_mCQ |
| `img/cascada-v.jpg` | Patrick Hodskins | https://unsplash.com/es/fotos/WB0wtXvRJ1c |
| `img/escalera.jpg` | Masjid MABA | https://unsplash.com/es/fotos/una-escalera-en-un-edificio-MsCipqna2bM |
| `img/bodegon.jpg` | Harper Sunday | https://unsplash.com/es/fotos/una-mesa-cubierta-con-vasos-y-una-botella-de-liquido-o09l6wRwIX8 |
