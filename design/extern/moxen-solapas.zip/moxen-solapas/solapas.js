/* =====================================================================
   Solapas · Moxen
   Pestañas para los registros de una app de gestión: abres clientes y pedidos en pestañas, las ordenas arrastrando, las cierras sin perder
   lo que habías escrito y, cuando ya no caben, las que menos usas pasan a un menú. Cada pestaña guarda su propio estado: lo que escribiste en
   sus campos, dónde estaba el cursor y si tiene cambios sin guardar (un punto naranja). Cerrar una pestaña con cambios no los tira: quedan como
   borrador y vuelven cuando abres el registro otra vez.

   Las reglas (las que hacen de esto un componente y no un dibujo):
     · vecina   = al cerrar la pestaña activa se activa la de su derecha y, si era la última, la de su izquierda. Se cuenta sobre el orden
                  completo de las pestañas abiertas (también las que están en el menú). Cerrar una pestaña que no es la activa no cambia la activa.
     · caben    = las pestañas visibles comparten el ancho de la tira, entre un mínimo y un máximo (--so-tab-min y --so-tab-max). Si no entran
                  todas ni al mínimo, se reserva el sitio del menú y caben tantas como entren al mínimo; el resto va al menú. Se mide el ancho real
                  de la tira (ResizeObserver), no el de la pantalla.
     · cuáles   = a la vista quedan las más recientes (la activa siempre, luego las que usaste hace poco) y se dibujan en el orden que tú les diste.
                  Al elegir una del menú entra a la tira y sale la que hace más que no usas; al agrandar la ventana vuelven solas.
     · orden    = arrastrar una pestaña (o Mayús + ← →) la pone en otro lugar entre las visibles; las que están en el menú conservan su sitio
                  relativo: la pestaña queda justo antes de la visible que la sigue (o, si pasa a ser la última, justo después de la que la precede).
                  Soltarla donde ya estaba no cambia nada.
     · borrador = el registro cuyos campos difieren de lo guardado tiene cambios sin guardar. Cerrar la pestaña no los toca; abrirla otra vez dice
                  «Borrador recuperado»; «Guardar» los vuelve lo guardado y «Descartar» vuelve a lo guardado.

   Lo que hace de verdad:
     · Abrir: un clic en un registro de la lista abre su pestaña al final y la activa, o lleva a ella si ya estaba abierta.
     · Ordenar: arrastra una pestaña con el ratón o el dedo; las otras se corren para dejarle sitio.
     · Cerrar: la × de cada pestaña (o Supr con ella en foco).
     · Teclado: ← → Inicio Fin se mueven por las pestañas y activan la que alcanzan; Mayús + ← → la reordenan; Supr la cierra; en el menú ↑ ↓ Inicio Fin
       recorren, Intro elige y Esc cierra devolviendo el foco. Todo cambio se anuncia en una región aria-live.

   Montaje (se inicia solo sobre [data-solapas]; el HTML de la demo es la plantilla):
     const s = Solapas(document.querySelector('[data-solapas]'), {
       registros: REGISTROS,      // [{ id, tipo: 'cliente' | 'pedido', titulo, sub, campos: { dato, estado, nota }, borrador?, act? }]
       abiertos: ['p1048', …],    // los ids abiertos al empezar, en orden
       activo: 'floristeria',
       alCambiar: ({ orden, activa, visibles, ocultas }) => {},
     });
     s.abre('libreria');  s.cierra('taller');  s.activa('p1048');  s.mueve('panaderia', 0);  s.restablece();  s.estado();
     Solapas.vecina(orden, id);  Solapas.reparte(n, anchoTira, anchoConMenu, min, max, hueco);  Solapas.reordena(orden, visibles, id, lugar);

   Qué cambia qué: los colores y medidas son variables al principio de solapas.css (--so-ciruela es lo activo, --so-naranja lo sin guardar y lo
   que se cuenta; --so-tab-min, --so-tab-max, --so-gap, --so-menu y --so-pad dan las medidas que solapas.js lee para decidir cuántas caben). Los
   registros de ejemplo, en REGISTROS. Cada pestaña va en su sitio con transform: translateX(--x), así que mover una pestaña es cambiar su --x y
   la transición hace el resto. El tiempo sale de transiciones CSS y de setTimeout (sin Date ni azar). Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  /* Los registros de ejemplo de una pequeña empresa. Son tipos de negocio y números de pedido, no personas. `campos` es lo guardado y `borrador`,
     lo que alguien dejó escrito sin guardar. */
  const REGISTROS = [
    { id: 'floristeria', tipo: 'cliente', titulo: 'Floristería', sub: 'Cliente desde 2024 · último contacto 18 oct',
      campos: { dato: 'hola@floristeria.dev', estado: 'En trato', nota: 'Pidió cotizar centros de mesa para un evento. Llamar el lunes antes de las 10.' },
      act: [['18 oct', 'Se envió la cotización'], ['12 oct', 'Reunión de revisión'], ['3 oct', 'Alta del cliente']] },
    { id: 'panaderia', tipo: 'cliente', titulo: 'Panadería', sub: 'Cliente desde 2023 · último contacto 21 oct',
      campos: { dato: 'pedidos@panaderia.dev', estado: 'Cliente', nota: 'Entrega siempre antes de las 7 de la mañana.' },
      borrador: { nota: 'Entrega siempre antes de las 7 de la mañana. Pidió sumar pan integral desde noviembre.' },
      act: [['21 oct', 'Pedido 1049 entregado'], ['14 oct', 'Cambio de horario de entrega'], ['2 oct', 'Renovación del contrato']] },
    { id: 'taller', tipo: 'cliente', titulo: 'Taller mecánico', sub: 'Cliente desde 2026 · último contacto 20 oct',
      campos: { dato: 'contacto@taller.dev', estado: 'Nuevo', nota: 'Preguntó por el plan anual y por las visitas a domicilio.' },
      act: [['20 oct', 'Llamada de presentación'], ['19 oct', 'Formulario de contacto recibido']] },
    { id: 'libreria', tipo: 'cliente', titulo: 'Librería', sub: 'Cliente desde 2025 · último contacto 16 oct',
      campos: { dato: 'ventas@libreria.dev', estado: 'En trato', nota: 'Quiere recibir la factura a fin de mes.' },
      act: [['16 oct', 'Se acordó la factura mensual'], ['9 oct', 'Primera cotización'], ['1 oct', 'Alta del cliente']] },
    { id: 'gimnasio', tipo: 'cliente', titulo: 'Gimnasio', sub: 'Cliente desde 2022 · último contacto 8 oct',
      campos: { dato: 'recepcion@gimnasio.dev', estado: 'Cliente', nota: 'La renovación del servicio vence en noviembre.' },
      act: [['8 oct', 'Recordatorio de renovación'], ['21 sep', 'Pedido 1054 confirmado']] },
    { id: 'p1048', tipo: 'pedido', titulo: 'Pedido 1048', sub: 'Floristería · 12 productos',
      campos: { dato: 'Viernes 30 oct, mañana', estado: 'En preparación', nota: 'Embalar aparte las piezas frágiles.' },
      act: [['22 oct', 'Pedido confirmado'], ['22 oct', 'Pasó a preparación']] },
    { id: 'p1049', tipo: 'pedido', titulo: 'Pedido 1049', sub: 'Panadería · 4 productos',
      campos: { dato: 'Jueves 22 oct, 7:00', estado: 'Entregado', nota: 'Dejar en la puerta trasera.' },
      act: [['22 oct', 'Entregado'], ['21 oct', 'Pedido confirmado']] },
    { id: 'p1051', tipo: 'pedido', titulo: 'Pedido 1051', sub: 'Taller mecánico · 7 productos',
      campos: { dato: 'Lunes 26 oct, tarde', estado: 'Pendiente', nota: 'Confirmar el stock de repuestos antes de armarlo.' },
      borrador: { dato: 'Martes 27 oct, tarde' },
      act: [['23 oct', 'Pedido recibido']] },
    { id: 'p1052', tipo: 'pedido', titulo: 'Pedido 1052', sub: 'Librería · 3 productos',
      campos: { dato: 'Miércoles 28 oct', estado: 'Pendiente', nota: 'Incluir la factura dentro del paquete.' },
      act: [['23 oct', 'Pedido recibido']] },
    { id: 'p1054', tipo: 'pedido', titulo: 'Pedido 1054', sub: 'Gimnasio · 9 productos',
      campos: { dato: 'Viernes 30 oct, tarde', estado: 'En preparación', nota: 'Retira una persona del equipo con la guía impresa.' },
      act: [['23 oct', 'Pasó a preparación'], ['21 oct', 'Pedido confirmado']] },
  ];
  const ABIERTOS = ['p1048', 'floristeria', 'panaderia', 'p1051', 'taller'];
  const ACTIVO = 'floristeria';
  const TIPOS = {
    cliente: { eti: 'Cliente', dato: 'Contacto', estado: 'Etapa', estados: ['Nuevo', 'En trato', 'Cliente'], icono: 'so-i-cliente', grupo: 'Clientes', tipo: 'email' },
    pedido: { eti: 'Pedido', dato: 'Entrega', estado: 'Estado', estados: ['Pendiente', 'En preparación', 'Entregado'], icono: 'so-i-pedido', grupo: 'Pedidos', tipo: 'text' },
  };
  const CAMPOS = ['dato', 'estado', 'nota'];

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const uso = (id, clase) => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true'); if (clase) s.setAttribute('class', clase);
    const u = document.createElementNS('http://www.w3.org/2000/svg', 'use'); u.setAttribute('href', '#' + id); s.appendChild(u); return s; };
  const plural = (n, uno, varios) => n + ' ' + (n === 1 ? uno : varios);

  /* ── las cuentas ───────────────────────────────────────────────────── */
  // Al cerrar la pestaña `id`, cuál pasa a ser la activa: la de su derecha, o la de su izquierda si era la última.
  function vecina(orden, id) {
    const i = orden.indexOf(id);
    if (i < 0) return null;
    return orden[i + 1] || orden[i - 1] || null;
  }
  // Cuántas pestañas caben y cuánto mide cada una. n pestañas; `ancho` es lo que hay para ellas sin menú y `anchoMenu` lo que queda si se
  // reserva el sitio del menú. Entre `min` y `max` de ancho, con `hueco` entre una y otra.
  function reparte(n, ancho, anchoMenu, min, max, hueco) {
    if (n <= 0) return { cap: 0, w: Math.min(max, ancho) };
    const todas = Math.floor((ancho - (n - 1) * hueco) / n);
    if (todas >= min) return { cap: n, w: Math.min(max, todas) };
    const cap = Math.max(1, Math.floor((anchoMenu + hueco) / (min + hueco)));
    return { cap, w: Math.min(max, Math.max(min, Math.floor((anchoMenu - (cap - 1) * hueco) / cap))) };
  }
  // El orden completo después de poner `id` en el lugar `lugar` de las pestañas visibles (cuenta desde 0, ya sin `id` en la fila).
  function reordena(orden, visibles, id, lugar) {
    const V = visibles.filter(x => x !== id), O = orden.filter(x => x !== id);
    if (!V.length) return orden.slice();
    const k = lim(lugar, 0, V.length);
    if (visibles.indexOf(id) === k) return orden.slice();     // ya estaba en ese lugar de la fila: no se toca nada (tampoco su sitio respecto de las ocultas)
    V.splice(k, 0, id);
    const pos = k < V.length - 1 ? O.indexOf(V[k + 1]) : O.indexOf(V[k - 1]) + 1;
    O.splice(pos, 0, id);
    return O;
  }

  function Solapas(raiz, opciones) {
    const op = Object.assign({ registros: REGISTROS, abiertos: ABIERTOS, activo: ACTIVO, alCambiar: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const tiras = $('[data-tiras]'), tablist = $('[data-tablist]'), masC = $('[data-mas-c]'), masB = $('[data-mas]'), masN = $('[data-mas-n]'), menu = $('[data-menu]');
    const hoja = $('[data-hoja]'), vacio = $('[data-vacio]'), lateral = $('[data-lateral]'), voz = $('[data-voz]'), reset = $('[data-reset]');

    const tabs = {}, paneles = {}, items = {};          // id → elementos
    const K = { min: 150, max: 212, gap: 4, menu: 66, pad: 14 };
    let E = null, abierto = false, vozT = 0;
    const timers = [];

    /* ── el estado ───────────────────────────────────────────────────── */
    function inicial() {
      const regs = {};
      op.registros.forEach(r => {
        regs[r.id] = { id: r.id, tipo: r.tipo, titulo: r.titulo, sub: r.sub || '', act: r.act || [], base: Object.assign({}, r.campos), campos: Object.assign({}, r.campos, r.borrador || {}),
          abierta: false, recuperado: false, vista: null };
      });
      const orden = op.abiertos.filter(id => regs[id]);
      orden.forEach(id => { regs[id].abierta = true; });
      const activa = regs[op.activo] && regs[op.activo].abierta ? op.activo : (orden[0] || null);
      const rec = activa ? [activa].concat(orden.filter(id => id !== activa)) : orden.slice();
      return { regs, orden, rec, activa, vis: [], cap: 0, w: 0, arrastre: null };
    }
    const sucia = r => CAMPOS.some(k => r.campos[k] !== r.base[k]);
    const cambios = r => CAMPOS.filter(k => r.campos[k] !== r.base[k]).length;
    const px = (cs, v, d) => { const n = parseFloat(cs.getPropertyValue(v)); return isNaN(n) ? d : n; };
    function mide() {
      const cs = getComputedStyle(raiz);
      K.min = px(cs, '--so-tab-min', 150); K.max = px(cs, '--so-tab-max', 212); K.gap = px(cs, '--so-gap', 4); K.menu = px(cs, '--so-menu', 66); K.pad = px(cs, '--so-pad', 14);
    }
    const anuncia = txt => { clearTimeout(vozT); voz.textContent = ''; vozT = setTimeout(() => { voz.textContent = txt; }, 30); };

    /* ── la lista de la izquierda ────────────────────────────────────── */
    function construyeLateral() {
      lateral.textContent = '';
      Object.keys(TIPOS).forEach(tipo => {
        const g = h('div', 'so-grupo'), t = h('h3', '', TIPOS[tipo].grupo), ul = h('ul'); ul.setAttribute('role', 'list');
        op.registros.filter(r => r.tipo === tipo).forEach(r => {
          const li = h('li'), b = h('button', 'so-item'); b.type = 'button'; b.dataset.id = r.id;
          const ico = h('span', 'so-item-ico'); ico.appendChild(uso(TIPOS[tipo].icono));
          const txt = h('span', 'so-item-t'), nom = h('b', '', r.titulo), sub = h('small');
          txt.append(nom, sub);
          const est = h('i', 'so-item-est');
          b.append(ico, txt, est);
          b.addEventListener('click', () => abre(r.id, true));
          li.appendChild(b); ul.appendChild(li);
          items[r.id] = { b, sub, est };
        });
        g.append(t, ul); lateral.appendChild(g);
      });
    }
    function pintaLateral() {
      Object.keys(items).forEach(id => {
        const r = E.regs[id], it = items[id], dirty = sucia(r);
        it.b.classList.toggle('es-abierta', r.abierta);
        it.b.classList.toggle('es-activa', E.activa === id);
        it.b.classList.toggle('es-borrador', !r.abierta && dirty);
        it.b.classList.toggle('es-sucia', r.abierta && dirty);
        if (E.activa === id) it.b.setAttribute('aria-current', 'true'); else it.b.removeAttribute('aria-current');
        const t = r.campos.estado; if (it.sub.textContent !== t) it.sub.textContent = t;
        const est = r.abierta ? (dirty ? 'sin guardar' : 'abierto') : (dirty ? 'borrador' : '');
        if (it.est.textContent !== est) it.est.textContent = est;
        it.b.setAttribute('aria-label', r.titulo + ', ' + TIPOS[r.tipo].eti.toLowerCase() + ', ' + (r.abierta ? 'abierto' : 'cerrado') + (dirty ? ', con cambios sin guardar' : ''));
      });
    }

    /* ── los paneles (uno por registro, siempre en el DOM: así lo escrito no se pierde) ── */
    function construyePanel(def) {
      const id = def.id, tp = TIPOS[def.tipo], P = {};
      const reg = () => E.regs[id];
      const p = h('section', 'so-panel'); p.id = 'so-p-' + id; p.setAttribute('role', 'tabpanel'); p.setAttribute('aria-labelledby', 'so-t-' + id); p.hidden = true; p.dataset.id = id;
      const cab = h('header', 'so-ph');
      const ico = h('span', 'so-ph-ico'); ico.appendChild(uso(tp.icono));
      const tit = h('div', 'so-ph-t'); tit.append(h('p', 'so-eti', tp.eti), h('h2', '', def.titulo), h('p', 'so-sub', def.sub || ''));
      P.chip = h('span', 'so-chip');
      cab.append(ico, tit, P.chip);

      const cuerpo = h('div', 'so-ph-cuerpo'), form = h('form', 'so-form'); form.noValidate = true; form.addEventListener('submit', ev => ev.preventDefault());
      // campo de texto corto
      const l1 = h('label', 'so-campo'); l1.appendChild(h('span', 'so-et', tp.dato));
      P.dato = h('input'); P.dato.type = 'text'; P.dato.autocomplete = 'off'; P.dato.spellcheck = false; P.dato.setAttribute('aria-label', tp.dato + ' de ' + def.titulo);
      l1.appendChild(P.dato);
      // etapa o estado: un grupo de opciones
      const g = h('div', 'so-campo'), gt = h('span', 'so-et', tp.estado); gt.id = 'so-seg-' + id;
      P.seg = h('div', 'so-seg'); P.seg.setAttribute('role', 'radiogroup'); P.seg.setAttribute('aria-labelledby', gt.id);
      P.opc = tp.estados.map(e => {
        const b = h('button', 'so-opc', e); b.type = 'button'; b.setAttribute('role', 'radio'); b.dataset.valor = e;
        b.addEventListener('click', () => { reg().campos.estado = e; refleja(id); });
        b.addEventListener('keydown', ev => {
          const i = tp.estados.indexOf(reg().campos.estado), d = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[ev.key];
          if (d == null) return;
          ev.preventDefault();
          const n = tp.estados[(i + d + tp.estados.length) % tp.estados.length];
          reg().campos.estado = n; refleja(id); P.opc[tp.estados.indexOf(n)].focus();
        });
        P.seg.appendChild(b); return b;
      });
      g.append(gt, P.seg);
      // las notas
      const l3 = h('label', 'so-campo so-campo-nota'); l3.appendChild(h('span', 'so-et', 'Notas'));
      P.nota = h('textarea'); P.nota.rows = 5; P.nota.spellcheck = false; P.nota.setAttribute('aria-label', 'Notas de ' + def.titulo);
      l3.appendChild(P.nota);
      // el pie del formulario: el estado de lo guardado y los dos botones
      const acc = h('div', 'so-acc');
      P.est = h('p', 'so-est'); P.est.setAttribute('role', 'status');
      P.descartar = h('button', 'so-btn so-btn-sec', 'Descartar'); P.descartar.type = 'button';
      P.guardar = h('button', 'so-btn so-btn-pri'); P.guardar.type = 'button';
      P.guardar.append(uso('so-i-check'), document.createTextNode('Guardar'));
      acc.append(P.est, P.descartar, P.guardar);
      form.append(l1, g, l3, acc);

      const lado = h('aside', 'so-act'); lado.setAttribute('aria-label', 'Actividad de ' + def.titulo);
      lado.appendChild(h('h3', '', 'Actividad'));
      const ol = h('ol'); (def.act || []).forEach(a => { const li = h('li'); li.append(h('b', '', a[0]), h('span', '', a[1])); ol.appendChild(li); });
      lado.appendChild(ol);
      cuerpo.append(form, lado);
      p.append(cab, cuerpo);

      // todo lo escrito va al registro vivo (E.regs[id]), que «Restablecer» reemplaza: por eso se busca en cada evento
      P.dato.addEventListener('input', () => { reg().campos.dato = P.dato.value; refleja(id); });
      P.nota.addEventListener('input', () => { reg().campos.nota = P.nota.value; refleja(id); });
      P.guardar.addEventListener('click', () => guarda(id));
      P.descartar.addEventListener('click', () => descarta(id));
      hoja.insertBefore(p, vacio); P.el = p; paneles[id] = P;
    }
    /* lo que muestran un panel, su pestaña, la lista y el menú sale siempre de r.campos */
    function refleja(id) {
      const r = E.regs[id], P = paneles[id], dirty = sucia(r), n = cambios(r);
      if (P.dato.value !== r.campos.dato) P.dato.value = r.campos.dato;
      if (P.nota.value !== r.campos.nota) P.nota.value = r.campos.nota;
      P.opc.forEach(b => { const on = b.dataset.valor === r.campos.estado; b.setAttribute('aria-checked', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1; });
      P.chip.textContent = r.campos.estado;
      P.chip.dataset.estado = String(TIPOS[r.tipo].estados.indexOf(r.campos.estado));
      P.est.classList.toggle('es-sucia', dirty);
      P.est.textContent = '';
      if (dirty) {
        P.est.append(h('i', 'so-punto'), document.createTextNode('Sin guardar · ' + plural(n, 'cambio', 'cambios')));
        if (r.recuperado) P.est.append(h('em', 'so-recup', 'Borrador recuperado'));
      } else { P.est.append(uso('so-i-check'), document.createTextNode('Guardado')); }
      P.guardar.disabled = !dirty; P.descartar.disabled = !dirty;
      const t = tabs[id]; if (t) { t.classList.toggle('es-sucia', dirty); t.setAttribute('aria-label', r.titulo + (dirty ? ', con cambios sin guardar' : '')); }
      pintaLateral(); pintaMenu();
    }
    function guarda(id) {
      const r = E.regs[id]; if (!sucia(r)) return;
      r.base = Object.assign({}, r.campos); r.recuperado = false; refleja(id);
      const t = paneles[id].guardar; t.classList.remove('es-hecho'); void t.offsetWidth; t.classList.add('es-hecho');
      anuncia(r.titulo + ': guardado.');
    }
    function descarta(id) {
      const r = E.regs[id]; if (!sucia(r)) return;
      r.campos = Object.assign({}, r.base); r.recuperado = false; refleja(id);
      anuncia(r.titulo + ': se descartaron los cambios.');
    }
    // lo que cada panel recuerda de su vista: dónde estaba el cursor de las notas y cuánto se había desplazado
    function guardaVista(id) {
      const P = id && paneles[id]; if (!P) return;
      E.regs[id].vista = { a: P.nota.selectionStart, b: P.nota.selectionEnd, nota: P.nota.scrollTop, panel: P.el.scrollTop, foco: document.activeElement === P.nota ? 'nota' : document.activeElement === P.dato ? 'dato' : '' };
    }
    function restauraVista(id) {
      const P = paneles[id], v = E.regs[id].vista; if (!v) return;
      try { P.nota.setSelectionRange(v.a, v.b); } catch (e) { /* sin selección que restaurar */ }
      P.nota.scrollTop = v.nota; P.el.scrollTop = v.panel;
    }

    /* ── las pestañas ─────────────────────────────────────────────────── */
    function construyeTab(id, nueva) {
      const r = E.regs[id], t = h('div', 'so-tab' + (nueva ? ' es-nueva' : ''));
      t.id = 'so-t-' + id; t.dataset.id = id; t.setAttribute('role', 'tab'); t.setAttribute('aria-controls', 'so-p-' + id); t.setAttribute('aria-selected', 'false'); t.tabIndex = -1;
      const ico = h('span', 'so-tab-ico'); ico.appendChild(uso(TIPOS[r.tipo].icono));
      const tit = h('span', 'so-tab-t', r.titulo), pto = h('i', 'so-sucia'); pto.setAttribute('aria-hidden', 'true');
      const x = h('button', 'so-cerrar'); x.type = 'button'; x.tabIndex = -1; x.setAttribute('aria-label', 'Cerrar ' + r.titulo); x.appendChild(uso('so-i-cerrar'));
      x.addEventListener('click', ev => { ev.stopPropagation(); cierra(id, ev.detail === 0); });
      t.append(ico, tit, pto, x);   // la × queda posicionada encima (ver solapas.css)
      t.addEventListener('pointerdown', ev => apreta(ev, id, t));
      t.addEventListener('pointermove', ev => mueveArrastre(ev, id, t));
      const suelta = ev => sueltaArrastre(ev, id, t);
      t.addEventListener('pointerup', suelta); t.addEventListener('pointercancel', suelta); t.addEventListener('lostpointercapture', suelta);
      tablist.appendChild(t); tabs[id] = t;
      if (nueva) timers.push(setTimeout(() => t.classList.remove('es-nueva'), 600));
      return t;
    }
    const xDe = i => i * (E.w + K.gap);
    function ponX(id, i) { tabs[id].style.setProperty('--x', String(xDe(i))); }

    /* Dónde va cada pestaña: las más recientes que caben, en el orden del usuario; las demás se van al menú */
    function coloca() {
      mide();
      const A0 = Math.max(0, tiras.clientWidth - 2 * K.pad), A1 = Math.max(0, A0 - K.menu);
      const { cap, w } = reparte(E.orden.length, A0, A1, K.min, K.max, K.gap);
      E.cap = cap; E.w = w;
      const vis = new Set(E.rec.slice(0, cap)), V = E.orden.filter(id => vis.has(id));
      E.vis = V;
      tablist.style.setProperty('--w', String(w));
      E.orden.forEach(id => {
        const t = tabs[id]; if (!t) return;
        const dentro = vis.has(id);
        t.style.setProperty('--w', String(w));
        t.classList.toggle('es-oculta', !dentro); t.inert = !dentro;
        if (dentro) ponX(id, V.indexOf(id));
        else t.style.setProperty('--x', String(Math.max(0, A0 - K.menu + 10)));
        t.tabIndex = dentro && id === E.activa ? 0 : -1;
        t.setAttribute('aria-selected', id === E.activa ? 'true' : 'false');
      });
      const ocultas = E.orden.filter(id => !vis.has(id));
      masC.hidden = !ocultas.length;
      masN.textContent = String(ocultas.length);
      masB.setAttribute('aria-label', plural(ocultas.length, 'registro abierto más', 'registros abiertos más') + ' en el menú');
      pintaMenu();
      if (!ocultas.length) cierraMenu(false);
      raiz.dataset.visibles = V.join(','); raiz.dataset.ocultas = ocultas.join(',');
    }

    /* ── el menú de las que no caben ──────────────────────────────────── */
    function pintaMenu() {
      const vis = new Set(E.vis), ocultas = E.orden.filter(id => !vis.has(id));
      const llave = ocultas.map(id => id + (sucia(E.regs[id]) ? '*' : '')).join(',');
      masC.classList.toggle('tiene-borrador', ocultas.some(id => sucia(E.regs[id])));
      if (menu.dataset.llave === llave) return;
      menu.dataset.llave = llave; menu.textContent = '';
      ocultas.forEach(id => {
        const r = E.regs[id], li = h('li'), b = h('button', 'so-mi'); li.setAttribute('role', 'none');
        b.type = 'button'; b.setAttribute('role', 'menuitem'); b.dataset.id = id; b.tabIndex = -1;
        const t = h('span', '', r.titulo), pto = h('i', 'so-sucia' + (sucia(r) ? ' es-sucia' : ''));
        b.append(uso(TIPOS[r.tipo].icono), t, pto);
        b.addEventListener('click', ev => { activa(id, ev.detail === 0); cierraMenu(false); });
        li.appendChild(b); menu.appendChild(li);
      });
    }
    const filasMenu = () => Array.from(menu.querySelectorAll('.so-mi'));
    function abreMenu(conFoco) {
      if (abierto || masC.hidden) return;
      abierto = true; menu.hidden = false; masB.setAttribute('aria-expanded', 'true');
      if (conFoco) { const f = filasMenu()[0]; if (f) f.focus(); }
    }
    function cierraMenu(devuelveFoco) {
      if (!abierto) return;
      abierto = false; menu.hidden = true; masB.setAttribute('aria-expanded', 'false');
      if (devuelveFoco) masB.focus();
    }
    masB.addEventListener('click', ev => { if (abierto) cierraMenu(false); else abreMenu(ev.detail === 0); });
    masB.addEventListener('keydown', ev => { if (ev.key === 'ArrowDown') { ev.preventDefault(); abreMenu(true); } });
    menu.addEventListener('keydown', ev => {
      const f = filasMenu(), i = f.indexOf(document.activeElement);
      if (ev.key === 'ArrowDown') { ev.preventDefault(); f[(i + 1) % f.length].focus(); }
      else if (ev.key === 'ArrowUp') { ev.preventDefault(); f[(i - 1 + f.length) % f.length].focus(); }
      else if (ev.key === 'Home') { ev.preventDefault(); f[0].focus(); }
      else if (ev.key === 'End') { ev.preventDefault(); f[f.length - 1].focus(); }
      else if (ev.key === 'Escape') { ev.preventDefault(); cierraMenu(true); }
      else if (ev.key === 'Tab') cierraMenu(false);
    });
    document.addEventListener('pointerdown', ev => { if (abierto && !masC.contains(ev.target)) cierraMenu(false); });

    /* ── activar, abrir y cerrar ──────────────────────────────────────── */
    function muestraPanel(id, conAnim) {
      Object.keys(paneles).forEach(k => { const P = paneles[k]; if (k !== id && !P.el.hidden) { guardaVista(k); P.el.hidden = true; } });
      vacio.hidden = !!id;
      if (!id) return;
      const P = paneles[id];
      P.el.hidden = false; restauraVista(id);
      if (conAnim && !quieto()) { P.el.classList.remove('es-entra'); void P.el.offsetWidth; P.el.classList.add('es-entra'); }
    }
    function activa(id, conFoco) {
      const r = E.regs[id]; if (!r || !r.abierta) return;
      if (E.activa === id) { if (conFoco && tabs[id]) tabs[id].focus(); return; }
      guardaVista(E.activa);
      E.activa = id; E.rec = [id].concat(E.rec.filter(x => x !== id));
      muestraPanel(id, true); coloca(); pintaLateral(); avisa();
      if (conFoco && tabs[id]) tabs[id].focus();
    }
    function abre(id, desdeLista) {
      const r = E.regs[id]; if (!r) return;
      if (r.abierta) { activa(id, false); if (desdeLista) anuncia(r.titulo + ' ya estaba abierto: pestaña activa.'); return; }
      guardaVista(E.activa);
      r.abierta = true; r.recuperado = sucia(r);
      E.orden.push(id); E.rec.unshift(id); E.activa = id;
      construyeTab(id, true);
      muestraPanel(id, true); coloca(); refleja(id); avisa();
      anuncia((r.recuperado ? 'Borrador recuperado en ' : 'Se abrió ') + r.titulo + '.');
    }
    function cierra(id, conFoco) {
      const r = E.regs[id]; if (!r || !r.abierta) return;
      const eraActiva = E.activa === id, vec = eraActiva ? vecina(E.orden, id) : null, t = tabs[id];
      guardaVista(id);
      r.abierta = false; r.recuperado = false;
      E.orden = E.orden.filter(x => x !== id); E.rec = E.rec.filter(x => x !== id);
      delete tabs[id];
      if (t) { t.classList.add('es-sale'); t.inert = true; timers.push(setTimeout(() => t.remove(), quieto() ? 0 : 320)); }
      if (eraActiva) {
        E.activa = vec;
        if (vec) E.rec = [vec].concat(E.rec.filter(x => x !== vec));
        muestraPanel(vec, true);
      }
      coloca(); refleja(id); avisa();
      if (eraActiva) {
        anuncia(r.titulo + ' cerrado' + (sucia(r) ? ' (los cambios quedan como borrador)' : '') + (vec ? '; ahora está activo ' + E.regs[vec].titulo + '.' : '. No quedan registros abiertos.'));
        if (conFoco) { const n = vec && tabs[vec]; if (n) n.focus(); else items[id].b.focus(); }
      } else anuncia(r.titulo + ' cerrado' + (sucia(r) ? ' (los cambios quedan como borrador).' : '.'));
    }
    function mueve(id, lugar) {
      if (!E.vis.includes(id)) return;
      const nuevo = reordena(E.orden, E.vis, id, lugar);
      if (nuevo.join() === E.orden.join()) return;
      E.orden = nuevo; coloca(); avisa();
      anuncia(E.regs[id].titulo + ': lugar ' + (E.vis.indexOf(id) + 1) + ' de ' + E.vis.length + '.');
    }
    function avisa() {
      raiz.dataset.activa = E.activa || ''; raiz.dataset.orden = E.orden.join(',');
      if (op.alCambiar) op.alCambiar({ orden: E.orden.slice(), activa: E.activa, visibles: E.vis.slice(), ocultas: E.orden.filter(id => !E.vis.includes(id)) });
    }

    /* ── arrastrar una pestaña ────────────────────────────────────────── */
    function apreta(ev, id, t) {
      if (ev.button > 0 || ev.target.closest('.so-cerrar')) return;
      cierraMenu(false);
      activa(id, false);
      const i = E.vis.indexOf(id);
      E.arrastre = { id, px: ev.clientX, x0: xDe(i), i0: i, movido: false, k: i };
      try { t.setPointerCapture(ev.pointerId); } catch (e) { /* sin captura: sigue con los eventos de la propia pestaña */ }
    }
    function mueveArrastre(ev, id, t) {
      const a = E.arrastre; if (!a || a.id !== id) return;
      const dx = ev.clientX - a.px;
      if (!a.movido) { if (Math.abs(dx) < 5) return; a.movido = true; t.classList.add('es-arrastra'); tablist.classList.add('es-arrastrando'); }
      const V = E.vis, paso = E.w + K.gap, tope = (V.length - 1) * paso;
      const x = lim(a.x0 + dx, 0, tope), k = lim(Math.round(x / paso), 0, V.length - 1);
      t.style.setProperty('--x', String(x));
      if (k !== a.k) { a.k = k; const Vp = V.filter(v => v !== id); Vp.splice(k, 0, id); Vp.forEach((v, i) => { if (v !== id) ponX(v, i); }); }
    }
    function sueltaArrastre(ev, id, t) {
      const a = E.arrastre; if (!a || a.id !== id) return;
      E.arrastre = null;
      t.classList.remove('es-arrastra'); tablist.classList.remove('es-arrastrando');
      if (!a.movido) return;
      if (ev.type === 'pointercancel') { coloca(); return; }
      const nuevo = reordena(E.orden, E.vis, id, a.k);
      const cambio = nuevo.join() !== E.orden.join();
      E.orden = nuevo; coloca();
      if (cambio) { avisa(); anuncia(E.regs[id].titulo + ': lugar ' + (E.vis.indexOf(id) + 1) + ' de ' + E.vis.length + '.'); }
    }

    /* ── el teclado en la tira ────────────────────────────────────────── */
    tablist.addEventListener('keydown', ev => {
      const t = ev.target.closest('.so-tab'); if (!t || ev.target !== t) return;
      const id = t.dataset.id, V = E.vis, i = V.indexOf(id), k = ev.key;
      if ((k === 'ArrowLeft' || k === 'ArrowRight') && ev.shiftKey) {
        ev.preventDefault(); mueve(id, lim(i + (k === 'ArrowRight' ? 1 : -1), 0, V.length - 1)); tabs[id].focus(); return;
      }
      const j = k === 'ArrowRight' ? i + 1 : k === 'ArrowLeft' ? i - 1 : k === 'Home' ? 0 : k === 'End' ? V.length - 1 : null;
      if (j != null) { ev.preventDefault(); const n = V[lim(j, 0, V.length - 1)]; activa(n, true); }
      else if (k === 'Delete' || k === 'Backspace') { ev.preventDefault(); cierra(id, true); }
      else if (k === 'Enter' || k === ' ') { ev.preventDefault(); activa(id, true); }
    });

    function restablece() {
      timers.splice(0).forEach(clearTimeout);
      cierraMenu(false);
      Object.keys(tabs).forEach(k => { tabs[k].remove(); delete tabs[k]; });
      tablist.querySelectorAll('.so-tab').forEach(n => n.remove());
      E = inicial();
      E.orden.forEach(id => construyeTab(id, true));
      Object.keys(paneles).forEach(id => { const P = paneles[id]; P.nota.scrollTop = 0; P.el.scrollTop = 0; P.el.hidden = true; });
      muestraPanel(E.activa, false);
      coloca();
      Object.keys(E.regs).forEach(refleja);
      avisa();
      anuncia('Se restablecieron las pestañas.');
    }

    /* ── arranque ─────────────────────────────────────────────────────── */
    E = inicial();
    construyeLateral();
    op.registros.forEach(construyePanel);
    E.orden.forEach(id => construyeTab(id, false));
    muestraPanel(E.activa, false);
    mide(); coloca();
    Object.keys(E.regs).forEach(refleja);
    avisa();
    if (window.ResizeObserver) new ResizeObserver(() => coloca()).observe(tiras);
    window.addEventListener('resize', coloca);
    reset.addEventListener('click', restablece);

    return {
      abre: id => abre(id, false), cierra: id => cierra(id, false), activa: id => activa(id, false), mueve, restablece, guarda, descarta,
      estado: () => ({
        orden: E.orden.slice(), activa: E.activa, recientes: E.rec.slice(), visibles: E.vis.slice(), ocultas: E.orden.filter(id => !E.vis.includes(id)),
        ancho: E.w, capacidad: E.cap, sucias: Object.keys(E.regs).filter(id => sucia(E.regs[id])),
        campos: Object.fromEntries(Object.keys(E.regs).map(id => [id, Object.assign({}, E.regs[id].campos)])),
        abiertas: Object.keys(E.regs).filter(id => E.regs[id].abierta),
      }),
    };
  }

  Solapas.vecina = vecina; Solapas.reparte = reparte; Solapas.reordena = reordena; Solapas.REGISTROS = REGISTROS;
  window.Solapas = Solapas;
  document.querySelectorAll('[data-solapas]').forEach(el => { window.solapas = Solapas(el); });
})();
