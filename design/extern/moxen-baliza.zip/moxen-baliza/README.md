# Baliza · Moxen

Pequeñas balizas laten junto a lo nuevo de la interfaz y, al pasar el cursor o enfocarlas, abren una nota anclada con flecha; «Entendido» apaga la baliza con un último anillo. Una píldora cuenta lo descubierto y su lista lleva hasta cada baliza (la página se desplaza y el objeto se enmarca), se cierra en un ✓ naranja al terminar y «Ocultar consejos» manda las balizas a la píldora en cascada y queda recordado.

## Qué trae

- `index.html` — la demostración
- `baliza.css`
- `baliza.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `baliza.css` y `baliza.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Small beacons pulse next to what's new in the interface and, on hover or focus, open an anchored note with an arrow; “Got it” switches the beacon off with one last ring. A pill counts what you've discovered and its list takes you to each beacon (the page scrolls and the object gets framed), closes into an orange ✓ when you finish, and “Hide tips” sends the beacons flying into the pill in a cascade and is remembered.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
