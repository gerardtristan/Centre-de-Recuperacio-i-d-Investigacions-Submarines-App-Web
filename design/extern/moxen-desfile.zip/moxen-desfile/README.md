# Desfile · Moxen

Un carrusel de proyectos con el desplazamiento y el imán del propio navegador: «3 / 8», la barra de progreso y las flechas salen de la posición real, así que dicen la verdad después de arrastrar o deslizar. El avance automático lleva un botón Pausa y dice por qué se detiene (ratón encima, foco de teclado, pestaña oculta o movimiento reducido), las tarjetas fuera de vista quedan inertes y, al recorrerlo entero, la barra se cierra con un ✓ rojo de etiqueta.

## Qué trae

- `index.html` — la demostración
- `desfile.css`
- `desfile.js`
- `img/` — las fotos de la demostración (Unsplash; reemplázalas por las tuyas)
- `CREDITOS.md` — autor y enlace de cada foto
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `desfile.css` y `desfile.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

A project carousel with the browser's own scrolling and snapping: «3 / 8», the progress bar and the arrows come from the real position, so they tell the truth after dragging or swiping. The autoplay has a Pause button and says why it stops (pointer over it, keyboard focus, hidden tab or reduced motion), cards out of view are inert and, once you have gone through all of it, the bar closes with a red gallery-label ✓.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
