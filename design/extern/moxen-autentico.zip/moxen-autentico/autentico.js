/* =====================================================================
   Auténtico · Moxen
   Verificar un comprobante sin llamar a nadie. El negocio firma cada comprobante con una clave suya y deja impreso un código de
   20 caracteres; quien lo recibe (o cualquiera con la clave del negocio) vuelve a calcular el código con los datos que ve: si
   coincide, el comprobante es el que se emitió; si cambió un solo carácter, el código sale otro y deja de valer. Sirve para
   recibos, entradas, vales o certificados. No lleva importes: cuenta pedidos, cuotas, fechas y estados.

   · El CÓDIGO es HMAC-SHA-256(clave, datos), con los datos escritos como líneas «campo=valor» en un orden fijo (emisor, folio,
     cliente, concepto, pedido, cuota, fecha, medio, estado) y unidos con saltos de línea, y se queda con los primeros 10 bytes
     (20 caracteres hexadecimales) en cinco grupos de cuatro. Se calcula de verdad con crypto.subtle (HMAC / SHA-256); si el
     navegador no lo ofrece (una página sin HTTPS fuera de localhost) o la clave está vacía, entra un SHA-256 escrito a mano en
     este mismo archivo, que da exactamente lo mismo.
   · Cada vez que cambia un dato (se escribe, se elige una opción, se mueve la cuota) o la clave, se recalcula: el paso 1 muestra
     los datos con lo que cambió, el paso 2 el HMAC completo y el paso 3 compara grupo a grupo con el código impreso. El sello de
     la hoja dice «Válido» (✓ azul) o «Alterado» (✕ ámbar). Un solo carácter distinto cambia todo el código.
   · «Alterar un carácter» cambia uno al azar con semilla; «Restaurar el original» vuelve al comprobante emitido; Esc dentro de
     un campo devuelve ese campo a su valor emitido. «Copiar texto» deja el comprobante como texto (campo=valor y el código) y
     «Pegar otro» (o ⌘V / Ctrl+V en cualquier punto) verifica el de otra persona: si la clave es la del negocio y el código sale
     de esos datos, vale; si falta una línea, sobra una o el código no calza, lo dice.
   · Estricto a propósito: no se recortan espacios ni se ignoran mayúsculas en los datos («Pagado» y «pagado» son datos
     distintos). Del código impreso sí se ignoran las mayúsculas, los guiones y los espacios, porque son solo formato.

   Montaje (se inicia solo sobre [data-autentico]; el HTML de la demo es la plantilla):
     const a = Autentico(document.querySelector('[data-autentico]'), {
       clave: 'clave-de-ejemplo',   // la clave del negocio, de ejemplo (en un negocio real nunca se publica)
       datos: { emisor: '…', folio: '…', … },   // el comprobante emitido al abrir (los nueve campos)
       alCambiar: ({ veredicto, cambiados, codigo, calculado }) => {},
     });
     a.edita('cuota', '3 de 3');  a.altera();  a.restaura();  a.carga(texto);  a.texto();  a.clave('otra');  a.estado();
     (edita, altera, restaura y clave devuelven una promesa que se cumple cuando el código ya se recalculó; a.espera() da la última)
     Autentico.hmac(clave, texto)    // Promise con el HMAC completo en hexadecimal (crypto.subtle, o el respaldo)
     Autentico.hmacJs(clave, texto)  // lo mismo, síncrono, con el SHA-256 escrito a mano
     Autentico.lee(texto)            // el lector del texto pegado: { datos, codigo } o un Error que explica qué falta

   Qué cambia qué: los colores son variables al principio de autentico.css (azul = válido, ámbar = alterado, plata = hoja y
   texto). Para firmar otros datos cambia CAMPOS y DATOS0 (y las líneas de la hoja en index.html).
   El azar de «Alterar un carácter» tiene semilla fija (mulberry32) y el tiempo viene de requestAnimationFrame, de la
   animación del sello (Web Animations) y de setTimeout; nunca se usa Date para animar. Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const fija = (el, txt) => { if (el && el.textContent !== txt) el.textContent = txt; };
  const anima = (el, kf, op) => (quieto() || !el || !el.animate) ? null : el.animate(kf, op);
  const mulberry32 = a => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const hex = u8 => Array.from(u8, b => b.toString(16).padStart(2, '0')).join('');

  /* ── los campos del comprobante (el orden es parte de la firma) ──────── */
  const CAMPOS = ['emisor', 'folio', 'cliente', 'concepto', 'pedido', 'cuota', 'fecha', 'medio', 'estado'];
  const ETQ = { emisor: 'Emitido por', folio: 'Folio', cliente: 'Cliente n.º', concepto: 'Concepto', pedido: 'Pedido n.º', cuota: 'Cuota', fecha: 'Fecha de pago', medio: 'Medio de pago', estado: 'Estado' };
  const OPCIONES = { medio: ['Transferencia', 'Tarjeta', 'Efectivo'], estado: ['Pagado', 'Pendiente', 'Anulado'] };
  const DATOS0 = { emisor: 'Estudio de ejemplo', folio: 'CP-2026-0417', cliente: '0128', concepto: 'Asesoría de diseño', pedido: '0412', cuota: '2 de 3', fecha: '14-10-2026', medio: 'Transferencia', estado: 'Pagado' };
  const CLAVE0 = 'clave-de-ejemplo';
  /* «Alterar un carácter» recorre los campos en este orden, para que el primer clic ya cambie algo que se ve */
  const ORDEN_ALTERA = ['pedido', 'fecha', 'concepto', 'cuota', 'cliente', 'folio', 'emisor'];
  const LARGO_COD = 20;                                  // caracteres hexadecimales del código (10 bytes del HMAC)

  /* ── SHA-256 y HMAC escritos a mano (el respaldo) ─────────────────────
     Las constantes no se copian de una tabla: son las partes fraccionarias de las raíces cúbicas (K) y cuadradas (H0) de los
     primeros primos, que es de donde salen según la norma. Las pruebas comparan con hashlib/hmac de Python. */
  const PRIMOS = (() => { const p = []; for (let n = 2; p.length < 64; n++) if (p.every(q => n % q)) p.push(n); return p; })();
  const frac = x => Math.floor((x - Math.floor(x)) * 4294967296) >>> 0;
  const K = PRIMOS.map(p => frac(Math.cbrt(p)));
  const H0 = PRIMOS.slice(0, 8).map(p => frac(Math.sqrt(p)));
  const rotd = (x, n) => (x >>> n) | (x << (32 - n));
  function sha256(bytes) {
    const Hh = H0.slice(), l = bytes.length, bits = l * 8;
    const m = new Uint8Array(((l + 9 + 63) >> 6) << 6);
    m.set(bytes); m[l] = 0x80;
    const dv = new DataView(m.buffer);
    dv.setUint32(m.length - 8, Math.floor(bits / 4294967296)); dv.setUint32(m.length - 4, bits >>> 0);
    const w = new Uint32Array(64);
    for (let o = 0; o < m.length; o += 64) {
      for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
      for (let i = 16; i < 64; i++) {
        const a = w[i - 15], b = w[i - 2];
        w[i] = (w[i - 16] + (rotd(a, 7) ^ rotd(a, 18) ^ (a >>> 3)) + w[i - 7] + (rotd(b, 17) ^ rotd(b, 19) ^ (b >>> 10))) | 0;
      }
      let [a, b, c, d, e, f, g, hh] = Hh;
      for (let i = 0; i < 64; i++) {
        const t1 = (hh + (rotd(e, 6) ^ rotd(e, 11) ^ rotd(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
        const t2 = ((rotd(a, 2) ^ rotd(a, 13) ^ rotd(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
        hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      [a, b, c, d, e, f, g, hh].forEach((v, i) => { Hh[i] = (Hh[i] + v) | 0; });
    }
    const out = new Uint8Array(32), odv = new DataView(out.buffer);
    Hh.forEach((v, i) => odv.setUint32(i * 4, v >>> 0));
    return out;
  }
  function hmacBytes(clave, mensaje) {
    let k = clave.length > 64 ? sha256(clave) : clave;
    const ip = new Uint8Array(64 + mensaje.length), op = new Uint8Array(96);
    for (let i = 0; i < 64; i++) { const b = i < k.length ? k[i] : 0; ip[i] = b ^ 0x36; op[i] = b ^ 0x5c; }
    ip.set(mensaje, 64);
    op.set(sha256(ip), 64);
    return sha256(op);
  }
  const hmacJs = (clave, texto) => hex(hmacBytes(new TextEncoder().encode(clave), new TextEncoder().encode(texto)));
  const SUBTLE = !!(window.crypto && crypto.subtle && crypto.subtle.importKey);
  /* el HMAC de verdad: SubtleCrypto cuando está; si no (o con una clave vacía, que SubtleCrypto no admite), el respaldo */
  async function hmac(clave, texto) {
    const enc = new TextEncoder(), k = enc.encode(clave), m = enc.encode(texto);
    if (SUBTLE && k.length) {
      try {
        const llave = await crypto.subtle.importKey('raw', k, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
        return { hex: hex(new Uint8Array(await crypto.subtle.sign('HMAC', llave, m))), motor: 'subtle' };
      } catch (e) { /* cae al respaldo */ }
    }
    return { hex: hex(hmacBytes(k, m)), motor: 'js' };
  }

  /* ── los datos y el texto ────────────────────────────────────────────── */
  const canonico = d => CAMPOS.map(k => k + '=' + d[k]).join('\n');
  const grupos = c => (c.match(/.{4}/g) || []);                          // 20 caracteres → 5 grupos
  /* del código impreso solo cuenta lo que no es formato: sin mayúsculas, guiones ni espacios */
  const normaliza = c => { const s = String(c == null ? '' : c).toUpperCase().replace(/[\s-]/g, ''); return /^[0-9A-F]{20}$/.test(s) ? s : null; };
  const corta = s => (s.length > 40 ? s.slice(0, 40) + '…' : s);
  function leeTexto(texto) {
    const lineas = String(texto).replace(/\r\n?/g, '\n').split('\n').filter(l => l.trim());
    if (!lineas.length) throw new Error('El texto está vacío.');
    const datos = {};
    let codigo = null;
    lineas.forEach(l => {
      const i = l.indexOf('=');
      if (i < 1) throw new Error('La línea «' + corta(l) + '» no tiene la forma campo=valor.');
      const k = l.slice(0, i), v = l.slice(i + 1);
      if (k === 'codigo') { if (codigo !== null) throw new Error('El campo «codigo» aparece dos veces.'); codigo = v; return; }
      if (CAMPOS.indexOf(k) < 0) throw new Error('«' + corta(k) + '» no es un campo del comprobante.');
      if (k in datos) throw new Error('El campo «' + k + '» aparece dos veces.');
      datos[k] = v;
    });
    const falta = CAMPOS.find(k => !(k in datos));
    if (falta) throw new Error('Falta la línea «' + falta + '».');
    if (codigo === null) throw new Error('Falta la línea «codigo».');
    return { datos, codigo };
  }
  /* de a a b: la parte de b que es distinta (prefijo y sufijo comunes fuera). Si b solo perdió algo, i === jb. */
  function difiere(a, b) {
    let i = 0;
    const n = Math.min(a.length, b.length);
    while (i < n && a[i] === b[i]) i++;
    let ja = a.length, jb = b.length;
    while (ja > i && jb > i && a[ja - 1] === b[jb - 1]) { ja--; jb--; }
    return { i, jb };
  }

  function Autentico(raiz, opciones) {
    const o = opciones || {};
    const $ = s => raiz.querySelector(s), $$ = s => Array.from(raiz.querySelectorAll(s));
    const hoja = $('[data-hoja]'), sello = $('[data-sello]'), selloT = $('[data-sello-t]');
    const entradas = {}; $$('[data-in]').forEach(e => { entradas[e.dataset.in] = e; });
    const campoEl = {}; $$('[data-campo]').forEach(e => { campoEl[e.dataset.campo] = e; });
    const codEl = $('[data-cod]'), huellaHoja = $('[data-huella-hoja]'), huellaCalc = $('[data-huella-calc]');
    const datosEl = $('[data-datos]'), nBytes = $('[data-n-bytes]'), pegado = $('[data-pegado]'), area = $('[data-area]'), pegadoM = $('[data-pegado-m]');
    const claveEl = $('[data-clave]'), hexEl = $('[data-hex]');
    const nCoincide = $('[data-n-coincide]'), filaI = $('[data-fila-i]'), filaC = $('[data-fila-c]'), marcas = $('[data-marcas]');
    const verCaja = $('[data-veredicto-caja]'), verT = $('[data-ver-t]'), verD = $('[data-ver-d]'), estadoEl = $('[data-estado]');
    const btnAltera = $('[data-alterar]'), btnRestaura = $('[data-restaura]'), btnCopiar = $('[data-copiar]'), btnCopiarT = $('[data-copiar-t]'), btnPegar = $('[data-pegar]');
    const ESTADO0 = estadoEl.textContent, COPIAR0 = btnCopiarT.textContent;
    const azar = mulberry32(2026);

    const clave0 = o.clave != null ? String(o.clave) : CLAVE0;
    const E = { emitido: null, base: null, copia: null, clave0, clave: clave0, seq: 0, res: null, veredicto: null, hex: '', motor: SUBTLE ? 'subtle' : 'js', pegando: false, altera: 0, rueda: 0, listo: false };
    const copiaDe = d => { const c = {}; CAMPOS.forEach(k => { c[k] = d[k]; }); return c; };

    /* ── los controles de la hoja ───────────────────────────────────── */
    // opciones de medio y estado: botones de radio; si el dato pegado no es de la lista, aparece uno más con ese valor
    const opc = {};
    ['medio', 'estado'].forEach(k => {
      const grupo = $('[data-opc="' + k + '"]');
      OPCIONES[k].forEach(v => { const b = h('button', 'au-chip', v); b.type = 'button'; b.setAttribute('role', 'radio'); b.dataset.valor = v; grupo.appendChild(b); });
      const extra = h('button', 'au-chip au-chip-otro'); extra.type = 'button'; extra.setAttribute('role', 'radio'); extra.hidden = true; grupo.appendChild(extra);
      opc[k] = { grupo, extra };
      grupo.addEventListener('click', ev => { const b = ev.target.closest('.au-chip'); if (b && !b.hidden) edita(k, b.dataset.valor); });
      grupo.addEventListener('keydown', ev => {
        if (!/^(Arrow(Left|Right|Up|Down)|Home|End)$/.test(ev.key)) return;
        const bs = Array.from(grupo.querySelectorAll('.au-chip')).filter(b => !b.hidden), i = bs.indexOf(document.activeElement);
        if (i < 0) return;
        ev.preventDefault();
        const j = ev.key === 'Home' ? 0 : ev.key === 'End' ? bs.length - 1 : (i + (/Right|Down/.test(ev.key) ? 1 : -1) + bs.length) % bs.length;
        bs[j].focus(); edita(k, bs[j].dataset.valor);
      });
    });
    function pintaOpciones(k) {
      const { grupo, extra } = opc[k], v = E.copia[k], enLista = OPCIONES[k].indexOf(v) >= 0;
      extra.hidden = enLista; if (!enLista) { extra.textContent = v === '' ? '(vacío)' : v; extra.dataset.valor = v; }
      grupo.querySelectorAll('.au-chip').forEach(b => {
        const on = !b.hidden && b.dataset.valor === v;
        b.setAttribute('aria-checked', on ? 'true' : 'false'); b.tabIndex = on ? 0 : -1;
      });
      if (!grupo.querySelector('[tabindex="0"]')) grupo.querySelector('.au-chip').tabIndex = 0;
    }
    CAMPOS.forEach(k => {
      const e = entradas[k];
      if (!e) return;
      e.addEventListener('input', () => edita(k, e.value));
      e.addEventListener('click', () => e.select());
      // Esc devuelve el campo a como se emitió
      e.addEventListener('keydown', ev => { if (ev.key === 'Escape' && E.copia && E.copia[k] !== E.emitido[k]) { ev.preventDefault(); edita(k, E.emitido[k]); e.select(); } });
    });
    $$('[data-cuota]').forEach(b => b.addEventListener('click', () => {
      const m = /^(\d+) de (\d+)$/.exec(E.copia.cuota);
      if (!m) { entradas.cuota.focus(); return; }
      edita('cuota', lim(+m[1] + +b.dataset.cuota, 1, 9) + ' de ' + m[2]);
    }));

    /* ── editar, alterar, restaurar, copiar, pegar ──────────────────── */
    function edita(k, v) {
      if (!E.copia || CAMPOS.indexOf(k) < 0) return;
      v = String(v).replace(/[\r\n]+/g, ' ');
      E.copia[k] = v;
      return calcula();
    }
    /* cambia un carácter del siguiente campo de la lista: un dígito por otro dígito, una letra por otra, lo demás por «x» */
    function altera() {
      if (!E.copia) return;
      const k = ORDEN_ALTERA[E.altera++ % ORDEN_ALTERA.length];
      const v = E.copia[k], pos = v.length ? Math.floor(azar() * v.length) : 0, c = v[pos] || '';
      let nuevo;
      if (/\d/.test(c)) nuevo = String((+c + 1 + Math.floor(azar() * 9)) % 10);
      else if (/[a-záéíóúñ]/i.test(c)) { const abc = 'abcdefghijklmnopqrstuvwxyz'.replace(c.toLowerCase(), ''); nuevo = abc[Math.floor(azar() * abc.length)]; if (c !== c.toLowerCase()) nuevo = nuevo.toUpperCase(); }
      else nuevo = 'x';
      return edita(k, v.slice(0, pos) + nuevo + v.slice(pos + 1));
    }
    function restaura() {
      if (!E.emitido) return;
      E.copia = { ...copiaDe(E.emitido), codigo: E.emitido.codigo };
      E.base = copiaDe(E.emitido);
      E.clave = E.clave0; claveEl.value = E.clave0;
      cierraPegado();
      return calcula();
    }
    const textoActual = () => canonico(E.copia) + '\ncodigo=' + E.copia.codigo;
    function copiar() {
      const txt = textoActual();
      const listo = () => { fija(btnCopiarT, 'Copiado'); btnCopiar.classList.add('es-ok'); clearTimeout(E.tCopia); E.tCopia = setTimeout(() => { fija(btnCopiarT, COPIAR0); btnCopiar.classList.remove('es-ok'); }, 1500); };
      const respaldo = () => {
        const t = h('textarea'); t.value = txt; t.setAttribute('readonly', ''); t.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
        document.body.appendChild(t); t.select();
        try { document.execCommand('copy'); } catch (e) { /* sin portapapeles: el texto sigue visible en el paso 1 */ }
        t.remove(); listo();
      };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(listo, respaldo); else respaldo();
    }
    function cierraPegado() {
      if (!E.pegando) return;
      E.pegando = false; pegado.hidden = true; datosEl.hidden = false;
      btnPegar.setAttribute('aria-expanded', 'false');
    }
    function abrePegado() {
      E.pegando = true; datosEl.hidden = true; pegado.hidden = false; area.value = '';
      pegadoM.className = 'au-pegado-m'; fija(pegadoM, 'Cada línea es campo=valor y la última es el código.');
      btnPegar.setAttribute('aria-expanded', 'true');
      area.focus();
    }
    /* carga el texto de otro comprobante; si no se entiende, dice por qué y deja lo que había */
    function carga(texto) {
      let r;
      try { r = leeTexto(texto); }
      catch (e) {
        if (E.pegando) { pegadoM.className = 'au-pegado-m es-error'; fija(pegadoM, e.message); }
        else { estadoEl.className = 'au-estado es-error'; fija(estadoEl, e.message); }
        return false;
      }
      E.copia = { ...copiaDe(r.datos), codigo: r.codigo };
      E.base = copiaDe(r.datos);                      // lo que se edite desde aquí se marca contra este texto
      cierraPegado();
      estadoEl.className = 'au-estado';
      calcula();
      return true;
    }
    btnAltera.addEventListener('click', altera);
    btnRestaura.addEventListener('click', restaura);
    btnCopiar.addEventListener('click', copiar);
    btnPegar.addEventListener('click', () => { if (E.pegando) { cierraPegado(); pinta(false); } else abrePegado(); });
    area.addEventListener('input', () => { if (area.value.trim()) carga(area.value); });
    area.addEventListener('keydown', ev => { if (ev.key === 'Escape') { ev.preventDefault(); cierraPegado(); btnPegar.focus(); } });
    // ⌘V o Ctrl+V en cualquier parte (fuera de los campos) trae un comprobante del portapapeles
    document.addEventListener('paste', ev => {
      const t = ev.target;
      if (t && t.closest && (t.closest('[data-in]') || t.closest('[data-clave]') || t === area)) return;
      const txt = ev.clipboardData && ev.clipboardData.getData('text');
      if (txt) { ev.preventDefault(); carga(txt); }
    });
    claveEl.value = E.clave;
    claveEl.addEventListener('input', () => { E.clave = claveEl.value; calcula(); });
    claveEl.addEventListener('keydown', ev => { if (ev.key === 'Escape' && E.clave !== E.clave0) { ev.preventDefault(); E.clave = E.clave0; claveEl.value = E.clave0; calcula(); } });

    /* ── calcular: el HMAC de lo que hay en pantalla ────────────────── */
    function calcula() { return (E.ultimo = calculaAsync()); }
    async function calculaAsync() {
      const id = ++E.seq, canon = canonico(E.copia), clave = E.clave;
      const r = await hmac(clave, canon);
      if (id !== E.seq) return;                       // llegó tarde: ya hay un cambio más nuevo
      const anterior = E.res;
      E.motor = r.motor;
      E.hex = r.hex;
      const calc = r.hex.slice(0, LARGO_COD).toUpperCase(), impreso = normaliza(E.copia.codigo);
      const gi = impreso ? grupos(impreso) : null, gc = grupos(calc);
      const iguales = gc.map((g, i) => !!gi && gi[i] === g);
      const ok = !!impreso && impreso === calc;
      const cambiados = CAMPOS.filter(k => E.base && E.copia[k] !== E.base[k]);
      E.res = { ok, calc, impreso, gi, gc, iguales, canon, cambiados, hex: r.hex, nIguales: iguales.filter(Boolean).length };
      pinta(true, anterior);
      if (typeof o.alCambiar === 'function') o.alCambiar(estado());
    }

    /* ── pintar ─────────────────────────────────────────────────────── */
    const bar = n => { const b = document.createElement('i'); b.style.setProperty('--n', n); return b; };
    function pintaHuella(cont, nibs, impresos) {
      if (cont.children.length !== LARGO_COD) { cont.textContent = ''; for (let i = 0; i < LARGO_COD; i++) cont.appendChild(bar(0)); }
      Array.from(cont.children).forEach((b, i) => {
        const v = nibs ? parseInt(nibs[i], 16) : 0;
        b.style.setProperty('--n', nibs ? (v + 2) / 17 : .12);
        if (impresos !== null) b.classList.toggle('es-distinta', !impresos || !nibs || impresos[i].toLowerCase() !== nibs[i].toLowerCase());
      });
    }
    function celdas(cont, gs, marca) {
      if (cont.children.length !== 5) { cont.textContent = ''; for (let i = 0; i < 5; i++) cont.appendChild(h('span')); }
      Array.from(cont.children).forEach((c, i) => { fija(c, gs ? gs[i] : '····'); c.classList.toggle('es-mal', !!marca && !marca[i]); });
    }
    /* los hexadecimales del paso 2 «ruedan» un instante hasta su valor, de izquierda a derecha */
    function ruedaHex(destino) {
      if (hexEl.querySelectorAll('i').length !== 64) {
        hexEl.textContent = '';
        for (let b = 0; b < 8; b++) {
          const blq = h('span', 'au-hexb');
          for (let j = 0; j < 8; j++) blq.appendChild(h('i', b * 8 + j < LARGO_COD ? 'es-cod' : '', '0'));
          hexEl.appendChild(blq);
        }
      }
      const cs = Array.from(hexEl.querySelectorAll('i')), id = ++E.rueda, t0 = performance.now();
      const meta = i => 140 + i * 7;
      if (quieto()) { cs.forEach((c, i) => fija(c, destino[i])); return; }
      const paso = ahora => {
        if (id !== E.rueda) return;
        const t = ahora - t0;
        let fin = true;
        cs.forEach((c, i) => {
          if (t >= meta(i)) { fija(c, destino[i]); c.classList.remove('es-rueda'); return; }
          fin = false;
          const k = Math.imul(i + 1, 2654435761) ^ Math.imul(Math.floor(t / 42) + 1, 40503);
          fija(c, '0123456789abcdef'[(k >>> 7) & 15]); c.classList.add('es-rueda');
        });
        if (!fin) requestAnimationFrame(paso);
      };
      requestAnimationFrame(paso);
    }
    /* el paso 1: los datos como líneas; si algo cambió, la parte distinta se marca */
    function pintaDatos(R) {
      datosEl.textContent = '';
      CAMPOS.forEach(k => {
        const v = E.copia[k], linea = h('span', 'au-l'), cambio = !R.ok && R.cambiados.indexOf(k) >= 0;
        linea.dataset.k = k;
        linea.appendChild(h('b', 'au-k', k)); linea.appendChild(h('i', 'au-eq', '='));
        if (cambio) {
          const d = difiere(E.base[k], v);
          linea.appendChild(h('span', 'au-v', v.slice(0, d.i)));
          const m = h('mark', d.i === d.jb ? 'au-borra' : '', v.slice(d.i, d.jb)); linea.appendChild(m);
          linea.appendChild(h('span', 'au-v', v.slice(d.jb)));
          linea.classList.add('es-cambiada');
        } else linea.appendChild(h('span', 'au-v', v));
        datosEl.appendChild(linea);
      });
      fija(nBytes, new TextEncoder().encode(canonico(E.copia)).length + ' bytes');
    }
    function pinta(animado, anterior) {
      const R = E.res;
      if (!R) return;
      const nuevo = R.ok ? 'valido' : 'alterado', cambioVer = E.veredicto !== nuevo, primera = E.veredicto === null;
      // los campos
      CAMPOS.forEach(k => {
        const e = entradas[k];
        if (e && e.value !== E.copia[k]) e.value = E.copia[k];
        if (opc[k]) pintaOpciones(k);
        const marca = !R.ok && R.cambiados.indexOf(k) >= 0;
        if (campoEl[k]) campoEl[k].classList.toggle('es-cambiado', marca);
        if (k === 'emisor' || k === 'folio') { const e2 = entradas[k]; e2.classList.toggle('es-cambiado', marca); }
      });
      const mc = /^(\d+) de (\d+)$/.exec(E.copia.cuota);
      $$('[data-cuota]').forEach(b => { b.disabled = !mc || lim(+mc[1] + +b.dataset.cuota, 1, 9) === +mc[1]; });
      // el código impreso
      const raw = E.copia.codigo;
      codEl.textContent = '';
      (R.gi || [String(raw)]).forEach(g => { codEl.appendChild(h('span', R.gi ? '' : 'es-crudo es-mal', g)); });
      codEl.setAttribute('aria-label', 'Código de verificación impreso: ' + (R.gi ? R.gi.join(' ') : String(raw)));
      pintaHuella(huellaHoja, R.impreso, null);
      // paso 1, 2 y 3
      pintaDatos(R);
      if (primera || !animado) { const cs = hexEl.querySelectorAll('i'); if (cs.length === 64) cs.forEach((c, i) => fija(c, R.hex[i])); else ruedaHex(R.hex); } else if (!anterior || anterior.hex !== R.hex) ruedaHex(R.hex);
      hexEl.dataset.digest = R.hex; hexEl.dataset.motor = E.motor;
      pintaHuella(huellaCalc, R.hex.slice(0, LARGO_COD), R.impreso || '');
      celdas(filaI, R.gi, null); celdas(filaC, R.gc, R.iguales);
      fija(nCoincide, R.nIguales + ' de 5 coinciden');
      marcas.textContent = '';
      R.iguales.forEach((ok, i) => { const m = h('span', ok ? 'es-ok' : 'es-no'); m.style.setProperty('--i', i); marcas.appendChild(m); });
      // el sello, el veredicto y los botones
      hoja.dataset.veredicto = nuevo; verCaja.dataset.caso = nuevo;
      fija(selloT, R.ok ? 'VÁLIDO' : 'ALTERADO');
      const hayDatos = R.cambiados.length > 0, otraClave = E.clave !== E.clave0;
      const esOriginal = CAMPOS.every(k => E.copia[k] === E.emitido[k]) && R.impreso === normaliza(E.emitido.codigo) && !otraClave;
      if (R.ok) {
        fija(verT, esOriginal ? 'Es el original: el código coincide' : 'Válido: lo emitió el negocio');
        fija(verD, esOriginal ? '20 caracteres que salen de estos datos y de la clave: nada cambió.' : 'Es otro comprobante, pero su código sale de sus datos con la clave del negocio.');
      } else {
        fija(verT, 'Alterado: el código ya no vale');
        const n = R.nIguales;
        const cola = R.impreso ? 'Recalculado, coincide ' + (n === 0 ? 'ningún grupo' : n === 1 ? 'solo 1 grupo' : 'en ' + n + ' grupos') + ' de 5.' : 'El código impreso no tiene 20 caracteres hexadecimales.';
        if (hayDatos) fija(verD, 'Cambió ' + R.cambiados.map(k => '«' + ETQ[k].toLowerCase() + '»').join(', ').replace(/, ([^,]*)$/, ' y $1') + '. ' + cola);
        else if (otraClave) fija(verD, 'La clave no es la del negocio: los mismos datos dan otro código. ' + cola);
        else fija(verD, 'El código impreso no sale de estos datos con la clave del negocio. ' + cola);
      }
      const cambiaCopia = hayDatos || E.copia.codigo !== E.emitido.codigo || E.clave !== E.clave0;
      btnRestaura.disabled = !cambiaCopia;
      btnRestaura.classList.toggle('es-listo', !R.ok);
      if (!E.pegando && !(estadoEl.classList.contains('es-error') && !cambioVer)) {
        estadoEl.className = 'au-estado';
        fija(estadoEl, R.ok ? (esOriginal ? ESTADO0 : 'Válido: el código de este comprobante sale de sus datos y de la clave') : 'Alterado: ' + (hayDatos ? 'un dato cambió y el código dejó de valer' : 'el código no sale de estos datos'));
      }
      // el sello cae al cambiar el veredicto; si sigue igual, solo se estremece
      if (primera || !animado) { E.veredicto = nuevo; E.listo = true; return; }
      E.veredicto = nuevo;
      if (cambioVer) cae(nuevo); else estremece();
    }
    /* el sello cae con un poco de peso: llega grande y girado, se asienta y la hoja se hunde un pelo */
    function cae(v) {
      anima(sello, [
        { opacity: 0, transform: 'rotate(-15deg) scale(2)', offset: 0 },
        { opacity: 1, transform: 'rotate(-7deg) scale(.93)', offset: .55 },
        { opacity: 1, transform: 'rotate(-7deg) scale(1)', offset: 1 }
      ], { duration: 560, easing: 'cubic-bezier(.22, 1, .36, 1)' });
      const trazo = sello.querySelector(v === 'valido' ? '.au-ic-ok' : '.au-ic-no');
      anima(trazo, [{ strokeDashoffset: 1 }, { strokeDashoffset: 0 }], { duration: 380, delay: 260, easing: 'cubic-bezier(.22, 1, .36, 1)', fill: 'backwards' });
      if (v === 'valido') anima(hoja, [{ transform: 'translateY(0)' }, { transform: 'translateY(4px)', offset: .35 }, { transform: 'translateY(0)' }], { duration: 360, delay: 170, easing: 'ease-out' });
      else anima(hoja, [{ transform: 'translateX(0)' }, { transform: 'translateX(-7px)', offset: .16 }, { transform: 'translateX(6px)', offset: .36 }, { transform: 'translateX(-4px)', offset: .56 }, { transform: 'translateX(2px)', offset: .78 }, { transform: 'translateX(0)' }], { duration: 440, delay: 150, easing: 'ease-out' });
    }
    function estremece() {
      anima(sello, [{ transform: 'rotate(-7deg) scale(1)' }, { transform: 'rotate(-8.500deg) scale(1.07)', offset: .4 }, { transform: 'rotate(-7deg) scale(1)' }], { duration: 300, easing: 'ease-out' });
    }

    /* ── el estado, para quien integre o pruebe ─────────────────────── */
    function estado() {
      const R = E.res;
      return {
        veredicto: E.veredicto, cambiados: R ? R.cambiados.slice() : [], codigo: R ? R.impreso : null, calculado: R ? R.calc : null, hex: R ? R.hex : '',
        motor: E.motor, datos: copiaDe(E.copia), impreso: E.copia.codigo, emitido: copiaDe(E.emitido), codigoEmitido: E.emitido.codigo, clave: E.clave, canonico: R ? R.canon : canonico(E.copia), iguales: R ? R.iguales.slice() : []
      };
    }

    /* ── arranque: el negocio emite el comprobante y queda a la vista ─ */
    const d0 = Object.assign({}, DATOS0, o.datos || {});
    // la hoja se rellena de inmediato, sin esperar al primer HMAC (que es asíncrono): no hay un instante con los campos vacíos
    E.copia = copiaDe(d0);
    CAMPOS.forEach(k => { if (entradas[k]) entradas[k].value = d0[k]; if (opc[k]) pintaOpciones(k); });
    E.copia = null;
    const listo = (async () => {
      const r = await hmac(E.clave0, canonico(d0));
      const cod = grupos(r.hex.slice(0, LARGO_COD).toUpperCase()).join('-');
      E.emitido = { ...copiaDe(d0), codigo: cod };
      E.copia = { ...copiaDe(d0), codigo: cod };
      E.base = copiaDe(d0);
      await calcula();
      return estado();
    })();

    return { edita, altera, restaura, carga, espera: () => E.ultimo, texto: () => textoActual(), clave: v => { if (v != null) { E.clave = String(v); claveEl.value = E.clave; return calcula(); } return E.clave; }, estado, listo };
  }

  Autentico.hmac = async (clave, texto) => (await hmac(clave, texto)).hex;
  Autentico.hmacJs = hmacJs;
  Autentico.lee = leeTexto;
  Autentico.canonico = canonico;
  window.Autentico = Autentico;
  const raiz = document.querySelector('[data-autentico]');
  if (raiz) raiz.__autentico = Autentico(raiz);
})();
