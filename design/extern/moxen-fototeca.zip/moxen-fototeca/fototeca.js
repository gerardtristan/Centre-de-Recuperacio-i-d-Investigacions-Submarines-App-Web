/* =====================================================================
   Fototeca · Moxen
   Una mediateca de fotos con carpetas, como la de una aplicación de escritorio.
   · Arrastrar sobre el fondo dibuja un recuadro elástico (su esquina libre
     sigue al puntero con un resorte) y elige las fotos que toca; con Mayús
     (o ⌘/Ctrl) suma y resta a lo que ya estaba elegido. Las elegidas se
     elevan con un aro azul y un contador «5 elegidas» rueda en la barra.
   · Arrastrar el grupo hasta una carpeta de la izquierda: las fotos viajan
     apiladas con el puntero y, al soltar, salen en abanico hacia la carpeta,
     que se abre; su cifra sube y aparece un aviso con «Deshacer».
   · Pulsar una foto abre a la derecha un panel de detalles (nombre y
     etiquetas editables) que entra con resorte mientras las demás se
     estrechan a otra cantidad de columnas (FLIP: cada miniatura viaja de su
     sitio al nuevo, escalada).
   · Soltar un archivo sobre la rejilla (o pulsar «Subir») crea una
     miniatura con un anillo de carga que se resuelve en la foto.
   · Teclado: flechas mueven el foco entre fotos, Espacio elige, Mayús+flecha
     amplía, Intro abre los detalles, Ctrl/⌘+A elige todas, Esc cierra el panel
     o quita la selección. Para mover a una carpeta, elige y pulsa la carpeta.
   · Dedo: un toque elige (o abre los detalles si no hay nada elegido);
     mantener pulsado ~0,3 s arranca el recuadro o el arrastre del grupo.

   Montaje (se inicia solo sobre [data-fototeca]; el HTML de esta demo es la plantilla):
     const f = Fototeca(document.querySelector('[data-fototeca]'), {
       alElegir: ({ cantidad }) => {},                       // cambia la selección
       alMover: ({ carpeta, fotos }) => {},                  // fotos añadidas a una carpeta
       alSubir: ({ nombre }) => {},                          // una foto terminó de subirse
     });
     f.elegidas();                 // las fotos elegidas (objetos con .nombre, .etiquetas, .carpetas)
     f.limpia();                   // quita la selección
   Qué cambia qué: cada .fo-foto del HTML es una miniatura (data-ar = ancho / alto,
   data-nombre, data-dim, data-peso, data-fecha, data-etiquetas separadas por comas);
   cada .fo-carpeta[data-carpeta] es un destino y su cifra inicial sale de su texto;
   las fotos de <template data-reserva> son las que «Subir» va sumando. Todos los
   colores, el radio de las miniaturas y la tipografía están al principio de
   fototeca.css; los resortes, juntos en MUELLES de aquí abajo. Sin
   dependencias; el tiempo sale de requestAnimationFrame, de timers y de la
   Web Animations API, y no hay azar: la página y el vídeo coinciden.
   ===================================================================== */
(function () {
  'use strict';

  /* ── utilidades ───────────────────────────────────────────────────── */
  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  // un resorte: x es el valor, meta a dónde va, k la rigidez, c la amortiguación y e la precisión de reposo
  const resorte = (x, par, e) => ({ x, v: 0, meta: x, k: par.k, c: par.c, e: e || .0008 });
  function avanza(r, dt) {
    for (let t = dt; t > 0;) {
      const h = Math.min(t, 1 / 240);
      r.v += (r.k * (r.meta - r.x) - r.c * r.v) * h;
      r.x += r.v * h;
      t -= h;
    }
  }
  const enReposo = r => Math.abs(r.v) < r.e * 10 && Math.abs(r.meta - r.x) < r.e;
  // un resorte convertido en curva CSS linear() (y lo que tarda en asentarse, en ms)
  const SOPORTA_LINEAR = !!(window.CSS && CSS.supports && CSS.supports('animation-timing-function', 'linear(0, 1)'));
  function muelle(par) {
    if (!SOPORTA_LINEAR) return { curva: 'cubic-bezier(.34, 1.56, .64, 1)', ms: 600 };
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (par.k * (1 - x) - par.c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .002 && Math.abs(v) < .02) break;
    }
    const out = [];
    for (let i = 0; i <= 48; i++) out.push(pts[Math.round(i / 48 * (pts.length - 1))].toFixed(4));
    out[48] = '1';
    return { curva: 'linear(' + out.join(', ') + ')', ms: Math.round(t * 1000) };
  }

  // los resortes: cada pieza tiene el suyo, del más ágil al más pausado
  const MUELLES = {
    pieza: { k: 420, c: 20 },      // aros, marcas, chips y botones: un rebote corto
    panel: { k: 150, c: 19 },      // el panel de detalles al entrar
    dispone: { k: 190, c: 22 },    // las miniaturas al cambiar de columnas
    recuadro: { k: 560, c: 32 },   // la esquina elástica del recuadro
    cifra: { k: 300, c: 26 },      // el rodillo de las cifras
    grupo: { k: 300, c: 25 },      // las fotos que siguen al puntero
  };
  const PULSO_LARGO = 300;         // ms que un dedo debe mantenerse para empezar a elegir o arrastrar
  const AVISO_MS = 6000;           // ms que el aviso con «Deshacer» se queda
  const GAP = 12;                  // hueco entre miniaturas
  const MAX_FANTASMAS = 7;         // fotos que se dibujan viajando (el resto cuenta pero no vuela)
  const FANTASMA_W = 108;          // ancho de las fotos viajeras
  const ICONO_CARPETA = '<svg viewBox="0 0 12 11" aria-hidden="true"><path fill="currentColor" d="M1 2.6A1.2 1.2 0 0 1 2.2 1.4h2.3l1 1.2h4.3A1.2 1.2 0 0 1 11 3.8v4.9a1.2 1.2 0 0 1-1.2 1.2H2.2A1.2 1.2 0 0 1 1 8.7Z"/></svg>';
  const CARGA = '<span class="fo-carga" aria-hidden="true"><svg viewBox="0 0 44 44"><circle class="fo-carga-pista" cx="22" cy="22" r="18" pathLength="100"/><circle class="fo-carga-arco" cx="22" cy="22" r="18" pathLength="100"/></svg><b>0</b></span>';
  const CHECK = '<span class="fo-check" aria-hidden="true"><svg viewBox="0 0 24 24"><path pathLength="1" d="m6.8 12.6 3.4 3.4 7-7.6"/></svg></span>';

  /* ── una cifra que rueda: la vieja sube y se va, la nueva entra desde abajo ── */
  function Rueda(el, valor, curva) {
    let actual = valor;
    el.textContent = '';
    const s0 = document.createElement('span');
    s0.className = 'fo-r'; s0.textContent = valor; el.appendChild(s0);
    return {
      get valor() { return actual; },
      pon(v) {
        if (v === actual) return;
        const dir = v > actual ? 1 : -1;
        actual = v;
        // si una vuelta anterior sigue en marcha, se da por terminada
        while (el.children.length > 1) el.firstElementChild.remove();
        const viejo = el.lastElementChild;
        viejo.getAnimations().forEach(a => a.cancel());
        viejo.setAttribute('aria-hidden', 'true');          // un lector de pantalla solo lee la cifra nueva
        const nuevo = document.createElement('span');
        nuevo.className = 'fo-r'; nuevo.textContent = v;
        el.appendChild(nuevo);
        if (quieto()) { viejo.remove(); return; }
        const sale = viejo.animate([{ transform: 'translateY(0)', opacity: 1 }, { transform: 'translateY(' + (-dir * 105) + '%)', opacity: 0 }], { duration: 300, easing: 'cubic-bezier(.5, 0, .75, 0)', fill: 'forwards' });
        sale.onfinish = () => viejo.remove();
        nuevo.animate([{ transform: 'translateY(' + (dir * 105) + '%)', opacity: 0 }, { transform: 'translateY(0)', opacity: 1 }], { duration: curva.ms, easing: curva.curva, fill: 'backwards' });
      },
    };
  }

  function Fototeca(raiz, opc) {
    opc = Object.assign({ alElegir: null, alMover: null, alSubir: null }, opc || {});
    const ventana = raiz.querySelector('.fo-ventana');
    const principal = raiz.querySelector('.fo-main');
    const grid = raiz.querySelector('[data-grid]');
    const lienzo = raiz.querySelector('[data-lienzo]');
    const recuadro = raiz.querySelector('[data-recuadro]');
    const capa = raiz.querySelector('[data-fantasmas]');
    const detalle = raiz.querySelector('[data-detalle]');
    const aviso = raiz.querySelector('[data-aviso]');
    const avisoTx = raiz.querySelector('[data-aviso-tx]');
    const vivo = raiz.querySelector('[data-vivo]');
    const plantilla = raiz.querySelector('template[data-reserva]');
    const movil = matchMedia('(max-width: 760px)');

    // los resortes pasados a curvas CSS: --fo-resorte (piezas), --fo-resorte-panel (el panel)
    const mPieza = muelle(MUELLES.pieza), mPanel = muelle(MUELLES.panel), mDispone = muelle(MUELLES.dispone), mCifra = muelle(MUELLES.cifra);
    raiz.style.setProperty('--fo-resorte', mPieza.curva);
    raiz.style.setProperty('--fo-d-boton', mPieza.ms + 'ms');
    raiz.style.setProperty('--fo-resorte-panel', mPanel.curva);
    raiz.style.setProperty('--fo-d-panel', mPanel.ms + 'ms');

    /* ── las fotos ──────────────────────────────────────────────────── */
    const fotos = [];
    function creaFoto(el) {
      const f = {
        el, marco: el.querySelector('.fo-marco'), img: el.querySelector('img'),
        ar: +el.dataset.ar || 1.5, nombre: el.dataset.nombre || 'foto.jpg',
        dim: el.dataset.dim || '', peso: el.dataset.peso || '', fecha: el.dataset.fecha || '',
        etiquetas: (el.dataset.etiquetas || '').split(',').map(s => s.trim()).filter(Boolean),
        carpetas: [], x: 0, y: 0, w: 0, h: 0, on: false, listo: false, cargando: false,
      };
      f.marco.insertAdjacentHTML('beforeend', CHECK + '<span class="fo-en" aria-hidden="true">' + ICONO_CARPETA + '<span></span></span><span class="fo-pie"></span>');
      f.enTx = f.marco.querySelector('.fo-en span');
      f.pie = f.marco.querySelector('.fo-pie');
      f.pie.textContent = f.nombre;
      el.setAttribute('aria-label', f.nombre);
      el.tabIndex = -1;
      el._f = f;
      return f;
    }
    lienzo.querySelectorAll('.fo-foto').forEach(el => fotos.push(creaFoto(el)));
    if (fotos[0]) fotos[0].el.tabIndex = 0;
    let foco = fotos[0] || null;

    /* ── las carpetas ───────────────────────────────────────────────── */
    const carpetas = new Map();
    raiz.querySelectorAll('.fo-carpeta').forEach(el => {
      const num = el.querySelector('[data-n]');
      const n = parseInt(num.textContent, 10) || 0;
      carpetas.set(el.dataset.carpeta, { id: el.dataset.carpeta, el, nombre: el.dataset.nombre || el.textContent.trim(), n, rueda: Rueda(num, n, mCifra), mas: el.querySelector('.fo-mas'), ico: el.querySelector('.fo-cico') });
    });
    const cont = Rueda(raiz.querySelector('[data-contador]'), 0, mCifra);
    const palabra = raiz.querySelector('[data-palabra]');
    const totalRueda = Rueda(raiz.querySelector('[data-total]'), fotos.length, mCifra);
    const totalLado = Rueda(raiz.querySelector('[data-total-lado]'), fotos.length, mCifra);
    const totalPal = raiz.querySelector('[data-total-pal]');
    function pintaTotal() { totalRueda.pon(fotos.length); totalLado.pon(fotos.length); totalPal.textContent = fotos.length === 1 ? 'foto' : 'fotos'; }

    /* ── la disposición en columnas (masonry) y el FLIP ─────────────── */
    const ANCHO_PANEL = () => detalle.offsetWidth || 300;
    function dispone(anima) {
      const lr = lienzo.getBoundingClientRect();
      const antes = new Map();
      if (anima && !quieto()) fotos.forEach(f => { if (f.listo) { const r = f.el.getBoundingClientRect(); antes.set(f, [r.left - lr.left, r.top - lr.top, r.width, r.height]); } });
      const pad = movil.matches ? 12 : 20, arriba = movil.matches ? 8 : 12;      // arriba: aire para el aro de la primera fila
      const hueco = detalleAbierto && !movil.matches ? ANCHO_PANEL() : 0;
      const W = Math.max(120, grid.clientWidth - pad * 2 - hueco);
      const minCol = movil.matches ? 140 : 180;
      const n = Math.max(2, Math.floor((W + GAP) / (minCol + GAP)));
      const cw = (W - GAP * (n - 1)) / n;
      const alto = new Array(n).fill(arriba);
      fotos.forEach(f => {
        let c = 0;
        for (let i = 1; i < n; i++) if (alto[i] < alto[c] - .5) c = i;
        const h = cw / f.ar;
        f.x = pad + c * (cw + GAP); f.y = alto[c]; f.w = cw; f.h = h;
        alto[c] += h + GAP;
      });
      lienzo.style.height = Math.max(...alto) - GAP + pad + 'px';
      fotos.forEach(f => {
        f.el.style.width = f.w.toFixed(2) + 'px';
        f.el.style.height = f.h.toFixed(2) + 'px';
        f.el.style.transform = 'translate3d(' + f.x.toFixed(2) + 'px,' + f.y.toFixed(2) + 'px,0)';
        const a = antes.get(f);
        if (a && (Math.abs(a[0] - f.x) > .5 || Math.abs(a[1] - f.y) > .5 || Math.abs(a[2] - f.w) > .5)) {
          f.el.animate([
            { transform: 'translate3d(' + a[0] + 'px,' + a[1] + 'px,0) scale(' + (a[2] / f.w) + ',' + (a[3] / f.h) + ')' },
            { transform: 'translate3d(' + f.x + 'px,' + f.y + 'px,0) scale(1,1)' },
          ], { duration: mDispone.ms, easing: mDispone.curva });
        }
        f.listo = true;
      });
    }

    /* ── la selección ───────────────────────────────────────────────── */
    let sel = new Set();
    let ultimoN = 0;
    const ordenSel = () => fotos.filter(f => sel.has(f));
    function aplicaSel() {
      fotos.forEach(f => {
        const on = sel.has(f);
        if (on === f.on) return;
        f.on = on;
        f.el.classList.toggle('is-elegida', on);
        f.el.setAttribute('aria-selected', on ? 'true' : 'false');
      });
      const n = sel.size;
      raiz.classList.toggle('hay-sel', n > 0);
      if (n > 0) { cont.pon(n); palabra.textContent = n === 1 ? 'elegida' : 'elegidas'; }
      carpetas.forEach(c => { if (n > 0) c.el.setAttribute('aria-label', 'Añadir ' + (n === 1 ? 'la foto elegida' : n + ' fotos elegidas') + ' a ' + c.nombre); else c.el.removeAttribute('aria-label'); });
      if (detalleAbierto && !(n === 1 && sel.has(detFoto))) cierraDetalle(false);
      if (n !== ultimoN) { ultimoN = n; if (opc.alElegir) opc.alElegir({ cantidad: n }); }
    }
    function anuncia() { const n = sel.size; vivo.textContent = n ? n + (n === 1 ? ' foto elegida' : ' fotos elegidas') : 'Ninguna foto elegida'; }
    function pon(conjunto) { sel = conjunto; aplicaSel(); }
    function limpia() { pon(new Set()); anuncia(); }

    /* ── el panel de detalles ───────────────────────────────────────── */
    let detalleAbierto = false, detFoto = null, entraT = 0, cambiaT = 0;
    const det = {
      caja: detalle.querySelector('[data-det-foto]'), img: detalle.querySelector('[data-det-foto] img'),
      nombre: detalle.querySelector('[data-det-nombre]'), dim: detalle.querySelector('[data-det-dim]'),
      peso: detalle.querySelector('[data-det-peso]'), fecha: detalle.querySelector('[data-det-fecha]'),
      carp: detalle.querySelector('[data-det-carp]'), etq: detalle.querySelector('[data-det-etiquetas]'),
      titulo: detalle.querySelector('[data-det-titulo]'),
    };
    Array.from(detalle.children).forEach((h, i) => h.style.setProperty('--k', i));
    function textoCarpetas(f) { return f.carpetas.length ? f.carpetas.map(id => carpetas.get(id).nombre).join(', ') : '—'; }
    function pintaDetalle(f) {
      det.img.src = f.img.currentSrc || f.img.src;
      det.img.alt = f.img.alt;
      det.caja.style.setProperty('--c', f.el.style.getPropertyValue('--c') || '');
      det.caja.style.height = Math.round(lim(ANCHO_DET_FOTO() / f.ar, 150, 214)) + 'px';
      det.nombre.value = f.nombre;
      det.dim.textContent = f.dim; det.peso.textContent = f.peso; det.fecha.textContent = f.fecha;
      det.carp.textContent = textoCarpetas(f);
      det.etq.textContent = '';
      f.etiquetas.forEach(t => det.etq.appendChild(chip(f, t)));
      det.etq.appendChild(campoEtiqueta(f));
    }
    const ANCHO_DET_FOTO = () => det.caja.clientWidth || 260;
    function chip(f, texto) {
      const li = document.createElement('li');
      li.className = 'fo-chip';
      li.innerHTML = '<span></span><button type="button"><svg viewBox="0 0 8 8" aria-hidden="true"><path d="m1 1 6 6M7 1 1 7"/></svg></button>';
      li.firstChild.textContent = texto;
      const b = li.querySelector('button');
      b.setAttribute('aria-label', 'Quitar la etiqueta ' + texto);
      b.addEventListener('click', () => {
        f.etiquetas = f.etiquetas.filter(t => t !== texto);
        const entrada = det.etq.querySelector('input');
        const sal = () => { li.remove(); };
        if (quieto()) sal(); else { const a = li.animate([{ opacity: 1, transform: 'scale(1)' }, { opacity: 0, transform: 'scale(.6)' }], { duration: 180, easing: 'ease-in' }); a.onfinish = sal; }
        vivo.textContent = 'Etiqueta ' + texto + ' quitada';
        if (entrada) entrada.focus({ preventScroll: true });
      });
      return li;
    }
    function campoEtiqueta(f) {
      const li = document.createElement('li');
      li.className = 'fo-nueva';
      li.innerHTML = '<input type="text" maxlength="18" placeholder="+ Etiqueta" aria-label="Añadir una etiqueta" spellcheck="false" autocomplete="off">';
      const input = li.firstChild;
      input.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ',') {
          e.preventDefault();
          const t = input.value.trim().toLowerCase();
          if (!t) return;
          if (f.etiquetas.includes(t)) { input.value = ''; return; }
          f.etiquetas.push(t);
          det.etq.insertBefore(chip(f, t), li);
          input.value = '';
          vivo.textContent = 'Etiqueta ' + t + ' añadida';
        } else if (e.key === 'Backspace' && !input.value && f.etiquetas.length) {
          const quita = f.etiquetas.pop();
          const chips = det.etq.querySelectorAll('.fo-chip');
          if (chips.length) chips[chips.length - 1].remove();
          vivo.textContent = 'Etiqueta ' + quita + ' quitada';
        } else if (e.key === 'Escape' && input.value) { e.stopPropagation(); input.value = ''; }
      });
      return li;
    }
    det.nombre.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); det.nombre.blur(); }
      else if (e.key === 'Escape') { e.stopPropagation(); det.nombre.value = detFoto ? detFoto.nombre : ''; det.nombre.blur(); }
    });
    det.nombre.addEventListener('change', () => {
      if (!detFoto) return;
      const v = det.nombre.value.trim();
      if (v) { detFoto.nombre = v; detFoto.pie.textContent = v; detFoto.el.setAttribute('aria-label', v); } else det.nombre.value = detFoto.nombre;
    });

    // «Copiar enlace»: el botón se vuelve ✓ un momento y vuelve a su texto
    const botonCopia = detalle.querySelector('[data-copia]'), textoCopia = detalle.querySelector('[data-copia-tx]');
    let copiaT = 0;
    botonCopia.addEventListener('click', () => {
      const enlace = 'https://fotos.ejemplo.dev/' + (detFoto ? detFoto.nombre : '');
      try { if (navigator.clipboard) navigator.clipboard.writeText(enlace).catch(() => {}); } catch (_) {}
      botonCopia.classList.add('is-copiado'); textoCopia.textContent = 'Enlace copiado';
      vivo.textContent = 'Enlace copiado';
      clearTimeout(copiaT);
      copiaT = setTimeout(() => { botonCopia.classList.remove('is-copiado'); textoCopia.textContent = 'Copiar enlace'; }, 1800);
    });

    function abreDetalle(f, conTeclado) {
      detFoto = f;
      pintaDetalle(f);
      if (detalleAbierto) {
        clearTimeout(cambiaT);
        detalle.classList.remove('is-cambia'); void detalle.offsetWidth; detalle.classList.add('is-cambia');
        cambiaT = setTimeout(() => detalle.classList.remove('is-cambia'), 700);
        return;
      }
      detalleAbierto = true;
      clearTimeout(entraT);
      detalle.removeAttribute('inert'); detalle.setAttribute('aria-hidden', 'false');
      detalle.classList.add('is-abierto', 'is-entra');
      entraT = setTimeout(() => detalle.classList.remove('is-entra'), 1300);
      raiz.classList.add('hay-detalle');
      dispone(true);
      if (conTeclado) det.titulo.focus({ preventScroll: true });
      vivo.textContent = 'Detalles de ' + f.nombre;
    }
    function cierraDetalle(devuelveFoco) {
      if (!detalleAbierto) return;
      detalleAbierto = false;
      detalle.classList.remove('is-abierto', 'is-entra', 'is-cambia');
      detalle.setAttribute('inert', ''); detalle.setAttribute('aria-hidden', 'true');
      raiz.classList.remove('hay-detalle');
      const f = detFoto;
      detFoto = null;
      dispone(true);
      if (devuelveFoco && f) focoA(f);
    }
    detalle.querySelector('[data-cierra-detalle]').addEventListener('click', () => { const f = detFoto; cierraDetalle(true); if (f) limpia(); });

    /* ── el foco con teclado: una sola foto en el orden de tabulación ── */
    function focoA(f) {
      foco = f;
      fotos.forEach(x => { x.el.tabIndex = x === f ? 0 : -1; });
      f.el.focus({ preventScroll: false });
    }
    function vecino(f, dir) {
      const cx = f.x + f.w / 2, cy = f.y + f.h / 2;
      let mejor = null, nota = Infinity;
      fotos.forEach(g => {
        if (g === f || g.cargando) return;
        const dx = g.x + g.w / 2 - cx, dy = g.y + g.h / 2 - cy;
        let s;
        if (dir === 'ArrowRight' && dx > 10) s = dx + Math.abs(dy) * 2.5;
        else if (dir === 'ArrowLeft' && dx < -10) s = -dx + Math.abs(dy) * 2.5;
        else if (dir === 'ArrowDown' && dy > 10) s = dy + Math.abs(dx) * 2.5;
        else if (dir === 'ArrowUp' && dy < -10) s = -dy + Math.abs(dx) * 2.5;
        else return;
        if (s < nota) { nota = s; mejor = g; }
      });
      return mejor;
    }
    grid.addEventListener('keydown', e => {
      const f = e.target._f;
      if (!f) return;
      const k = e.key, mod = e.metaKey || e.ctrlKey;
      if (k.startsWith('Arrow')) {
        e.preventDefault();
        const v = vecino(f, k);
        if (!v) return;
        focoA(v);
        if (e.shiftKey) { const n = new Set(sel); n.add(f); n.add(v); pon(n); anuncia(); }
      } else if (k === ' ' || k === 'Spacebar') {
        e.preventDefault();
        const n = new Set(sel);
        if (n.has(f)) n.delete(f); else n.add(f);
        pon(n); anuncia();
      } else if (k === 'Enter') {
        e.preventDefault();
        detFoto = f; pon(new Set([f])); abreDetalle(f, true);
      } else if ((k === 'a' || k === 'A') && mod) {
        e.preventDefault();
        pon(new Set(fotos.filter(g => !g.cargando))); anuncia();
      } else if (k === 'Home' || k === 'End') {
        e.preventDefault();
        const vis = fotos.filter(g => !g.cargando);
        if (vis.length) focoA(k === 'Home' ? vis[0] : vis[vis.length - 1]);
      }
    });
    grid.addEventListener('focusin', e => { if (e.target._f && e.target._f !== foco) { foco = e.target._f; fotos.forEach(x => { x.el.tabIndex = x === foco ? 0 : -1; }); } });
    raiz.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      if (arr) { e.preventDefault(); acabaArrastre(true); return; }
      if (detalleAbierto) { e.preventDefault(); const f = detFoto; cierraDetalle(true); if (f) limpia(); }
      else if (sel.size) { e.preventDefault(); limpia(); }
    });

    /* ── el bucle de animación: recuadro, fotos viajeras y cargas ───── */
    let raf = 0, ultimo = 0;
    const fantasmas = [];
    const cargas = [];
    let rec = null;                                    // el recuadro en curso
    function despierta() { if (!raf) { ultimo = performance.now(); raf = requestAnimationFrame(bucle); } }
    function bucle(t) {
      const dt = Math.min(.05, Math.max(0, (t - ultimo) / 1000));
      ultimo = t;
      if (rec) { avanza(rec.cx, dt); avanza(rec.cy, dt); pintaRecuadro(); }
      for (let i = fantasmas.length - 1; i >= 0; i--) pasoFantasma(fantasmas[i], dt, i);
      for (let i = cargas.length - 1; i >= 0; i--) pasoCarga(cargas[i], dt, i);
      raf = (rec || fantasmas.length || cargas.length) ? requestAnimationFrame(bucle) : 0;
    }

    /* ── el recuadro elástico ───────────────────────────────────────── */
    function iniciaRecuadro() {
      p.modo = 'recuadro';
      const r = lienzo.getBoundingClientRect();
      const ox = p.x0 - r.left, oy = p.y0 - r.top;
      rec = { ox, oy, cx: resorte(ox, MUELLES.recuadro, .05), cy: resorte(oy, MUELLES.recuadro, .05), base: p.mayus ? new Set(sel) : new Set(), mayus: p.mayus, clave: '' };
      if (!p.mayus && sel.size) pon(new Set());
      recuadro.classList.add('is-activo');
      raiz.classList.add('is-recuadro');
      captura();
      despierta();
    }
    function mueveRecuadro() {
      const r = lienzo.getBoundingClientRect();
      rec.cx.meta = p.x - r.left; rec.cy.meta = p.y - r.top;
      if (quieto()) { rec.cx.x = rec.cx.meta; rec.cy.x = rec.cy.meta; pintaRecuadro(); }
    }
    function pintaRecuadro() {
      const x = Math.min(rec.ox, rec.cx.x), y = Math.min(rec.oy, rec.cy.x);
      const w = Math.abs(rec.cx.x - rec.ox), h = Math.abs(rec.cy.x - rec.oy);
      recuadro.style.left = x.toFixed(1) + 'px'; recuadro.style.top = y.toFixed(1) + 'px';
      recuadro.style.width = w.toFixed(1) + 'px'; recuadro.style.height = h.toFixed(1) + 'px';
      // lo que toca el recuadro tal como se ve (con su rebote), no donde está el puntero
      const dentro = [];
      fotos.forEach(f => { if (!f.cargando && f.x < x + w && f.x + f.w > x && f.y < y + h && f.y + f.h > y) dentro.push(f); });
      const clave = dentro.map(f => fotos.indexOf(f)).join(',');
      if (clave === rec.clave) return;
      rec.clave = clave;
      let n;
      if (rec.mayus) { n = new Set(rec.base); dentro.forEach(f => { if (n.has(f)) n.delete(f); else n.add(f); }); } else n = new Set(dentro);
      pon(n);
    }
    function acabaRecuadro() {
      rec = null;
      raiz.classList.remove('is-recuadro');
      const cierra = () => recuadro.classList.remove('is-activo');
      if (quieto()) cierra();
      else { const a = recuadro.animate([{ opacity: 1, transform: 'scale(1)' }, { opacity: 0, transform: 'scale(.97)' }], { duration: 220, easing: 'ease-out' }); a.onfinish = cierra; }
      anuncia();
    }

    /* ── arrastrar el grupo a una carpeta ───────────────────────────── */
    let arr = null;
    function centroDe(el, vr) { const r = el.getBoundingClientRect(); return [r.left + r.width / 2 - vr.left, r.top + r.height / 2 - vr.top, r.width]; }
    function creaFantasmas(lista, agarrada, vr) {
      const base = agarrada || lista[0];
      const bx = base.x + base.w / 2, by = base.y + base.h / 2;
      const orden = lista.slice().sort((a, b) => (a === base ? -1 : b === base ? 1 : Math.hypot(a.x - bx, a.y - by) - Math.hypot(b.x - bx, b.y - by)));
      const visibles = orden.slice(0, MAX_FANTASMAS);
      const fan = visibles.map((f, i) => {
        const w = FANTASMA_W, h = Math.round(lim(w / f.ar, 66, 150));
        const [cx, cy, rw] = centroDe(f.marco, vr);
        const el = document.createElement('div');
        el.className = 'fo-fantasma';
        el.style.cssText = 'width:' + w + 'px;height:' + h + 'px;margin:' + (-h / 2) + 'px 0 0 ' + (-w / 2) + 'px;--c:' + (f.el.style.getPropertyValue('--c') || '#ddd');
        const im = document.createElement('img');
        im.src = f.img.currentSrc || f.img.src; im.alt = ''; im.draggable = false;
        el.appendChild(im);
        if (i === 0) { const b = document.createElement('span'); b.className = 'fo-fantasma-n'; b.textContent = lista.length; el.appendChild(b); }
        const k = Math.max(120, MUELLES.grupo.k - i * 22), c = 2 * .78 * Math.sqrt(k);
        const g = { f, el, w, h, idx: i, n: visibles.length, modo: 'sigue', x: resorte(cx, { k, c }, .05), y: resorte(cy, { k, c }, .05), s: resorte(rw / w, { k, c }, .002), r: resorte(0, { k, c }, .02), o: 1, origen: [cx, cy, rw / w] };
        return g;
      });
      for (let i = fan.length - 1; i >= 0; i--) capa.appendChild(fan[i].el);   // el primero queda encima
      fan.forEach(g => { g.f.el.classList.add('is-llevada'); fantasmas.push(g); pintaFantasma(g); });
      despierta();
      return fan;
    }
    function pintaFantasma(g) {
      g.el.style.transform = 'translate3d(' + g.x.x.toFixed(1) + 'px,' + g.y.x.toFixed(1) + 'px,0) rotate(' + g.r.x.toFixed(2) + 'deg) scale(' + g.s.x.toFixed(4) + ')';
      g.el.style.opacity = g.o.toFixed(3);
    }
    function pasoFantasma(g, dt, i) {
      if (g.modo === 'sigue' && arr) {
        // la pila: cada foto, un poco más atrás y más girada, sigue al puntero con su propio resorte
        const m = g.idx, lado = m % 2 ? 1 : -1;
        // sobre una carpeta la pila se encoge y sube a un lado del puntero, para dejar leer la carpeta
        g.x.meta = arr.px + (m ? lado * m * 3.6 : 0) + (arr.sobre ? 50 : 0);
        g.y.meta = arr.py + m * 2.8 - (arr.sobre ? 44 : 0);
        g.r.meta = m ? lado * (2.6 + m * 2.2) : 0;
        g.s.meta = (arr.sobre ? .52 : 1) * (1 - m * .018);
      } else if (g.modo === 'vuelo') {
        g.t += dt;
        const u = lim((g.t - g.retraso) / g.dur, 0, 1);
        const e = u * u * (3 - 2 * u), a = 1 - e;
        g.x.x = a * a * g.p0[0] + 2 * a * e * g.c1[0] + e * e * g.p1[0];
        g.y.x = a * a * g.p0[1] + 2 * a * e * g.c1[1] + e * e * g.p1[1];
        g.s.x = lerp(g.s0, .2, e);
        g.r.x = g.r0 + g.giro * e;
        g.o = u > .8 ? 1 - (u - .8) / .2 : 1;
        pintaFantasma(g);
        if (u >= 1) { llega(g); fantasmas.splice(i, 1); }
        return;
      } else if (g.modo === 'vuelta') {
        g.x.meta = g.origen[0]; g.y.meta = g.origen[1]; g.s.meta = g.origen[2]; g.r.meta = 0;
      }
      avanza(g.x, dt); avanza(g.y, dt); avanza(g.s, dt); avanza(g.r, dt);
      pintaFantasma(g);
      if (g.modo === 'vuelta' && enReposo(g.x) && enReposo(g.y) && enReposo(g.s)) {
        g.el.remove(); g.f.el.classList.remove('is-llevada'); fantasmas.splice(i, 1);
      }
    }
    const carpetaBajo = (x, y) => { const el = document.elementFromPoint(x, y), b = el && el.closest && el.closest('.fo-carpeta'); return b ? carpetas.get(b.dataset.carpeta) : null; };
    function iniciaArrastre() {
      const f = p.f;
      if (!sel.has(f)) { const n = p.mayus ? new Set(sel) : new Set(); n.add(f); pon(n); }
      p.modo = 'arrastre';
      raiz.classList.add('is-arrastra'); ventana.classList.add('is-llevando');
      const vr = ventana.getBoundingClientRect();
      arr = { vr, px: p.x - vr.left, py: p.y - vr.top, sobre: null, fan: [] };
      arr.fan = creaFantasmas(ordenSel(), f, vr);
      captura();
    }
    function mueveArrastre() {
      arr.px = p.x - arr.vr.left; arr.py = p.y - arr.vr.top;
      const c = carpetaBajo(p.x, p.y);
      if (c !== arr.sobre) {
        if (arr.sobre) { arr.sobre.el.classList.remove('is-sobre', 'is-abierta'); }
        arr.sobre = c;
        if (c) {
          const nuevas = ordenSel().filter(f => !f.carpetas.includes(c.id)).length;
          c.mas.textContent = nuevas ? '+' + nuevas : '✓';
          c.el.classList.add('is-sobre', 'is-abierta');
        }
      }
      if (quieto()) fantasmas.forEach(g => { if (g.modo === 'sigue') { g.x.x = arr.px; g.y.x = arr.py; pintaFantasma(g); } });
    }
    function acabaArrastre(cancela) {
      const a = arr; arr = null;
      raiz.classList.remove('is-arrastra'); ventana.classList.remove('is-llevando');
      if (a.sobre) a.sobre.el.classList.remove('is-sobre');
      if (!cancela && a.sobre) entrega(a.sobre, a.fan);
      else { if (a.sobre) a.sobre.el.classList.remove('is-abierta'); a.fan.forEach(g => { g.modo = 'vuelta'; if (quieto()) { g.el.remove(); g.f.el.classList.remove('is-llevada'); fantasmas.splice(fantasmas.indexOf(g), 1); } }); anuncia(); }
    }

    /* ── entregar las fotos a una carpeta: salen en abanico y la carpeta se abre ── */
    let ultima = null;                  // lo último que se movió, para «Deshacer»
    function ponInsignia(f) {
      const id = f.carpetas[f.carpetas.length - 1];
      if (id) { f.enTx.textContent = carpetas.get(id).nombre; f.el.classList.add('is-en'); } else f.el.classList.remove('is-en');
    }
    function entrega(c, fan) {
      const lista = ordenSel();
      if (!fan) { const vr = ventana.getBoundingClientRect(); fan = creaFantasmas(lista, null, vr); }
      const nuevas = lista.filter(f => !f.carpetas.includes(c.id));
      if (!nuevas.length) {
        fan.forEach(g => { g.modo = 'vuelta'; });
        c.el.classList.remove('is-abierta');
        mensaje('Esas fotos ya estaban en ' + c.nombre, false);
        return;
      }
      const vr = ventana.getBoundingClientRect();
      const [fx, fy] = centroDe(c.ico, vr);
      const vuelan = fan.filter(g => nuevas.includes(g.f));
      fan.forEach(g => { if (!vuelan.includes(g)) g.modo = 'vuelta'; });
      const m = vuelan.length, extra = nuevas.length - m;
      const reg = { c, fotos: nuevas, pendientes: m, extra };
      ultima = reg;
      nuevas.forEach(f => f.carpetas.push(c.id));
      vuelan.forEach((g, k) => {
        const p0 = [g.x.x, g.y.x], p1 = [fx, fy];
        const dx = p1[0] - p0[0], dy = p1[1] - p0[1], largo = Math.hypot(dx, dy) || 1;
        const nx = -dy / largo, ny = dx / largo;               // la normal: cada foto abre su propio arco
        const abre = (k - (m - 1) / 2) * 64 + (m === 1 ? 30 : 0);
        g.modo = 'vuelo'; g.t = 0; g.retraso = k * .06; g.dur = .56 + Math.min(.3, largo / 900);
        g.p0 = p0; g.p1 = p1;
        g.c1 = [(p0[0] + p1[0]) / 2 + nx * abre - 28, (p0[1] + p1[1]) / 2 + ny * abre - 46];
        g.s0 = g.s.x; g.r0 = g.r.x; g.giro = (k - (m - 1) / 2) * 22 - 6;
        g.inc = Math.floor(nuevas.length / m) + (k < nuevas.length % m ? 1 : 0);
        g.reg = reg;
      });
      pon(new Set()); anuncia();
      c.el.classList.add('is-abierta');
      if (quieto()) vuelan.slice().forEach(g => { llega(g); fantasmas.splice(fantasmas.indexOf(g), 1); });
      despierta();
      if (opc.alMover) opc.alMover({ carpeta: c.id, fotos: nuevas });
    }
    function llega(g) {
      const reg = g.reg, c = reg.c;
      g.el.remove();
      g.f.el.classList.remove('is-llevada');
      ponInsignia(g.f);
      c.n += g.inc; c.rueda.pon(c.n);
      c.el.classList.remove('is-recibe'); void c.el.offsetWidth; c.el.classList.add('is-recibe');
      if (!quieto()) c.ico.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.2)' }, { transform: 'scale(1)' }], { duration: 420, easing: mPieza.curva });
      if (--reg.pendientes > 0) return;
      reg.fotos.forEach(ponInsignia);
      clearTimeout(c.cierraT);
      c.cierraT = setTimeout(() => { if (!arr || arr.sobre !== c) c.el.classList.remove('is-abierta'); }, quieto() ? 10 : 700);
      const n = reg.fotos.length;
      mensaje(n + (n === 1 ? ' foto añadida a ' : ' fotos añadidas a ') + c.nombre, true);
      if (detalleAbierto && detFoto) det.carp.textContent = textoCarpetas(detFoto);
    }
    function deshace() {
      const u = ultima;
      if (!u) return;
      ultima = null;
      ocultaAviso();
      u.fotos.forEach(f => { const i = f.carpetas.lastIndexOf(u.c.id); if (i > -1) f.carpetas.splice(i, 1); ponInsignia(f); });
      u.c.n -= u.fotos.length; u.c.rueda.pon(u.c.n);
      u.c.el.classList.remove('is-recibe'); void u.c.el.offsetWidth; u.c.el.classList.add('is-recibe');
      if (detalleAbierto && detFoto) det.carp.textContent = textoCarpetas(detFoto);
      vivo.textContent = 'Deshecho: las fotos salieron de ' + u.c.nombre;
    }
    // el aviso: un texto y, si se puede deshacer, el botón
    let avisoT = 0;
    function mensaje(texto, conDeshacer) {
      avisoTx.textContent = texto;
      aviso.classList.toggle('sin-deshacer', !conDeshacer);
      aviso.querySelector('[data-deshacer]').hidden = !conDeshacer;
      aviso.classList.remove('is-visible'); void aviso.offsetWidth;
      aviso.classList.add('is-visible');
      clearTimeout(avisoT);
      avisoT = setTimeout(ocultaAviso, AVISO_MS);
    }
    function ocultaAviso() { clearTimeout(avisoT); aviso.classList.remove('is-visible'); }
    aviso.querySelector('[data-deshacer]').addEventListener('click', deshace);
    carpetas.forEach(c => c.el.addEventListener('click', () => {
      if (sel.size) entrega(c, null);
      else vivo.textContent = 'Elige fotos y pulsa una carpeta para añadirlas a ' + c.nombre;
    }));

    /* ── subir fotos: la miniatura con su anillo de carga ───────────── */
    const reserva = plantilla ? Array.from(plantilla.content.querySelectorAll('.fo-foto')) : [];
    let nReserva = 0;
    function agrega(el) {
      const f = creaFoto(el);
      f.cargando = true;
      el.classList.add('is-cargando');
      el.setAttribute('aria-busy', 'true');
      el.style.setProperty('--i', 0);
      f.marco.insertAdjacentHTML('beforeend', CARGA);
      f.arco = f.marco.querySelector('.fo-carga-arco'); f.cifra = f.marco.querySelector('.fo-carga b');
      lienzo.insertBefore(el, lienzo.children[1] || null);        // detrás del recuadro, que es el primero
      fotos.unshift(f);
      pintaTotal();
      dispone(true);
      cargas.push({ f, u: 0, dur: 1.6 });
      despierta();
      if (quieto()) { cargas.pop(); terminaCarga(f); }
    }
    function pasoCarga(c, dt, i) {
      c.u = Math.min(1, c.u + dt / c.dur);
      const v = 1 - Math.pow(1 - c.u, 2.2);
      c.f.arco.style.strokeDashoffset = (100 - v * 100).toFixed(2);
      c.f.cifra.textContent = Math.round(v * 100);
      if (c.u >= 1) { cargas.splice(i, 1); terminaCarga(c.f); }
    }
    function terminaCarga(f) {
      f.el.classList.add('is-lista');
      f.cargando = false;
      f.el.removeAttribute('aria-busy');
      vivo.textContent = 'Foto subida: ' + f.nombre;
      setTimeout(() => { const cg = f.marco.querySelector('.fo-carga'); if (cg) cg.remove(); f.el.classList.remove('is-cargando', 'is-lista'); }, quieto() ? 10 : 800);
      if (opc.alSubir) opc.alSubir({ nombre: f.nombre });
    }
    function sube() {
      if (!reserva.length) return;
      const el = reserva[nReserva++ % reserva.length].cloneNode(true);
      agrega(el);
    }
    async function subeArchivo(archivo) {
      const url = URL.createObjectURL(archivo);
      const im = new Image();
      im.src = url;
      try { await im.decode(); } catch (_) { URL.revokeObjectURL(url); sube(); return; }
      const el = document.createElement('div');
      el.className = 'fo-foto'; el.setAttribute('role', 'option'); el.setAttribute('aria-selected', 'false');
      el.dataset.ar = (im.naturalWidth / im.naturalHeight).toFixed(3);
      el.dataset.nombre = archivo.name.slice(0, 30);
      el.dataset.dim = im.naturalWidth + ' × ' + im.naturalHeight + ' px';
      el.dataset.peso = (archivo.size / 1e6).toFixed(1).replace('.', ',') + ' MB';
      el.dataset.fecha = 'Hoy'; el.dataset.etiquetas = 'nueva';
      el.style.setProperty('--c', '#d9d9d4');
      el.innerHTML = '<div class="fo-marco"><img alt="" draggable="false"></div>';
      const img = el.querySelector('img');
      img.src = url; img.alt = archivo.name;
      agrega(el);
    }
    raiz.querySelector('[data-subir]').addEventListener('click', sube);
    let nArrastre = 0;
    const conArchivos = e => e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files');
    principal.addEventListener('dragenter', e => { if (!conArchivos(e)) return; e.preventDefault(); nArrastre++; raiz.classList.add('is-sobre-archivo'); });
    principal.addEventListener('dragover', e => { if (conArchivos(e)) e.preventDefault(); });
    principal.addEventListener('dragleave', e => { if (!conArchivos(e)) return; if (--nArrastre <= 0) { nArrastre = 0; raiz.classList.remove('is-sobre-archivo'); } });
    principal.addEventListener('drop', e => {
      if (!conArchivos(e)) return;
      e.preventDefault(); nArrastre = 0; raiz.classList.remove('is-sobre-archivo');
      const imgs = Array.from(e.dataTransfer.files).filter(a => /^image\//.test(a.type)).slice(0, 3);
      if (!imgs.length) { sube(); return; }
      imgs.forEach(subeArchivo);
    });

    /* ── el puntero: recuadro, arrastre de grupo y clic ─────────────── */
    let p = null;                       // el gesto en curso
    const captura = () => { try { grid.setPointerCapture(p.id); } catch (_) {} };
    grid.addEventListener('pointerdown', e => {
      if (e.button > 0 || p) return;
      const f = e.target.closest && e.target.closest('.fo-foto');
      const foto = f ? f._f : null;
      if (foto && foto.cargando) return;
      p = { id: e.pointerId, tipo: e.pointerType, x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, f: foto, mayus: e.shiftKey || e.metaKey || e.ctrlKey, modo: null, espera: 0 };
      // con el dedo, el gesto empieza al mantener pulsado: antes, un arrastre es un desplazamiento
      if (p.tipo === 'touch') p.espera = setTimeout(() => { if (p) { p.espera = 0; if (!p.modo) empieza(); } }, PULSO_LARGO);
    });
    function empieza() { if (p.f) iniciaArrastre(); else iniciaRecuadro(); }
    grid.addEventListener('pointermove', e => {
      if (!p || e.pointerId !== p.id) return;
      p.x = e.clientX; p.y = e.clientY;
      if (!p.modo) {
        const d = Math.hypot(p.x - p.x0, p.y - p.y0);
        if (p.tipo === 'touch') { if (d > 9) { clearTimeout(p.espera); p = null; } return; }
        if (d < 5) return;
        empieza();
      }
      if (p.modo === 'recuadro') mueveRecuadro(); else mueveArrastre();
    });
    function suelta(e) {
      if (!p || e.pointerId !== p.id) return;
      const g = p;
      clearTimeout(g.espera);
      try { grid.releasePointerCapture(g.id); } catch (_) {}
      if (g.modo === 'recuadro') { p = null; acabaRecuadro(); }
      else if (g.modo === 'arrastre') { p = null; acabaArrastre(e.type === 'pointercancel'); }
      else { p = null; if (e.type === 'pointerup') clic(g); }
    }
    grid.addEventListener('pointerup', suelta);
    grid.addEventListener('pointercancel', suelta);
    // con el dedo, una vez empezado el gesto el navegador no debe desplazar la rejilla
    grid.addEventListener('touchmove', e => { if (p && p.modo) e.preventDefault(); }, { passive: false });
    grid.addEventListener('contextmenu', e => { if (p && p.tipo === 'touch') e.preventDefault(); });

    function clic(g) {
      const f = g.f;
      if (!f) { if (!g.mayus) limpia(); return; }
      focoA(f);
      const toca = g.tipo === 'touch' && sel.size > 0 && !(sel.size === 1 && sel.has(f));
      if (g.mayus || toca) {
        const n = new Set(sel);
        if (n.has(f)) n.delete(f); else n.add(f);
        pon(n); anuncia();
      } else {
        detFoto = f; pon(new Set([f])); abreDetalle(f, false);
      }
    }
    raiz.querySelector('[data-limpia]').addEventListener('click', () => { limpia(); });

    /* ── medidas ────────────────────────────────────────────────────── */
    let anchoPrevio = 0;
    const mide = () => { const w = grid.clientWidth; if (w === anchoPrevio) return; anchoPrevio = w; dispone(false); };
    if (window.ResizeObserver) new ResizeObserver(mide).observe(grid); else window.addEventListener('resize', mide);
    movil.addEventListener && movil.addEventListener('change', () => dispone(false));
    mq.addEventListener && mq.addEventListener('change', () => { fantasmas.slice().forEach(g => { g.el.remove(); g.f.el.classList.remove('is-llevada'); }); fantasmas.length = 0; });
    anchoPrevio = grid.clientWidth;
    dispone(false);
    pintaTotal();
    // las fuentes cambian el alto de la barra y del panel: se vuelve a medir cuando llegan
    (document.fonts && document.fonts.ready || Promise.resolve()).then(() => { anchoPrevio = 0; mide(); });

    return { elegidas: () => ordenSel(), limpia, sube, abre: f => { detFoto = f; pon(new Set([f])); abreDetalle(f, false); }, fotos: () => fotos.slice() };
  }

  window.Fototeca = Fototeca;
  document.querySelectorAll('[data-fototeca]').forEach(r => { r.fototeca = Fototeca(r); });
})();
