/* =====================================================================
   Trámite · Moxen
   El seguimiento de un pago en vivo, como el que ve un cliente al pagar un
   pedido: procesando → autorizado → abonado, con reintento si el emisor lo
   rechaza y un comprobante al final que se imprime o se guarda en PDF.

   · Una máquina de estados de verdad (TRANSICIONES, arriba del JS): cada
     cambio pasa por ir(), que solo acepta las transiciones válidas. Desde
     «fallido» solo se puede reintentar (vuelve a procesando) o cancelar;
     desde «abonado» y «cancelado» no hay salida, solo un pago nuevo. Un
     clic en un botón apagado no hace nada: el botón se sacude y el aviso
     de abajo dice por qué.
   · Cada paso tarda lo suyo (tProcesa y tAutoriza): la línea de cada tramo
     se llena a lo largo de ese tiempo, y al terminar el paso queda
     anotada su duración medida («1,2 s»). El registro de la izquierda
     cuenta el pago con sus tiempos relativos.
   · Si falla, la etapa se vuelve amarilla con «!», el título cambia y solo
     quedan activos Reintentar y Cancelar. Al reintentar, el pago vuelve a
     procesando con un intento más y, si sale bien, llega a abonado.
   · Al abonarse, el comprobante sale por una ranura: número, fecha, estado
     (con ✓), intentos y el tiempo de cada paso. «Imprimir o guardar PDF»
     llama a window.print() y los estilos de impresión dejan solo el
     comprobante en blanco y negro, listo para el papel o para el PDF.
   · Teclado: Tab recorre los botones (los apagados siguen enfocables y
     explican por qué no se puede). Movimiento reducido: sin giros ni
     líneas que se llenan, todo cambia de golpe.

   No hay importes de dinero en la demo: se trabaja con números de pedido y
   de comprobante, fechas, tiempos y estados.

   Montaje (se inicia solo sobre [data-tramite]; el HTML de index.html es la
   plantilla):
     const t = Tramite(document.querySelector('[data-tramite]'), {
       pedido: 3188, numero: '000428', fecha: '2026-10-26T16:42',
       tProcesa: 1200, tAutoriza: 1000,   // ms que dura cada paso
       fallaPrimero: true,                // el primer intento lo rechaza el emisor
       inicio: 'fallido',                 // 'fallido' o 'procesando' al empezar
       alCambio: ({ de, a, intento }) => {},
     });
     t.estado();  t.puede('abonado');  t.ir('procesando');  t.reintenta();  t.cancela();  t.nuevo();  t.registro();

   Qué cambia qué: TRANSICIONES, TEXTOS y ETIQUETAS (arriba del JS) dicen qué
   estados existen y cómo se llaman; los colores están en las variables
   --tr-* del CSS (--tr-azul es el progreso y el éxito, --tr-amarillo el
   fallo). Sin dependencias; el tiempo sale de timers, de transiciones y de
   performance.now (nada de Date).
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;

  // un resorte convertido en curva CSS linear(): sirve para las transiciones y para Web Animations
  function muelle(k, c) {
    const pts = [0];
    let x = 0, v = 0, t = 0;
    while (t < 3) {
      v += (k * (1 - x) - c * v) / 240; x += v / 240; t += 1 / 240;
      pts.push(x);
      if (t > .15 && Math.abs(1 - x) < .001 && Math.abs(v) < .01) break;
    }
    const out = [];
    for (let i = 0; i <= 40; i++) out.push(pts[Math.round(i / 40 * (pts.length - 1))].toFixed(4));
    out[40] = '1';
    return 'linear(' + out.join(', ') + ')';
  }
  const h = (tag, clase, texto) => { const e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; };
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';

  /* La máquina de estados: de cada estado, a cuáles se puede pasar. Todo lo demás se rechaza. */
  const TRANSICIONES = {
    procesando: ['autorizado', 'fallido', 'cancelado'],
    autorizado: ['abonado', 'fallido'],
    fallido: ['procesando', 'cancelado'],      // reintentar o cancelar
    abonado: [],
    cancelado: [],
  };
  const ETIQUETAS = { procesando: 'Procesando', autorizado: 'Autorizado', abonado: 'Abonado', fallido: 'Fallido', cancelado: 'Cancelado' };
  const VERBO = { procesando: 'reintentar', autorizado: 'autorizar', abonado: 'abonar', fallido: 'rechazar', cancelado: 'cancelar' };
  const TEXTOS = {
    procesando: { titulo: 'Procesando tu pago', texto: n => 'Estamos validando los datos con el emisor. Intento ' + n + '.' },
    autorizado: { titulo: 'Pago autorizado', texto: () => 'El emisor aprobó el cobro; falta abonarlo al comercio.' },
    abonado:    { titulo: 'Pago abonado', texto: () => 'Listo: el comercio ya lo recibió y tu comprobante está disponible.' },
    fallido:    { titulo: 'No pudimos completar el pago', texto: n => 'El emisor rechazó el intento ' + n + '. Puedes reintentar o cancelar; no se cobró nada.' },
    cancelado:  { titulo: 'Pago cancelado', texto: () => 'No se hizo ningún cobro. Puedes empezar un pago nuevo.' },
  };
  const PASOS = ['procesando', 'autorizado', 'abonado'];
  const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

  const ICO = {
    procesando: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.8" y="6" width="16.4" height="12" rx="2.6"/><path d="M3.8 10.2h16.4M7.5 14.5h3"/></svg>',
    autorizado: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.6 18.6 6v5.6c0 3.9-2.7 7-6.6 8.8-3.9-1.8-6.6-4.9-6.6-8.8V6z"/><path d="m9.2 11.8 2 2 3.6-3.9"/></svg>',
    abonado: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v9M8.3 9.8 12 13.5l3.7-3.7"/><path d="M4.5 14.5v3a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-3"/></svg>',
    visto: '<svg class="tr-i-visto" viewBox="0 0 24 24" aria-hidden="true"><path d="M6.4 12.6l3.9 3.9 7.3-8.4" pathLength="1"/></svg>',
    alerta: '<svg class="tr-i-alerta" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 6.5v7M12 17.2v.3"/></svg>',
    cruz: '<svg class="tr-i-cruz" viewBox="0 0 24 24" aria-hidden="true"><path d="m8 8 8 8M16 8l-8 8"/></svg>',
  };

  function Tramite(raiz, opciones) {
    const o = Object.assign({ pedido: 3188, numero: '000428', fecha: '2026-10-26T16:42', tProcesa: 1200, tAutoriza: 1000, fallaPrimero: true, inicio: 'fallido', alCambio: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const DUR = [o.tProcesa, o.tAutoriza];
    raiz.style.setProperty('--tr-muelle', muelle(190, 15));
    const MUELLE = muelle(190, 15);
    const timers = new Set();
    const tarde = (f, ms) => { const id = setTimeout(() => { timers.delete(id); f(); }, ms); timers.add(id); return id; };
    const limpia = () => { timers.forEach(clearTimeout); timers.clear(); };
    const vivo = $('[data-vivo]');
    const anuncia = t => { vivo.textContent = ''; setTimeout(() => { vivo.textContent = t; }, 40); };
    const seg = ms => (ms / 1000).toFixed(1).replace('.', ',');
    const ahora = () => performance.now();

    /* ── el estado ────────────────────────────────────────────────────── */
    const E = { estado: null, intento: 1, fallaEn: -1, t0: 0, tiempos: [null, null], log: [], simulaFalla: !!o.fallaPrimero };
    const puede = dest => E.estado != null && TRANSICIONES[E.estado].indexOf(dest) > -1;
    const esFinal = () => E.estado != null && TRANSICIONES[E.estado].length === 0;
    const lista = a => a.length < 2 ? (a[0] || '') : a.slice(0, -1).join(', ') + ' o ' + a[a.length - 1];

    /* ── las etapas ───────────────────────────────────────────────────── */
    const ol = $('[data-pasos]');
    const nodos = PASOS.map((p, i) => {
      const li = h('li', 'tr-paso');
      li.dataset.e = 'pendiente';
      li.innerHTML = '<span class="tr-nodo"><svg class="tr-aro" viewBox="0 0 60 60" aria-hidden="true"><circle cx="30" cy="30" r="27"/></svg>'
        + '<span class="tr-ico tr-ico-paso">' + ICO[p] + '</span><span class="tr-ico tr-ico-visto">' + ICO.visto + '</span><span class="tr-ico tr-ico-alerta">' + ICO.alerta + '</span><span class="tr-ico tr-ico-cruz">' + ICO.cruz + '</span></span>'
        + '<b class="tr-p-n">' + ETIQUETAS[p] + '</b><span class="tr-p-t"></span>'
        + (i < PASOS.length - 1 ? '<i class="tr-tramo" data-s="vacio"><i></i></i>' : '');
      ol.appendChild(li);
      return li;
    });
    const tramos = nodos.map(li => li.querySelector('.tr-tramo'));
    const TEXTO_PASO = { pendiente: 'en espera', activo: 'en curso', fallo: 'rechazado', cancelado: 'detenido' };
    function pintaPasos() {
      const idx = PASOS.indexOf(E.estado);     // -1 si fallido/cancelado
      nodos.forEach((li, i) => {
        let e = 'pendiente', t = TEXTO_PASO.pendiente;
        if (E.estado === 'procesando' || E.estado === 'autorizado') e = i < idx ? 'hecho' : i === idx ? 'activo' : 'pendiente';
        else if (E.estado === 'abonado') e = 'hecho';
        else if (E.estado === 'fallido' || E.estado === 'cancelado') {
          const cae = Math.max(0, E.fallaEn);
          e = i < cae ? 'hecho' : i === cae ? (E.estado === 'fallido' ? 'fallo' : 'cancelado') : 'pendiente';
        }
        // la última etapa no tiene duración propia: cuenta lo que tardó todo el pago
        if (e === 'hecho') t = i === PASOS.length - 1 ? 'total ' + seg((E.tiempos[0] || 0) + (E.tiempos[1] || 0)) + ' s' : (E.tiempos[i] != null ? seg(E.tiempos[i]) + ' s' : '—');
        else t = TEXTO_PASO[e] || '';
        li.dataset.e = e;
        li.querySelector('.tr-p-t').textContent = t;
      });
    }
    // cada tramo se llena durante el paso que lo recorre; al pasar de pago se vacía de golpe para volver a empezar
    function pintaTramos(reinicio) {
      if (reinicio) { ol.classList.add('sin-t'); tramos.forEach(t => t && (t.dataset.s = 'vacio')); void ol.offsetWidth; ol.classList.remove('sin-t'); }
      const idx = PASOS.indexOf(E.estado);
      tramos.forEach((t, i) => {
        if (!t) return;
        let s = 'vacio';
        if (E.estado === 'procesando' || E.estado === 'autorizado') s = i < idx ? 'lleno' : i === idx ? 'corre' : 'vacio';
        else if (E.estado === 'abonado') s = 'lleno';
        else s = i < Math.max(0, E.fallaEn) ? 'lleno' : 'vacio';
        t.style.setProperty('--dur', (quieto() ? 0 : DUR[i]) + 'ms');
        if (t.dataset.s !== s) t.dataset.s = s;
      });
    }

    /* ── el registro ──────────────────────────────────────────────────── */
    const logEl = $('[data-log]');
    // «rel» es el tiempo (ms) desde que empezó el intento; si no se da, se mide
    function anota(texto, tipo, animar, rel) {
      if (rel == null) rel = ahora() - E.t0;
      const marca = '+' + seg(Math.max(0, rel)) + ' s';
      const li = h('li', 'tr-l tr-l-' + tipo);
      li.innerHTML = '<span class="tr-l-t">' + marca + '</span><i class="tr-l-p"></i><span class="tr-l-m"></span>';
      li.querySelector('.tr-l-m').textContent = texto;
      logEl.appendChild(li);
      E.log.push({ t: marca, texto, tipo });
      while (logEl.children.length > 4) logEl.removeChild(logEl.firstChild);
      if (animar && !quieto()) li.animate([{ transform: 'translateY(14px)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 520, easing: MUELLE });
    }

    /* ── lo que se ve según el estado ─────────────────────────────────── */
    const pastilla = $('[data-pastilla]'), pastillaT = $('[data-pastilla-t]');
    const titulo = $('[data-titulo]'), texto = $('[data-texto]');
    const acciones = {};
    raiz.querySelectorAll('[data-accion]').forEach(b => { acciones[b.dataset.accion] = b; });
    const motivo = $('[data-motivo]');
    const hint = () => E.estado == null ? '' : esFinal()
      ? '«' + ETIQUETAS[E.estado] + '» es un estado final: solo queda empezar un pago nuevo.'
      : 'Desde «' + ETIQUETAS[E.estado] + '» solo se puede ' + lista(TRANSICIONES[E.estado].map(d => VERBO[d])) + '.';
    let flash = 0;
    const muestraMotivo = (t, error) => {
      motivo.textContent = t; motivo.classList.toggle('es-error', !!error);
      clearTimeout(flash);
      if (error) flash = setTimeout(() => { motivo.textContent = hint(); motivo.classList.remove('es-error'); }, 2600);
    };
    function pintaAcciones() {
      const fin = esFinal();
      const hab = { reintentar: puede('procesando'), cancelar: puede('cancelado'), nuevo: fin, imprimir: E.estado === 'abonado' };
      Object.keys(acciones).forEach(k => {
        const b = acciones[k];
        b.setAttribute('aria-disabled', hab[k] ? 'false' : 'true');
        b.classList.toggle('es-off', !hab[k]);
      });
      acciones.reintentar.hidden = fin; acciones.cancelar.hidden = fin; acciones.nuevo.hidden = !fin;
      acciones.reintentar.classList.toggle('tr-btn-p', E.estado === 'fallido');
      if (!motivo.classList.contains('es-error')) motivo.textContent = hint();
    }
    function pintaEstado(cambio) {
      const e = E.estado, t = TEXTOS[e];
      raiz.dataset.estado = e;
      pastillaT.textContent = ETIQUETAS[e] + (e === 'abonado' ? ' ✓' : '');
      titulo.textContent = t.titulo;
      texto.textContent = t.texto(E.intento);
      $('[data-pedido]').textContent = o.pedido;
      $('[data-vacio-t]').textContent = e === 'cancelado' ? 'Sin comprobante: el pago se canceló' : e === 'fallido' ? 'Sin comprobante: el pago no se completó' : 'El comprobante sale cuando el pago se abona';
      pintaPasos(); pintaAcciones();
      if (cambio && !quieto()) {
        [titulo, texto].forEach((el, k) => el.animate([{ transform: 'translateY(12px)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 560, delay: k * 60, easing: CURVA, fill: 'backwards' }));
        pastilla.animate([{ transform: 'scale(.88)' }, { transform: 'none' }], { duration: 520, easing: MUELLE });
      }
    }

    /* ── el comprobante ───────────────────────────────────────────────── */
    const fechaTexto = () => { const [d, hh] = o.fecha.split('T'), [y, m, dd] = d.split('-').map(Number); return dd + ' ' + MESES[m - 1] + ' ' + y + ' · ' + hh; };
    function llenaComprobante() {
      $('[data-c-num]').textContent = 'N.º ' + o.numero;
      $('[data-c-pedido]').textContent = String(o.pedido);
      $('[data-c-fecha]').textContent = fechaTexto();
      $('[data-c-estado]').textContent = 'Abonado ✓';
      $('[data-c-intentos]').textContent = String(E.intento);
      $('[data-c-t0]').textContent = seg(E.tiempos[0] || 0) + ' s';
      $('[data-c-t1]').textContent = seg(E.tiempos[1] || 0) + ' s';
    }
    const salida = $('[data-salida]'), comp = $('[data-comprobante]');
    function muestraComprobante(on) {
      salida.dataset.sale = on ? '1' : '0';
      comp.setAttribute('aria-hidden', on ? 'false' : 'true');
      if (on) llenaComprobante();
    }

    /* ── cambiar de estado: solo por las transiciones válidas ─────────── */
    function entra(dest, nuevo) {
      const de = E.estado;
      limpia();
      E.estado = dest;
      if (dest === 'procesando') {
        if (nuevo) { E.intento = 1; E.tiempos = [null, null]; E.fallaEn = -1; logEl.textContent = ''; E.log = []; }
        else if (de === 'fallido') E.intento += 1;
        E.fallaEn = -1; E.tiempos = [null, null]; E.t0 = ahora();
        anota('Intento ' + E.intento + ' · pago enviado', 'info', true, 0);
        muestraComprobante(false);
        pintaEstado(true); pintaTramos(true);
        tarde(() => { E.tiempos[0] = ahora() - E.t0; ir((E.simulaFalla && E.intento === 1) ? 'fallido' : 'autorizado'); }, DUR[0]);
      } else if (dest === 'autorizado') {
        anota('Autorizado por el emisor', 'ok', true);
        pintaEstado(true); pintaTramos(false);
        const t1 = ahora();
        tarde(() => { E.tiempos[1] = ahora() - t1; ir('abonado'); }, DUR[1]);
      } else if (dest === 'abonado') {
        anota('Abonado en la cuenta del comercio', 'ok', true);
        pintaEstado(true); pintaTramos(false);
        tarde(() => muestraComprobante(true), quieto() ? 0 : 450);
        anuncia('Pago abonado. Comprobante número ' + o.numero + ' disponible');
      } else if (dest === 'fallido') {
        E.fallaEn = de === 'autorizado' ? 1 : 0;
        if (E.tiempos[E.fallaEn] == null) E.tiempos[E.fallaEn] = ahora() - E.t0;
        anota('Rechazado por el emisor', 'falla', true);
        pintaEstado(true); pintaTramos(false);
        anuncia('No se pudo completar el pago. Puedes reintentar o cancelar');
      } else if (dest === 'cancelado') {
        E.fallaEn = de === 'autorizado' ? 1 : (de === 'fallido' ? Math.max(0, E.fallaEn) : 0);
        anota('Cancelado por ti', 'info', true);
        pintaEstado(true); pintaTramos(false);
        anuncia('Pago cancelado');
      }
      if (o.alCambio) o.alCambio({ de, a: dest, intento: E.intento });
    }
    function sacude(el) {
      if (!el || quieto()) return;
      el.animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-7px)' }, { transform: 'translateX(6px)' }, { transform: 'translateX(-4px)' }, { transform: 'translateX(2px)' }, { transform: 'translateX(0)' }], { duration: 420, easing: CURVA });
    }
    // ir() es la única puerta: si la transición no existe, no pasa nada y se dice por qué
    function ir(dest, boton) {
      if (!puede(dest)) {
        const msg = esFinal() ? '«' + ETIQUETAS[E.estado] + '» es un estado final: no admite más cambios.'
          : 'No se puede ' + (VERBO[dest] || dest) + ' desde «' + ETIQUETAS[E.estado] + '»: solo se puede ' + lista(TRANSICIONES[E.estado].map(d => VERBO[d])) + '.';
        muestraMotivo(msg, true);
        sacude(boton);
        return false;
      }
      entra(dest, false);
      return true;
    }
    function nuevo() {
      if (!esFinal()) { muestraMotivo('Hay un pago en curso: espera a que termine o cancélalo.', true); return false; }
      entra('procesando', true);
      return true;
    }

    /* ── los botones ──────────────────────────────────────────────────── */
    acciones.reintentar.addEventListener('click', () => ir('procesando', acciones.reintentar));
    acciones.cancelar.addEventListener('click', () => ir('cancelado', acciones.cancelar));
    acciones.nuevo.addEventListener('click', nuevo);
    function imprime() {
      if (E.estado !== 'abonado') { muestraMotivo('El comprobante se imprime cuando el pago está abonado.', true); sacude(acciones.imprimir); return false; }
      const previo = document.title;
      document.title = 'Comprobante ' + o.numero;          // el título es el nombre sugerido del PDF
      try { window.print(); } finally { document.title = previo; }
      return true;
    }
    acciones.imprimir.addEventListener('click', imprime);
    const sim = $('[data-sim]');
    sim.addEventListener('click', () => { E.simulaFalla = !E.simulaFalla; sim.setAttribute('aria-checked', E.simulaFalla ? 'true' : 'false'); });
    sim.setAttribute('aria-checked', E.simulaFalla ? 'true' : 'false');

    /* ── el estado inicial ────────────────────────────────────────────── */
    if (o.inicio === 'procesando') { E.t0 = ahora(); entra('procesando', true); }
    else {
      // empieza ya fallido: el primer intento ya pasó (el registro lo cuenta)
      E.estado = 'fallido'; E.fallaEn = 0; E.tiempos = [o.tProcesa, null]; E.intento = 1;
      E.t0 = ahora() - o.tProcesa;
      anota('Intento 1 · pago enviado', 'info', false, 0);
      anota('Rechazado por el emisor', 'falla', false, o.tProcesa);
      muestraComprobante(false);
      pintaEstado(false); pintaTramos(true);
    }

    return {
      estado: () => E.estado, intento: () => E.intento, puede, ir: d => ir(d), reintenta: () => ir('procesando'), cancela: () => ir('cancelado'), nuevo, imprime,
      registro: () => E.log.map(l => l.t + ' ' + l.texto),
      tiempos: () => E.tiempos.slice(),
      comprobante: () => ({ numero: o.numero, fecha: fechaTexto(), estado: 'Abonado', intentos: E.intento }),
    };
  }

  window.Tramite = Tramite;
  document.querySelectorAll('[data-tramite]').forEach(el => { el.__tramite = Tramite(el); });
})();
