# Antefirma · Moxen

Escribes tu nombre o cargo, tu empresa y tus datos de contacto, y la firma se arma en vivo en tres plantillas y cuatro colores, con una línea nueva que se resalta al aparecer. «Copiar con formato» deja en el portapapeles el mismo HTML que ves, con los estilos en línea y los enlaces de correo, teléfono y sitio, y también hay texto plano y código; un campo vacío no deja líneas ni separadores sueltos, y un correo o un teléfono mal escrito se explica antes de copiar.

## Qué trae

- `index.html` — la demostración
- `antefirma.css`
- `antefirma.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `antefirma.css` y `antefirma.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

You write your name or job title, your company and your contact details, and the signature builds live in three templates and four colors, with each new line highlighted as it appears. “Copy with formatting” puts the very HTML you see on the clipboard, with inline styles and links for email, phone and website, and there is also plain text and code; an empty field leaves no stray lines or separators, and a badly typed email or phone is explained before copying.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
