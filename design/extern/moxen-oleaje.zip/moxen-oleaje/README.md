# Oleaje · Moxen

Al bajar, la sección siguiente sube desde abajo con el borde en ola, precedida por una franja de espuma; al subir, la de encima se escurre y deja ver la anterior. La ola se agita más cuanto más rápido sube el agua, el contenido la sigue con paralaje y responde a botones, rueda y flechas.

## Qué trae

- `index.html` — la demostración
- `oleaje.css`
- `oleaje.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `oleaje.css` y `oleaje.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Going down, the next section rises from below with a wavy edge, led by a strip of foam; going up, the one on top drains away to reveal the previous one. The wave gets choppier the faster the water rises, the content follows with parallax, and it responds to buttons, the wheel and the arrow keys.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
