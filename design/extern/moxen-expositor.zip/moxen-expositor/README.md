# Expositor · Moxen

Al soltar las fotos, cada una cae en su celda con un anillo de subida; una demasiado pequeña se raya en bermellón y explica por qué. Arrastrar una celda la levanta y las demás se apartan con resorte (con teclado: Espacio y flechas), «Hacer portada» cruza dos fotos en vuelo mientras la etiqueta salta, y quitar una cierra la rejilla; al completar, «6 fotos listas» con un ✓ bermellón.

## Qué trae

- `index.html` — la demostración
- `expositor.css`
- `expositor.js`
- `img/` — las fotos de la demostración (Unsplash; reemplázalas por las tuyas)
- `CREDITOS.md` — autor y enlace de cada foto
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `expositor.css` y `expositor.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

When you drop the photos, each one falls into its cell with an upload ring; one that is too small is scratched out in vermilion with the reason. Dragging a cell lifts it while the others spring aside (by keyboard: Space and arrows), «Make cover» swaps two photos in flight as the tag jumps, and removing one closes the grid; when done, «6 photos ready» with a vermilion ✓.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
