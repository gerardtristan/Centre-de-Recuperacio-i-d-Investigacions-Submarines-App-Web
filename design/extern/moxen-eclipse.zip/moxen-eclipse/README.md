# Eclipse · Moxen

El sol cruza el riel con un resorte mientras la luna lo va tapando: brilla el anillo de diamante, queda la corona, las nubes se hunden y salen las estrellas; al volver, la luna se aparta y las nubes suben con un rebote. Si quieres, también cambia el tema de la página con una onda que nace del astro.

## Qué trae

- `index.html` — la demostración
- `eclipse.css`
- `eclipse.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `eclipse.css` y `eclipse.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

The sun crosses the track on a spring while the moon slowly covers it: the diamond ring flashes, the corona remains, the clouds sink and the stars come out; switching back, the moon slides away and the clouds bounce up. It can also switch the page theme with a wave that spreads from the sun.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
