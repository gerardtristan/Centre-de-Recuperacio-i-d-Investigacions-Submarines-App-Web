# Monograma · Moxen

Escribes un nombre y el avatar se recompone en vivo, con una transición suave de formas y tonos: el mismo texto da siempre la misma imagen. Cuatro estilos (iniciales, bloques, ondas y mosaico) se alternan con un volteo, «Otra variante» lo sacude y cambia la semilla, tres paletas recolorean el conjunto y «Copiar SVG» y «Descargar» se vuelven ✓.

## Qué trae

- `index.html` — la demostración
- `monograma.css`
- `monograma.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `monograma.css` y `monograma.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Type a name and the avatar rebuilds itself live with a smooth transition of shapes and tones: the same text always gives the same picture. Four styles (initials, blocks, waves and mosaic) swap with a flip, «Another variant» shakes it and changes the seed, three palettes recolour the whole set and «Copy SVG» and «Download» turn into a ✓.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
