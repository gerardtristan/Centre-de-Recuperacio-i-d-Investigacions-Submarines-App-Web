/* =====================================================================
   Ramillete · Moxen
   La barra de una app con una acción central: en un teléfono, un botón redondo en medio de la barra inferior que abre las
   acciones rápidas (nueva cita, nuevo cliente, nuevo cobro, nota); en una pantalla ancha, la misma barra pasa a ser lateral
   y el botón se divide en acción principal + flecha. Sirve para cualquier app de trabajo donde lo que más se hace es «crear algo».

   · Es una sola barra con los mismos nodos en las dos formas. Quien decide la forma es el CSS, con consultas de CONTENEDOR
     (@container pagina en ramillete.css): por debajo de 760 px de ancho, barra inferior; desde 760 px, barra lateral. Cada forma
     publica su nombre en la variable --rm-modo y este script la lee con un ResizeObserver: no repite ningún límite. Como el
     estado vive en el DOM (qué pestaña es aria-current, cuántos avisos tiene Cobros, qué se creó, si el menú está abierto), cambiar
     de forma no pierde nada: no se vuelve a crear ni un nodo. Solo se mueve el botón de acción (al centro o al principio de la
     lista, para que el orden del teclado coincida con lo que se ve) y se le devuelve el foco si lo tenía.
   · El menú es un menú de verdad (role="menu"). Al abrirse, el foco pasa a la primera acción y queda atrapado: ↑ ↓ recorren las
     acciones, Inicio y Fin saltan a los extremos, Tab y Mayús + Tab también giran dentro del menú, Esc lo cierra y devuelve el foco al
     botón, y tocar fuera (el velo) lo cierra. Mientras está abierto, lo demás queda inerte (atributo inert). aria-expanded vive en
     el botón que abre el menú: el redondo en la barra inferior; la flecha en la lateral, donde el botón principal hace la acción por
     defecto (la primera de la lista) sin abrir nada.
   · Elegir una acción abre una hoja con un campo ya llenado con un ejemplo (Intro crea, Esc cancela, el foco gira dentro). Al crear,
     el contador de la pantalla de inicio sube, el aviso de Cobros suma uno si era un cobro, aparece un aviso de «creado» y lo nuevo
     entra arriba de su lista. Todo eso sobrevive al cambio de forma.
   · El ancho de la demo se cambia con «Teléfono / Escritorio»: es una ventana (.rm-marco) cuyo ancho se anima; el ancho que se ve en
     el contador es el real, medido con el ResizeObserver, no el pedido.

   Montaje (se inicia solo sobre [data-ramillete]; el HTML de la demo es la plantilla):
     const r = Ramillete(document.querySelector('[data-ramillete]'), {
       alCambiar: ({ evento, modo, activo, abierto, cuentas }) => {},   // 'modo', 'abre', 'cierra', 'crea', 'pestaña'
     });
     r.abre();  r.cierra();  r.elige('cobro');  r.activa('cobros');  r.ancho(1100);  r.estado();
   Las acciones del menú y las pestañas son las listas ACCIONES y TABS de arriba; el icono de cada una es el símbolo #rm-i-<id> del
   HTML. Qué cambia qué: los colores y medidas, al principio de ramillete.css (--rm-ciruela es lo activo, --rm-naranja la acción), y los
   límites de las dos formas, en la consulta @container del final de ese archivo. Sin azar y sin dependencias; el tiempo sale de
   transiciones CSS, animaciones y setTimeout (nada de Date para animar).
   ===================================================================== */
(function () {
  'use strict';

  const TABS = [
    { id: 'inicio', t: 'Inicio' },
    { id: 'agenda', t: 'Agenda' },
    { id: 'clientes', t: 'Clientes' },
    { id: 'cobros', t: 'Cobros' }
  ];
  /* Las acciones rápidas: cada una abre su hoja con un campo ya llenado. `r` es lo que se inclina al salir del botón. */
  const ACCIONES = [
    { id: 'cita', t: 'Nueva cita', d: 'Elige día y hora', hoja: 'Dale un nombre al servicio. La hora la eliges después.', campo: 'Servicio', pre: 'Consulta inicial', boton: 'Crear cita', ok: 'Cita creada', r: -9 },
    { id: 'cliente', t: 'Nuevo cliente', d: 'Nombre y contacto', hoja: 'Anota cómo quieres ver a esta persona en tu lista.', campo: 'Cliente', pre: 'Cliente nuevo', boton: 'Crear cliente', ok: 'Cliente creado', r: 6 },
    { id: 'cobro', t: 'Nuevo cobro', d: 'Pedido, cuotas y fecha', hoja: 'El pedido que quieres cobrar. Las cuotas y la fecha, después.', campo: 'Concepto', pre: 'Pedido 0483', boton: 'Crear cobro', ok: 'Cobro creado', r: -6 },
    { id: 'nota', t: 'Nota rápida', d: 'Para que no se te olvide', hoja: 'Lo que quieras recordar. Queda en tu inicio.', campo: 'Nota', pre: 'Llamar para confirmar', boton: 'Guardar nota', ok: 'Nota guardada', r: 5 }
  ];
  const BASE = { cita: 6, cliente: 5, cobro: 3, nota: 2 };           // lo que ya había antes de crear nada
  const POR_ID = {}; ACCIONES.forEach(a => { POR_ID[a.id] = a; });
  const DESTINO = { cita: 'agenda', cliente: 'clientes', cobro: 'cobros', nota: 'inicio' };
  const ESTADO_FORMA = {
    abajo: 'Barra inferior: la acción central abre el menú en abanico',
    lateral: 'Barra lateral: el botón se divide en acción principal y flecha'
  };
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const h = (tag, clase) => { const e = document.createElement(tag); if (clase) e.className = clase; return e; };
  const ico = id => '<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#rm-i-' + id + '"/></svg>';

  function Ramillete(raiz, opciones) {
    const op = Object.assign({ alCambiar: null }, opciones);
    const $ = s => raiz.querySelector(s);
    const quieto = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    const anima = (el, kf, o) => (quieto() || !el || !el.animate) ? null : el.animate(kf, o);
    const CURVA = 'cubic-bezier(.22, 1, .36, 1)', REBOTE = 'cubic-bezier(.3, 1.4, .5, 1)';

    const marco = $('[data-marco]'), pagina = $('[data-pagina]'), app = $('[data-app]'), nav = $('[data-nav]'), lista = $('[data-lista]'), contenido = $('[data-contenido]'), brand = $('[data-brand]');
    const accionLi = $('[data-accion]'), fab = $('[data-fab]'), caret = $('[data-caret]'), menu = $('[data-menu]'), velo = $('[data-velo]');
    const hoja = $('[data-hoja]'), form = $('[data-form]'), campo = $('[data-campo]'), campoT = $('[data-campo-t]'), errorEl = $('[data-error]'), hojaT = $('[data-hoja-t]'), hojaD = $('[data-hoja-d]'), hojaIco = $('[data-hoja-ico]'), btnCrea = $('[data-crea]'), btnCancela = $('[data-cancela]'), btnCierra = $('[data-hoja-cierra]');
    const toast = $('[data-toast]'), toastT = $('[data-toast-t]');
    const vistas = $('[data-vistas]'), pastilla = $('[data-pastilla]'), lectura = $('[data-ancho-v]'), estadoEl = $('[data-estado]');
    const botonesVista = Array.from(raiz.querySelectorAll('[data-vista]'));

    const E = { activo: 'inicio', abierto: false, hoja: null, modo: 'abajo', creados: [], cuentas: Object.assign({}, BASE), vista: 'telefono', bump: null, recien: null, origen: null, toastT: 0 };
    let sec = 0;

    /* ── las pestañas: los mismos nodos en las dos formas ─────────────── */
    const tabs = {};
    TABS.forEach(p => {
      const li = h('li'), b = h('button', 'rm-tab');
      b.type = 'button'; b.dataset.id = p.id;
      b.innerHTML = '<span class="rm-tab-ico">' + ico(p.id) + '</span><span class="rm-tab-txt">' + esc(p.t) + '</span>';
      li.appendChild(b);
      if (p.id === 'cobros') { const av = h('b', 'rm-aviso'); b.appendChild(av); tabs.avisoCobros = av; }
      tabs[p.id] = b;
      // al principio: Inicio, Agenda, [acción], Clientes, Cobros
      if (p.id === 'inicio' || p.id === 'agenda') lista.insertBefore(li, accionLi); else lista.appendChild(li);
      b.addEventListener('click', () => activa(p.id));
    });

    /* ── el menú: cada acción sale del botón, en abanico ──────────────── */
    const items = ACCIONES.map((a, i) => {
      const li = h('li'), b = h('button', 'rm-it');
      li.setAttribute('role', 'none');
      b.type = 'button'; b.tabIndex = -1; b.setAttribute('role', 'menuitem'); b.dataset.id = a.id;
      b.style.setProperty('--n', ACCIONES.length - 1 - i);          // 0 = la más cercana al botón
      b.style.setProperty('--r', a.r + 'deg');
      b.innerHTML = '<span class="rm-it-ico">' + ico(a.id) + '</span><span class="rm-it-txt"><b>' + esc(a.t) + '</b><small>' + esc(a.d) + '</small></span>';
      li.appendChild(b); menu.appendChild(li);
      b.addEventListener('click', () => elige(a.id, disparador()));
      return b;
    });

    /* ── las pantallas ────────────────────────────────────────────────── */
    const hoy = 'Martes 27 de octubre';
    const fila = (o) => '<div class="rm-fila' + (o.nueva ? ' es-nueva' : '') + '">'
      + (o.h ? '<time>' + esc(o.h) + '</time>' : '') + (o.ico ? '<span class="rm-it-ico">' + ico(o.ico) + '</span>' : '')
      + '<div class="rm-fila-t"><b>' + esc(o.t) + '</b><small>' + esc(o.d) + '</small></div>'
      + (o.chip ? '<span class="rm-chip' + (o.c ? ' es-' + o.c : '') + '">' + esc(o.chip) + '</span>' : '') + '</div>';
    const creadosDe = id => E.creados.filter(c => c.id === id);
    const PANTALLAS = {
      inicio: { t: 'Inicio', f: hoy, cuerpo() {
        const tile = (id, n, t, d) => '<div class="rm-tarjeta"><b data-n="' + id + '"' + (E.bump === id ? ' class="rm-sube"' : '') + '>' + n + '</b><span>' + t + '</span><small>' + d + '</small></div>';
        const nuevos = E.creados.slice(0, 3);
        return '<div class="rm-tarjetas">' + tile('cita', E.cuentas.cita, 'Citas hoy', '2 por confirmar') + tile('cliente', E.cuentas.cliente, 'Clientes nuevos', 'esta semana')
          + tile('cobro', E.cuentas.cobro, 'Por cobrar', 'pedidos pendientes') + tile('nota', E.cuentas.nota, 'Notas', 'guardadas') + '</div>'
          + '<div class="rm-proxima"><div><p>Próxima cita</p><b>10:30</b><span class="rm-prox-t">Corte y peinado · 60 min</span></div><span class="rm-chip">En 45 min</span></div>'
          + '<h3 class="rm-sub">Recién creado</h3>'
          + (nuevos.length ? '<div class="rm-filas">' + nuevos.map((c, i) => fila({ ico: c.id, t: c.texto, d: POR_ID[c.id].ok, chip: 'Ahora', c: 'naranja', nueva: c.n === E.recien && i === 0 })).join('') + '</div>'
            : '<p class="rm-vacio">Todavía nada: toca el botón + para crear algo.</p>');
      } },
      agenda: { t: 'Agenda', f: hoy, cuerpo() {
        const base = [['09:00', 'Consulta inicial', '45 min', 'Confirmada', ''], ['10:30', 'Corte y peinado', '60 min', 'Confirmada', ''], ['12:00', 'Revisión de color', '30 min', 'Por confirmar', 'naranja'], ['15:30', 'Sesión de seguimiento', '45 min', 'Por confirmar', 'naranja']];
        const nuevas = creadosDe('cita').map(c => fila({ h: 'Sin hora', t: c.texto, d: 'Elige la hora al abrirla', chip: 'Nueva', c: 'naranja', nueva: c.n === E.recien }));
        return '<div class="rm-filas">' + nuevas.join('') + base.map(b => fila({ h: b[0], t: b[1], d: b[2], chip: b[3], c: b[4] })).join('') + '</div>';
      } },
      clientes: { t: 'Clientes', f: 'Tu lista', cuerpo() {
        const base = [['Recurrentes', 'Vienen al menos una vez al mes', '38'], ['Nuevos esta semana', 'Todavía sin segunda visita', '5'], ['Sin visita hace 60 días', 'Buenos para un recordatorio', '12']];
        const nuevos = creadosDe('cliente').map(c => fila({ ico: 'cliente', t: c.texto, d: 'Recién agregado', chip: 'Nuevo', c: 'naranja', nueva: c.n === E.recien }));
        return '<div class="rm-filas">' + nuevos.join('') + base.map(b => fila({ t: b[0], d: b[1], chip: b[2] })).join('') + '</div>';
      } },
      cobros: { t: 'Cobros', f: 'Por cobrar', cuerpo() {
        const base = [['Pedido 0482', 'Vence el 30 oct · 2 cuotas', 'Por cobrar', 'naranja'], ['Pedido 0479', 'Vence el 3 nov · 1 cuota', 'Por cobrar', 'naranja'], ['Pedido 0471', 'Venció hace 2 días · 1 cuota', 'Vencido', 'gris']];
        const nuevos = creadosDe('cobro').map(c => fila({ ico: 'cobro', t: c.texto, d: 'Sin fecha todavía', chip: 'Nuevo', c: 'naranja', nueva: c.n === E.recien }));
        return '<div class="rm-filas">' + nuevos.join('') + base.map(b => fila({ t: b[0], d: b[1], chip: b[2], c: b[3] })).join('') + '</div>';
      } }
    };
    function render(conEntrada) {
      const p = PANTALLAS[E.activo];
      contenido.innerHTML = '<header class="rm-cab"><p class="rm-fecha">' + esc(p.f) + '</p><h2>' + esc(p.t) + '</h2></header><div class="rm-cuerpo"><div class="rm-pantalla"' + (conEntrada ? '' : ' style="animation:none"') + '>' + p.cuerpo() + '</div></div>';
      E.bump = null; E.recien = null;
      TABS.forEach(t => { if (t.id === E.activo) tabs[t.id].setAttribute('aria-current', 'page'); else tabs[t.id].removeAttribute('aria-current'); });
      const n = E.cuentas.cobro;
      tabs.avisoCobros.textContent = n;
      tabs.cobros.setAttribute('aria-label', 'Cobros, ' + n + (n === 1 ? ' pendiente' : ' pendientes'));
    }
    function activa(id) {
      if (!PANTALLAS[id] || id === E.activo) return;
      E.activo = id; render(true);
      aviso('pestaña');
    }

    /* ── el menú abierto: foco atrapado, inerte lo demás ──────────────── */
    const disparador = () => (E.modo === 'lateral' ? caret : fab);
    const lleva = el => { if (el && el.focus) el.focus({ preventScroll: true }); };
    const otros = () => Array.from(lista.children).filter(li => li !== accionLi);
    /* Lo que no es el menú (o la hoja) queda inerte: no recibe foco ni toques mientras está abierto. */
    function bloquea(on, todo) {
      contenido.inert = on;
      if (todo) nav.inert = on;                                 // la hoja: toda la barra
      else { otros().forEach(li => { li.inert = on; }); brand.inert = on; }   // el menú: todo menos el botón de acción
    }
    function sync() {
      const lat = E.modo === 'lateral';
      fab.setAttribute('aria-label', lat ? ACCIONES[0].t : 'Acciones rápidas');
      if (lat) { fab.removeAttribute('aria-haspopup'); fab.removeAttribute('aria-expanded'); fab.removeAttribute('aria-controls'); caret.setAttribute('aria-expanded', E.abierto ? 'true' : 'false'); }
      else { fab.setAttribute('aria-haspopup', 'menu'); fab.setAttribute('aria-expanded', E.abierto ? 'true' : 'false'); fab.setAttribute('aria-controls', 'rm-menu'); caret.setAttribute('aria-expanded', 'false'); }
    }
    function abre(cual) {
      if (E.abierto || E.hoja) return;
      E.abierto = true; app.classList.add('es-abierto'); sync(); bloquea(true);
      lleva(cual === 'ultimo' ? items[items.length - 1] : items[0]);
      aviso('abre');
    }
    function cierra(devuelve) {
      if (!E.abierto) return;
      E.abierto = false; app.classList.remove('es-abierto'); sync(); bloquea(false);
      if (devuelve !== false) lleva(disparador());
      aviso('cierra');
    }
    const alterna = () => (E.abierto ? cierra(true) : abre());

    /* ── la hoja: un formulario corto ─────────────────────────────────── */
    function abreHoja(a, origen) {
      E.hoja = a.id; E.origen = origen || disparador();
      hojaT.textContent = a.t; hojaD.textContent = a.hoja; campoT.textContent = a.campo; campo.value = a.pre;
      hojaIco.innerHTML = '<use href="#rm-i-' + a.id + '"/>'; btnCrea.textContent = a.boton;
      errorEl.hidden = true; campo.removeAttribute('aria-invalid'); campo.removeAttribute('aria-describedby');
      hoja.classList.add('es-abierta'); app.classList.add('hay-hoja'); bloquea(true, true);
      lleva(campo); campo.select();
    }
    function cierraHoja(devuelve) {
      if (!E.hoja) return;
      E.hoja = null; hoja.classList.remove('es-abierta'); app.classList.remove('hay-hoja'); bloquea(false, true);
      if (devuelve !== false) lleva(E.origen && E.origen.isConnected ? E.origen : disparador());
    }
    function elige(id, origen) {
      const a = POR_ID[id]; if (!a) return;
      if (E.abierto) cierra(false);
      abreHoja(a, origen);
    }
    function crea(a, texto) {
      E.cuentas[a.id]++; sec++;
      E.creados.unshift({ id: a.id, texto, n: sec });
      cierraHoja(true);
      E.bump = a.id; E.recien = sec;
      render(false);
      if (a.id === 'cobro') { tabs.avisoCobros.classList.remove('rm-sube'); void tabs.avisoCobros.offsetWidth; tabs.avisoCobros.classList.add('rm-sube'); }
      avisa(a.ok);
      aviso('crea');
    }
    form.addEventListener('submit', ev => {
      ev.preventDefault();
      const a = POR_ID[E.hoja]; if (!a) return;
      const v = campo.value.trim();
      if (!v) {
        errorEl.textContent = 'Escribe algo para crear: ' + a.campo.toLowerCase() + '.'; errorEl.id = 'rm-error'; errorEl.hidden = false;
        campo.setAttribute('aria-invalid', 'true'); campo.setAttribute('aria-describedby', 'rm-error'); lleva(campo);
        return;
      }
      crea(a, v);
    });
    campo.addEventListener('input', () => { if (!errorEl.hidden) { errorEl.hidden = true; campo.removeAttribute('aria-invalid'); } });
    btnCancela.addEventListener('click', () => cierraHoja(true));
    btnCierra.addEventListener('click', () => cierraHoja(true));
    /* el aviso de «creado»: se apaga solo */
    function avisa(texto) {
      toastT.textContent = texto; toast.classList.add('es-visible');
      clearTimeout(E.toastT); E.toastT = setTimeout(() => toast.classList.remove('es-visible'), 2300);
    }

    /* ── los botones de acción ─────────────────────────────────────────── */
    fab.addEventListener('click', () => { if (E.modo === 'lateral') elige(ACCIONES[0].id, fab); else alterna(); });
    caret.addEventListener('click', alterna);
    velo.addEventListener('click', () => { if (E.hoja) cierraHoja(true); else cierra(true); });

    raiz.addEventListener('keydown', ev => {
      if (ev.key === 'Escape') {
        if (E.hoja) { ev.preventDefault(); cierraHoja(true); }
        else if (E.abierto) { ev.preventDefault(); cierra(true); }
        return;
      }
      if (ev.key === 'Tab') {
        if (E.hoja) {                                                    // la hoja: gira entre sus controles
          const f = [btnCierra, campo, btnCancela, btnCrea], i = f.indexOf(document.activeElement);
          if (ev.shiftKey && i <= 0) { ev.preventDefault(); lleva(f[f.length - 1]); }
          else if (!ev.shiftKey && (i === f.length - 1 || i < 0)) { ev.preventDefault(); lleva(f[0]); }
        } else if (E.abierto) {                                         // el menú: gira entre las acciones
          ev.preventDefault();
          const i = items.indexOf(document.activeElement);
          lleva(items[i < 0 ? (ev.shiftKey ? items.length - 1 : 0) : (i + (ev.shiftKey ? -1 : 1) + items.length) % items.length]);
        }
        return;
      }
      if (E.abierto) {
        const i = items.indexOf(document.activeElement);
        const k = ev.key;
        if (k === 'ArrowDown' || k === 'ArrowUp' || k === 'Home' || k === 'End') {
          ev.preventDefault();
          const n = items.length;
          lleva(items[k === 'Home' ? 0 : k === 'End' ? n - 1 : i < 0 ? (k === 'ArrowDown' ? 0 : n - 1) : (i + (k === 'ArrowDown' ? 1 : -1) + n) % n]);
        }
      } else if (!E.hoja && (document.activeElement === disparador()) && (ev.key === 'ArrowDown' || ev.key === 'ArrowUp')) {
        ev.preventDefault(); abre(ev.key === 'ArrowUp' ? 'ultimo' : 'primero');        // como cualquier botón de menú
      }
    });

    /* ── la forma de la barra: la mide el ResizeObserver, la decide el CSS ─ */
    function alModo(modo) {
      const activo = document.activeElement;
      E.modo = modo; app.dataset.modo = modo;
      // el botón de acción va al principio de la lista en la lateral y en el centro en la inferior (el teclado sigue el orden visual)
      const resto = otros();
      lista.insertBefore(accionLi, modo === 'lateral' ? resto[0] : resto[2]);
      if (activo && activo !== document.body && activo.isConnected && !activo.inert) lleva(activo);
      sync();
      estadoEl.textContent = ESTADO_FORMA[modo];
      // un respiro al cambiar: lo que se mueve no es la barra (el menú abierto debe seguir encima del velo)
      Array.from(raiz.querySelectorAll('.rm-tab, .rm-brand')).forEach((el, i) => anima(el, [{ opacity: 0, transform: 'translateY(6px)' }, { opacity: 1, transform: 'none' }], { duration: 420, delay: i * 25, easing: CURVA, fill: 'backwards' }));
      anima(fab, [{ transform: 'scale(.82)' }, { transform: 'none' }], { duration: 520, easing: REBOTE });
      aviso('modo');
    }
    function lee() {
      lectura.textContent = Math.round(pagina.getBoundingClientRect().width);
      const modo = (getComputedStyle(app).getPropertyValue('--rm-modo') || '').trim() || 'abajo';
      if (modo !== E.modo) alModo(modo);
    }
    if (window.ResizeObserver) new ResizeObserver(lee).observe(pagina);
    window.addEventListener('resize', lee);

    /* ── el control del ancho ──────────────────────────────────────────── */
    function colocaPastilla(sinMovimiento) {
      const b = botonesVista.find(x => x.getAttribute('aria-checked') === 'true');
      if (!b || !b.offsetWidth) return;
      if (sinMovimiento) pastilla.style.transition = 'none';
      pastilla.style.width = b.offsetWidth + 'px';
      pastilla.style.transform = 'translateX(' + b.offsetLeft + 'px)';
      if (sinMovimiento) { void pastilla.offsetWidth; pastilla.style.transition = ''; }
    }
    function vista(nombre) {
      const b = botonesVista.find(x => x.dataset.vista === nombre); if (!b) return;
      E.vista = nombre;
      botonesVista.forEach(x => { const on = x === b; x.setAttribute('aria-checked', on ? 'true' : 'false'); x.tabIndex = on ? 0 : -1; });
      marco.style.setProperty('--rm-w', b.dataset.w + 'px');
      colocaPastilla();
    }
    botonesVista.forEach(b => b.addEventListener('click', () => vista(b.dataset.vista)));
    vistas.addEventListener('keydown', ev => {
      const i = botonesVista.findIndex(x => x === document.activeElement);
      if (i < 0) return;
      const d = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[ev.key];
      if (!d) return;
      ev.preventDefault();
      const s = botonesVista[(i + d + botonesVista.length) % botonesVista.length];
      vista(s.dataset.vista); lleva(s);
    });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => colocaPastilla(true));

    /* ── lo que se avisa y la API pequeña ──────────────────────────────── */
    function aviso(evento) {
      if (op.alCambiar) op.alCambiar({ evento, modo: E.modo, activo: E.activo, abierto: E.abierto, cuentas: Object.assign({}, E.cuentas) });
    }
    const api = {
      abre() { abre(); return api; }, cierra() { cierra(true); return api; },
      elige(id) { elige(id); return api; }, activa(id) { activa(id); return api; },
      ancho(px) { vista((+px || 375) >= 760 ? 'escritorio' : 'telefono'); marco.style.setProperty('--rm-w', Math.max(320, Math.min(1100, +px || 375)) + 'px'); return api; },
      vista(n) { vista(n); return api; },
      estado() { return { activo: E.activo, modo: E.modo, abierto: E.abierto, hoja: E.hoja, cuentas: Object.assign({}, E.cuentas), creados: E.creados.map(c => ({ id: c.id, texto: c.texto })), ancho: Math.round(pagina.getBoundingClientRect().width) }; }
    };

    render(false);
    colocaPastilla(true);
    lee();
    sync();
    return api;
  }

  window.Ramillete = Ramillete;
  const raiz = document.querySelector('[data-ramillete]');
  if (raiz) window.ramillete = Ramillete(raiz);
})();
