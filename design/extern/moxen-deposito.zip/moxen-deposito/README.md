# Depósito · Moxen

Quien paga copia los datos de la cuenta de un toque (campo por campo o todos juntos, tal como se ven), sube su comprobante y sigue el avance; el archivo se valida por su contenido y no por su nombre: imagen o PDF de hasta 3 MB, con el motivo si no sirve. El panel del negocio recibe lo que llega por revisar y lo confirma o lo rechaza con un motivo, y quien paga lo lee al instante.

## Qué trae

- `index.html` — la demostración
- `deposito.css`
- `deposito.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `deposito.css` y `deposito.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

The payer copies the account details with one tap (field by field or all together, exactly as shown), uploads the receipt and follows the progress; the file is checked by its content, not by its name: an image or PDF up to 3 MB, with the reason if it doesn't qualify. The business panel receives what is waiting for review and confirms it or rejects it with a reason, which the payer reads straight away.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
