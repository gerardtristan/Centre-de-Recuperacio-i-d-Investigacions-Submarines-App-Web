/* =====================================================================
   Seguir · Moxen
   Un botón «Seguir» que pasa a «Siguiendo» en una ficha de perfil: el
   botón se estira con un rebote de goma, las palabras se relevan en
   vertical (la palomita se dibuja), el contador de seguidores sube
   rodando cifra a cifra, y el avatar late mientras su anillo se dibuja
   y suelta unas partículas. Otro clic lo deshace, con su propio gesto.

     const s = Seguir(document.querySelector('.sg-boton'), { contador: el, avatar: el });
     s.alterna();      s.siguiendo();

   El botón no cambia de ancho (nada de recolocar la página): el
   estirón es una escala con resorte, hecha con Web Animations.
   ===================================================================== */
(function () {
  'use strict';

  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const MAS = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';
  const OK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.6 4.6L19 7.5"/></svg>';
  // 1284 → «1.284», con el punto de miles como se escribe aquí
  const miles = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');

  /* El contador: una columna 0–9 por dígito. Cambiar de número es mover
     cada columna a su cifra; las que no cambian no se mueven. */
  function Contador(el, inicial) {
    let columnas = [];
    function pinta(n) {
      const s = miles(n);
      // si cambia la forma (999 → 1.000) se rehace; si no, solo ruedan las columnas
      if (s.replace(/\d/g, '0') !== el.dataset.forma) {
        el.dataset.forma = s.replace(/\d/g, '0');
        el.textContent = '';
        el.classList.add('sg-cuenta');
        columnas = [];
        for (const ch of s) {
          if (/\d/.test(ch)) {
            const c = document.createElement('span');
            c.className = 'sg-columna';
            c.innerHTML = '0123456789'.split('').map(d => '<span>' + d + '</span>').join('');
            el.appendChild(c); columnas.push(c);
          } else {
            const g = document.createElement('span');
            g.className = 'sg-signo'; g.textContent = ch; el.appendChild(g);
          }
        }
      }
      s.replace(/\D/g, '').split('').forEach((d, i) => {
        columnas[i].style.transform = 'translateY(' + (-d * 10) + '%)';
      });
      el.setAttribute('aria-label', s);
    }
    pinta(inicial);
    return pinta;
  }

  function Seguir(boton, opciones) {
    const o = Object.assign({ despues: 'Siguiendo', contador: null, avatar: null }, opciones);
    const antes = boton.textContent.trim();
    boton.innerHTML = '<span class="sg-fondo" aria-hidden="true"></span>'
      + '<span class="sg-cara sg-antes">' + MAS + '<span></span></span><span class="sg-cara sg-despues">' + OK + '<span></span></span>';
    const [a, b] = boton.querySelectorAll('.sg-cara');
    a.lastChild.textContent = antes;
    b.lastChild.textContent = o.despues;
    boton.setAttribute('aria-pressed', 'false');

    let cuenta = o.contador ? +o.contador.dataset.seguirCuenta || 0 : 0;
    const pinta = o.contador ? Contador(o.contador, cuenta) : () => {};
    let sigue = false;

    /* El estirón: el botón se ensancha y se aplasta como una goma y
       vuelve con dos rebotes que se apagan. Al dejar de seguir, en
       cambio, se encoge un poco: un gesto más corto y seco. */
    function estira(adelante) {
      boton.animate(adelante ? [
        { transform: 'scale(1)' },
        { transform: 'scale(1.07, .9)', offset: .22 },
        { transform: 'scale(.97, 1.04)', offset: .48 },
        { transform: 'scale(1.015, .99)', offset: .72 },
        { transform: 'scale(1)' },
      ] : [
        { transform: 'scale(1)' },
        { transform: 'scale(.95, .96)', offset: .3 },
        { transform: 'scale(1.01)', offset: .65 },
        { transform: 'scale(1)' },
      ], { duration: adelante ? 620 : 420, easing: 'ease-out' });
    }

    // unas partículas finas que salen del anillo del avatar
    function chispas() {
      if (!o.avatar) return;
      const n = 12;
      for (let i = 0; i < n; i++) {
        const p = document.createElement('i');
        p.className = 'sg-chispa';
        const ang = i / n * Math.PI * 2 + (i % 2 ? .12 : -.08);
        const lejos = 78 + (i % 3) * 14, cerca = 58;
        const x0 = Math.cos(ang) * cerca, y0 = Math.sin(ang) * cerca;
        const x1 = Math.cos(ang) * lejos, y1 = Math.sin(ang) * lejos;
        o.avatar.appendChild(p);
        p.animate([
          { transform: 'translate(' + x0 + 'px, ' + y0 + 'px) scale(1)', opacity: 1 },
          { transform: 'translate(' + x1 + 'px, ' + y1 + 'px) scale(.2)', opacity: 0 },
        ], { duration: 640 + (i % 4) * 60, delay: 140, easing: 'cubic-bezier(.22, 1, .36, 1)', fill: 'both' })
          .onfinish = () => p.remove();
      }
    }

    function alterna() {
      sigue = !sigue;
      boton.classList.toggle('is-sigue', sigue);
      boton.setAttribute('aria-pressed', String(sigue));
      if (o.avatar) o.avatar.classList.toggle('is-sigue', sigue);
      cuenta += sigue ? 1 : -1;
      pinta(cuenta);
      if (reduce) return;
      estira(sigue);
      if (sigue && o.avatar) {
        o.avatar.animate([
          { transform: 'scale(1)' }, { transform: 'scale(1.07)', offset: .3 }, { transform: 'scale(.98)', offset: .65 }, { transform: 'scale(1)' },
        ], { duration: 560, delay: 80, easing: 'ease-out' });
        chispas();
      }
    }

    boton.addEventListener('click', alterna);
    return { alterna, siguiendo: () => sigue };
  }

  window.Seguir = Seguir;
})();
