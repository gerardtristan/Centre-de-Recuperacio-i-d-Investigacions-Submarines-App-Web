# Ramillete · Moxen

Pon la acción que más se usa al alcance del pulgar: un botón central en la barra inferior que se abre en abanico con nueva cita, nuevo cliente, nuevo cobro y nota, con foco atrapado, Esc, flechas y cierre al tocar fuera. Al ensanchar la ventana la misma barra pasa a lateral y el botón se divide en acción principal y flecha, sin perder la pestaña abierta, los avisos ni lo que acabas de crear.

## Qué trae

- `index.html` — la demostración
- `ramillete.css`
- `ramillete.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `ramillete.css` y `ramillete.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

Put the most-used action within thumb's reach: a central button in the bottom bar that fans out into new appointment, new client, new charge and note, with trapped focus, Esc, arrow keys and close on outside tap. When the window widens the same bar becomes a sidebar and the button splits into a main action and an arrow, without losing the open tab, the badges or what you just created.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
