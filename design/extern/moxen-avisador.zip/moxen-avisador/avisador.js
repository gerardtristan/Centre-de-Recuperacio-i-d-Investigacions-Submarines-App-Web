/* =====================================================================
   Avisador · Moxen
   Las preferencias de avisos de una app: una matriz de «qué te avisamos» (filas) por «dónde» (columnas: correo, mensaje y en la
   app), con una vista previa de cómo llega cada aviso y un resumen en palabras que se reescribe con cada cambio.

   Funciona de verdad (nada está precalculado; solo la matriz de partida, BASE):
   · Cada casilla es un interruptor. El resumen («En palabras») y los contadores salen del estado real de la matriz, no de un texto fijo.
   · Un canal apagado (el interruptor de la cabecera) apaga y bloquea toda su columna; las casillas recuerdan lo que tenían y lo recuperan
     al encender el canal otra vez. Tocar una casilla bloqueada hace parpadear el interruptor del canal y explica por qué.
   · Dependencias: el resumen del día solo existe por correo, así que sin correo la fila se bloquea («Necesita el correo») y el resumen
     lo dice («Sin correo no hay resumen del día»). Las dependencias están en EVENTOS (requiere) y se leen en un solo lugar: bloqueo().
   · Regla mínima: «Cambio o cancelación» siempre debe llegar por al menos un canal. Si apagar una casilla o un canal lo dejaría sin
     ninguno, el cambio se rechaza con su motivo en lugar de dejar la matriz inválida.
   · «Solo lo importante» apaga todo lo que no es importante y deja tus elecciones en lo que sí lo es; «Restaurar» vuelve exactamente
     a BASE (el botón se apaga cuando ya estás ahí).
   · Teclado: Tab entra a la matriz; ← → ↑ ↓ mueven entre casillas (saltan las que no aplican), Inicio y Fin van a los extremos de la
     fila, Espacio o Intro alternan. Los avisos de error y los cambios se anuncian en una región aria-live.

   Cómo se monta (ver index.html): se inicia solo sobre [data-avisador]; el HTML es el esqueleto.
     const a = Avisador(document.querySelector('[data-avisador]'), { estado: BASE, alCambiar: estado => {} });
     a.alterna('cita', 'correo');   a.canal('correo', false);   a.soloImportante();   a.restaura();   a.estado();   a.resumen();
   Avisador.nucleo expone las cuentas sin pantalla: activo(estado, evento, canal), cuenta(estado), resumen(estado), soloImportante(estado),
   faltante(estado), BASE, CANALES y EVENTOS.
   Qué se personaliza: los colores, al principio de avisador.css (--av-lila para lo activo, --av-nar para lo importante y los bloqueos);
   los canales, los avisos y lo que depende de qué, en CANALES y EVENTOS; el estado de partida, en BASE; los textos de la vista previa, en
   PREV. El tiempo sale de requestAnimationFrame, WAAPI, transiciones y setTimeout (sin Date). Sin dependencias.
   ===================================================================== */
(function () {
  'use strict';

  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const quieto = () => mq.matches;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const h = (tag, clase, html) => { const e = document.createElement(tag); if (clase) e.className = clase; if (html != null) e.innerHTML = html; return e; };
  const CURVA = 'cubic-bezier(.22, 1, .36, 1)';

  /* ── los íconos (trazo; el color lo pone el CSS) ───────────────────────── */
  const ICO = {
    correo: '<rect x="3.500" y="5.500" width="17" height="13" rx="2.500"/><path d="m4.500 7.500 7.500 6 7.500-6"/>',
    mensaje: '<path d="M5 5.500h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-6.500L8 21v-3.500H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z"/>',
    app: '<rect x="7" y="3" width="10" height="18" rx="2.500"/><path d="M10.500 18h3"/>',
    campana: '<path d="M6 16.500V11a6 6 0 0 1 12 0v5.500l1.500 1.500h-15Z"/><path d="M10 20.500a2.200 2.200 0 0 0 4 0"/>',
    candado: '<rect x="5.500" y="10.500" width="13" height="9.500" rx="2.500"/><path d="M8.500 10.500V8a3.500 3.500 0 0 1 7 0v2.500"/>',
    alto: '<circle cx="12" cy="12" r="8.500"/><path d="M12 7.500v5.500M12 16.500h.01"/>',
    apagado: '<circle cx="12" cy="12" r="8.500"/><path d="M6 18 18 6"/>',
    ok: '<path d="M5 12.500 10 17.500 19 7" pathLength="1"/>',
  };
  const svg = (k, clase) => '<svg viewBox="0 0 24 24" aria-hidden="true"' + (clase ? ' class="' + clase + '"' : '') + '>' + ICO[k] + '</svg>';

  /* ── los datos: por dónde, qué y desde dónde partimos ──────────────────── */
  const CANALES = [
    { id: 'correo', nombre: 'Correo', corto: 'correo', art: 'el correo' },
    { id: 'mensaje', nombre: 'Mensaje', corto: 'mensaje', art: 'el mensaje' },
    { id: 'app', nombre: 'En la app', corto: 'la app', art: 'la app' },
  ];

  /* imp: va en el grupo de los importantes. minimo: siempre debe llegar por al menos ese número de canales.
     requiere: sin ese canal encendido el aviso no existe (y la fila se bloquea). canales: dónde tiene sentido. */
  const EVENTOS = [
    { id: 'cita', nombre: 'Cita nueva', sub: 'Cuando alguien reserva contigo', corto: 'citas nuevas', imp: true, canales: ['correo', 'mensaje', 'app'] },
    { id: 'recordatorio', nombre: 'Recordatorio', sub: 'Antes de la hora de la cita', corto: 'recordatorios', imp: true, canales: ['correo', 'mensaje', 'app'] },
    { id: 'cambio', nombre: 'Cambio o cancelación', sub: 'Siempre llega por algún canal', corto: 'cambios', imp: true, minimo: 1, canales: ['correo', 'mensaje', 'app'] },
    { id: 'mensajes', nombre: 'Mensajes nuevos', sub: 'Cuando alguien te escribe', corto: 'mensajes', canales: ['correo', 'app'] },
    { id: 'resumen', nombre: 'Resumen del día', sub: 'Tus citas de mañana, cada tarde', corto: 'resumen del día', canales: ['correo'], requiere: 'correo', notaOn: 'El resumen del día sale cada tarde, solo por correo.' },
    { id: 'novedades', nombre: 'Novedades', sub: 'Mejoras del servicio', corto: 'novedades', canales: ['correo', 'app'] },
  ];

  /* El estado: canal[c] es el interruptor de la columna; celda[e][c] es la casilla (solo donde el aviso aplica). */
  const BASE = {
    canal: { correo: true, mensaje: true, app: true },
    celda: {
      cita: { correo: true, mensaje: false, app: true },
      recordatorio: { correo: false, mensaje: true, app: true },
      cambio: { correo: true, mensaje: true, app: true },
      mensajes: { correo: false, app: true },
      resumen: { correo: true },
      novedades: { correo: true, app: false },
    },
  };

  /* Lo que se ve en cada canal, para cada aviso (datos de ejemplo, nada real). */
  const PREV = {
    cita: {
      correo: { de: 'Agenda', asunto: 'Cita nueva: mar 27 oct, 10:30', texto: 'Alguien reservó contigo. Revisa los detalles y confírmala.' },
      mensaje: { texto: 'Cita nueva: mar 27 oct, 10:30. Entra para confirmarla.' },
      app: { titulo: 'Cita nueva', texto: 'Mar 27 oct · 10:30' },
    },
    recordatorio: {
      correo: { de: 'Agenda', asunto: 'Mañana tienes una cita a las 10:30', texto: 'Te lo recordamos con un día de anticipación.' },
      mensaje: { texto: 'Recuerda: mañana a las 10:30 tienes una cita.' },
      app: { titulo: 'Tu cita es en 2 horas', texto: 'Hoy · 10:30' },
    },
    cambio: {
      correo: { de: 'Agenda', asunto: 'Tu cita cambió: ahora jue 29 oct, 16:00', texto: 'La hora anterior quedó libre. Puedes aceptar o pedir otra.' },
      mensaje: { texto: 'Tu cita pasó al jue 29 oct, 16:00. Responde para aceptar.' },
      app: { titulo: 'Cita movida', texto: 'Jue 29 oct · 16:00' },
    },
    mensajes: {
      correo: { de: 'Agenda', asunto: 'Tienes 2 mensajes nuevos', texto: 'Respóndelos desde tu bandeja sin abrir la app.' },
      app: { titulo: '2 mensajes nuevos', texto: 'Toca para responder' },
    },
    resumen: {
      correo: { de: 'Agenda', asunto: 'Tus citas de mañana: 4', texto: 'Desde las 9:00 hasta las 17:30, con una pausa a las 13:00.' },
    },
    novedades: {
      correo: { de: 'Agenda', asunto: 'Novedades de este mes', texto: 'Dos mejoras en la agenda y un ajuste en los recordatorios.' },
      app: { titulo: 'Hay algo nuevo', texto: 'Mira qué cambió este mes' },
    },
  };

  /* ── el núcleo: cuentas puras, sin pantalla ────────────────────────────── */
  const clona = e => JSON.parse(JSON.stringify(e));
  const evento = id => EVENTOS.find(e => e.id === id);
  const canalDe = id => CANALES.find(c => c.id === id);
  const aplica = (ev, c) => ev.canales.indexOf(c) >= 0;

  /* Por qué una casilla no se puede tocar: 'canal' (la columna está apagada), 'dep' (el aviso necesita otro canal) o null. */
  function bloqueo(est, ev, c) {
    if (!est.canal[c]) return 'canal';
    if (ev.requiere && !est.canal[ev.requiere]) return 'dep';
    return null;
  }
  const activo = (est, ev, c) => aplica(ev, c) && !bloqueo(est, ev, c) && !!est.celda[ev.id][c];

  /* El primer aviso con mínimo que se quedó sin canales, o null si todo es válido. */
  function faltante(est) {
    return EVENTOS.find(ev => ev.minimo && CANALES.filter(c => activo(est, ev, c.id)).length < ev.minimo) || null;
  }

  function cuenta(est) {
    const r = { posibles: 0, activos: 0, canal: {}, evento: {} };
    CANALES.forEach(c => { r.canal[c.id] = { posibles: 0, activos: 0 }; });
    EVENTOS.forEach(ev => {
      r.evento[ev.id] = 0;
      ev.canales.forEach(c => {
        r.posibles++; r.canal[c].posibles++;
        if (activo(est, ev, c)) { r.activos++; r.canal[c].activos++; r.evento[ev.id]++; }
      });
    });
    return r;
  }

  function lista(xs) {
    if (xs.length < 2) return xs.join('');
    return xs.slice(0, -1).join(', ') + ' y ' + xs[xs.length - 1];
  }

  /* El resumen en palabras: una línea por canal y una nota sobre lo que depende de qué. */
  function resumen(est) {
    const lineas = CANALES.map(c => {
      if (!est.canal[c.id]) return { canal: c.id, nombre: c.nombre, rotulo: c.nombre + ' apagado:', estado: 'apagado', texto: 'no recibes nada por aquí.' };
      const xs = EVENTOS.filter(ev => activo(est, ev, c.id)).map(ev => ev.corto);
      return { canal: c.id, nombre: c.nombre, rotulo: c.nombre + ':', estado: xs.length ? 'activo' : 'vacio', texto: xs.length ? lista(xs) + '.' : 'ningún aviso.' };
    });
    let nota = '';
    const sin = EVENTOS.filter(ev => ev.requiere && !est.canal[ev.requiere]);
    if (sin.length) nota = sin.map(ev => 'Sin ' + canalDe(ev.requiere).corto + ' no hay ' + ev.corto + '.').join(' ');
    else {
      const on = EVENTOS.filter(ev => ev.requiere && activo(est, ev, ev.requiere) && ev.notaOn);
      nota = on.map(ev => ev.notaOn).join(' ');
    }
    const c = cuenta(est);
    return { lineas, nota, activos: c.activos, posibles: c.posibles };
  }

  /* «Solo lo importante»: apaga todo lo que no es importante y deja lo que elegiste en lo que sí lo es. */
  function soloImportante(est) {
    const e = clona(est);
    EVENTOS.forEach(ev => { if (!ev.imp) ev.canales.forEach(c => { e.celda[ev.id][c] = false; }); });
    EVENTOS.forEach(ev => {
      if (!ev.imp || !ev.minimo) return;
      if (CANALES.filter(c => activo(e, ev, c.id)).length >= ev.minimo) return;
      const c = ev.canales.find(k => !bloqueo(e, ev, k));
      if (c) e.celda[ev.id][c] = true;
    });
    return e;
  }

  const igual = (a, b) => CANALES.every(c => a.canal[c.id] === b.canal[c.id]) &&
    EVENTOS.every(ev => ev.canales.every(c => !!a.celda[ev.id][c] === !!b.celda[ev.id][c]));
  const sinImportante = est => EVENTOS.every(ev => ev.imp || ev.canales.every(c => !est.celda[ev.id][c]));

  /* ── la interfaz ───────────────────────────────────────────────────────── */
  function Avisador(raiz, opciones) {
    const op = Object.assign({ estado: BASE, alCambiar: null }, opciones);
    const el = {
      matriz: $('[data-matriz]', raiz), aviso: $('[data-aviso]', raiz), solo: $('[data-solo]', raiz), restaura: $('[data-restaura]', raiz),
      tiles: $('[data-tiles]', raiz), prevEv: $('[data-prev-ev]', raiz), total: $('[data-total]', raiz), posibles: $('[data-posibles]', raiz),
      lineas: $('[data-lineas]', raiz), nota: $('[data-nota]', raiz), vivo: $('[data-vivo]', raiz),
    };
    const PISTA = 'Toca una casilla para elegir qué te avisamos y por dónde.';
    const S = { e: clona(op.estado), sel: EVENTOS[0].id, visto: null, anim: 0, aviso: 0, hover: 0, foco: [0, 0], cascada: 0 };
    const celdas = {};        // celdas[evento][canal] = botón
    const filas = {};         // filas[evento] = div
    const maestros = {};      // maestros[canal] = botón del interruptor de la columna
    const cuentas = {};       // cuentas[canal] = texto bajo el interruptor
    const cabCanal = {};
    const subs = {};
    const prevClave = {};

    /* ── armar la matriz ─────────────────────────────────────────────── */
    const cab = h('div', 'av-fila av-cab-fila');
    cab.append(h('div', 'av-esq', '<span>Qué te avisamos</span><i aria-hidden="true">por dónde →</i>'));
    CANALES.forEach(c => {
      const d = h('div', 'av-canal');
      d.dataset.canal = c.id; cabCanal[c.id] = d;
      d.innerHTML = '<span class="av-canal-ico">' + svg(c.id) + '</span><b class="av-canal-n">' + c.nombre + '</b>';
      const m = h('button', 'av-maestro', '<i></i>');
      m.type = 'button'; m.setAttribute('role', 'switch'); m.dataset.maestro = c.id;
      m.setAttribute('aria-label', 'Recibir avisos por ' + c.corto);
      m.addEventListener('click', () => canal(c.id, !S.e.canal[c.id]));
      maestros[c.id] = m;
      const n = h('span', 'av-canal-c'); cuentas[c.id] = n;
      d.append(m, n); cab.append(d);
    });
    el.matriz.append(cab);

    const grupos = [{ t: 'Importantes', imp: true }, { t: 'El resto', imp: false }];
    grupos.forEach(g => {
      el.matriz.append(h('div', 'av-grupo' + (g.imp ? ' av-grupo-imp' : ''), '<i aria-hidden="true"></i><span>' + g.t + '</span>'));
      EVENTOS.filter(ev => !!ev.imp === g.imp).forEach(ev => {
        const f = h('div', 'av-fila av-ev'); f.dataset.e = ev.id; filas[ev.id] = f; celdas[ev.id] = {};
        const nombre = h('div', 'av-nombre', '<span class="av-n">' + ev.nombre + '</span>');
        const sub = h('span', 'av-sub', ev.sub); subs[ev.id] = sub; nombre.append(sub);
        f.append(nombre);
        CANALES.forEach(c => {
          const caja = h('div', 'av-celda');
          if (aplica(ev, c.id)) {
            const b = h('button', 'av-c', '<svg viewBox="0 0 24 24" aria-hidden="true">' + ICO.ok + '</svg>');
            b.type = 'button'; b.setAttribute('role', 'switch'); b.dataset.e = ev.id; b.dataset.c = c.id;
            b.addEventListener('click', () => alterna(ev.id, c.id));
            celdas[ev.id][c.id] = b; caja.append(b);
          } else {
            caja.append(h('span', 'av-na', '<i aria-hidden="true"></i><span class="av-sr">No aplica: ' + ev.nombre + ' no se envía por ' + c.corto + '.</span>'));
            caja.title = ev.nombre + ' no se envía por ' + c.corto;
          }
          f.append(caja);
        });
        f.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') seleccionaLento(ev.id); });
        f.addEventListener('focusin', () => selecciona(ev.id));
        el.matriz.append(f);
      });
    });

    /* ── teclado: una sola parada de Tab y flechas entre casillas ─────── */
    function mapa() {
      const filasM = [CANALES.map(c => maestros[c.id])];
      EVENTOS.slice().sort((a, b) => (b.imp ? 1 : 0) - (a.imp ? 1 : 0)).forEach(ev => filasM.push(CANALES.map(c => celdas[ev.id][c.id] || null)));
      return filasM;
    }
    const M = mapa();
    function ponFoco(r, c) {
      S.foco = [r, c];
      M.forEach((fila, i) => fila.forEach((b, j) => { if (b) b.tabIndex = (i === r && j === c) ? 0 : -1; }));
    }
    ponFoco(1, 0);
    el.matriz.addEventListener('focusin', e => {
      M.forEach((fila, i) => fila.forEach((b, j) => { if (b === e.target) ponFoco(i, j); }));
    });
    el.matriz.addEventListener('keydown', e => {
      if (e.altKey || e.ctrlKey || e.metaKey) return;
      const [r, c] = S.foco;
      const libre = (i, j) => M[i] && M[i][j];
      let t = null;
      if (e.key === 'ArrowRight') { for (let j = c + 1; j < 3 && !t; j++) if (libre(r, j)) t = [r, j]; }
      else if (e.key === 'ArrowLeft') { for (let j = c - 1; j >= 0 && !t; j--) if (libre(r, j)) t = [r, j]; }
      else if (e.key === 'ArrowDown') { for (let i = r + 1; i < M.length && !t; i++) if (libre(i, c)) t = [i, c]; }
      else if (e.key === 'ArrowUp') { for (let i = r - 1; i >= 0 && !t; i--) if (libre(i, c)) t = [i, c]; }
      else if (e.key === 'Home') { for (let j = 0; j < 3 && !t; j++) if (libre(r, j)) t = [r, j]; }
      else if (e.key === 'End') { for (let j = 2; j >= 0 && !t; j--) if (libre(r, j)) t = [r, j]; }
      if (!t) return;
      e.preventDefault(); M[t[0]][t[1]].focus();
    });

    /* ── mensajes: un aviso breve que vuelve a la pista ───────────────── */
    /* Los avisos que piden atención se ven bajo la matriz y vuelven a la pista; los demás cambios solo se anuncian a quien usa lector. */
    function avisa(texto, tipo) {
      el.vivo.textContent = '';
      if (tipo !== 'alto') { setTimeout(() => { el.vivo.textContent = texto; }, 30); return; }
      el.aviso.textContent = texto; el.aviso.dataset.tipo = 'alto';
      clearTimeout(S.aviso);
      S.aviso = setTimeout(() => { el.aviso.textContent = PISTA; el.aviso.dataset.tipo = ''; }, 4200);
    }
    function parpadea(nodo, clase) {
      if (!nodo || quieto()) return;
      nodo.classList.remove(clase); void nodo.offsetWidth; nodo.classList.add(clase);
      setTimeout(() => nodo.classList.remove(clase), 800);
    }

    /* ── los cambios: todo pasa por aquí y se rechaza si deja la matriz inválida ── */
    function intenta(nuevo, tras) {
      const f = faltante(nuevo);
      if (f) { return f; }
      const antes = S.e;
      S.e = nuevo;
      pinta({ antes, cascada: !!(tras && tras.cascada) });
      if (op.alCambiar) op.alCambiar(clona(S.e));
      return null;
    }
    function alterna(evId, c) {
      const ev = evento(evId);
      if (!ev || !aplica(ev, c)) return false;
      const b = celdas[evId][c];
      selecciona(evId);
      const blq = bloqueo(S.e, ev, c);
      if (blq) {
        const quien = blq === 'dep' ? ev.requiere : c;
        parpadea(maestros[quien], 'av-pulso');
        avisa(blq === 'dep' ? ev.nombre + ' necesita ' + canalDe(quien).art + ': enciéndelo para recibirlo.' : canalDe(c).nombre + ' está apagado: enciéndelo arriba para elegir qué te llega por aquí.', 'alto');
        return false;
      }
      const nuevo = clona(S.e);
      nuevo.celda[evId][c] = !nuevo.celda[evId][c];
      const f = intenta(nuevo);
      if (f) {
        parpadea(b, 'av-sacude');
        avisa(f.nombre + ' necesita al menos un canal: deja uno encendido.', 'alto');
        return false;
      }
      avisa(ev.nombre + ' por ' + canalDe(c).corto + ': ' + (nuevo.celda[evId][c] ? 'activado' : 'apagado') + '.', '');
      return true;
    }
    function canal(c, on) {
      if (!!S.e.canal[c] === !!on) return true;
      const nuevo = clona(S.e);
      nuevo.canal[c] = !!on;
      const f = intenta(nuevo, { cascada: true });
      if (f) {
        parpadea(maestros[c], 'av-sacude');
        avisa(f.nombre + ' necesita al menos un canal: no puedes apagar ' + canalDe(c).art + ' ahora.', 'alto');
        return false;
      }
      const sin = EVENTOS.filter(ev => ev.requiere === c);
      avisa(on ? canalDe(c).nombre + ' encendido: vuelven tus casillas.' : canalDe(c).nombre + ' apagado' + (sin.length ? ': sin ' + canalDe(c).corto + ' no hay ' + sin.map(ev => ev.corto).join(' ni ') + '.' : '.'), on ? '' : 'alto');
      return true;
    }
    function solo() {
      const nuevo = soloImportante(S.e);
      if (igual(nuevo, S.e)) { avisa('Ya recibes solo lo importante.', ''); return; }
      intenta(nuevo, { cascada: true });
      avisa('Solo lo importante: apagamos lo demás y dejamos tus elecciones en los avisos que no pueden faltar.', '');
    }
    function restablece() {
      if (igual(S.e, op.estado)) return;
      intenta(clona(op.estado), { cascada: true });
      avisa('Todo volvió a como estaba al principio.', '');
    }
    el.solo.addEventListener('click', solo);
    el.restaura.addEventListener('click', () => { if (el.restaura.getAttribute('aria-disabled') !== 'true') restablece(); });

    /* ── la vista previa: cómo llega el aviso elegido por cada canal ──── */
    function selecciona(id) {
      clearTimeout(S.hover);
      if (S.sel === id) return;
      S.sel = id; pintaSel(); pintaPrev();
    }
    function seleccionaLento(id) {
      clearTimeout(S.hover);
      S.hover = setTimeout(() => selecciona(id), 190);
    }
    function pintaSel() {
      Object.keys(filas).forEach(id => { if (id === S.sel) filas[id].dataset.sel = ''; else delete filas[id].dataset.sel; });
    }
    function tileHTML(c, d) {
      if (c === 'correo') return '<div class="av-mail"><span class="av-mail-pt" aria-hidden="true"></span><div><div class="av-mail-top"><b>' + d.de + '</b><time>ahora</time></div><p class="av-mail-as">' + d.asunto + '</p><p class="av-mail-tx">' + d.texto + '</p></div></div>';
      if (c === 'mensaje') return '<div class="av-burbuja">' + d.texto + '</div>';
      return '<div class="av-toast"><span class="av-toast-ico" aria-hidden="true">' + svg('campana') + '</span><div><b>' + d.titulo + '</b><p>' + d.texto + '</p></div><time>ahora</time></div>';
    }
    function pintaPrev() {
      const ev = evento(S.sel);
      el.prevEv.textContent = ev.nombre;
      CANALES.forEach(c => {
        const tile = $('[data-tile="' + c.id + '"]', el.tiles), cuerpo = $('[data-cuerpo]', tile);
        const on = activo(S.e, ev, c.id);
        let clave, html;
        if (on) { clave = ev.id + ':on'; html = tileHTML(c.id, PREV[ev.id][c.id]); }
        else {
          const blq = aplica(ev, c.id) ? bloqueo(S.e, ev, c.id) : 'na';
          const motivo = blq === 'na' ? 'Este aviso no se envía por ' + c.corto + '.' : blq === 'canal' ? c.nombre + ' está apagado.' : blq === 'dep' ? 'Necesita ' + canalDe(ev.requiere).art + '.' : 'Apagado para este aviso.';
          clave = ev.id + ':off:' + blq;
          html = '<p class="av-vacio" data-t="' + (blq === 'canal' || blq === 'dep' ? 'bloq' : 'sin') + '">' + svg(blq === 'na' ? 'alto' : blq === 'canal' || blq === 'dep' ? 'candado' : 'apagado') + '<span>' + motivo + '</span></p>';
        }
        tile.dataset.on = on ? '1' : '0';
        if (prevClave[c.id] === clave) return;
        const primera = prevClave[c.id] === undefined;
        prevClave[c.id] = clave;
        cuerpo.innerHTML = html;
        if (!primera && !quieto() && cuerpo.animate) cuerpo.animate([{ opacity: 0, transform: 'translateY(7px)' }, { opacity: 1, transform: 'none' }], { duration: 340, easing: CURVA });
      });
    }

    /* ── el resumen: números que ruedan y líneas que se reescriben ────── */
    function rueda(a) {
      const id = ++S.anim, de = S.visto === null ? a : S.visto;
      if (quieto() || de === a) { S.visto = a; el.total.textContent = a; return; }
      let t0 = null;
      requestAnimationFrame(function paso(t) {
        if (id !== S.anim) return;
        if (t0 === null) t0 = t;
        const u = Math.min(1, (t - t0) / 520), e = 1 - Math.pow(1 - u, 3);
        S.visto = Math.round(de + (a - de) * e);
        el.total.textContent = S.visto;
        if (u < 1) requestAnimationFrame(paso);
      });
    }
    function pintaResumen() {
      const r = resumen(S.e);
      rueda(r.activos);
      el.total.setAttribute('aria-label', r.activos + ' de ' + r.posibles);
      el.posibles.textContent = r.posibles;
      const previos = $$('li', el.lineas);
      r.lineas.forEach((l, i) => {
        let li = previos[i];
        if (!li) { li = h('li'); el.lineas.append(li); }
        const html = '<span class="av-l-ico" aria-hidden="true">' + svg(l.canal) + '</span><p><b>' + l.rotulo + '</b> ' + l.texto + '</p>';
        if (li.dataset.h !== html) {
          const nuevo = li.dataset.h !== undefined;
          li.dataset.h = html; li.innerHTML = html; li.dataset.estado = l.estado;
          if (nuevo && !quieto() && li.animate) li.animate([{ opacity: .15, transform: 'translateX(-6px)' }, { opacity: 1, transform: 'none' }], { duration: 380, easing: CURVA });
        }
      });
      if (el.nota.textContent !== r.nota) {
        el.nota.textContent = r.nota;
        el.nota.dataset.tipo = (!S.e.canal.correo && r.nota) ? 'alto' : '';
        el.nota.hidden = !r.nota;
        if (r.nota && !quieto() && el.nota.animate) el.nota.animate([{ opacity: 0, transform: 'translateY(5px)' }, { opacity: 1, transform: 'none' }], { duration: 340, easing: CURVA });
      }
    }

    /* ── pintar todo desde el estado ───────────────────────────────────── */
    function pinta(o) {
      o = o || {};
      const cambian = [];
      let k = 0;
      EVENTOS.slice().sort((a, b) => (b.imp ? 1 : 0) - (a.imp ? 1 : 0)).forEach(ev => {
        const bloqFila = ev.requiere && !S.e.canal[ev.requiere];
        const sub = subs[ev.id];
        if (ev.requiere) {
          sub.innerHTML = bloqFila ? svg('candado') + 'Necesita ' + canalDe(ev.requiere).art : ev.sub;
          sub.dataset.tipo = bloqFila ? 'alto' : '';
        } else if (ev.minimo) { sub.innerHTML = svg('candado') + ev.sub; sub.dataset.tipo = 'regla'; }
        ev.canales.forEach(c => {
          const b = celdas[ev.id][c];
          const on = activo(S.e, ev, c), blq = bloqueo(S.e, ev, c);
          const antes = o.antes ? activo(o.antes, ev, c) : on;
          if (o.cascada && antes !== on) { cambian.push(b); b.style.setProperty('--d', (k++ * 55) + 'ms'); }
          b.setAttribute('aria-checked', on ? 'true' : 'false');
          b.setAttribute('aria-disabled', blq ? 'true' : 'false');
          if (blq) b.dataset.bloq = blq; else delete b.dataset.bloq;
          b.setAttribute('aria-label', ev.nombre + ' por ' + canalDe(c).corto + (blq === 'dep' ? ' (necesita ' + canalDe(ev.requiere).art + ')' : blq ? ' (' + canalDe(c).corto + ' apagado)' : ''));
        });
      });
      const cu = cuenta(S.e);
      CANALES.forEach(c => {
        const on = !!S.e.canal[c.id];
        maestros[c.id].setAttribute('aria-checked', on ? 'true' : 'false');
        cabCanal[c.id].dataset.on = on ? '1' : '0';
        cuentas[c.id].textContent = on ? cu.canal[c.id].activos + ' de ' + cu.canal[c.id].posibles : 'Apagado';
      });
      el.solo.setAttribute('aria-pressed', sinImportante(S.e) ? 'true' : 'false');
      el.restaura.setAttribute('aria-disabled', igual(S.e, op.estado) ? 'true' : 'false');
      pintaSel(); pintaPrev(); pintaResumen();
      if (cambian.length) {
        clearTimeout(S.cascada);
        S.cascada = setTimeout(() => cambian.forEach(b => b.style.removeProperty('--d')), 1200 + cambian.length * 55);
      }
    }

    el.aviso.textContent = PISTA;
    pinta();
    const api = {
      alterna, canal, soloImportante: solo, restaura: restablece, selecciona,
      estado: () => clona(S.e), resumen: () => resumen(S.e),
      pon: est => { const f = faltante(est); if (f) return false; const antes = S.e; S.e = clona(est); pinta({ antes }); return true; },
    };
    return api;
  }

  Avisador.nucleo = { activo, cuenta, resumen, soloImportante, faltante, bloqueo, igual, BASE, CANALES, EVENTOS };
  window.Avisador = Avisador;

  /* se inicia solo */
  $$('[data-avisador]').forEach(r => { r.__avisador = Avisador(r); window.__avisador = r.__avisador; });
})();
