/* =====================================================================
   Camilla · Moxen
   Una app de clínica dentro de un teléfono dibujado con un contenedor (no un marco). Las pantallas son HTML de verdad con
   navegación: especialidad → profesional → día y hora → datos del paciente → confirmación, con «Atrás» que conserva lo
   elegido (y lo que ya escribiste), «Mis citas» y un .ics de la cita con sus recordatorios.

   Lo que se calcula de verdad (no hay horas escritas a mano):
   · cada especialidad tiene su duración de consulta (`data-min`) y cada profesional su agenda: días, jornada, pausa y horas ya
     tomadas. Las horas de la cuadrícula salen de ahí y solo se pueden elegir las libres; las tomadas se ven apagadas;
   · «Cualquiera disponible» junta las agendas de la especialidad y asigna la hora al primer profesional que la tiene libre;
   · al confirmar, la cita ocupa esa agenda (la hora se apaga) y al cancelarla vuelve a quedar libre;
   · los datos del paciente se validan mientras escribes: nombre y apellido, una fecha de nacimiento que exista de verdad (con
     años bisiestos, sin ser futura), un teléfono con 8 a 15 dígitos, un correo con forma de correo y la autorización. Cada
     campo dice por qué falla, y «Confirmar» no avanza hasta que todos valen;
   · el .ics trae la cita (hora local, sin zona), su duración y un VALARM por cada aviso (−P1D y −PT1H).

   Montaje (se inicia solo sobre [data-camilla]; el HTML es la plantilla y las especialidades salen de sus data-min):
     const c = Camilla(document.querySelector('[data-camilla]'), {
       hoy: '2026-11-11',                // la fecha de hoy, AAAA-MM-DD (la pones tú)
       ahora: '09:40',                   // la hora de hoy: hoy no se ofrece nada antes de ahora + anticipación
       anticipacion: 30,                 // minutos mínimos entre ahora y la cita
       dias: 28,                         // cuántos días hacia adelante se pide hora
       carga: .5,                        // qué parte de la agenda de ejemplo ya está tomada (0 a 1)
       profesionales: [ { id, esp: 'general', dias: [0, 1, 2], jornada: ['09:00', '17:00'], pausa: ['13:00', '14:00'] } ],
       ocupado: (profId, fecha) => [[540, 560]],   // minutos del día ya tomados (si no, una agenda de ejemplo con azar con semilla)
       alConfirmar: cita => {},          // {id, esp, pro, fecha, ini, fin, paciente, motivo}: aquí va tu servidor
     });
     c.huecos('general', 'a', '2026-11-12');   c.estado();   c.reinicia();   Camilla.valida('correo', 'x@y.dev');

   `dias` de cada profesional: 0 = lunes … 6 = domingo. Las horas empiezan en la cuadrícula de la clínica (08:00 más múltiplos
   de la consulta), así que todos los profesionales de una especialidad comparten horarios. Teclado: Tab e Intro en todo,
   ← → entre los días, Intro pasa al campo siguiente, Esc para volver. Todo lo que se mueve es transform u opacity. No usa
   Date (la fecha es aritmética) y el azar de la agenda de ejemplo tiene semilla, así que la página y el vídeo muestran lo mismo.
   ===================================================================== */
(function () {
  'use strict';

  /* ── las fechas, a mano ───────────────────────────────────────────
     Cada día es un número entero (días desde el 1-1-1970): sin husos
     horarios que corran un día, y el «hoy» lo decides tú. */
  const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const DIAS = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
  const DIAS_C = ['lun', 'mar', 'mié', 'jue', 'vie', 'sáb', 'dom'];
  function diaSemana(a, m, d) {                       // Sakamoto, con la semana que empieza el lunes
    const t = [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4];
    if (m < 3) a -= 1;
    return ((a + Math.floor(a / 4) - Math.floor(a / 100) + Math.floor(a / 400) + t[m - 1] + d) % 7 + 6) % 7;
  }
  function aNumero(a, m, d) {                         // los «días civiles» de H. Hinnant
    a -= m <= 2 ? 1 : 0;
    const era = Math.floor(a / 400), ae = a - era * 400;
    const dia = Math.floor((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1;
    return era * 146097 + ae * 365 + Math.floor(ae / 4) - Math.floor(ae / 100) + dia - 719468;
  }
  function aFecha(n) {
    n += 719468;
    const era = Math.floor(n / 146097), de = n - era * 146097;
    const ae = Math.floor((de - Math.floor(de / 1460) + Math.floor(de / 36524) - Math.floor(de / 146096)) / 365);
    const da = de - (365 * ae + Math.floor(ae / 4) - Math.floor(ae / 100));
    const mp = Math.floor((5 * da + 2) / 153), m = mp < 10 ? mp + 3 : mp - 9;
    return { a: ae + era * 400 + (m <= 2 ? 1 : 0), m, d: da - Math.floor((153 * mp + 2) / 5) + 1 };
  }
  const dos = v => (v < 10 ? '0' : '') + v;
  const leeISO = s => { const p = String(s).split('-').map(Number); return aNumero(p[0], p[1], p[2]); };
  const aISO = n => { const f = aFecha(n); return f.a + '-' + dos(f.m) + '-' + dos(f.d); };
  const semanaDe = n => { const f = aFecha(n); return diaSemana(f.a, f.m, f.d); };
  const nombreDia = n => { const f = aFecha(n); return DIAS[semanaDe(n)] + ' ' + f.d + ' de ' + MESES[f.m - 1]; };
  const cortoDia = n => { const f = aFecha(n); return DIAS_C[semanaDe(n)] + ' ' + f.d; };
  const mayus = t => t.charAt(0).toUpperCase() + t.slice(1);

  // las horas son minutos desde la medianoche: 630 = 10:30
  const hm = m => dos(Math.floor(m / 60)) + ':' + dos(m % 60);
  const aMin = h => { const p = h.split(':').map(Number); return p[0] * 60 + p[1]; };

  function mulberry32(s) {                            // azar con semilla: la página y el vídeo coinciden
    return () => {
      s = s + 0x6D2B79F5 | 0;
      let t = Math.imul(s ^ s >>> 15, 1 | s);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  /* ── los profesionales de ejemplo ─────────────────────────────────
     Cada uno atiende una especialidad, unos días y una jornada: por eso Cardiología solo tiene un profesional y los martes
     y jueves. Los nombres son roles («Profesional A»), no personas. */
  const PROFESIONALES = [
    { id: 'a', esp: 'general', dias: [0, 1, 2, 3, 4], jornada: ['09:00', '17:00'], pausa: ['13:00', '14:00'] },
    { id: 'b', esp: 'general', dias: [1, 3, 4], jornada: ['10:00', '18:00'], pausa: ['14:00', '15:00'] },
    { id: 'c', esp: 'pediatria', dias: [0, 2, 4], jornada: ['09:00', '16:00'], pausa: ['13:00', '14:00'] },
    { id: 'd', esp: 'pediatria', dias: [1, 3], jornada: ['10:00', '18:00'] },
    { id: 'e', esp: 'cardiologia', dias: [1, 3], jornada: ['10:00', '17:00'], pausa: ['13:20', '14:40'] },
    { id: 'f', esp: 'dermatologia', dias: [0, 2, 3], jornada: ['11:00', '18:00'] },
    { id: 'g', esp: 'dermatologia', dias: [1, 4], jornada: ['09:00', '15:00'] },
    { id: 'h', esp: 'odontologia', dias: [0, 1, 2, 3, 4], jornada: ['08:00', '18:00'], pausa: ['12:30', '14:00'] },
    { id: 'i', esp: 'oftalmologia', dias: [1, 4], jornada: ['09:00', '15:00'] },
  ];
  const ORIGEN = 480;                                  // la cuadrícula de la clínica parte a las 08:00

  /* ── las reglas de los datos del paciente ─────────────────────────
     Cada regla devuelve el motivo del fallo o '' si el valor vale. Son funciones puras (se pueden probar sin la app). */
  const LETRAS = /^[\p{L}][\p{L}'’.\-]*$/u;
  const REGLAS = {
    nombre: v => {
      const t = v.trim().replace(/\s+/g, ' ');
      if (!t) return 'Escribe tu nombre y apellido.';
      const p = t.split(' ');
      if (!p.every(w => LETRAS.test(w))) return 'Usa solo letras en el nombre.';
      if (p.length < 2) return 'Falta el apellido.';
      if (!p.every(w => w.length >= 2)) return 'Cada palabra necesita al menos 2 letras.';
      return '';
    },
    nacimiento: (v, hoy) => {
      if (!v) return 'Escribe tu fecha de nacimiento.';
      const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(v);
      if (!m) return 'Usa el formato día/mes/año.';
      const d = +m[1], mes = +m[2], a = +m[3];
      if (mes < 1 || mes > 12) return 'El mes va de 01 a 12.';
      const n = aNumero(a, mes, d), f = aFecha(n);
      if (d < 1 || f.d !== d || f.m !== mes || f.a !== a) return 'Esa fecha no existe.';
      if (hoy !== undefined && n > hoy) return 'La fecha no puede ser futura.';
      if (hoy !== undefined && edad(a, mes, d, hoy) > 120) return 'Revisa el año de nacimiento.';
      return '';
    },
    telefono: v => {
      if (!v.trim()) return 'Escribe un teléfono para avisarte.';
      if (/[^\d\s()+\-]/.test(v)) return 'Usa solo números.';
      const n = v.replace(/\D/g, '').length;
      if (n < 8) return 'Faltan dígitos: son al menos 8.';
      if (n > 15) return 'Sobran dígitos: son 15 como máximo.';
      return '';
    },
    correo: v => {
      const t = v.trim();
      if (!t) return 'Escribe tu correo.';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@.]{2,}$/.test(t)) return 'Revisa el correo: falta la @ o el dominio.';
      return '';
    },
    consentimiento: ok => (ok ? '' : 'Necesitamos tu autorización para confirmar la cita.'),
  };
  // los años cumplidos a una fecha (n = día civil de «hoy»)
  function edad(a, m, d, n) {
    const h = aFecha(n);
    return h.a - a - (h.m < m || (h.m === m && h.d < d) ? 1 : 0);
  }
  // 14031990 → 14/03/1990 mientras se escribe
  const mascaraFecha = v => {
    const s = v.replace(/\D/g, '').slice(0, 8);
    return s.length > 4 ? s.slice(0, 2) + '/' + s.slice(2, 4) + '/' + s.slice(4) : s.length > 2 ? s.slice(0, 2) + '/' + s.slice(2) : s;
  };

  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  function Camilla(raiz, opciones) {
    const o = Object.assign({ hoy: '2026-01-05', ahora: '09:00', anticipacion: 30, dias: 28, carga: .5, profesionales: PROFESIONALES, ocupado: null, alConfirmar: null }, opciones);
    const HOY = leeISO(o.hoy), AHORA = aMin(o.ahora), ULTIMO = HOY + o.dias - 1;
    const $ = s => raiz.querySelector(s);
    const $$ = s => Array.from(raiz.querySelectorAll(s));
    const vistas = {};
    $$('[data-vista]').forEach(v => { vistas[v.dataset.vista] = v; });
    const titulo = $('[data-titulo]'), atras = $('[data-atras]'), mis = $('[data-mis]'), cuenta = $('[data-cuenta]');
    const pasos = $$('[data-pasos] li'), pie = $('[data-pie]'), cta = $('[data-cta]'), toast = $('[data-toast]');
    const listaPro = $('[data-lista-pro]'), diasCaja = $('[data-dias]'), horasCaja = $('[data-horas]');
    const mesTitulo = $('[data-mes]'), diaTitulo = $('[data-dia-titulo]'), diaSub = $('[data-dia-sub]');
    const resumen = $('[data-resumen]'), boleto = $('[data-boleto]'), listaMis = $('[data-lista-mis]'), vacio = $('[data-vacio]');
    const form = $('[data-form]'), consiente = $('[data-consentimiento]');

    // las especialidades salen del HTML: id, nombre, minutos e ícono
    const espec = {};
    $$('[data-especialidad]').forEach(b => {
      espec[b.dataset.especialidad] = { id: b.dataset.especialidad, nombre: b.dataset.nombre, min: +b.dataset.min, icono: b.querySelector('use').getAttribute('href'), info: b.querySelector('[data-info]') };
    });
    const profs = o.profesionales.map((p, i) => Object.assign({ idx: i, nombre: 'Profesional ' + p.id.toUpperCase() }, p));
    const profPor = id => profs.find(p => p.id === id);
    const deEsp = id => profs.filter(p => p.esp === id);
    Object.keys(espec).forEach(k => {
      const e = espec[k], n = deEsp(k).length;
      if (e.info) e.info.innerHTML = '<span>' + e.min + ' min por consulta</span><span>' + n + (n === 1 ? ' profesional' : ' profesionales') + '</span>';
    });

    /* ── la agenda ─────────────────────────────────────────────────── */
    const reservas = [];
    const solapa = (a, b, c, d) => a < d && c < b;
    // ¿esa hora ya estaba tomada de antes? (azar con semilla por profesional, día y hora; así la agenda no cambia entre cargas)
    function tomadaDeAntes(p, n, ini, fin) {
      if (o.ocupado) return o.ocupado(p.id, aISO(n)).some(b => solapa(ini, fin, b[0], b[1]));
      return mulberry32((p.idx + 3) * 7919 + n * 104729 + ini * 13)() < o.carga;
    }
    /* El corazón: los turnos de un profesional ese día. La cuadrícula parte a las 08:00 y avanza de a una consulta; un turno
       vale solo si cabe entero en la jornada, no toca la pausa y (hoy) queda después de ahora + anticipación. Está libre si
       nadie lo tomó antes ni lo reservamos aquí. */
    function turnos(p, n) {
      if (n < HOY || n > ULTIMO || p.dias.indexOf(semanaDe(n)) < 0) return [];
      const dur = espec[p.esp].min, ini = aMin(p.jornada[0]), fin = aMin(p.jornada[1]);
      const pausa = p.pausa ? [aMin(p.pausa[0]), aMin(p.pausa[1])] : null, salida = [];
      for (let t = ORIGEN + Math.ceil((ini - ORIGEN) / dur) * dur; t + dur <= fin; t += dur) {
        if (pausa && solapa(t, t + dur, pausa[0], pausa[1])) continue;
        if (n === HOY && t < AHORA + o.anticipacion) continue;
        const mia = reservas.some(r => r.pro === p.id && r.n === n && solapa(t, t + dur, r.ini, r.fin));
        salida.push({ ini: t, fin: t + dur, pro: p.id, libre: !mia && !tomadaDeAntes(p, n, t, t + dur) });
      }
      return salida;
    }
    // las horas de un día para el profesional elegido o, con «cualquiera», la unión: cada hora se asigna al primero que la tiene libre
    function huecos(espId, profId, iso) {
      const n = leeISO(iso), quienes = profId === 'any' ? deEsp(espId) : [profPor(profId)];
      const mapa = new Map();
      quienes.forEach(p => {
        if (!p || p.esp !== espId) return;
        turnos(p, n).forEach(t => { const ya = mapa.get(t.ini); if (!ya || (!ya.libre && t.libre)) mapa.set(t.ini, t); });
      });
      return Array.from(mapa.values()).sort((a, b) => a.ini - b.ini);
    }
    const huecosN = (espId, profId, n) => huecos(espId, profId, aISO(n));
    const libresN = (espId, profId, n) => huecosN(espId, profId, n).filter(h => h.libre);
    function proximo(espId, profId) {
      for (let n = HOY; n <= ULTIMO; n++) { const h = libresN(espId, profId, n); if (h.length) return { n, ini: h[0].ini }; }
      return null;
    }

    /* ── el estado de la app ───────────────────────────────────────── */
    const st = { esp: null, pro: null, n: null, hora: null, motivo: '' };
    const ORDEN = { especialidad: 0, profesional: 1, hora: 2, datos: 3, listo: 4, mis: 5 };
    let actual = 'especialidad', previa = 'especialidad', maximo = 0, ventana = HOY, ultima = null, contador = 5012, temporizador = 0, avisoT = 0;
    const TITULOS = { especialidad: 'Pide tu hora', profesional: 'Profesional', hora: 'Día y hora', datos: 'Tus datos', listo: 'Cita lista', mis: 'Mis citas' };
    const espActual = () => st.esp && espec[st.esp];

    // si cambia la especialidad, lo que se eligió después puede dejar de valer: se revisa y se descarta solo lo inválido
    function revalida() {
      const e = espActual();
      if (!e) return;
      if (st.pro && st.pro !== 'any' && profPor(st.pro).esp !== e.id) { st.pro = null; st.hora = null; }
      if (st.hora !== null) {
        const ok = st.pro && st.n !== null && libresN(e.id, st.pro, st.n).some(h => h.ini === st.hora);
        if (!ok) st.hora = null;
      }
    }
    const completo = i => (i === 0 ? !!st.esp : i === 1 ? !!st.pro : i === 2 ? st.hora !== null : false);
    // con «cualquiera», el profesional real de la hora elegida
    function proDeLaHora() {
      if (st.hora === null) return null;
      const h = libresN(st.esp, st.pro, st.n).find(x => x.ini === st.hora);
      return h ? h.pro : null;
    }

    /* ── navegar entre pantallas ───────────────────────────────────── */
    function ir(v, dir) {
      if (v === actual) return;
      const nueva = vistas[v], vieja = vistas[actual];
      if (dir === undefined) dir = ORDEN[v] >= ORDEN[actual] ? 1 : -1;
      if (v === 'mis') previa = actual;
      // la nueva espera a un lado sin transición y luego entra; la vieja sale hacia el otro
      nueva.style.transition = 'none';
      nueva.dataset.pos = dir > 0 ? 'der' : 'izq';
      void nueva.offsetWidth;
      nueva.style.transition = '';
      nueva.dataset.pos = 'activa'; nueva.inert = false;
      vieja.dataset.pos = dir > 0 ? 'izq' : 'der'; vieja.inert = true;
      nueva.classList.remove('is-entra'); void nueva.offsetWidth; nueva.classList.add('is-entra');
      nueva.scrollTop = 0;
      if (ORDEN[v] <= 3 && ORDEN[v] > maximo) maximo = ORDEN[v];
      actual = v;
      marco();
      const h = nueva.querySelector('.ca-h');
      if (h) h.focus({ preventScroll: true });
    }
    // la barra de arriba, los segmentos de progreso y el botón de abajo
    function marco() {
      const i = ORDEN[actual];
      const t = TITULOS[actual];
      if (titulo.textContent !== t) {
        titulo.textContent = t;
        titulo.classList.remove('is-cambia'); void titulo.offsetWidth; titulo.classList.add('is-cambia');
      }
      raiz.dataset.pantalla = actual;
      atras.hidden = !(i > 0 && actual !== 'listo');
      pasos.forEach((p, k) => { p.dataset.hecho = String(actual === 'mis' ? false : k <= Math.min(i, 3) || actual === 'listo'); });
      cuenta.textContent = reservas.length;
      mis.dataset.n = reservas.length;
      mis.setAttribute('aria-label', 'Mis citas (' + reservas.length + ')');
      // «Continuar» solo aparece al volver atrás: elegir ya avanza, así que no estorba la primera vez
      let texto = '', ver = false;
      if (i <= 2 && actual !== 'mis') { texto = 'Continuar'; ver = completo(i) && maximo > i; }
      if (actual === 'datos') { texto = 'Confirmar cita'; ver = true; }
      if (texto) cta.textContent = texto;
      pie.dataset.ver = ver ? '1' : '0';
      pie.inert = !ver;
    }
    // el botón de abajo: avanza a la pantalla que sigue (con lo ya elegido) o, en los datos, confirma
    function siguiente() {
      if (actual === 'datos') return confirma();
      if (actual === 'especialidad') { pintaProfesionales(); return ir('profesional', 1); }
      if (actual === 'profesional') { pintaHora(); return ir('hora', 1); }
      if (actual === 'hora') { pintaDatos(); return ir('datos', 1); }
    }
    function vuelve() {
      if (actual === 'mis') return ir(previa, -1);
      const i = ORDEN[actual];
      if (i > 0 && i < 4) ir(Object.keys(ORDEN)[i - 1], -1);
    }

    /* ── 1 · especialidad ──────────────────────────────────────────── */
    function eligeEspecialidad(id) {
      st.esp = id;
      $$('[data-especialidad]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.especialidad === id)));
      revalida();
      clearTimeout(temporizador);
      temporizador = setTimeout(() => { pintaProfesionales(); ir('profesional', 1); }, reduce ? 90 : 260);
    }

    /* ── 2 · profesional ───────────────────────────────────────────── */
    const rangoDias = d => {
      const out = [];
      for (let i = 0; i < d.length; i++) {
        let j = i;
        while (j + 1 < d.length && d[j + 1] === d[j] + 1) j++;
        out.push(j - i >= 2 ? DIAS_C[d[i]] + ' a ' + DIAS_C[d[j]] : d.slice(i, j + 1).map(x => DIAS_C[x]).join(', '));
        i = j;
      }
      return out.join(', ');
    };
    // «Hoy · 10:20» o «jue 12 · 11:00»: el próximo hueco libre de una agenda
    const textoProximo = (espId, profId) => {
      const p = proximo(espId, profId);
      return p ? (p.n === HOY ? '<i class="ca-punto"></i>Hoy · ' : 'Próxima hora: ' + cortoDia(p.n) + ' · ') + hm(p.ini) : 'Sin horas por ahora';
    };
    function pintaProfesionales() {
      const e = espActual();
      if (!e) return;
      const quienes = deEsp(e.id);
      const tarjeta = (id, nombre, avatar, linea, extra, i) =>
        '<li data-c style="--i:' + (i + 2) + '"><button type="button" class="ca-pro" data-pro="' + id + '" aria-pressed="' + (st.pro === id) + '">' +
        '<span class="ca-avatar" data-av="' + (id === 'any' ? 'any' : 'p' + (profPor(id).idx % 3)) + '">' + avatar + '</span>' +
        '<span class="ca-txt"><b>' + nombre + '</b><small>' + linea + '</small><em>' + extra + '</em></span>' +
        '<span class="ca-tilde" aria-hidden="true"><svg class="ca-i"><use href="#ca-i-tilde"/></svg></span></button></li>';
      let html = '';
      if (quienes.length > 1) html += tarjeta('any', 'Cualquiera disponible', '<svg class="ca-i" aria-hidden="true"><use href="#ca-i-cualquiera"/></svg>',
        'Quien tenga libre esa hora', textoProximo(e.id, 'any'), 0);
      quienes.forEach((p, i) => {
        html += tarjeta(p.id, p.nombre, p.id.toUpperCase(), mayus(rangoDias(p.dias)) + ' · ' + p.jornada[0] + ' a ' + p.jornada[1], textoProximo(e.id, p.id), i + 1);
      });
      listaPro.innerHTML = html;
      $('[data-sub-pro]').textContent = e.nombre + ': consultas de ' + e.min + ' min. Cada agenda muestra su próxima hora libre.';
    }
    function eligePro(id) {
      st.pro = id;
      $$('[data-pro]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.pro === id)));
      revalida();
      clearTimeout(temporizador);
      temporizador = setTimeout(() => { pintaHora(); ir('hora', 1); }, reduce ? 90 : 260);
    }

    /* ── 3 · día y hora ────────────────────────────────────────────── */
    function pintaHora(animar, fijo) {
      const e = espActual();
      if (!e || !st.pro) return;
      // sin día elegido (o el elegido ya no tiene horas): el primero con horas. Al cambiar de semana a mano (`fijo`) no se salta.
      if (!fijo && (st.n === null || !libresN(e.id, st.pro, st.n).length)) {
        const p = proximo(e.id, st.pro);
        st.n = p ? p.n : HOY;
      }
      if (!fijo && (st.n < ventana || st.n > ventana + 6)) ventana = Math.min(Math.max(HOY, st.n), ULTIMO - 6);
      const f0 = aFecha(ventana), f1 = aFecha(ventana + 6);
      mesTitulo.textContent = mayus(MESES[f0.m - 1]) + (f0.m !== f1.m ? ' – ' + mayus(MESES[f1.m - 1]) : '') + ' ' + f1.a;
      let html = '';
      for (let k = 0; k < 7; k++) {
        const n = ventana + k, libresDia = n <= ULTIMO ? libresN(e.id, st.pro, n).length : 0, f = aFecha(n);
        html += '<button type="button" class="ca-dia' + (n === HOY ? ' is-hoy' : '') + '" data-n="' + n + '" aria-pressed="' + (n === st.n) + '"' + (libresDia ? '' : ' disabled') +
          ' aria-label="' + nombreDia(n) + (libresDia ? ', ' + libresDia + ' horas libres' : ', sin horas') + '"><small>' + DIAS_C[semanaDe(n)] + '</small><b>' + f.d + '</b><i></i></button>';
      }
      diasCaja.innerHTML = html;
      $$('[data-semana]').forEach(b => { b.disabled = +b.dataset.semana < 0 ? ventana <= HOY : ventana + 7 > ULTIMO; });
      pintaHoras(animar);
    }
    function pintaHoras(animar) {
      const e = espActual(), lista = huecosN(e.id, st.pro, st.n), libres = lista.filter(h => h.libre).length;
      diaTitulo.textContent = mayus(nombreDia(st.n));
      diaSub.textContent = libres
        ? libres + (libres === 1 ? ' hora libre' : ' horas libres') + ' · consulta de ' + e.min + ' min'
        : 'Sin horas libres este día';
      const grupo = (t, arr, ini) => arr.length
        ? '<p class="ca-grupo">' + t + '</p><div class="ca-chips">' + arr.map((h, i) =>
          '<button type="button" class="ca-hora" data-ini="' + h.ini + '" aria-pressed="' + (h.libre && h.ini === st.hora) + '" style="--i:' + (ini + i) + '"' + (h.libre ? '' : ' disabled') +
          ' aria-label="' + hm(h.ini) + ' a ' + hm(h.fin) + (h.libre ? (st.pro === 'any' ? ', con ' + profPor(h.pro).nombre : '') : ', ya tomada') + '"><b>' + hm(h.ini) + '</b>' +
          (st.pro === 'any' && h.libre ? '<i class="ca-quien" aria-hidden="true">' + h.pro.toUpperCase() + '</i>' : '') + '</button>').join('') + '</div>'
        : '';
      const m = lista.filter(h => h.ini < 720), t = lista.filter(h => h.ini >= 720);
      horasCaja.innerHTML = lista.length ? grupo('Mañana', m, 0) + grupo('Tarde', t, m.length)
        : '<div class="ca-sin"><p>Este profesional no atiende ese día.</p><button type="button" class="ca-boton ca-boton-linea" data-siguiente>Ir a la próxima hora libre</button></div>';
      if (animar !== false) { horasCaja.classList.remove('is-entra'); void horasCaja.offsetWidth; horasCaja.classList.add('is-entra'); }
    }
    function eligeDia(n) {
      if (n !== st.n) st.hora = null;                   // la hora elegida era de otro día
      st.n = n;
      $$('.ca-dia').forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.n === n)));
      pintaHoras();
    }
    function eligeHora(ini) {
      st.hora = ini;
      $$('.ca-hora').forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.ini === ini)));
      clearTimeout(temporizador);
      temporizador = setTimeout(() => { pintaDatos(); ir('datos', 1); }, reduce ? 90 : 260);
    }
    function mueveSemana(k) {
      ventana = Math.max(HOY, Math.min(ULTIMO - 6, ventana + 7 * k));
      const e = espActual();
      // el día elegido pasa al primer día con horas de la semana nueva, para que la lista nunca quede vacía sin avisar
      st.n = ventana;
      for (let j = 0; j < 7; j++) if (libresN(e.id, st.pro, ventana + j).length) { st.n = ventana + j; break; }
      st.hora = null;
      pintaHora(true, true);
    }

    /* ── 4 · datos del paciente ────────────────────────────────────── */
    function tarjetaCita(r, extra) {
      const e = espec[r.esp], p = profPor(r.pro), f = aFecha(r.n);
      return '<div class="ca-tk-cab"><span class="ca-ico"><svg class="ca-i" aria-hidden="true"><use href="' + e.icono + '"/></svg></span>' +
        '<span class="ca-txt"><b>' + e.nombre + '</b><small>' + e.min + ' min · ' + p.nombre + '</small></span></div>' +
        '<div class="ca-tk-cuerpo"><div class="ca-tk-datos"><div><small>Día</small><b>' + mayus(DIAS_C[semanaDe(r.n)]) + ' ' + f.d + '</b><span>' + MESES[f.m - 1] + '</span></div>' +
        '<div><small>Hora</small><b>' + hm(r.ini) + '</b><span>hasta ' + hm(r.fin) + '</span></div></div>' + (extra || '') + '</div>';
    }
    function pintaDatos() {
      const e = espActual(), pid = proDeLaHora();
      if (!e || !pid) return;
      const f = aFecha(st.n);
      resumen.innerHTML = '<span class="ca-txt"><b>' + mayus(DIAS_C[semanaDe(st.n)]) + ' ' + f.d + ' ' + MESES[f.m - 1].slice(0, 3) + ' · ' + hm(st.hora) + '</b><small>' + e.nombre + ' · ' + profPor(pid).nombre + '</small></span>' +
        '<button type="button" class="ca-cambiar" data-cambiar>Cambiar</button>';
    }

    const campos = {};
    $$('[data-form] [data-campo]').forEach(c => { if (REGLAS[c.dataset.campo]) campos[c.dataset.campo] = { el: c, input: c.querySelector('input'), error: c.querySelector('[data-error]'), tocado: false }; });
    const valorDe = k => (k === 'consentimiento' ? consiente.checked : campos[k].input.value);
    const motivoFalla = k => (k === 'nacimiento' ? REGLAS.nacimiento(valorDe(k), HOY) : REGLAS[k](valorDe(k)));
    // el estado visible de un campo: ✓ en cuanto vale; el motivo solo después de salir de él (o de intentar confirmar)
    function pintaCampo(k) {
      const c = campos[k], falla = motivoFalla(k), lleno = k === 'consentimiento' ? consiente.checked : c.input.value.trim() !== '';
      const estado = !falla && lleno ? 'ok' : falla && c.tocado ? 'error' : '';
      c.el.dataset.estado = estado;
      c.error.textContent = estado === 'error' ? falla : '';
      if (c.input) c.input.setAttribute('aria-invalid', String(estado === 'error'));
      if (k === 'nacimiento' && !falla && lleno) {
        const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(c.input.value);
        const años = edad(+m[3], +m[2], +m[1], HOY);
        if (años < 18) { c.error.textContent = 'Es menor de edad: debe venir con una persona adulta.'; c.el.dataset.estado = 'aviso'; }
      }
    }
    Object.keys(campos).forEach(k => {
      const c = campos[k];
      if (!c.input) return;
      c.input.addEventListener('input', () => {
        if (k === 'nacimiento') c.input.value = mascaraFecha(c.input.value);
        pintaCampo(k);
      });
      c.input.addEventListener('blur', () => { c.tocado = true; pintaCampo(k); });
      c.input.addEventListener('keydown', e => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        const orden = ['nombre', 'nacimiento', 'telefono', 'correo'], i = orden.indexOf(k);
        if (k === 'consentimiento') return confirma();
        (i < orden.length - 1 ? campos[orden[i + 1]].input : consiente).focus();
      });
    });
    consiente.addEventListener('change', () => { campos.consentimiento.tocado = true; pintaCampo('consentimiento'); });
    $$('.ca-ficha').forEach(b => b.addEventListener('click', () => {
      const ya = b.getAttribute('aria-checked') === 'true';
      st.motivo = ya ? '' : b.dataset.motivo;
      $$('.ca-ficha').forEach(x => x.setAttribute('aria-checked', String(!ya && x === b)));
    }));
    // los campos que no valen, en orden de pantalla
    const invalidos = () => Object.keys(campos).filter(k => motivoFalla(k));

    /* ── 5 · confirmar ─────────────────────────────────────────────── */
    function confirma() {
      const e = espActual(), pid = proDeLaHora();
      if (!e || !pid) return;
      const malos = invalidos();
      if (malos.length) {                                // no se avanza: se marcan todos y el foco va al primero
        Object.keys(campos).forEach(k => { campos[k].tocado = true; pintaCampo(k); });
        const c = campos[malos[0]];
        (c.input || consiente).focus({ preventScroll: false });
        cta.classList.remove('is-sacude'); void cta.offsetWidth; cta.classList.add('is-sacude');
        avisa(malos.length === 1 ? 'Revisa 1 campo antes de confirmar' : 'Revisa ' + malos.length + ' campos antes de confirmar');
        return;
      }
      const paciente = { nombre: campos.nombre.input.value.trim().replace(/\s+/g, ' '), nacimiento: campos.nacimiento.input.value, telefono: campos.telefono.input.value.trim(), correo: campos.correo.input.value.trim() };
      const r = { id: 'C' + (++contador), esp: e.id, pro: pid, n: st.n, fecha: aISO(st.n), ini: st.hora, fin: st.hora + e.min, paciente, motivo: st.motivo };
      reservas.push(r);
      ultima = r;
      boleto.innerHTML = tarjetaCita(r, '<dl class="ca-tk-paciente"><div><dt>Paciente</dt><dd>' + paciente.nombre + '</dd></div>' + (r.motivo ? '<div><dt>Motivo</dt><dd>' + r.motivo + '</dd></div>' : '') + '</dl>' +
        '<p class="ca-tk-pie"><span>Cita N.º ' + r.id.slice(1) + '</span><span>Llega 10 min antes</span></p>');
      pintaMis();
      ir('listo', 1);
      if (o.alConfirmar) o.alConfirmar(r);
    }

    /* ── el .ics: la cita y un VALARM por cada aviso ───────────────── */
    const esc = t => String(t).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
    const pliega = l => {                                   // las líneas del .ics se parten a los 75 octetos
      const sal = [];
      while (l.length > 70) { sal.push(l.slice(0, 70)); l = ' ' + l.slice(70); }
      sal.push(l);
      return sal.join('\r\n');
    };
    function icsDe(r) {
      const dia = r.fecha.replace(/-/g, ''), t = m => dia + 'T' + dos(Math.floor(m / 60)) + dos(m % 60) + '00';
      const e = espec[r.esp], p = profPor(r.pro);
      const l = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Camilla//ES', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'BEGIN:VEVENT',
        'UID:' + dia + 't' + hm(r.ini).replace(':', '') + '-' + r.pro + '@camilla.local',
        'DTSTAMP:' + o.hoy.replace(/-/g, '') + 'T' + hm(AHORA).replace(':', '') + '00Z',
        'DTSTART:' + t(r.ini), 'DTEND:' + t(r.fin),                                   // hora local, sin zona: cae a la hora de la clínica
        'SUMMARY:' + esc(e.nombre + ' · ' + p.nombre),
        'DESCRIPTION:' + esc('Cita N.º ' + r.id.slice(1) + '. ' + e.nombre + ' (' + e.min + ' min) con ' + p.nombre + '. Llega 10 minutos antes.'),
        'LOCATION:' + esc('Clínica'),
        'BEGIN:VALARM', 'TRIGGER:-P1D', 'ACTION:DISPLAY', 'DESCRIPTION:' + esc('Mañana: ' + e.nombre), 'END:VALARM',
        'BEGIN:VALARM', 'TRIGGER:-PT1H', 'ACTION:DISPLAY', 'DESCRIPTION:' + esc('En 1 hora: ' + e.nombre), 'END:VALARM',
        'END:VEVENT', 'END:VCALENDAR'];
      return l.map(pliega).join('\r\n') + '\r\n';
    }
    function descarga(r) {
      if (!r) return;
      const url = URL.createObjectURL(new Blob([icsDe(r)], { type: 'text/calendar' }));
      const a = document.createElement('a');
      a.href = url; a.download = 'cita-' + r.fecha + '-' + hm(r.ini).replace(':', '') + '.ics';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      avisa('Cita lista para tu calendario');
    }

    /* ── 6 · mis citas ─────────────────────────────────────────────── */
    function pintaMis() {
      const orden = reservas.slice().sort((a, b) => a.n - b.n || a.ini - b.ini);
      listaMis.innerHTML = orden.map((r, i) => '<li class="ca-tk" data-c style="--i:' + (i + 1) + '" data-id="' + r.id + '">' + tarjetaCita(r,
        '<div class="ca-tk-acc"><button type="button" class="ca-mini" data-agrega="' + r.id + '"><svg class="ca-i" aria-hidden="true"><use href="#ca-i-agregar"/></svg>Calendario</button>' +
        '<button type="button" class="ca-mini ca-mini-peligro" data-cancela="' + r.id + '"><svg class="ca-i" aria-hidden="true"><use href="#ca-i-basura"/></svg>Cancelar</button></div>') + '</li>').join('');
      vacio.hidden = reservas.length > 0;
      cuenta.textContent = reservas.length;
      mis.dataset.n = reservas.length;
    }
    function cancela(id) {
      const k = reservas.findIndex(r => r.id === id);
      if (k < 0) return;
      reservas.splice(k, 1);
      pintaMis();
      marco();
      avisa('Cita cancelada: la hora queda libre');
    }

    function avisa(texto) {
      toast.textContent = texto;
      toast.dataset.ver = '1';
      clearTimeout(avisoT);
      avisoT = setTimeout(() => { toast.dataset.ver = '0'; }, 2400);
    }
    function reinicia() {
      st.esp = st.pro = st.n = st.hora = null; st.motivo = '';
      ventana = HOY; maximo = 0;
      $$('[data-especialidad]').forEach(b => b.setAttribute('aria-pressed', 'false'));
      form.reset();
      $$('.ca-ficha').forEach(x => x.setAttribute('aria-checked', 'false'));
      Object.keys(campos).forEach(k => { campos[k].tocado = false; pintaCampo(k); });
      ir('especialidad', -1);
    }

    /* ── ratón, dedo y teclado ─────────────────────────────────────── */
    raiz.addEventListener('click', e => {
      const t = e.target.closest('button, [data-especialidad]');
      if (!t || t.disabled) return;
      if (t.dataset.especialidad) return eligeEspecialidad(t.dataset.especialidad);
      if (t.dataset.pro) return eligePro(t.dataset.pro);
      if (t.classList.contains('ca-dia')) return eligeDia(+t.dataset.n);
      if (t.classList.contains('ca-hora')) return eligeHora(+t.dataset.ini);
      if (t.dataset.semana) return mueveSemana(+t.dataset.semana);
      if ('siguiente' in t.dataset) { const p = proximo(st.esp, st.pro); if (p) { st.n = p.n; pintaHora(); } return; }
      if ('cambiar' in t.dataset) return ir('hora', -1);
      if ('atras' in t.dataset) return vuelve();
      if ('mis' in t.dataset) return actual === 'mis' ? vuelve() : ir('mis', 1);
      if ('cta' in t.dataset) return siguiente();
      if ('ics' in t.dataset) return descarga(ultima);
      if ('verMis' in t.dataset) return ir('mis', 1);
      if ('otra' in t.dataset) return reinicia();
      if (t.dataset.agrega) return descarga(reservas.find(r => r.id === t.dataset.agrega));
      if (t.dataset.cancela) return cancela(t.dataset.cancela);
    });
    raiz.addEventListener('keydown', e => {
      if (e.key === 'Escape' && !atras.hidden) { e.preventDefault(); vuelve(); return; }
      const d = e.target.closest && e.target.closest('.ca-dia');
      if (d && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
        const bs = Array.from(diasCaja.querySelectorAll('.ca-dia:not(:disabled)')), i = bs.indexOf(d), sig = bs[i + (e.key === 'ArrowRight' ? 1 : -1)];
        if (sig) { e.preventDefault(); sig.focus(); }
      }
    });

    /* ── arranque ─────────────────────────────────────────────────── */
    Object.keys(vistas).forEach(k => { vistas[k].dataset.pos = k === 'especialidad' ? 'activa' : 'der'; vistas[k].inert = k !== 'especialidad'; });
    vistas.especialidad.classList.add('is-entra');
    // una cita ya tomada, para que «Mis citas» no empiece vacía y esa hora ya esté ocupada en su agenda
    reservas.push({ id: 'C5012', esp: 'oftalmologia', pro: 'i', n: HOY + 2, fecha: aISO(HOY + 2), ini: 630, fin: 660, paciente: { nombre: 'Paciente de ejemplo' }, motivo: '' });
    pintaMis();
    Object.keys(campos).forEach(k => pintaCampo(k));
    marco();

    return {
      huecos, ocupado: (profId, iso) => turnos(profPor(profId), leeISO(iso)).filter(t => !t.libre).map(t => [t.ini, t.fin]),
      estado: () => ({ vista: actual, especialidad: st.esp, pro: st.pro, fecha: st.n === null ? null : aISO(st.n), hora: st.hora === null ? null : hm(st.hora), citas: reservas.length, invalidos: invalidos() }),
      ics: id => icsDe(reservas.find(r => r.id === id) || ultima),
      citas: () => reservas.map(r => Object.assign({}, r)),
      reinicia,
    };
  }

  // las reglas se pueden usar sueltas: Camilla.valida('correo', 'a@b.dev') → '' si vale, o el motivo
  Camilla.valida = (campo, valor, hoy) => (campo === 'nacimiento' ? REGLAS.nacimiento(valor, hoy === undefined ? undefined : leeISO(hoy)) : REGLAS[campo](valor));
  window.Camilla = Camilla;
})();
